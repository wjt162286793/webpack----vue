const server = require('./server/index')
server()