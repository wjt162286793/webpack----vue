"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_components_globalList_vue"],{

/***/ 41216:
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".listContent {\n  height: 100%;\n  position: relative;\n  padding: 10px;\n}\n.listContent .searchbox {\n  display: flex;\n}\n.listContent .searchbox .searchItem {\n  width: 240px;\n  margin: 0 20px 0 0px;\n}\n.listContent .searchbox .searchBtn {\n  margin-right: 10px;\n  margin-bottom: 20px;\n}\n.listContent .pagination {\n  height: 30px;\n  position: absolute;\n  bottom: 20px;\n  right: 0px;\n  margin-right: 30px;\n}\n.jumpIn {\n  color: #79bbff;\n  cursor: pointer;\n}\n.jumpOut {\n  color: #79bbff;\n  cursor: pointer;\n}\n", "",{"version":3,"sources":["webpack://./src/components/globalList.vue","webpack://./globalList.vue"],"names":[],"mappings":"AACA;EACE,YAAA;EACA,kBAAA;EAEA,aAAA;ACDF;ADHA;EAOI,aAAA;ACDJ;ADNA;EAUM,YAAA;EACA,oBAAA;ACDN;ADVA;EAeM,kBAAA;EACA,mBAAA;ACFN;ADdA;EAoBI,YAAA;EACA,kBAAA;EACA,YAAA;EACA,UAAA;EACA,kBAAA;ACHJ;ADMA;EACE,cAAA;EACA,eAAA;ACJF;ADMA;EACE,cAAA;EACA,eAAA;ACJF","sourcesContent":["\n.listContent {\n  height: 100%;\n  position: relative;\n  // margin-bottom: 50px;\n  padding: 10px;\n\n  .searchbox {\n    display: flex;\n\n    .searchItem {\n      width: 240px;\n      margin: 0 20px 0 0px;\n    }\n\n    .searchBtn {\n      margin-right: 10px;\n      margin-bottom: 20px;\n    }\n  }\n  .pagination {\n    height: 30px;\n    position: absolute;\n    bottom: 20px;\n    right: 0px;\n    margin-right: 30px;\n  }\n}\n.jumpIn {\n  color: #79bbff;\n  cursor: pointer;\n}\n.jumpOut {\n  color: #79bbff;\n  cursor: pointer;\n}\n",".listContent {\n  height: 100%;\n  position: relative;\n  padding: 10px;\n}\n.listContent .searchbox {\n  display: flex;\n}\n.listContent .searchbox .searchItem {\n  width: 240px;\n  margin: 0 20px 0 0px;\n}\n.listContent .searchbox .searchBtn {\n  margin-right: 10px;\n  margin-bottom: 20px;\n}\n.listContent .pagination {\n  height: 30px;\n  position: absolute;\n  bottom: 20px;\n  right: 0px;\n  margin-right: 30px;\n}\n.jumpIn {\n  color: #79bbff;\n  cursor: pointer;\n}\n.jumpOut {\n  color: #79bbff;\n  cursor: pointer;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 98994:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalList.vue?vue&type=script&setup=true&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 53059);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var _components_creatRisk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/creatRisk */ 55473);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/dictionaries/wordList.json */ 59950);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/store */ 28360);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue */ 62494);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'globalList',
  props: {
    modeType: Object
  },
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var props = __props;
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_7__.useRoute)();
    var multipleTableRef = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(null);
    var creatRisk = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(null);
    var templateData = (0,vue__WEBPACK_IMPORTED_MODULE_6__.reactive)({});
    var dialogDeleteVisible = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(false);
    var deleteText = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)("");
    var delRow = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)({});
    var reqTemplate = function reqTemplate() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/template"), {
        name: props.modeType.type
      }).then(function (res) {
        templateData.searchTemplate = res.data.searchTemplate;
        templateData.searchData = res.data.searchData;
        templateData.tableTemplate = res.data.tableTemplate;
        reqList();
      });
    };
    var tableData = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)([]);
    var total = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(0);
    var pageSize = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(10);
    var currentPage = (0,vue__WEBPACK_IMPORTED_MODULE_6__.ref)(1);
    var handleSelectionChange = function handleSelectionChange(val) {};
    var reqListFun = function reqListFun() {
      var postData = {};
      postData.searchData = templateData.searchData;
      postData.currentPage = currentPage.value;
      postData.pageSize = pageSize.value;
      postData.modeType = props.modeType.type;
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/list"), postData).then(function (res) {
        if (res.code === 200) {
          tableData.value = res.data.list;
          total.value = res.data.total;
        }
      });
    };
    var openRisk = function openRisk(record) {
      creatRisk.value.openDialog(record);
    };
    var reqList = lodash__WEBPACK_IMPORTED_MODULE_1___default().throttle(reqListFun, 2000);
    //查询列表
    //外部跳转
    var jumpUrl = function jumpUrl(url) {
      window.open("http://".concat(url));
    };
    //按钮事件
    var btnClick = function btnClick(btnFlag) {
      switch (btnFlag) {
        case "search":
          reqList();
          break;
        case "toAdd":
          toAdd();
      }
    };
    //新增
    var toAdd = function toAdd() {
      console.log("新增");
      console.log(props.modeType.list);
      router.push({
        name: props.modeType.add,
        query: {
          type: "new",
          mode: props.modeType.type
        }
      });
    };
    //查看
    var jumpDetail = function jumpDetail(row) {
      console.log("查看");
      console.log(_store__WEBPACK_IMPORTED_MODULE_5__["default"].state, "路由");
      router.push({
        name: props.modeType.detail,
        query: {
          uuid: row.uuid,
          type: "detail",
          mode: props.modeType.type
        }
      });
    };
    //修改
    var editRow = function editRow(row) {
      router.push({
        name: props.modeType.edit,
        query: {
          uuid: row.uuid,
          type: "edit",
          mode: props.modeType.type
        }
      });
    };
    function deleteDialogOpen(row) {
      delRow.value = row;
      deleteText.value = "\u786E\u5B9A\u8981\u5220\u9664".concat(row[props.modeType.type + "Name"], "\u8FD9\u6761\u8D44\u4EA7\u5417");
      dialogDeleteVisible.value = true;
    }
    //删除
    var deleteRow = function deleteRow() {
      console.log(delRow.value, "删除");
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/delete"), {
        uuid: delRow.value.uuid,
        mode: props.modeType.type
      }).then(function (res) {
        if (res.code === 200) {
          (0,element_plus__WEBPACK_IMPORTED_MODULE_8__.ElMessage)({
            type: "success",
            message: "删除成功"
          });
          dialogDeleteVisible.value = false;
          reqList();
        }
      });
    };
    //从词表里获取对应值
    var getMap = function getMap(property, value) {
      var val = _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_4__[route.name][property][value];
      return val;
    };
    var getTimeRange = function getTimeRange(property, value) {
      var str = "".concat(value[0], "  \u81F3  ").concat(value[1]);
      return str;
    };
    var addRiskSuccess = function addRiskSuccess() {
      reqList();
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_6__.onMounted)(function () {
      reqTemplate();
    });
    var __returned__ = {
      props: props,
      router: router,
      route: route,
      get multipleTableRef() {
        return multipleTableRef;
      },
      set multipleTableRef(v) {
        multipleTableRef = v;
      },
      creatRisk: creatRisk,
      get templateData() {
        return templateData;
      },
      set templateData(v) {
        templateData = v;
      },
      get dialogDeleteVisible() {
        return dialogDeleteVisible;
      },
      set dialogDeleteVisible(v) {
        dialogDeleteVisible = v;
      },
      get deleteText() {
        return deleteText;
      },
      set deleteText(v) {
        deleteText = v;
      },
      get delRow() {
        return delRow;
      },
      set delRow(v) {
        delRow = v;
      },
      get reqTemplate() {
        return reqTemplate;
      },
      set reqTemplate(v) {
        reqTemplate = v;
      },
      tableData: tableData,
      total: total,
      get pageSize() {
        return pageSize;
      },
      set pageSize(v) {
        pageSize = v;
      },
      get currentPage() {
        return currentPage;
      },
      set currentPage(v) {
        currentPage = v;
      },
      handleSelectionChange: handleSelectionChange,
      reqListFun: reqListFun,
      openRisk: openRisk,
      reqList: reqList,
      jumpUrl: jumpUrl,
      btnClick: btnClick,
      toAdd: toAdd,
      jumpDetail: jumpDetail,
      editRow: editRow,
      deleteDialogOpen: deleteDialogOpen,
      deleteRow: deleteRow,
      getMap: getMap,
      getTimeRange: getTimeRange,
      addRiskSuccess: addRiskSuccess,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get lodash() {
        return (lodash__WEBPACK_IMPORTED_MODULE_1___default());
      },
      get Delete() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__.Delete;
      },
      get Edit() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__.Edit;
      },
      get WarnTriangleFilled() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__.WarnTriangleFilled;
      },
      get CreatRisk() {
        return _components_creatRisk__WEBPACK_IMPORTED_MODULE_2__["default"];
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"];
      },
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_7__.useRouter;
      },
      get useRoute() {
        return vue_router__WEBPACK_IMPORTED_MODULE_7__.useRoute;
      },
      get words() {
        return _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_4__;
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_8__.ElMessage;
      },
      get store() {
        return _store__WEBPACK_IMPORTED_MODULE_5__["default"];
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 82017:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalList.vue?vue&type=template&id=36bc9471 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _hoisted_1 = {
  "class": "listContent"
};
var _hoisted_2 = {
  "class": "searchbox"
};
var _hoisted_3 = {
  key: 0
};
var _hoisted_4 = {
  key: 1
};
var _hoisted_5 = {
  key: 2,
  "class": "searchBtn"
};
var _hoisted_6 = {
  "class": "tableBox"
};
var _hoisted_7 = ["onClick"];
var _hoisted_8 = {
  "class": "pagination"
};
var _hoisted_9 = {
  "class": "dialog-footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_table_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table-column");
  var _component_el_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table");
  var _component_el_pagination = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-pagination");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.templateData.searchTemplate, function (item, index) {
    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      key: index
    }, [item.type === 'input' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <span>{{ item.label }}:</span> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
      modelValue: $setup.templateData.searchData[item.name],
      "onUpdate:modelValue": function onUpdateModelValue($event) {
        return $setup.templateData.searchData[item.name] = $event;
      },
      "class": "searchItem",
      clearable: "",
      onChange: $setup.reqList,
      placeholder: item.placeholder
    }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "onChange", "placeholder"])])) : item.type === 'select' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <span>{{ item.label }}:</span> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
      "class": "searchItem",
      modelValue: $setup.templateData.searchData[item.name],
      "onUpdate:modelValue": function onUpdateModelValue($event) {
        return $setup.templateData.searchData[item.name] = $event;
      },
      placeholder: item.placeholder,
      clearable: "",
      onChange: $setup.reqList
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item.options, function (val, ind) {
          return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
            key: ind,
            label: val.label,
            value: val.value
          }, null, 8 /* PROPS */, ["label", "value"]);
        }), 128 /* KEYED_FRAGMENT */))];
      }),

      _: 2 /* DYNAMIC */
    }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue", "placeholder", "onChange"])])) : item.type === 'button' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
      type: item.btnType,
      onClick: function onClick($event) {
        return $setup.btnClick(item.event);
      }
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.text), 1 /* TEXT */)];
      }),

      _: 2 /* DYNAMIC */
    }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["type", "onClick"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 64 /* STABLE_FRAGMENT */);
  }), 128 /* KEYED_FRAGMENT */))]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table, {
    border: true,
    ref: "multipleTableRef",
    data: $setup.tableData,
    style: {
      "width": "100%"
    },
    onSelectionChange: $setup.handleSelectionChange
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <el-table-column type=\"selection\" width=\"55\" />\r\n                <el-table-column label=\"Date\" width=\"120\">\r\n                    <template #default=\"scope\">{{ scope.row.date }}</template>\r\n                </el-table-column>\r\n                <el-table-column property=\"name\" label=\"Name\" width=\"120\" />\r\n                <el-table-column property=\"address\" label=\"Address\" show-overflow-tooltip /> "), ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.templateData.tableTemplate, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
          key: index
        }, [item.column === 'normal' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 0,
          property: item.property,
          width: item.width,
          label: item.label,
          sortable: item.sortable || false
        }, null, 8 /* PROPS */, ["property", "width", "label", "sortable"])) : item.column === 'jumpIn' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 1,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <p class=\"jumpIn\">{{ scope.row[item.property] }}</p> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
              link: "",
              type: "primary"
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row[item.property]), 1 /* TEXT */)];
              }),

              _: 2 /* DYNAMIC */
            }, 1024 /* DYNAMIC_SLOTS */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"])) : item.column === 'details' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 2,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <p class=\"jumpIn\" @click=\"jumpDetail(scope.row)\">\r\n                {{ scope.row[item.property] }}\r\n              </p> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
              link: "",
              type: "primary",
              onClick: function onClick($event) {
                return $setup.jumpDetail(scope.row);
              }
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row[item.property]), 1 /* TEXT */)];
              }),

              _: 2 /* DYNAMIC */
            }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])];
          }),
          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"])) : item.column === 'map' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 3,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getMap(item.property, scope.row[item.property])), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"])) : item.column === 'timeRange' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 4,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getTimeRange(item.property, scope.row[item.property])), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"])) : item.column === 'jumpOut' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 5,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
              "class": "jumpOut",
              onClick: function onClick($event) {
                return $setup.jumpUrl(scope.row[item.property]);
              }
            }, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row[item.property]), 9 /* TEXT, PROPS */, _hoisted_7)];
          }),
          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"])) : ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_table_column, {
          key: 6,
          width: item.width,
          label: item.label
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row[item.property]), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["width", "label"]))], 64 /* STABLE_FRAGMENT */);
      }), 128 /* KEYED_FRAGMENT */)), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        width: 240,
        label: "操作",
        fixed: "right"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" {{scope.row[item.property]}} "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            link: "",
            onClick: function onClick($event) {
              return $setup.editRow(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 编辑 ")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "danger",
            link: "",
            onClick: function onClick($event) {
              return $setup.deleteDialogOpen(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("删除")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "warning",
            link: "",
            onClick: function onClick($event) {
              return $setup.openRisk(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("标记风险")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_8, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_pagination, {
    small: "",
    background: "",
    layout: "prev, pager, next, jumper, ->, total",
    total: $setup.total,
    "class": "mt-4",
    "page-size": $setup.pageSize,
    "onUpdate:pageSize": _cache[0] || (_cache[0] = function ($event) {
      return $setup.pageSize = $event;
    }),
    "current-page": $setup.currentPage,
    "onUpdate:currentPage": _cache[1] || (_cache[1] = function ($event) {
      return $setup.currentPage = $event;
    }),
    onSizeChange: $setup.reqList,
    onCurrentChange: $setup.reqList,
    onPrevClick: $setup.reqList,
    onNextClick: $setup.reqList
  }, {
    "pager-text": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "共 " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.total) + " 条数据", 1 /* TEXT */)];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["total", "page-size", "current-page", "onSizeChange", "onCurrentChange", "onPrevClick", "onNextClick"])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_dialog, {
    modelValue: $setup.dialogDeleteVisible,
    "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
      return $setup.dialogDeleteVisible = $event;
    }),
    title: "删除",
    width: "25%"
  }, {
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        type: "primary",
        onClick: $setup.deleteRow
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("确定")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: _cache[2] || (_cache[2] = function ($event) {
          return $setup.dialogDeleteVisible = false;
        })
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      })])];
    }),

    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.deleteText), 1 /* TEXT */)];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["CreatRisk"], {
    ref: "creatRisk",
    onAddRiskSuccess: $setup.addRiskSuccess
  }, null, 512 /* NEED_PATCH */)], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 95854:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less */ 41216);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 37818:
/*!***************************************!*\
  !*** ./src/components/globalList.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _globalList_vue_vue_type_template_id_36bc9471__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./globalList.vue?vue&type=template&id=36bc9471 */ 659);
/* harmony import */ var _globalList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globalList.vue?vue&type=script&setup=true&lang=js */ 55202);
/* harmony import */ var _globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less */ 9363);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_globalList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_globalList_vue_vue_type_template_id_36bc9471__WEBPACK_IMPORTED_MODULE_0__.render],['__file',"src/components/globalList.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 55202:
/*!**************************************************************************!*\
  !*** ./src/components/globalList.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalList.vue?vue&type=script&setup=true&lang=js */ 98994);
 

/***/ }),

/***/ 659:
/*!*********************************************************************!*\
  !*** ./src/components/globalList.vue?vue&type=template&id=36bc9471 ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalList_vue_vue_type_template_id_36bc9471__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalList_vue_vue_type_template_id_36bc9471__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalList.vue?vue&type=template&id=36bc9471 */ 82017);


/***/ }),

/***/ 9363:
/*!************************************************************************************!*\
  !*** ./src/components/globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalList_vue_vue_type_style_index_0_id_36bc9471_lang_less__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/style-loader/dist/cjs.js!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalList.vue?vue&type=style&index=0&id=36bc9471&lang=less */ 95854);


/***/ }),

/***/ 59950:
/*!****************************************!*\
  !*** ./src/dictionaries/wordList.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"entiryList":{"entiryType":{"kind":"实物资产","mechanical":"机械设备","individual":"个体资产","information":"IT资产"},"region":{"important":"重要资产","affiliate":"附属资产","noGlobal":"非公共资产","risk":"风险资产"}},"typeList":{"business":"业务领域","entiry":"实体","task":"任务","valueflow":"价值流"}}');

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2NvbXBvbmVudHNfZ2xvYmFsTGlzdF92dWUuYjlmMjAyMWNhM2VhZjIwNWQzMDguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUM2RztBQUNqQjtBQUM1Riw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0Esd0RBQXdELGlCQUFpQix1QkFBdUIsa0JBQWtCLEdBQUcsMkJBQTJCLGtCQUFrQixHQUFHLHVDQUF1QyxpQkFBaUIseUJBQXlCLEdBQUcsc0NBQXNDLHVCQUF1Qix3QkFBd0IsR0FBRyw0QkFBNEIsaUJBQWlCLHVCQUF1QixpQkFBaUIsZUFBZSx1QkFBdUIsR0FBRyxXQUFXLG1CQUFtQixvQkFBb0IsR0FBRyxZQUFZLG1CQUFtQixvQkFBb0IsR0FBRyxTQUFTLDZIQUE2SCxVQUFVLFdBQVcsVUFBVSxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssVUFBVSxXQUFXLEtBQUssS0FBSyxXQUFXLFdBQVcsS0FBSyxLQUFLLFdBQVcsV0FBVyxVQUFVLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSyxVQUFVLFVBQVUseUNBQXlDLGlCQUFpQix1QkFBdUIsMkJBQTJCLGtCQUFrQixrQkFBa0Isb0JBQW9CLHFCQUFxQixxQkFBcUIsNkJBQTZCLE9BQU8sb0JBQW9CLDJCQUEyQiw0QkFBNEIsT0FBTyxLQUFLLGlCQUFpQixtQkFBbUIseUJBQXlCLG1CQUFtQixpQkFBaUIseUJBQXlCLEtBQUssR0FBRyxXQUFXLG1CQUFtQixvQkFBb0IsR0FBRyxZQUFZLG1CQUFtQixvQkFBb0IsR0FBRyxtQkFBbUIsaUJBQWlCLHVCQUF1QixrQkFBa0IsR0FBRywyQkFBMkIsa0JBQWtCLEdBQUcsdUNBQXVDLGlCQUFpQix5QkFBeUIsR0FBRyxzQ0FBc0MsdUJBQXVCLHdCQUF3QixHQUFHLDRCQUE0QixpQkFBaUIsdUJBQXVCLGlCQUFpQixlQUFlLHVCQUF1QixHQUFHLFdBQVcsbUJBQW1CLG9CQUFvQixHQUFHLFlBQVksbUJBQW1CLG9CQUFvQixHQUFHLHFCQUFxQjtBQUM3Z0U7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQUTtBQUNuQjtBQUMrQztBQUM1QjtBQUNKO0FBQ007QUFDQTtBQUNSO0FBQ2I7OztBQUM1QixpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIscURBQVM7QUFDMUIsZ0JBQWdCLG9EQUFRO0FBQ3hCLDJCQUEyQix3Q0FBRztBQUM5QixvQkFBb0Isd0NBQUc7QUFDdkIsdUJBQXVCLDZDQUFRO0FBQy9CLDhCQUE4Qix3Q0FBRztBQUNqQyxxQkFBcUIsd0NBQUc7QUFDeEIsaUJBQWlCLHdDQUFHO0FBQ3BCO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkIsZ0JBQWdCLHdDQUFHO0FBQ25CLG1CQUFtQix3Q0FBRztBQUN0QixzQkFBc0Isd0NBQUc7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLGdFQUFZLFdBQVcsK0RBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHNEQUFlO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixvREFBVztBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sZ0VBQVksV0FBVywrREFBYztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsdURBQVM7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isd0RBQUs7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4Q0FBUztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsd0RBQU87QUFDdEI7QUFDQTtBQUNBLGVBQWUsK0NBQU07QUFDckI7QUFDQTtBQUNBLGVBQWUsMkRBQU07QUFDckI7QUFDQTtBQUNBLGVBQWUseURBQUk7QUFDbkI7QUFDQTtBQUNBLGVBQWUsdUVBQWtCO0FBQ2pDO0FBQ0E7QUFDQSxlQUFlLDZEQUFTO0FBQ3hCO0FBQ0E7QUFDQSxlQUFlLDJEQUFPO0FBQ3RCO0FBQ0E7QUFDQSxlQUFlLGlEQUFTO0FBQ3hCO0FBQ0E7QUFDQSxlQUFlLGdEQUFRO0FBQ3ZCO0FBQ0E7QUFDQSxlQUFlLHdEQUFLO0FBQ3BCO0FBQ0E7QUFDQSxlQUFlLG1EQUFTO0FBQ3hCO0FBQ0E7QUFDQSxlQUFlLDhDQUFLO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztFQ2pRTSxTQUFNO0FBQWE7O0VBQ2pCLFNBQU07QUFBVzs7Ozs7Ozs7O0VBZ0NzQixTQUFNOzs7RUFPN0MsU0FBTTtBQUFVOzs7RUF1R2hCLFNBQU07QUFBWTs7RUF1QmYsU0FBTTtBQUFlOzs7Ozs7Ozs7O3FLQXRLL0JBLHVEQUFBLENBa0tNLE9BbEtOQyxVQWtLTSxHQWpLSkQsdURBQUEsQ0FzQ00sT0F0Q05FLFVBc0NNLDBEQXJDSkMsdURBQUEsQ0FvQ1dDLHlDQUFBLFFBQUFDLCtDQUFBLENBbkNlQyxNQUFBLENBQUFDLFlBQVksQ0FBQ0MsY0FBYyxZQUEzQ0MsSUFBSSxFQUFFQyxLQUFLOztXQUNiQTtJQUFLLElBRUFELElBQUksQ0FBQ0UsSUFBSSxrRUFBcEJSLHVEQUFBLENBU00sT0FBQVMsVUFBQSxHQVJKQyx1REFBQSxvQ0FBdUMsRUFDdkNDLGdEQUFBLENBTVlDLG1CQUFBO2tCQUxEVCxNQUFBLENBQUFDLFlBQVksQ0FBQ1MsVUFBVSxDQUFDUCxJQUFJLENBQUNRLElBQUk7O2VBQWpDWCxNQUFBLENBQUFDLFlBQVksQ0FBQ1MsVUFBVSxDQUFDUCxJQUFJLENBQUNRLElBQUksSUFBQUMsTUFBQTtNQUFBO01BQzFDLFNBQU0sWUFBWTtNQUNsQkMsU0FBUyxFQUFULEVBQVM7TUFDUkMsUUFBTSxFQUFFZCxNQUFBLENBQUFlLE9BQU87TUFDZkMsV0FBVyxFQUFFYixJQUFJLENBQUNhO21HQUdQYixJQUFJLENBQUNFLElBQUksbUVBQXpCUix1REFBQSxDQWdCTSxPQUFBb0IsVUFBQSxHQWZKVix1REFBQSxvQ0FBdUMsRUFDdkNDLGdEQUFBLENBYVlVLG9CQUFBO01BWlYsU0FBTSxZQUFZO2tCQUNUbEIsTUFBQSxDQUFBQyxZQUFZLENBQUNTLFVBQVUsQ0FBQ1AsSUFBSSxDQUFDUSxJQUFJOztlQUFqQ1gsTUFBQSxDQUFBQyxZQUFZLENBQUNTLFVBQVUsQ0FBQ1AsSUFBSSxDQUFDUSxJQUFJLElBQUFDLE1BQUE7TUFBQTtNQUN6Q0ksV0FBVyxFQUFFYixJQUFJLENBQUNhLFdBQVc7TUFDOUJILFNBQVMsRUFBVCxFQUFTO01BQ1JDLFFBQU0sRUFBRWQsTUFBQSxDQUFBZTs7OERBR1A7UUFBQSxPQUFrQyx3REFEcENsQix1REFBQSxDQUthQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUpVSSxJQUFJLENBQUNnQixPQUFPLFlBQXpCQyxHQUFHLEVBQUVDLEdBQUc7bUVBRGxCQyxnREFBQSxDQUthQyxvQkFBQTtZQUhWQyxHQUFHLEVBQUVILEdBQUc7WUFDUkksS0FBSyxFQUFFTCxHQUFHLENBQUNLLEtBQUs7WUFDaEJDLEtBQUssRUFBRU4sR0FBRyxDQUFDTTs7Ozs7OytHQUlGdkIsSUFBSSxDQUFDRSxJQUFJLG1FQUF6QlIsdURBQUEsQ0FJTSxPQUpOOEIsVUFJTSxHQUhKbkIsZ0RBQUEsQ0FFY29CLG9CQUFBO01BRkZ2QixJQUFJLEVBQUVGLElBQUksQ0FBQzBCLE9BQU87TUFBR0MsT0FBSyxXQUFBQSxRQUFBbEIsTUFBQTtRQUFBLE9BQUVaLE1BQUEsQ0FBQStCLFFBQVEsQ0FBQzVCLElBQUksQ0FBQzZCLEtBQUs7TUFBQTs7OERBQUc7UUFBQSxPQUU1RCwyR0FEQTdCLElBQUksQ0FBQzhCLElBQUk7Ozs7O29DQUtqQnZDLHVEQUFBLENBc0dNLE9BdEdOd0MsVUFzR00sR0FyR0oxQixnREFBQSxDQW9HVzJCLG1CQUFBO0lBbkdSQyxNQUFNLEVBQUUsSUFBSTtJQUNiQyxHQUFHLEVBQUMsa0JBQWtCO0lBQ3JCQyxJQUFJLEVBQUV0QyxNQUFBLENBQUF1QyxTQUFTO0lBQ2hCQyxLQUFtQixFQUFuQjtNQUFBO0lBQUEsQ0FBbUI7SUFDbEJDLGlCQUFnQixFQUFFekMsTUFBQSxDQUFBMEM7OzREQUVuQjtNQUFBLE9BS3dGLENBTHhGbkMsdURBQUEsK2FBS3dGLHlEQUN4RlYsdURBQUEsQ0F1RVdDLHlDQUFBLFFBQUFDLCtDQUFBLENBdEVlQyxNQUFBLENBQUFDLFlBQVksQ0FBQzBDLGFBQWEsWUFBMUN4QyxJQUFJLEVBQUVDLEtBQUs7O2VBQ2JBO1FBQUssSUFHSEQsSUFBSSxDQUFDeUMsTUFBTSxtRUFEbkJ0QixnREFBQSxDQU1tQnVCLDBCQUFBOztVQUpoQkMsUUFBUSxFQUFFM0MsSUFBSSxDQUFDMkMsUUFBUTtVQUN2QkMsS0FBSyxFQUFFNUMsSUFBSSxDQUFDNEMsS0FBSztVQUNqQnRCLEtBQUssRUFBRXRCLElBQUksQ0FBQ3NCLEtBQUs7VUFDakJ1QixRQUFRLEVBQUU3QyxJQUFJLENBQUM2QyxRQUFROytFQUdiN0MsSUFBSSxDQUFDeUMsTUFBTSxtRUFEeEJ0QixnREFBQSxDQVdrQnVCLDBCQUFBOztVQVRmRSxLQUFLLEVBQUU1QyxJQUFJLENBQUM0QyxLQUFLO1VBQ2pCdEIsS0FBSyxFQUFFdEIsSUFBSSxDQUFDc0I7O1VBRUYsV0FBT3dCLDRDQUFBLENBQ2hCLFVBRGtCQyxLQUFLO1lBQUEsUUFDdkIzQyx1REFBQSw0REFBNkQsRUFDN0RDLGdEQUFBLENBRWNvQixvQkFBQTtjQUZIdUIsSUFBSSxFQUFKLEVBQUk7Y0FBQzlDLElBQUksRUFBQzs7c0VBQVU7Z0JBQUEsT0FFN0IsMkdBREE2QyxLQUFLLENBQUNFLEdBQUcsQ0FBQ2pELElBQUksQ0FBQzJDLFFBQVE7Ozs7Ozs7O21FQUtoQjNDLElBQUksQ0FBQ3lDLE1BQU0sb0VBRHhCdEIsZ0RBQUEsQ0Fha0J1QiwwQkFBQTs7VUFYZkUsS0FBSyxFQUFFNUMsSUFBSSxDQUFDNEMsS0FBSztVQUNqQnRCLEtBQUssRUFBRXRCLElBQUksQ0FBQ3NCOztVQUVGLFdBQU93Qiw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztZQUFBLFFBQ3ZCM0MsdURBQUEsbUlBRVEsRUFDUkMsZ0RBQUEsQ0FFY29CLG9CQUFBO2NBRkh1QixJQUFJLEVBQUosRUFBSTtjQUFDOUMsSUFBSSxFQUFDLFNBQVM7Y0FBRXlCLE9BQUssV0FBQUEsUUFBQWxCLE1BQUE7Z0JBQUEsT0FBRVosTUFBQSxDQUFBcUQsVUFBVSxDQUFDSCxLQUFLLENBQUNFLEdBQUc7Y0FBQTs7c0VBQUc7Z0JBQUEsT0FFNUQsMkdBREFGLEtBQUssQ0FBQ0UsR0FBRyxDQUFDakQsSUFBSSxDQUFDMkMsUUFBUTs7Ozs7OzttRUFLaEIzQyxJQUFJLENBQUN5QyxNQUFNLGdFQUR4QnRCLGdEQUFBLENBUWtCdUIsMEJBQUE7O1VBTmZFLEtBQUssRUFBRTVDLElBQUksQ0FBQzRDLEtBQUs7VUFDakJ0QixLQUFLLEVBQUV0QixJQUFJLENBQUNzQjs7VUFFRixXQUFPd0IsNENBQUEsQ0FDaEIsVUFEa0JDLEtBQUs7WUFBQSxRQUN2QnhELHVEQUFBLENBQTRELFdBQUE0RCxvREFBQSxDQUF0RHRELE1BQUEsQ0FBQXVELE1BQU0sQ0FBQ3BELElBQUksQ0FBQzJDLFFBQVEsRUFBRUksS0FBSyxDQUFDRSxHQUFHLENBQUNqRCxJQUFJLENBQUMyQyxRQUFROzs7O21FQUkxQzNDLElBQUksQ0FBQ3lDLE1BQU0sc0VBRHhCdEIsZ0RBQUEsQ0FRa0J1QiwwQkFBQTs7VUFOZkUsS0FBSyxFQUFFNUMsSUFBSSxDQUFDNEMsS0FBSztVQUNqQnRCLEtBQUssRUFBRXRCLElBQUksQ0FBQ3NCOztVQUVGLFdBQU93Qiw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztZQUFBLFFBQ3ZCeEQsdURBQUEsQ0FBa0UsV0FBQTRELG9EQUFBLENBQTVEdEQsTUFBQSxDQUFBd0QsWUFBWSxDQUFDckQsSUFBSSxDQUFDMkMsUUFBUSxFQUFFSSxLQUFLLENBQUNFLEdBQUcsQ0FBQ2pELElBQUksQ0FBQzJDLFFBQVE7Ozs7bUVBSWhEM0MsSUFBSSxDQUFDeUMsTUFBTSxvRUFEeEJ0QixnREFBQSxDQVVrQnVCLDBCQUFBOztVQVJmRSxLQUFLLEVBQUU1QyxJQUFJLENBQUM0QyxLQUFLO1VBQ2pCdEIsS0FBSyxFQUFFdEIsSUFBSSxDQUFDc0I7O1VBRUYsV0FBT3dCLDRDQUFBLENBQ2hCLFVBRGtCQyxLQUFLO1lBQUEsUUFDdkJ4RCx1REFBQSxDQUVJO2NBRkQsU0FBTSxTQUFTO2NBQUVvQyxPQUFLLFdBQUFBLFFBQUFsQixNQUFBO2dCQUFBLE9BQUVaLE1BQUEsQ0FBQXlELE9BQU8sQ0FBQ1AsS0FBSyxDQUFDRSxHQUFHLENBQUNqRCxJQUFJLENBQUMyQyxRQUFRO2NBQUE7b0VBQ3JESSxLQUFLLENBQUNFLEdBQUcsQ0FBQ2pELElBQUksQ0FBQzJDLFFBQVEseUJBQUFZLFVBQUE7OztzSEFJaENwQyxnREFBQSxDQUlrQnVCLDBCQUFBOztVQUpPRSxLQUFLLEVBQUU1QyxJQUFJLENBQUM0QyxLQUFLO1VBQUd0QixLQUFLLEVBQUV0QixJQUFJLENBQUNzQjs7VUFDNUMsV0FBT3dCLDRDQUFBLENBQ2hCLFVBRGtCQyxLQUFLO1lBQUEsa0hBQ3BCQSxLQUFLLENBQUNFLEdBQUcsQ0FBQ2pELElBQUksQ0FBQzJDLFFBQVE7Ozs7O3NDQUloQ3RDLGdEQUFBLENBY2tCcUMsMEJBQUE7UUFkQUUsS0FBSyxFQUFFLEdBQUc7UUFBRXRCLEtBQUssRUFBQyxJQUFJO1FBQUNrQyxLQUFLLEVBQUM7O1FBQ2xDLFdBQU9WLDRDQUFBLENBQ2hCLFVBRGtCQyxLQUFLO1VBQUEsUUFDdkIzQyx1REFBQSxrQ0FBcUMsRUFDckNDLGdEQUFBLENBRVlvQixvQkFBQTtZQUZEdkIsSUFBSSxFQUFDLFNBQVM7WUFBQzhDLElBQUksRUFBSixFQUFJO1lBQUVyQixPQUFLLFdBQUFBLFFBQUFsQixNQUFBO2NBQUEsT0FBRVosTUFBQSxDQUFBNEQsT0FBTyxDQUFDVixLQUFLLENBQUNFLEdBQUc7WUFBQTs7b0VBQUc7Y0FBQSxPQUUzRCxzREFGMkQsTUFFM0Q7Ozs0REFFQTVDLGdEQUFBLENBRUNvQixvQkFBQTtZQUZVdkIsSUFBSSxFQUFDLFFBQVE7WUFBQzhDLElBQUksRUFBSixFQUFJO1lBQUVyQixPQUFLLFdBQUFBLFFBQUFsQixNQUFBO2NBQUEsT0FBRVosTUFBQSxDQUFBNkQsZ0JBQWdCLENBQUNYLEtBQUssQ0FBQ0UsR0FBRztZQUFBOztvRUFDN0Q7Y0FBQSxPQUFFLHNEQUFGLElBQUU7Ozs0REFFTDVDLGdEQUFBLENBRUNvQixvQkFBQTtZQUZVdkIsSUFBSSxFQUFDLFNBQVM7WUFBQzhDLElBQUksRUFBSixFQUFJO1lBQUVyQixPQUFLLFdBQUFBLFFBQUFsQixNQUFBO2NBQUEsT0FBRVosTUFBQSxDQUFBOEQsUUFBUSxDQUFDWixLQUFLLENBQUNFLEdBQUc7WUFBQTs7b0VBQ3REO2NBQUEsT0FBSSxzREFBSixNQUFJOzs7Ozs7Ozs7O2lDQU1mMUQsdURBQUEsQ0FrQk0sT0FsQk5xRSxVQWtCTSxHQWpCSnZELGdEQUFBLENBZ0JnQndELHdCQUFBO0lBZmRDLEtBQUssRUFBTCxFQUFLO0lBQ0xDLFVBQVUsRUFBVixFQUFVO0lBQ1ZDLE1BQU0sRUFBQyxzQ0FBc0M7SUFDNUNDLEtBQUssRUFBRXBFLE1BQUEsQ0FBQW9FLEtBQUs7SUFDYixTQUFNLE1BQU07SUFDSixXQUFTLEVBQUVwRSxNQUFBLENBQUFxRSxRQUFROzthQUFSckUsTUFBQSxDQUFBcUUsUUFBUSxHQUFBekQsTUFBQTtJQUFBO0lBQ25CLGNBQVksRUFBRVosTUFBQSxDQUFBc0UsV0FBVzs7YUFBWHRFLE1BQUEsQ0FBQXNFLFdBQVcsR0FBQTFELE1BQUE7SUFBQTtJQUNoQzJELFlBQVcsRUFBRXZFLE1BQUEsQ0FBQWUsT0FBTztJQUNwQnlELGVBQWMsRUFBRXhFLE1BQUEsQ0FBQWUsT0FBTztJQUN2QjBELFdBQVUsRUFBRXpFLE1BQUEsQ0FBQWUsT0FBTztJQUNuQjJELFdBQVUsRUFBRTFFLE1BQUEsQ0FBQWU7O0lBRUYsWUFBVSxFQUFBa0MsNENBQUEsQ0FDbkI7TUFBQSxPQUE4QixDQUE5QnZELHVEQUFBLENBQThCLGNBQXhCLElBQUUsR0FBQTRELG9EQUFBLENBQUd0RCxNQUFBLENBQUFvRSxLQUFLLElBQUcsTUFBSTs7OztrSUFLL0I1RCxnREFBQSxDQVFZbUUsb0JBQUE7Z0JBUlEzRSxNQUFBLENBQUE0RSxtQkFBbUI7O2FBQW5CNUUsTUFBQSxDQUFBNEUsbUJBQW1CLEdBQUFoRSxNQUFBO0lBQUE7SUFBRWlFLEtBQUssRUFBQyxJQUFJO0lBQUM5QixLQUFLLEVBQUM7O0lBRTdDK0IsTUFBTSxFQUFBN0IsNENBQUEsQ0FDZjtNQUFBLE9BR08sQ0FIUHZELHVEQUFBLENBR08sUUFIUHFGLFVBR08sR0FGTHZFLGdEQUFBLENBQTJEb0Isb0JBQUE7UUFBaER2QixJQUFJLEVBQUMsU0FBUztRQUFFeUIsT0FBSyxFQUFFOUIsTUFBQSxDQUFBZ0Y7O2dFQUFXO1VBQUEsT0FBRSxzREFBRixJQUFFOzs7VUFDL0N4RSxnREFBQSxDQUE4RG9CLG9CQUFBO1FBQWxERSxPQUFLLEVBQUFtRCxNQUFBLFFBQUFBLE1BQUEsZ0JBQUFyRSxNQUFBO1VBQUEsT0FBRVosTUFBQSxDQUFBNEUsbUJBQW1CO1FBQUE7O2dFQUFVO1VBQUEsT0FBRSxzREFBRixJQUFFOzs7Ozs7NERBSnREO01BQUEsT0FBNkIsQ0FBN0JsRix1REFBQSxDQUE2QixjQUFBNEQsb0RBQUEsQ0FBcEJ0RCxNQUFBLENBQUFrRixVQUFVOzs7O3FDQVFyQjFFLGdEQUFBLENBQXdFUixNQUFBO0lBQTdEcUMsR0FBRyxFQUFDLFdBQVc7SUFBRThDLGdCQUFjLEVBQUVuRixNQUFBLENBQUFvRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUs5QyxNQUFrRztBQUNsRyxNQUF3RjtBQUN4RixNQUErRjtBQUMvRixNQUFrSDtBQUNsSCxNQUEyRztBQUMzRyxNQUEyRztBQUMzRyxNQUFrVTtBQUNsVTtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDRSQUFPOzs7O0FBSTRRO0FBQ3BTLE9BQU8saUVBQWUsNFJBQU8sSUFBSSxtU0FBYyxHQUFHLG1TQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCTjtBQUNDO0FBQ0w7O0FBRW5FLENBQXNFOztBQUU0QztBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQywwRkFBTSxhQUFhLGlGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7OztBQ3hCOFYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbExpc3QudnVlP2IzZGIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxMaXN0LnZ1ZT8yOThjIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL2NvbXBvbmVudHMvZ2xvYmFsTGlzdC52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxMaXN0LnZ1ZT84ODEzIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL2NvbXBvbmVudHMvZ2xvYmFsTGlzdC52dWU/MjNlMyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbExpc3QudnVlP2Q0NWMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxMaXN0LnZ1ZT8zZWU1Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL2NvbXBvbmVudHMvZ2xvYmFsTGlzdC52dWU/YmQxMiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5saXN0Q29udGVudCB7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBwYWRkaW5nOiAxMHB4O1xcbn1cXG4ubGlzdENvbnRlbnQgLnNlYXJjaGJveCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbn1cXG4ubGlzdENvbnRlbnQgLnNlYXJjaGJveCAuc2VhcmNoSXRlbSB7XFxuICB3aWR0aDogMjQwcHg7XFxuICBtYXJnaW46IDAgMjBweCAwIDBweDtcXG59XFxuLmxpc3RDb250ZW50IC5zZWFyY2hib3ggLnNlYXJjaEJ0biB7XFxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XFxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xcbn1cXG4ubGlzdENvbnRlbnQgLnBhZ2luYXRpb24ge1xcbiAgaGVpZ2h0OiAzMHB4O1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgYm90dG9tOiAyMHB4O1xcbiAgcmlnaHQ6IDBweDtcXG4gIG1hcmdpbi1yaWdodDogMzBweDtcXG59XFxuLmp1bXBJbiB7XFxuICBjb2xvcjogIzc5YmJmZjtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmp1bXBPdXQge1xcbiAgY29sb3I6ICM3OWJiZmY7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9jb21wb25lbnRzL2dsb2JhbExpc3QudnVlXCIsXCJ3ZWJwYWNrOi8vLi9nbG9iYWxMaXN0LnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtFQUVBLGFBQUE7QUNERjtBREhBO0VBT0ksYUFBQTtBQ0RKO0FETkE7RUFVTSxZQUFBO0VBQ0Esb0JBQUE7QUNETjtBRFZBO0VBZU0sa0JBQUE7RUFDQSxtQkFBQTtBQ0ZOO0FEZEE7RUFvQkksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtBQ0hKO0FETUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0pGO0FETUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0pGXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcbi5saXN0Q29udGVudCB7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAvLyBtYXJnaW4tYm90dG9tOiA1MHB4O1xcbiAgcGFkZGluZzogMTBweDtcXG5cXG4gIC5zZWFyY2hib3gge1xcbiAgICBkaXNwbGF5OiBmbGV4O1xcblxcbiAgICAuc2VhcmNoSXRlbSB7XFxuICAgICAgd2lkdGg6IDI0MHB4O1xcbiAgICAgIG1hcmdpbjogMCAyMHB4IDAgMHB4O1xcbiAgICB9XFxuXFxuICAgIC5zZWFyY2hCdG4ge1xcbiAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcXG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xcbiAgICB9XFxuICB9XFxuICAucGFnaW5hdGlvbiB7XFxuICAgIGhlaWdodDogMzBweDtcXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICBib3R0b206IDIwcHg7XFxuICAgIHJpZ2h0OiAwcHg7XFxuICAgIG1hcmdpbi1yaWdodDogMzBweDtcXG4gIH1cXG59XFxuLmp1bXBJbiB7XFxuICBjb2xvcjogIzc5YmJmZjtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmp1bXBPdXQge1xcbiAgY29sb3I6ICM3OWJiZmY7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcblwiLFwiLmxpc3RDb250ZW50IHtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHBhZGRpbmc6IDEwcHg7XFxufVxcbi5saXN0Q29udGVudCAuc2VhcmNoYm94IHtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5saXN0Q29udGVudCAuc2VhcmNoYm94IC5zZWFyY2hJdGVtIHtcXG4gIHdpZHRoOiAyNDBweDtcXG4gIG1hcmdpbjogMCAyMHB4IDAgMHB4O1xcbn1cXG4ubGlzdENvbnRlbnQgLnNlYXJjaGJveCAuc2VhcmNoQnRuIHtcXG4gIG1hcmdpbi1yaWdodDogMTBweDtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5saXN0Q29udGVudCAucGFnaW5hdGlvbiB7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBib3R0b206IDIwcHg7XFxuICByaWdodDogMHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xcbn1cXG4uanVtcEluIHtcXG4gIGNvbG9yOiAjNzliYmZmO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4uanVtcE91dCB7XFxuICBjb2xvcjogIzc5YmJmZjtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsImltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcbmltcG9ydCBsb2Rhc2ggZnJvbSBcImxvZGFzaFwiO1xuaW1wb3J0IHsgRGVsZXRlLCBFZGl0LCBXYXJuVHJpYW5nbGVGaWxsZWQgfSBmcm9tIFwiQGVsZW1lbnQtcGx1cy9pY29ucy12dWVcIjtcbmltcG9ydCBDcmVhdFJpc2sgZnJvbSBcIkAvY29tcG9uZW50cy9jcmVhdFJpc2tcIjtcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyLCB1c2VSb3V0ZSB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XG5pbXBvcnQgd29yZHMgZnJvbSBcIkAvZGljdGlvbmFyaWVzL3dvcmRMaXN0Lmpzb25cIjtcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcbmltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZVwiO1xuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdnbG9iYWxMaXN0JyxcbiAgcHJvcHM6IHtcbiAgICBtb2RlVHlwZTogT2JqZWN0XG4gIH0sXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlO1xuICAgIGV4cG9zZSgpO1xuICAgIHZhciBwcm9wcyA9IF9fcHJvcHM7XG4gICAgdmFyIHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICAgIHZhciByb3V0ZSA9IHVzZVJvdXRlKCk7XG4gICAgdmFyIG11bHRpcGxlVGFibGVSZWYgPSByZWYobnVsbCk7XG4gICAgdmFyIGNyZWF0UmlzayA9IHJlZihudWxsKTtcbiAgICB2YXIgdGVtcGxhdGVEYXRhID0gcmVhY3RpdmUoe30pO1xuICAgIHZhciBkaWFsb2dEZWxldGVWaXNpYmxlID0gcmVmKGZhbHNlKTtcbiAgICB2YXIgZGVsZXRlVGV4dCA9IHJlZihcIlwiKTtcbiAgICB2YXIgZGVsUm93ID0gcmVmKHt9KTtcbiAgICB2YXIgcmVxVGVtcGxhdGUgPSBmdW5jdGlvbiByZXFUZW1wbGF0ZSgpIHtcbiAgICAgIHJlcXVlc3QucG9zdChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3B1YmxpY0FwaS90ZW1wbGF0ZVwiKSwge1xuICAgICAgICBuYW1lOiBwcm9wcy5tb2RlVHlwZS50eXBlXG4gICAgICB9KS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgdGVtcGxhdGVEYXRhLnNlYXJjaFRlbXBsYXRlID0gcmVzLmRhdGEuc2VhcmNoVGVtcGxhdGU7XG4gICAgICAgIHRlbXBsYXRlRGF0YS5zZWFyY2hEYXRhID0gcmVzLmRhdGEuc2VhcmNoRGF0YTtcbiAgICAgICAgdGVtcGxhdGVEYXRhLnRhYmxlVGVtcGxhdGUgPSByZXMuZGF0YS50YWJsZVRlbXBsYXRlO1xuICAgICAgICByZXFMaXN0KCk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciB0YWJsZURhdGEgPSByZWYoW10pO1xuICAgIHZhciB0b3RhbCA9IHJlZigwKTtcbiAgICB2YXIgcGFnZVNpemUgPSByZWYoMTApO1xuICAgIHZhciBjdXJyZW50UGFnZSA9IHJlZigxKTtcbiAgICB2YXIgaGFuZGxlU2VsZWN0aW9uQ2hhbmdlID0gZnVuY3Rpb24gaGFuZGxlU2VsZWN0aW9uQ2hhbmdlKHZhbCkge307XG4gICAgdmFyIHJlcUxpc3RGdW4gPSBmdW5jdGlvbiByZXFMaXN0RnVuKCkge1xuICAgICAgdmFyIHBvc3REYXRhID0ge307XG4gICAgICBwb3N0RGF0YS5zZWFyY2hEYXRhID0gdGVtcGxhdGVEYXRhLnNlYXJjaERhdGE7XG4gICAgICBwb3N0RGF0YS5jdXJyZW50UGFnZSA9IGN1cnJlbnRQYWdlLnZhbHVlO1xuICAgICAgcG9zdERhdGEucGFnZVNpemUgPSBwYWdlU2l6ZS52YWx1ZTtcbiAgICAgIHBvc3REYXRhLm1vZGVUeXBlID0gcHJvcHMubW9kZVR5cGUudHlwZTtcbiAgICAgIHJlcXVlc3QucG9zdChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3B1YmxpY0FwaS9saXN0XCIpLCBwb3N0RGF0YSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgdGFibGVEYXRhLnZhbHVlID0gcmVzLmRhdGEubGlzdDtcbiAgICAgICAgICB0b3RhbC52YWx1ZSA9IHJlcy5kYXRhLnRvdGFsO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBvcGVuUmlzayA9IGZ1bmN0aW9uIG9wZW5SaXNrKHJlY29yZCkge1xuICAgICAgY3JlYXRSaXNrLnZhbHVlLm9wZW5EaWFsb2cocmVjb3JkKTtcbiAgICB9O1xuICAgIHZhciByZXFMaXN0ID0gbG9kYXNoLnRocm90dGxlKHJlcUxpc3RGdW4sIDIwMDApO1xuICAgIC8v5p+l6K+i5YiX6KGoXG4gICAgLy/lpJbpg6jot7PovaxcbiAgICB2YXIganVtcFVybCA9IGZ1bmN0aW9uIGp1bXBVcmwodXJsKSB7XG4gICAgICB3aW5kb3cub3BlbihcImh0dHA6Ly9cIi5jb25jYXQodXJsKSk7XG4gICAgfTtcbiAgICAvL+aMiemSruS6i+S7tlxuICAgIHZhciBidG5DbGljayA9IGZ1bmN0aW9uIGJ0bkNsaWNrKGJ0bkZsYWcpIHtcbiAgICAgIHN3aXRjaCAoYnRuRmxhZykge1xuICAgICAgICBjYXNlIFwic2VhcmNoXCI6XG4gICAgICAgICAgcmVxTGlzdCgpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwidG9BZGRcIjpcbiAgICAgICAgICB0b0FkZCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgLy/mlrDlop5cbiAgICB2YXIgdG9BZGQgPSBmdW5jdGlvbiB0b0FkZCgpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwi5paw5aKeXCIpO1xuICAgICAgY29uc29sZS5sb2cocHJvcHMubW9kZVR5cGUubGlzdCk7XG4gICAgICByb3V0ZXIucHVzaCh7XG4gICAgICAgIG5hbWU6IHByb3BzLm1vZGVUeXBlLmFkZCxcbiAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICB0eXBlOiBcIm5ld1wiLFxuICAgICAgICAgIG1vZGU6IHByb3BzLm1vZGVUeXBlLnR5cGVcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgICAvL+afpeeci1xuICAgIHZhciBqdW1wRGV0YWlsID0gZnVuY3Rpb24ganVtcERldGFpbChyb3cpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwi5p+l55yLXCIpO1xuICAgICAgY29uc29sZS5sb2coc3RvcmUuc3RhdGUsIFwi6Lev55SxXCIpO1xuICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICBuYW1lOiBwcm9wcy5tb2RlVHlwZS5kZXRhaWwsXG4gICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgdXVpZDogcm93LnV1aWQsXG4gICAgICAgICAgdHlwZTogXCJkZXRhaWxcIixcbiAgICAgICAgICBtb2RlOiBwcm9wcy5tb2RlVHlwZS50eXBlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgLy/kv67mlLlcbiAgICB2YXIgZWRpdFJvdyA9IGZ1bmN0aW9uIGVkaXRSb3cocm93KSB7XG4gICAgICByb3V0ZXIucHVzaCh7XG4gICAgICAgIG5hbWU6IHByb3BzLm1vZGVUeXBlLmVkaXQsXG4gICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgdXVpZDogcm93LnV1aWQsXG4gICAgICAgICAgdHlwZTogXCJlZGl0XCIsXG4gICAgICAgICAgbW9kZTogcHJvcHMubW9kZVR5cGUudHlwZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGZ1bmN0aW9uIGRlbGV0ZURpYWxvZ09wZW4ocm93KSB7XG4gICAgICBkZWxSb3cudmFsdWUgPSByb3c7XG4gICAgICBkZWxldGVUZXh0LnZhbHVlID0gXCJcXHU3ODZFXFx1NUI5QVxcdTg5ODFcXHU1MjIwXFx1OTY2NFwiLmNvbmNhdChyb3dbcHJvcHMubW9kZVR5cGUudHlwZSArIFwiTmFtZVwiXSwgXCJcXHU4RkQ5XFx1Njc2MVxcdThENDRcXHU0RUE3XFx1NTQxN1wiKTtcbiAgICAgIGRpYWxvZ0RlbGV0ZVZpc2libGUudmFsdWUgPSB0cnVlO1xuICAgIH1cbiAgICAvL+WIoOmZpFxuICAgIHZhciBkZWxldGVSb3cgPSBmdW5jdGlvbiBkZWxldGVSb3coKSB7XG4gICAgICBjb25zb2xlLmxvZyhkZWxSb3cudmFsdWUsIFwi5Yig6ZmkXCIpO1xuICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvcHVibGljQXBpL2RlbGV0ZVwiKSwge1xuICAgICAgICB1dWlkOiBkZWxSb3cudmFsdWUudXVpZCxcbiAgICAgICAgbW9kZTogcHJvcHMubW9kZVR5cGUudHlwZVxuICAgICAgfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCLliKDpmaTmiJDlip9cIlxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGRpYWxvZ0RlbGV0ZVZpc2libGUudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICByZXFMaXN0KCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgLy/ku47or43ooajph4zojrflj5blr7nlupTlgLxcbiAgICB2YXIgZ2V0TWFwID0gZnVuY3Rpb24gZ2V0TWFwKHByb3BlcnR5LCB2YWx1ZSkge1xuICAgICAgdmFyIHZhbCA9IHdvcmRzW3JvdXRlLm5hbWVdW3Byb3BlcnR5XVt2YWx1ZV07XG4gICAgICByZXR1cm4gdmFsO1xuICAgIH07XG4gICAgdmFyIGdldFRpbWVSYW5nZSA9IGZ1bmN0aW9uIGdldFRpbWVSYW5nZShwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgICAgIHZhciBzdHIgPSBcIlwiLmNvbmNhdCh2YWx1ZVswXSwgXCIgIFxcdTgxRjMgIFwiKS5jb25jYXQodmFsdWVbMV0pO1xuICAgICAgcmV0dXJuIHN0cjtcbiAgICB9O1xuICAgIHZhciBhZGRSaXNrU3VjY2VzcyA9IGZ1bmN0aW9uIGFkZFJpc2tTdWNjZXNzKCkge1xuICAgICAgcmVxTGlzdCgpO1xuICAgIH07XG4gICAgb25Nb3VudGVkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHJlcVRlbXBsYXRlKCk7XG4gICAgfSk7XG4gICAgdmFyIF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIHByb3BzOiBwcm9wcyxcbiAgICAgIHJvdXRlcjogcm91dGVyLFxuICAgICAgcm91dGU6IHJvdXRlLFxuICAgICAgZ2V0IG11bHRpcGxlVGFibGVSZWYoKSB7XG4gICAgICAgIHJldHVybiBtdWx0aXBsZVRhYmxlUmVmO1xuICAgICAgfSxcbiAgICAgIHNldCBtdWx0aXBsZVRhYmxlUmVmKHYpIHtcbiAgICAgICAgbXVsdGlwbGVUYWJsZVJlZiA9IHY7XG4gICAgICB9LFxuICAgICAgY3JlYXRSaXNrOiBjcmVhdFJpc2ssXG4gICAgICBnZXQgdGVtcGxhdGVEYXRhKCkge1xuICAgICAgICByZXR1cm4gdGVtcGxhdGVEYXRhO1xuICAgICAgfSxcbiAgICAgIHNldCB0ZW1wbGF0ZURhdGEodikge1xuICAgICAgICB0ZW1wbGF0ZURhdGEgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBkaWFsb2dEZWxldGVWaXNpYmxlKCkge1xuICAgICAgICByZXR1cm4gZGlhbG9nRGVsZXRlVmlzaWJsZTtcbiAgICAgIH0sXG4gICAgICBzZXQgZGlhbG9nRGVsZXRlVmlzaWJsZSh2KSB7XG4gICAgICAgIGRpYWxvZ0RlbGV0ZVZpc2libGUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBkZWxldGVUZXh0KCkge1xuICAgICAgICByZXR1cm4gZGVsZXRlVGV4dDtcbiAgICAgIH0sXG4gICAgICBzZXQgZGVsZXRlVGV4dCh2KSB7XG4gICAgICAgIGRlbGV0ZVRleHQgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBkZWxSb3coKSB7XG4gICAgICAgIHJldHVybiBkZWxSb3c7XG4gICAgICB9LFxuICAgICAgc2V0IGRlbFJvdyh2KSB7XG4gICAgICAgIGRlbFJvdyA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlcVRlbXBsYXRlKCkge1xuICAgICAgICByZXR1cm4gcmVxVGVtcGxhdGU7XG4gICAgICB9LFxuICAgICAgc2V0IHJlcVRlbXBsYXRlKHYpIHtcbiAgICAgICAgcmVxVGVtcGxhdGUgPSB2O1xuICAgICAgfSxcbiAgICAgIHRhYmxlRGF0YTogdGFibGVEYXRhLFxuICAgICAgdG90YWw6IHRvdGFsLFxuICAgICAgZ2V0IHBhZ2VTaXplKCkge1xuICAgICAgICByZXR1cm4gcGFnZVNpemU7XG4gICAgICB9LFxuICAgICAgc2V0IHBhZ2VTaXplKHYpIHtcbiAgICAgICAgcGFnZVNpemUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjdXJyZW50UGFnZSgpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnRQYWdlO1xuICAgICAgfSxcbiAgICAgIHNldCBjdXJyZW50UGFnZSh2KSB7XG4gICAgICAgIGN1cnJlbnRQYWdlID0gdjtcbiAgICAgIH0sXG4gICAgICBoYW5kbGVTZWxlY3Rpb25DaGFuZ2U6IGhhbmRsZVNlbGVjdGlvbkNoYW5nZSxcbiAgICAgIHJlcUxpc3RGdW46IHJlcUxpc3RGdW4sXG4gICAgICBvcGVuUmlzazogb3BlblJpc2ssXG4gICAgICByZXFMaXN0OiByZXFMaXN0LFxuICAgICAganVtcFVybDoganVtcFVybCxcbiAgICAgIGJ0bkNsaWNrOiBidG5DbGljayxcbiAgICAgIHRvQWRkOiB0b0FkZCxcbiAgICAgIGp1bXBEZXRhaWw6IGp1bXBEZXRhaWwsXG4gICAgICBlZGl0Um93OiBlZGl0Um93LFxuICAgICAgZGVsZXRlRGlhbG9nT3BlbjogZGVsZXRlRGlhbG9nT3BlbixcbiAgICAgIGRlbGV0ZVJvdzogZGVsZXRlUm93LFxuICAgICAgZ2V0TWFwOiBnZXRNYXAsXG4gICAgICBnZXRUaW1lUmFuZ2U6IGdldFRpbWVSYW5nZSxcbiAgICAgIGFkZFJpc2tTdWNjZXNzOiBhZGRSaXNrU3VjY2VzcyxcbiAgICAgIGdldCBlbnZuYW1lKCkge1xuICAgICAgICByZXR1cm4gZW52bmFtZTtcbiAgICAgIH0sXG4gICAgICBnZXQgbG9kYXNoKCkge1xuICAgICAgICByZXR1cm4gbG9kYXNoO1xuICAgICAgfSxcbiAgICAgIGdldCBEZWxldGUoKSB7XG4gICAgICAgIHJldHVybiBEZWxldGU7XG4gICAgICB9LFxuICAgICAgZ2V0IEVkaXQoKSB7XG4gICAgICAgIHJldHVybiBFZGl0O1xuICAgICAgfSxcbiAgICAgIGdldCBXYXJuVHJpYW5nbGVGaWxsZWQoKSB7XG4gICAgICAgIHJldHVybiBXYXJuVHJpYW5nbGVGaWxsZWQ7XG4gICAgICB9LFxuICAgICAgZ2V0IENyZWF0UmlzaygpIHtcbiAgICAgICAgcmV0dXJuIENyZWF0UmlzaztcbiAgICAgIH0sXG4gICAgICBnZXQgcmVxdWVzdCgpIHtcbiAgICAgICAgcmV0dXJuIHJlcXVlc3Q7XG4gICAgICB9LFxuICAgICAgZ2V0IHVzZVJvdXRlcigpIHtcbiAgICAgICAgcmV0dXJuIHVzZVJvdXRlcjtcbiAgICAgIH0sXG4gICAgICBnZXQgdXNlUm91dGUoKSB7XG4gICAgICAgIHJldHVybiB1c2VSb3V0ZTtcbiAgICAgIH0sXG4gICAgICBnZXQgd29yZHMoKSB7XG4gICAgICAgIHJldHVybiB3b3JkcztcbiAgICAgIH0sXG4gICAgICBnZXQgRWxNZXNzYWdlKCkge1xuICAgICAgICByZXR1cm4gRWxNZXNzYWdlO1xuICAgICAgfSxcbiAgICAgIGdldCBzdG9yZSgpIHtcbiAgICAgICAgcmV0dXJuIHN0b3JlO1xuICAgICAgfVxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsIjx0ZW1wbGF0ZT5cclxuICA8ZGl2IGNsYXNzPVwibGlzdENvbnRlbnRcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hib3hcIj5cclxuICAgICAgPHRlbXBsYXRlXHJcbiAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHRlbXBsYXRlRGF0YS5zZWFyY2hUZW1wbGF0ZVwiXHJcbiAgICAgICAgOmtleT1cImluZGV4XCJcclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgdi1pZj1cIml0ZW0udHlwZSA9PT0gJ2lucHV0J1wiPlxyXG4gICAgICAgICAgPCEtLSA8c3Bhbj57eyBpdGVtLmxhYmVsIH19Ojwvc3Bhbj4gLS0+XHJcbiAgICAgICAgICA8ZWwtaW5wdXRcclxuICAgICAgICAgICAgdi1tb2RlbD1cInRlbXBsYXRlRGF0YS5zZWFyY2hEYXRhW2l0ZW0ubmFtZV1cIlxyXG4gICAgICAgICAgICBjbGFzcz1cInNlYXJjaEl0ZW1cIlxyXG4gICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgQGNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgICAgICA6cGxhY2Vob2xkZXI9XCJpdGVtLnBsYWNlaG9sZGVyXCJcclxuICAgICAgICAgID48L2VsLWlucHV0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnc2VsZWN0J1wiPlxyXG4gICAgICAgICAgPCEtLSA8c3Bhbj57eyBpdGVtLmxhYmVsIH19Ojwvc3Bhbj4gLS0+XHJcbiAgICAgICAgICA8ZWwtc2VsZWN0XHJcbiAgICAgICAgICAgIGNsYXNzPVwic2VhcmNoSXRlbVwiXHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJ0ZW1wbGF0ZURhdGEuc2VhcmNoRGF0YVtpdGVtLm5hbWVdXCJcclxuICAgICAgICAgICAgOnBsYWNlaG9sZGVyPVwiaXRlbS5wbGFjZWhvbGRlclwiXHJcbiAgICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgICBAY2hhbmdlPVwicmVxTGlzdFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxlbC1vcHRpb25cclxuICAgICAgICAgICAgICB2LWZvcj1cIih2YWwsIGluZCkgaW4gaXRlbS5vcHRpb25zXCJcclxuICAgICAgICAgICAgICA6a2V5PVwiaW5kXCJcclxuICAgICAgICAgICAgICA6bGFiZWw9XCJ2YWwubGFiZWxcIlxyXG4gICAgICAgICAgICAgIDp2YWx1ZT1cInZhbC52YWx1ZVwiXHJcbiAgICAgICAgICAgID48L2VsLW9wdGlvbj5cclxuICAgICAgICAgIDwvZWwtc2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnYnV0dG9uJ1wiIGNsYXNzPVwic2VhcmNoQnRuXCI+XHJcbiAgICAgICAgICA8ZWwtYnV0dG9uIDp0eXBlPVwiaXRlbS5idG5UeXBlXCIgQGNsaWNrPVwiYnRuQ2xpY2soaXRlbS5ldmVudClcIj57e1xyXG4gICAgICAgICAgICBpdGVtLnRleHRcclxuICAgICAgICAgIH19PC9lbC1idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJ0YWJsZUJveFwiPlxyXG4gICAgICA8ZWwtdGFibGVcclxuICAgICAgICA6Ym9yZGVyPVwidHJ1ZVwiXHJcbiAgICAgICAgcmVmPVwibXVsdGlwbGVUYWJsZVJlZlwiXHJcbiAgICAgICAgOmRhdGE9XCJ0YWJsZURhdGFcIlxyXG4gICAgICAgIHN0eWxlPVwid2lkdGg6IDEwMCVcIlxyXG4gICAgICAgIEBzZWxlY3Rpb24tY2hhbmdlPVwiaGFuZGxlU2VsZWN0aW9uQ2hhbmdlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDwhLS0gPGVsLXRhYmxlLWNvbHVtbiB0eXBlPVwic2VsZWN0aW9uXCIgd2lkdGg9XCI1NVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8ZWwtdGFibGUtY29sdW1uIGxhYmVsPVwiRGF0ZVwiIHdpZHRoPVwiMTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwic2NvcGVcIj57eyBzY29wZS5yb3cuZGF0ZSB9fTwvdGVtcGxhdGU+XHJcbiAgICAgICAgICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICAgICAgICAgIDxlbC10YWJsZS1jb2x1bW4gcHJvcGVydHk9XCJuYW1lXCIgbGFiZWw9XCJOYW1lXCIgd2lkdGg9XCIxMjBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wZXJ0eT1cImFkZHJlc3NcIiBsYWJlbD1cIkFkZHJlc3NcIiBzaG93LW92ZXJmbG93LXRvb2x0aXAgLz4gLS0+XHJcbiAgICAgICAgPHRlbXBsYXRlXHJcbiAgICAgICAgICB2LWZvcj1cIihpdGVtLCBpbmRleCkgaW4gdGVtcGxhdGVEYXRhLnRhYmxlVGVtcGxhdGVcIlxyXG4gICAgICAgICAgOmtleT1cImluZGV4XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZWwtdGFibGUtY29sdW1uXHJcbiAgICAgICAgICAgIHYtaWY9XCJpdGVtLmNvbHVtbiA9PT0gJ25vcm1hbCdcIlxyXG4gICAgICAgICAgICA6cHJvcGVydHk9XCJpdGVtLnByb3BlcnR5XCJcclxuICAgICAgICAgICAgOndpZHRoPVwiaXRlbS53aWR0aFwiXHJcbiAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICA6c29ydGFibGU9XCJpdGVtLnNvcnRhYmxlIHx8IGZhbHNlXCJcclxuICAgICAgICAgID48L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICAgIDxlbC10YWJsZS1jb2x1bW5cclxuICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS5jb2x1bW4gPT09ICdqdW1wSW4nXCJcclxuICAgICAgICAgICAgOndpZHRoPVwiaXRlbS53aWR0aFwiXHJcbiAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgICAgIDwhLS0gPHAgY2xhc3M9XCJqdW1wSW5cIj57eyBzY29wZS5yb3dbaXRlbS5wcm9wZXJ0eV0gfX08L3A+IC0tPlxyXG4gICAgICAgICAgICAgIDxlbC1idXR0b24gbGluayB0eXBlPVwicHJpbWFyeVwiPnt7XHJcbiAgICAgICAgICAgICAgICBzY29wZS5yb3dbaXRlbS5wcm9wZXJ0eV1cclxuICAgICAgICAgICAgICB9fTwvZWwtYnV0dG9uPlxyXG4gICAgICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICAgICAgICA8ZWwtdGFibGUtY29sdW1uXHJcbiAgICAgICAgICAgIHYtZWxzZS1pZj1cIml0ZW0uY29sdW1uID09PSAnZGV0YWlscydcIlxyXG4gICAgICAgICAgICA6d2lkdGg9XCJpdGVtLndpZHRoXCJcclxuICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgICAgPCEtLSA8cCBjbGFzcz1cImp1bXBJblwiIEBjbGljaz1cImp1bXBEZXRhaWwoc2NvcGUucm93KVwiPlxyXG4gICAgICAgICAgICAgICAge3sgc2NvcGUucm93W2l0ZW0ucHJvcGVydHldIH19XHJcbiAgICAgICAgICAgICAgPC9wPiAtLT5cclxuICAgICAgICAgICAgICA8ZWwtYnV0dG9uIGxpbmsgdHlwZT1cInByaW1hcnlcIiBAY2xpY2s9XCJqdW1wRGV0YWlsKHNjb3BlLnJvdylcIj57e1xyXG4gICAgICAgICAgICAgICAgc2NvcGUucm93W2l0ZW0ucHJvcGVydHldXHJcbiAgICAgICAgICAgICAgfX08L2VsLWJ1dHRvbj5cclxuICAgICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICAgIDwvZWwtdGFibGUtY29sdW1uPlxyXG4gICAgICAgICAgPGVsLXRhYmxlLWNvbHVtblxyXG4gICAgICAgICAgICB2LWVsc2UtaWY9XCJpdGVtLmNvbHVtbiA9PT0gJ21hcCdcIlxyXG4gICAgICAgICAgICA6d2lkdGg9XCJpdGVtLndpZHRoXCJcclxuICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgICAgPHA+e3sgZ2V0TWFwKGl0ZW0ucHJvcGVydHksIHNjb3BlLnJvd1tpdGVtLnByb3BlcnR5XSkgfX08L3A+XHJcbiAgICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICAgIDxlbC10YWJsZS1jb2x1bW5cclxuICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS5jb2x1bW4gPT09ICd0aW1lUmFuZ2UnXCJcclxuICAgICAgICAgICAgOndpZHRoPVwiaXRlbS53aWR0aFwiXHJcbiAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgICAgIDxwPnt7IGdldFRpbWVSYW5nZShpdGVtLnByb3BlcnR5LCBzY29wZS5yb3dbaXRlbS5wcm9wZXJ0eV0pIH19PC9wPlxyXG4gICAgICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICAgICAgICA8ZWwtdGFibGUtY29sdW1uXHJcbiAgICAgICAgICAgIHYtZWxzZS1pZj1cIml0ZW0uY29sdW1uID09PSAnanVtcE91dCdcIlxyXG4gICAgICAgICAgICA6d2lkdGg9XCJpdGVtLndpZHRoXCJcclxuICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJqdW1wT3V0XCIgQGNsaWNrPVwianVtcFVybChzY29wZS5yb3dbaXRlbS5wcm9wZXJ0eV0pXCI+XHJcbiAgICAgICAgICAgICAgICB7eyBzY29wZS5yb3dbaXRlbS5wcm9wZXJ0eV0gfX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICAgIDxlbC10YWJsZS1jb2x1bW4gdi1lbHNlIDp3aWR0aD1cIml0ZW0ud2lkdGhcIiA6bGFiZWw9XCJpdGVtLmxhYmVsXCI+XHJcbiAgICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgICAge3sgc2NvcGUucm93W2l0ZW0ucHJvcGVydHldIH19XHJcbiAgICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gOndpZHRoPVwiMjQwXCIgbGFiZWw9XCLmk43kvZxcIiBmaXhlZD1cInJpZ2h0XCI+XHJcbiAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgICA8IS0tIHt7c2NvcGUucm93W2l0ZW0ucHJvcGVydHldfX0gLS0+XHJcbiAgICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiBsaW5rIEBjbGljaz1cImVkaXRSb3coc2NvcGUucm93KVwiPlxyXG4gICAgICAgICAgICAgIOe8lui+kVxyXG4gICAgICAgICAgICA8L2VsLWJ1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cImRhbmdlclwiIGxpbmsgQGNsaWNrPVwiZGVsZXRlRGlhbG9nT3BlbihzY29wZS5yb3cpXCJcclxuICAgICAgICAgICAgICA+5Yig6ZmkPC9lbC1idXR0b25cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJ3YXJuaW5nXCIgbGluayBAY2xpY2s9XCJvcGVuUmlzayhzY29wZS5yb3cpXCJcclxuICAgICAgICAgICAgICA+5qCH6K6w6aOO6ZmpPC9lbC1idXR0b25cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgPC9lbC10YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cInBhZ2luYXRpb25cIj5cclxuICAgICAgPGVsLXBhZ2luYXRpb25cclxuICAgICAgICBzbWFsbFxyXG4gICAgICAgIGJhY2tncm91bmRcclxuICAgICAgICBsYXlvdXQ9XCJwcmV2LCBwYWdlciwgbmV4dCwganVtcGVyLCAtPiwgdG90YWxcIlxyXG4gICAgICAgIDp0b3RhbD1cInRvdGFsXCJcclxuICAgICAgICBjbGFzcz1cIm10LTRcIlxyXG4gICAgICAgIHYtbW9kZWw6cGFnZS1zaXplPVwicGFnZVNpemVcIlxyXG4gICAgICAgIHYtbW9kZWw6Y3VycmVudC1wYWdlPVwiY3VycmVudFBhZ2VcIlxyXG4gICAgICAgIEBzaXplLWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBjdXJyZW50LWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBwcmV2LWNsaWNrPVwicmVxTGlzdFwiXHJcbiAgICAgICAgQG5leHQtY2xpY2s9XCJyZXFMaXN0XCJcclxuICAgICAgPlxyXG4gICAgICAgIDx0ZW1wbGF0ZSAjcGFnZXItdGV4dD5cclxuICAgICAgICAgIDxzcGFuPuWFsSB7eyB0b3RhbCB9fSDmnaHmlbDmja48L3NwYW4+XHJcbiAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgPC9lbC1wYWdpbmF0aW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgPGVsLWRpYWxvZyB2LW1vZGVsPVwiZGlhbG9nRGVsZXRlVmlzaWJsZVwiIHRpdGxlPVwi5Yig6ZmkXCIgd2lkdGg9XCIyNSVcIj5cclxuICAgIDxzcGFuPnt7IGRlbGV0ZVRleHQgfX08L3NwYW4+XHJcbiAgICA8dGVtcGxhdGUgI2Zvb3Rlcj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJkaWFsb2ctZm9vdGVyXCI+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cImRlbGV0ZVJvd1wiPuehruWumjwvZWwtYnV0dG9uPlxyXG4gICAgICAgIDxlbC1idXR0b24gQGNsaWNrPVwiZGlhbG9nRGVsZXRlVmlzaWJsZSA9IGZhbHNlXCI+5Y+W5raIPC9lbC1idXR0b24+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvdGVtcGxhdGU+XHJcbiAgPC9lbC1kaWFsb2c+XHJcbiAgPENyZWF0UmlzayByZWY9XCJjcmVhdFJpc2tcIiBAYWRkUmlza1N1Y2Nlc3M9XCJhZGRSaXNrU3VjY2Vzc1wiPjwvQ3JlYXRSaXNrPlxyXG48L3RlbXBsYXRlPlxyXG48c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgeyBlbnZuYW1lIH0gZnJvbSBcIkAvamF2YXNjcmlwdC9lbnZuYW1lXCI7XHJcbmltcG9ydCBsb2Rhc2ggZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgeyBEZWxldGUsIEVkaXQsIFdhcm5UcmlhbmdsZUZpbGxlZCB9IGZyb20gXCJAZWxlbWVudC1wbHVzL2ljb25zLXZ1ZVwiO1xyXG5pbXBvcnQgQ3JlYXRSaXNrIGZyb20gXCJAL2NvbXBvbmVudHMvY3JlYXRSaXNrXCI7XHJcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIsIHVzZVJvdXRlIH0gZnJvbSBcInZ1ZS1yb3V0ZXJcIjtcclxuaW1wb3J0IHdvcmRzIGZyb20gXCJAL2RpY3Rpb25hcmllcy93b3JkTGlzdC5qc29uXCI7XHJcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcclxuaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlXCI7XHJcbmNvbnN0IHByb3BzID0gZGVmaW5lUHJvcHMoe1xyXG4gIG1vZGVUeXBlOiBPYmplY3QsXHJcbn0pO1xyXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpO1xyXG5sZXQgbXVsdGlwbGVUYWJsZVJlZiA9IHJlZihudWxsKTtcclxuY29uc3QgY3JlYXRSaXNrID0gcmVmKG51bGwpO1xyXG5sZXQgdGVtcGxhdGVEYXRhID0gcmVhY3RpdmUoe30pO1xyXG5sZXQgZGlhbG9nRGVsZXRlVmlzaWJsZSA9IHJlZihmYWxzZSk7XHJcbmxldCBkZWxldGVUZXh0ID0gcmVmKFwiXCIpO1xyXG5sZXQgZGVsUm93ID0gcmVmKHt9KTtcclxubGV0IHJlcVRlbXBsYXRlID0gKCkgPT4ge1xyXG4gIHJlcXVlc3RcclxuICAgIC5wb3N0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvcHVibGljQXBpL3RlbXBsYXRlYCwge1xyXG4gICAgICBuYW1lOiBwcm9wcy5tb2RlVHlwZS50eXBlLFxyXG4gICAgfSlcclxuICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgdGVtcGxhdGVEYXRhLnNlYXJjaFRlbXBsYXRlID0gcmVzLmRhdGEuc2VhcmNoVGVtcGxhdGU7XHJcbiAgICAgIHRlbXBsYXRlRGF0YS5zZWFyY2hEYXRhID0gcmVzLmRhdGEuc2VhcmNoRGF0YTtcclxuICAgICAgdGVtcGxhdGVEYXRhLnRhYmxlVGVtcGxhdGUgPSByZXMuZGF0YS50YWJsZVRlbXBsYXRlO1xyXG4gICAgICByZXFMaXN0KCk7XHJcbiAgICB9KTtcclxufTtcclxuY29uc3QgdGFibGVEYXRhID0gcmVmKFtdKTtcclxuY29uc3QgdG90YWwgPSByZWYoMCk7XHJcbmxldCBwYWdlU2l6ZSA9IHJlZigxMCk7XHJcbmxldCBjdXJyZW50UGFnZSA9IHJlZigxKTtcclxuY29uc3QgaGFuZGxlU2VsZWN0aW9uQ2hhbmdlID0gKHZhbCkgPT4ge307XHJcbmNvbnN0IHJlcUxpc3RGdW4gPSAoKSA9PiB7XHJcbiAgbGV0IHBvc3REYXRhID0ge307XHJcbiAgcG9zdERhdGEuc2VhcmNoRGF0YSA9IHRlbXBsYXRlRGF0YS5zZWFyY2hEYXRhO1xyXG4gIHBvc3REYXRhLmN1cnJlbnRQYWdlID0gY3VycmVudFBhZ2UudmFsdWU7XHJcbiAgcG9zdERhdGEucGFnZVNpemUgPSBwYWdlU2l6ZS52YWx1ZTtcclxuICBwb3N0RGF0YS5tb2RlVHlwZSA9IHByb3BzLm1vZGVUeXBlLnR5cGU7XHJcbiAgcmVxdWVzdC5wb3N0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvcHVibGljQXBpL2xpc3RgLCBwb3N0RGF0YSkudGhlbigocmVzKSA9PiB7XHJcbiAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICB0YWJsZURhdGEudmFsdWUgPSByZXMuZGF0YS5saXN0O1xyXG4gICAgICB0b3RhbC52YWx1ZSA9IHJlcy5kYXRhLnRvdGFsO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBvcGVuUmlzayA9IChyZWNvcmQpID0+IHtcclxuICBjcmVhdFJpc2sudmFsdWUub3BlbkRpYWxvZyhyZWNvcmQpO1xyXG59O1xyXG5jb25zdCByZXFMaXN0ID0gbG9kYXNoLnRocm90dGxlKHJlcUxpc3RGdW4sIDIwMDApO1xyXG4vL+afpeivouWIl+ihqFxyXG4vL+WklumDqOi3s+i9rFxyXG5jb25zdCBqdW1wVXJsID0gKHVybCkgPT4ge1xyXG4gIHdpbmRvdy5vcGVuKGBodHRwOi8vJHt1cmx9YCk7XHJcbn07XHJcbi8v5oyJ6ZKu5LqL5Lu2XHJcbmNvbnN0IGJ0bkNsaWNrID0gKGJ0bkZsYWcpID0+IHtcclxuICBzd2l0Y2ggKGJ0bkZsYWcpIHtcclxuICAgIGNhc2UgXCJzZWFyY2hcIjpcclxuICAgICAgcmVxTGlzdCgpO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgXCJ0b0FkZFwiOlxyXG4gICAgICB0b0FkZCgpO1xyXG4gIH1cclxufTtcclxuLy/mlrDlop5cclxuY29uc3QgdG9BZGQgPSAoKSA9PiB7XHJcbiAgY29uc29sZS5sb2coXCLmlrDlop5cIik7XHJcbiAgY29uc29sZS5sb2cocHJvcHMubW9kZVR5cGUubGlzdCk7XHJcbiAgcm91dGVyLnB1c2goe1xyXG4gICAgbmFtZTogcHJvcHMubW9kZVR5cGUuYWRkLFxyXG4gICAgcXVlcnk6IHtcclxuICAgICAgdHlwZTogXCJuZXdcIixcclxuICAgICAgbW9kZTogcHJvcHMubW9kZVR5cGUudHlwZSxcclxuICAgIH0sXHJcbiAgfSk7XHJcbn07XHJcbi8v5p+l55yLXHJcbmNvbnN0IGp1bXBEZXRhaWwgPSAocm93KSA9PiB7XHJcbiAgY29uc29sZS5sb2coXCLmn6XnnItcIik7XHJcbiAgY29uc29sZS5sb2coc3RvcmUuc3RhdGUsIFwi6Lev55SxXCIpO1xyXG4gIHJvdXRlci5wdXNoKHtcclxuICAgIG5hbWU6IHByb3BzLm1vZGVUeXBlLmRldGFpbCxcclxuICAgIHF1ZXJ5OiB7XHJcbiAgICAgIHV1aWQ6IHJvdy51dWlkLFxyXG4gICAgICB0eXBlOiBcImRldGFpbFwiLFxyXG4gICAgICBtb2RlOiBwcm9wcy5tb2RlVHlwZS50eXBlLFxyXG4gICAgfSxcclxuICB9KTtcclxufTtcclxuLy/kv67mlLlcclxuY29uc3QgZWRpdFJvdyA9IChyb3cpID0+IHtcclxuICByb3V0ZXIucHVzaCh7XHJcbiAgICBuYW1lOiBwcm9wcy5tb2RlVHlwZS5lZGl0LFxyXG4gICAgcXVlcnk6IHtcclxuICAgICAgdXVpZDogcm93LnV1aWQsXHJcbiAgICAgIHR5cGU6IFwiZWRpdFwiLFxyXG4gICAgICBtb2RlOiBwcm9wcy5tb2RlVHlwZS50eXBlLFxyXG4gICAgfSxcclxuICB9KTtcclxufTtcclxuZnVuY3Rpb24gZGVsZXRlRGlhbG9nT3Blbihyb3cpIHtcclxuICBkZWxSb3cudmFsdWUgPSByb3c7XHJcbiAgZGVsZXRlVGV4dC52YWx1ZSA9IGDnoa7lrpropoHliKDpmaQke3Jvd1twcm9wcy5tb2RlVHlwZS50eXBlICsgXCJOYW1lXCJdfei/meadoei1hOS6p+WQl2A7XHJcbiAgZGlhbG9nRGVsZXRlVmlzaWJsZS52YWx1ZSA9IHRydWU7XHJcbn1cclxuLy/liKDpmaRcclxuY29uc3QgZGVsZXRlUm93ID0gKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKGRlbFJvdy52YWx1ZSwgXCLliKDpmaRcIik7XHJcbiAgcmVxdWVzdFxyXG4gICAgLnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC9wdWJsaWNBcGkvZGVsZXRlYCwge1xyXG4gICAgICB1dWlkOiBkZWxSb3cudmFsdWUudXVpZCxcclxuICAgICAgbW9kZTogcHJvcHMubW9kZVR5cGUudHlwZSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XHJcbiAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCLliKDpmaTmiJDlip9cIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBkaWFsb2dEZWxldGVWaXNpYmxlLnZhbHVlID0gZmFsc2U7XHJcbiAgICAgICAgcmVxTGlzdCgpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxufTtcclxuLy/ku47or43ooajph4zojrflj5blr7nlupTlgLxcclxuY29uc3QgZ2V0TWFwID0gKHByb3BlcnR5LCB2YWx1ZSkgPT4ge1xyXG4gIGxldCB2YWwgPSB3b3Jkc1tyb3V0ZS5uYW1lXVtwcm9wZXJ0eV1bdmFsdWVdO1xyXG4gIHJldHVybiB2YWw7XHJcbn07XHJcbmNvbnN0IGdldFRpbWVSYW5nZSA9IChwcm9wZXJ0eSwgdmFsdWUpID0+IHtcclxuICBsZXQgc3RyID0gYCR7dmFsdWVbMF19ICDoh7MgICR7dmFsdWVbMV19YDtcclxuICByZXR1cm4gc3RyO1xyXG59O1xyXG5jb25zdCBhZGRSaXNrU3VjY2VzcyA9ICgpID0+IHtcclxuICByZXFMaXN0KCk7XHJcbn07XHJcbm9uTW91bnRlZCgoKSA9PiB7XHJcbiAgcmVxVGVtcGxhdGUoKTtcclxufSk7XHJcbjwvc2NyaXB0PlxyXG48c3R5bGUgbGFuZz1cImxlc3NcIj5cclxuLmxpc3RDb250ZW50IHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC8vIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgcGFkZGluZzogMTBweDtcclxuXHJcbiAgLnNlYXJjaGJveCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgIC5zZWFyY2hJdGVtIHtcclxuICAgICAgd2lkdGg6IDI0MHB4O1xyXG4gICAgICBtYXJnaW46IDAgMjBweCAwIDBweDtcclxuICAgIH1cclxuXHJcbiAgICAuc2VhcmNoQnRuIHtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgfVxyXG4gIH1cclxuICAucGFnaW5hdGlvbiB7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDIwcHg7XHJcbiAgICByaWdodDogMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xyXG4gIH1cclxufVxyXG4uanVtcEluIHtcclxuICBjb2xvcjogIzc5YmJmZjtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmp1bXBPdXQge1xyXG4gIGNvbG9yOiAjNzliYmZmO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG48L3N0eWxlPiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MzZiYzk0NzEmbGFuZz1sZXNzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MzZiYzk0NzEmbGFuZz1sZXNzXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vZ2xvYmFsTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MzZiYzk0NzFcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9nbG9iYWxMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MzZiYzk0NzEmbGFuZz1sZXNzXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fZmlsZScsXCJzcmMvY29tcG9uZW50cy9nbG9iYWxMaXN0LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIzNmJjOTQ3MVwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzM2YmM5NDcxJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMzZiYzk0NzEnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTM2YmM5NDcxXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJzM2YmM5NDcxJywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9nbG9iYWxMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZ2xvYmFsTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2dsb2JhbExpc3QudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTM2YmM5NDcxXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9nbG9iYWxMaXN0LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTM2YmM5NDcxJmxhbmc9bGVzc1wiIl0sIm5hbWVzIjpbIl9jcmVhdGVFbGVtZW50Vk5vZGUiLCJfaG9pc3RlZF8xIiwiX2hvaXN0ZWRfMiIsIl9jcmVhdGVFbGVtZW50QmxvY2siLCJfRnJhZ21lbnQiLCJfcmVuZGVyTGlzdCIsIiRzZXR1cCIsInRlbXBsYXRlRGF0YSIsInNlYXJjaFRlbXBsYXRlIiwiaXRlbSIsImluZGV4IiwidHlwZSIsIl9ob2lzdGVkXzMiLCJfY3JlYXRlQ29tbWVudFZOb2RlIiwiX2NyZWF0ZVZOb2RlIiwiX2NvbXBvbmVudF9lbF9pbnB1dCIsInNlYXJjaERhdGEiLCJuYW1lIiwiJGV2ZW50IiwiY2xlYXJhYmxlIiwib25DaGFuZ2UiLCJyZXFMaXN0IiwicGxhY2Vob2xkZXIiLCJfaG9pc3RlZF80IiwiX2NvbXBvbmVudF9lbF9zZWxlY3QiLCJvcHRpb25zIiwidmFsIiwiaW5kIiwiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF9lbF9vcHRpb24iLCJrZXkiLCJsYWJlbCIsInZhbHVlIiwiX2hvaXN0ZWRfNSIsIl9jb21wb25lbnRfZWxfYnV0dG9uIiwiYnRuVHlwZSIsIm9uQ2xpY2siLCJidG5DbGljayIsImV2ZW50IiwidGV4dCIsIl9ob2lzdGVkXzYiLCJfY29tcG9uZW50X2VsX3RhYmxlIiwiYm9yZGVyIiwicmVmIiwiZGF0YSIsInRhYmxlRGF0YSIsInN0eWxlIiwib25TZWxlY3Rpb25DaGFuZ2UiLCJoYW5kbGVTZWxlY3Rpb25DaGFuZ2UiLCJ0YWJsZVRlbXBsYXRlIiwiY29sdW1uIiwiX2NvbXBvbmVudF9lbF90YWJsZV9jb2x1bW4iLCJwcm9wZXJ0eSIsIndpZHRoIiwic29ydGFibGUiLCJfd2l0aEN0eCIsInNjb3BlIiwibGluayIsInJvdyIsImp1bXBEZXRhaWwiLCJfdG9EaXNwbGF5U3RyaW5nIiwiZ2V0TWFwIiwiZ2V0VGltZVJhbmdlIiwianVtcFVybCIsIl9ob2lzdGVkXzciLCJmaXhlZCIsImVkaXRSb3ciLCJkZWxldGVEaWFsb2dPcGVuIiwib3BlblJpc2siLCJfaG9pc3RlZF84IiwiX2NvbXBvbmVudF9lbF9wYWdpbmF0aW9uIiwic21hbGwiLCJiYWNrZ3JvdW5kIiwibGF5b3V0IiwidG90YWwiLCJwYWdlU2l6ZSIsImN1cnJlbnRQYWdlIiwib25TaXplQ2hhbmdlIiwib25DdXJyZW50Q2hhbmdlIiwib25QcmV2Q2xpY2siLCJvbk5leHRDbGljayIsIl9jb21wb25lbnRfZWxfZGlhbG9nIiwiZGlhbG9nRGVsZXRlVmlzaWJsZSIsInRpdGxlIiwiZm9vdGVyIiwiX2hvaXN0ZWRfOSIsImRlbGV0ZVJvdyIsIl9jYWNoZSIsImRlbGV0ZVRleHQiLCJvbkFkZFJpc2tTdWNjZXNzIiwiYWRkUmlza1N1Y2Nlc3MiXSwic291cmNlUm9vdCI6IiJ9