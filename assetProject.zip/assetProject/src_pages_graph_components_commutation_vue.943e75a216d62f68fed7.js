"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_graph_components_commutation_vue"],{

/***/ 10153:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/graph/components/commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#chartBox[data-v-45f28dd4] {\n  margin-top: 20px;\n  width: 1400px;\n  height: 600px;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/graph/components/commutation.vue","webpack://./commutation.vue"],"names":[],"mappings":"AACA;EACE,gBAAA;EACA,aAAA;EACA,aAAA;ACAF","sourcesContent":["\n#chartBox {\n  margin-top: 20px;\n  width: 1400px;\n  height: 600px;\n}\n","#chartBox {\n  margin-top: 20px;\n  width: 1400px;\n  height: 600px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 46005:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/graph/components/commutation.vue?vue&type=script&setup=true&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'commutation',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var echarts = (0,vue__WEBPACK_IMPORTED_MODULE_0__.inject)("echarts");
    var option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)({});
    var base = +new Date(1988, 9, 3);
    var oneDay = 24 * 3600 * 1000;
    var data = [[base, Math.random() * 300]];
    for (var i = 1; i < 20000; i++) {
      var now = new Date(base += oneDay);
      data.push([+now, Math.round((Math.random() - 0.5) * 20 + data[i - 1][1])]);
    }
    var chartFun = function chartFun() {
      var chartDom = document.getElementById("chartBox");
      var myChart = echarts.init(chartDom);
      option.value = {
        tooltip: {
          trigger: "axis",
          position: function position(pt) {
            return [pt[0], "10%"];
          }
        },
        title: {
          left: "center",
          text: "通信记录"
        },
        toolbox: {
          feature: {
            dataZoom: {
              yAxisIndex: "none"
            },
            restore: {},
            saveAsImage: {}
          }
        },
        xAxis: {
          type: "time",
          boundaryGap: false
        },
        yAxis: {
          type: "value",
          boundaryGap: [0, "100%"]
        },
        dataZoom: [{
          type: "inside",
          start: 0,
          end: 20
        }, {
          start: 0,
          end: 20
        }],
        series: [{
          name: "通信流量",
          type: "line",
          smooth: true,
          symbol: "none",
          areaStyle: {},
          data: data
        }]
      };
      myChart.setOption(option.value);
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(function () {
      (0,vue__WEBPACK_IMPORTED_MODULE_0__.nextTick)(function () {
        chartFun();
      });
    });
    var __returned__ = {
      get echarts() {
        return echarts;
      },
      set echarts(v) {
        echarts = v;
      },
      option: option,
      get base() {
        return base;
      },
      set base(v) {
        base = v;
      },
      get oneDay() {
        return oneDay;
      },
      set oneDay(v) {
        oneDay = v;
      },
      get data() {
        return data;
      },
      set data(v) {
        data = v;
      },
      chartFun: chartFun
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 63968:
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/graph/components/commutation.vue?vue&type=template&id=45f28dd4&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-45f28dd4"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  id: "chartBox"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1);
}

/***/ }),

/***/ 19058:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/graph/components/commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true */ 10153);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 73284:
/*!****************************************************!*\
  !*** ./src/pages/graph/components/commutation.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _commutation_vue_vue_type_template_id_45f28dd4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commutation.vue?vue&type=template&id=45f28dd4&scoped=true */ 11867);
/* harmony import */ var _commutation_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commutation.vue?vue&type=script&setup=true&lang=js */ 63904);
/* harmony import */ var _commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true */ 25660);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_commutation_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_commutation_vue_vue_type_template_id_45f28dd4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-45f28dd4"],['__file',"src/pages/graph/components/commutation.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 63904:
/*!***************************************************************************************!*\
  !*** ./src/pages/graph/components/commutation.vue?vue&type=script&setup=true&lang=js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_commutation_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_commutation_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./commutation.vue?vue&type=script&setup=true&lang=js */ 46005);
 

/***/ }),

/***/ 11867:
/*!**********************************************************************************************!*\
  !*** ./src/pages/graph/components/commutation.vue?vue&type=template&id=45f28dd4&scoped=true ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_commutation_vue_vue_type_template_id_45f28dd4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_commutation_vue_vue_type_template_id_45f28dd4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./commutation.vue?vue&type=template&id=45f28dd4&scoped=true */ 63968);


/***/ }),

/***/ 25660:
/*!*************************************************************************************************************!*\
  !*** ./src/pages/graph/components/commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_commutation_vue_vue_type_style_index_0_id_45f28dd4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./commutation.vue?vue&type=style&index=0&id=45f28dd4&lang=less&scoped=true */ 19058);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2dyYXBoX2NvbXBvbmVudHNfY29tbXV0YXRpb25fdnVlLjk0M2U3NWEyMTZkNjJmNjhmZWQ3LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDbUg7QUFDakI7QUFDbEcsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLHNFQUFzRSxxQkFBcUIsa0JBQWtCLGtCQUFrQixHQUFHLFNBQVMsMklBQTJJLFdBQVcsVUFBVSxVQUFVLHNDQUFzQyxxQkFBcUIsa0JBQWtCLGtCQUFrQixHQUFHLGdCQUFnQixxQkFBcUIsa0JBQWtCLGtCQUFrQixHQUFHLHFCQUFxQjtBQUN4ZjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QyxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLDJDQUFNO0FBQ3hCLGlCQUFpQix3Q0FBRztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhDQUFTO0FBQ2IsTUFBTSw2Q0FBUTtBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUN0R01BLEVBQUUsRUFBQztBQUFVOzsyREFBbEJDLHVEQUFBLENBQXlCLE9BQXpCQyxVQUF5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBM0IsTUFBd0c7QUFDeEcsTUFBOEY7QUFDOUYsTUFBcUc7QUFDckcsTUFBd0g7QUFDeEgsTUFBaUg7QUFDakgsTUFBaUg7QUFDakgsTUFBdVc7QUFDdlc7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx5U0FBTzs7OztBQUlpVDtBQUN6VSxPQUFPLGlFQUFlLHlTQUFPLElBQUksZ1RBQWMsR0FBRyxnVEFBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQk87QUFDWDtBQUNMOztBQUVwRSxDQUFtRjs7QUFFK0I7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsMkZBQU0sYUFBYSw4RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7QUN4QnVYIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9jb21tdXRhdGlvbi52dWU/ZDQ3ZiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9ncmFwaC9jb21wb25lbnRzL2NvbW11dGF0aW9uLnZ1ZT8wNGRjIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvY29tbXV0YXRpb24udnVlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvY29tbXV0YXRpb24udnVlP2UzYzEiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9jb21tdXRhdGlvbi52dWU/YjljMSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9ncmFwaC9jb21wb25lbnRzL2NvbW11dGF0aW9uLnZ1ZT9iZDA5Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvY29tbXV0YXRpb24udnVlPzFjOGQiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9jb21tdXRhdGlvbi52dWU/MDI2YyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIiNjaGFydEJveFtkYXRhLXYtNDVmMjhkZDRdIHtcXG4gIG1hcmdpbi10b3A6IDIwcHg7XFxuICB3aWR0aDogMTQwMHB4O1xcbiAgaGVpZ2h0OiA2MDBweDtcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvY29tbXV0YXRpb24udnVlXCIsXCJ3ZWJwYWNrOi8vLi9jb21tdXRhdGlvbi52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0FDQUZcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxuI2NoYXJ0Qm94IHtcXG4gIG1hcmdpbi10b3A6IDIwcHg7XFxuICB3aWR0aDogMTQwMHB4O1xcbiAgaGVpZ2h0OiA2MDBweDtcXG59XFxuXCIsXCIjY2hhcnRCb3gge1xcbiAgbWFyZ2luLXRvcDogMjBweDtcXG4gIHdpZHRoOiAxNDAwcHg7XFxuICBoZWlnaHQ6IDYwMHB4O1xcbn1cXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdjb21tdXRhdGlvbicsXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlO1xuICAgIGV4cG9zZSgpO1xuICAgIHZhciBlY2hhcnRzID0gaW5qZWN0KFwiZWNoYXJ0c1wiKTtcbiAgICB2YXIgb3B0aW9uID0gcmVmKHt9KTtcbiAgICB2YXIgYmFzZSA9ICtuZXcgRGF0ZSgxOTg4LCA5LCAzKTtcbiAgICB2YXIgb25lRGF5ID0gMjQgKiAzNjAwICogMTAwMDtcbiAgICB2YXIgZGF0YSA9IFtbYmFzZSwgTWF0aC5yYW5kb20oKSAqIDMwMF1dO1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgMjAwMDA7IGkrKykge1xuICAgICAgdmFyIG5vdyA9IG5ldyBEYXRlKGJhc2UgKz0gb25lRGF5KTtcbiAgICAgIGRhdGEucHVzaChbK25vdywgTWF0aC5yb3VuZCgoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAyMCArIGRhdGFbaSAtIDFdWzFdKV0pO1xuICAgIH1cbiAgICB2YXIgY2hhcnRGdW4gPSBmdW5jdGlvbiBjaGFydEZ1bigpIHtcbiAgICAgIHZhciBjaGFydERvbSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2hhcnRCb3hcIik7XG4gICAgICB2YXIgbXlDaGFydCA9IGVjaGFydHMuaW5pdChjaGFydERvbSk7XG4gICAgICBvcHRpb24udmFsdWUgPSB7XG4gICAgICAgIHRvb2x0aXA6IHtcbiAgICAgICAgICB0cmlnZ2VyOiBcImF4aXNcIixcbiAgICAgICAgICBwb3NpdGlvbjogZnVuY3Rpb24gcG9zaXRpb24ocHQpIHtcbiAgICAgICAgICAgIHJldHVybiBbcHRbMF0sIFwiMTAlXCJdO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICBsZWZ0OiBcImNlbnRlclwiLFxuICAgICAgICAgIHRleHQ6IFwi6YCa5L+h6K6w5b2VXCJcbiAgICAgICAgfSxcbiAgICAgICAgdG9vbGJveDoge1xuICAgICAgICAgIGZlYXR1cmU6IHtcbiAgICAgICAgICAgIGRhdGFab29tOiB7XG4gICAgICAgICAgICAgIHlBeGlzSW5kZXg6IFwibm9uZVwiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzdG9yZToge30sXG4gICAgICAgICAgICBzYXZlQXNJbWFnZToge31cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHhBeGlzOiB7XG4gICAgICAgICAgdHlwZTogXCJ0aW1lXCIsXG4gICAgICAgICAgYm91bmRhcnlHYXA6IGZhbHNlXG4gICAgICAgIH0sXG4gICAgICAgIHlBeGlzOiB7XG4gICAgICAgICAgdHlwZTogXCJ2YWx1ZVwiLFxuICAgICAgICAgIGJvdW5kYXJ5R2FwOiBbMCwgXCIxMDAlXCJdXG4gICAgICAgIH0sXG4gICAgICAgIGRhdGFab29tOiBbe1xuICAgICAgICAgIHR5cGU6IFwiaW5zaWRlXCIsXG4gICAgICAgICAgc3RhcnQ6IDAsXG4gICAgICAgICAgZW5kOiAyMFxuICAgICAgICB9LCB7XG4gICAgICAgICAgc3RhcnQ6IDAsXG4gICAgICAgICAgZW5kOiAyMFxuICAgICAgICB9XSxcbiAgICAgICAgc2VyaWVzOiBbe1xuICAgICAgICAgIG5hbWU6IFwi6YCa5L+h5rWB6YePXCIsXG4gICAgICAgICAgdHlwZTogXCJsaW5lXCIsXG4gICAgICAgICAgc21vb3RoOiB0cnVlLFxuICAgICAgICAgIHN5bWJvbDogXCJub25lXCIsXG4gICAgICAgICAgYXJlYVN0eWxlOiB7fSxcbiAgICAgICAgICBkYXRhOiBkYXRhXG4gICAgICAgIH1dXG4gICAgICB9O1xuICAgICAgbXlDaGFydC5zZXRPcHRpb24ob3B0aW9uLnZhbHVlKTtcbiAgICB9O1xuICAgIG9uTW91bnRlZChmdW5jdGlvbiAoKSB7XG4gICAgICBuZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNoYXJ0RnVuKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgZ2V0IGVjaGFydHMoKSB7XG4gICAgICAgIHJldHVybiBlY2hhcnRzO1xuICAgICAgfSxcbiAgICAgIHNldCBlY2hhcnRzKHYpIHtcbiAgICAgICAgZWNoYXJ0cyA9IHY7XG4gICAgICB9LFxuICAgICAgb3B0aW9uOiBvcHRpb24sXG4gICAgICBnZXQgYmFzZSgpIHtcbiAgICAgICAgcmV0dXJuIGJhc2U7XG4gICAgICB9LFxuICAgICAgc2V0IGJhc2Uodikge1xuICAgICAgICBiYXNlID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgb25lRGF5KCkge1xuICAgICAgICByZXR1cm4gb25lRGF5O1xuICAgICAgfSxcbiAgICAgIHNldCBvbmVEYXkodikge1xuICAgICAgICBvbmVEYXkgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBkYXRhKCkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgIH0sXG4gICAgICBzZXQgZGF0YSh2KSB7XG4gICAgICAgIGRhdGEgPSB2O1xuICAgICAgfSxcbiAgICAgIGNoYXJ0RnVuOiBjaGFydEZ1blxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsIjx0ZW1wbGF0ZT5cclxuICA8ZGl2IGlkPVwiY2hhcnRCb3hcIj48L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmxldCBlY2hhcnRzID0gaW5qZWN0KFwiZWNoYXJ0c1wiKTtcclxuY29uc3Qgb3B0aW9uID0gcmVmKHt9KTtcclxubGV0IGJhc2UgPSArbmV3IERhdGUoMTk4OCwgOSwgMyk7XHJcbmxldCBvbmVEYXkgPSAyNCAqIDM2MDAgKiAxMDAwO1xyXG5sZXQgZGF0YSA9IFtbYmFzZSwgTWF0aC5yYW5kb20oKSAqIDMwMF1dO1xyXG5mb3IgKGxldCBpID0gMTsgaSA8IDIwMDAwOyBpKyspIHtcclxuICBsZXQgbm93ID0gbmV3IERhdGUoKGJhc2UgKz0gb25lRGF5KSk7XHJcbiAgZGF0YS5wdXNoKFsrbm93LCBNYXRoLnJvdW5kKChNYXRoLnJhbmRvbSgpIC0gMC41KSAqIDIwICsgZGF0YVtpIC0gMV1bMV0pXSk7XHJcbn1cclxuXHJcbmNvbnN0IGNoYXJ0RnVuID0gKCkgPT4ge1xyXG4gIGNvbnN0IGNoYXJ0RG9tID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjaGFydEJveFwiKTtcclxuICBjb25zdCBteUNoYXJ0ID0gZWNoYXJ0cy5pbml0KGNoYXJ0RG9tKTtcclxuICBvcHRpb24udmFsdWUgPSB7XHJcbiAgICB0b29sdGlwOiB7XHJcbiAgICAgIHRyaWdnZXI6IFwiYXhpc1wiLFxyXG4gICAgICBwb3NpdGlvbjogZnVuY3Rpb24gKHB0KSB7XHJcbiAgICAgICAgcmV0dXJuIFtwdFswXSwgXCIxMCVcIl07XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgbGVmdDogXCJjZW50ZXJcIixcclxuICAgICAgdGV4dDogXCLpgJrkv6HorrDlvZVcIixcclxuICAgIH0sXHJcbiAgICB0b29sYm94OiB7XHJcbiAgICAgIGZlYXR1cmU6IHtcclxuICAgICAgICBkYXRhWm9vbToge1xyXG4gICAgICAgICAgeUF4aXNJbmRleDogXCJub25lXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICByZXN0b3JlOiB7fSxcclxuICAgICAgICBzYXZlQXNJbWFnZToge30sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgeEF4aXM6IHtcclxuICAgICAgdHlwZTogXCJ0aW1lXCIsXHJcbiAgICAgIGJvdW5kYXJ5R2FwOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICB5QXhpczoge1xyXG4gICAgICB0eXBlOiBcInZhbHVlXCIsXHJcbiAgICAgIGJvdW5kYXJ5R2FwOiBbMCwgXCIxMDAlXCJdLFxyXG4gICAgfSxcclxuICAgIGRhdGFab29tOiBbXHJcbiAgICAgIHtcclxuICAgICAgICB0eXBlOiBcImluc2lkZVwiLFxyXG4gICAgICAgIHN0YXJ0OiAwLFxyXG4gICAgICAgIGVuZDogMjAsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBzdGFydDogMCxcclxuICAgICAgICBlbmQ6IDIwLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICAgIHNlcmllczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogXCLpgJrkv6HmtYHph49cIixcclxuICAgICAgICB0eXBlOiBcImxpbmVcIixcclxuICAgICAgICBzbW9vdGg6IHRydWUsXHJcbiAgICAgICAgc3ltYm9sOiBcIm5vbmVcIixcclxuICAgICAgICBhcmVhU3R5bGU6IHt9LFxyXG4gICAgICAgIGRhdGE6IGRhdGEsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH07XHJcbiAgbXlDaGFydC5zZXRPcHRpb24ob3B0aW9uLnZhbHVlKTtcclxufTtcclxuXHJcbm9uTW91bnRlZCgoKSA9PiB7XHJcbiAgbmV4dFRpY2soKCkgPT4ge1xyXG4gICAgY2hhcnRGdW4oKTtcclxuICB9KTtcclxufSk7XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4jY2hhcnRCb3gge1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgd2lkdGg6IDE0MDBweDtcclxuICBoZWlnaHQ6IDYwMHB4O1xyXG59XHJcbjwvc3R5bGU+XHJcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2NvbW11dGF0aW9uLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ1ZjI4ZGQ0Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD00NWYyOGRkNCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDVmMjhkZDQmc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vY29tbXV0YXRpb24udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NDVmMjhkZDQmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtNDVmMjhkZDRcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvY29tbXV0YXRpb24udnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcIjQ1ZjI4ZGQ0XCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnNDVmMjhkZDQnLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCc0NWYyOGRkNCcsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vY29tbXV0YXRpb24udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTQ1ZjI4ZGQ0JnNjb3BlZD10cnVlXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJzQ1ZjI4ZGQ0JywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2NvbW11dGF0aW9uLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vY29tbXV0YXRpb24udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTQ1ZjI4ZGQ0JnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9jb21tdXRhdGlvbi52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD00NWYyOGRkNCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIiJdLCJuYW1lcyI6WyJpZCIsIl9jcmVhdGVFbGVtZW50QmxvY2siLCJfaG9pc3RlZF8xIl0sInNvdXJjZVJvb3QiOiIifQ==