"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_business_components_businessList_vue"],{

/***/ 98906:
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".exhibition[data-v-7826de0c] {\n  position: relative;\n  height: 100%;\n  padding-bottom: 50px;\n}\n.search[data-v-7826de0c] {\n  padding: 10px;\n}\n.search .el-input[data-v-7826de0c],\n.search .el-select[data-v-7826de0c] {\n  width: 240px;\n  margin-right: 20px;\n}\n.table[data-v-7826de0c] {\n  padding: 10px;\n  display: grid;\n}\n.pagination[data-v-7826de0c] {\n  height: 30px;\n  position: absolute;\n  bottom: 20px;\n  right: 0px;\n  margin-right: 30px;\n}\n.operaIcon[data-v-7826de0c] {\n  width: 16px;\n  height: 16px;\n  margin-right: 10px;\n  cursor: pointer;\n}\n.operaIcon[data-v-7826de0c]:hover {\n  color: var(--text-color2);\n}\n", "",{"version":3,"sources":["webpack://./src/pages/business/components/businessList.vue","webpack://./businessList.vue"],"names":[],"mappings":"AACA;EACE,kBAAA;EACA,YAAA;EACA,oBAAA;ACAF;ADEA;EACE,aAAA;ACAF;ADDA;;EAII,YAAA;EACA,kBAAA;ACCJ;ADGA;EACE,aAAA;EAEA,aAAA;ACFF;ADIA;EACE,YAAA;EACA,kBAAA;EACA,YAAA;EACA,UAAA;EACA,kBAAA;ACFF;ADIA;EACE,WAAA;EACA,YAAA;EACA,kBAAA;EACA,eAAA;ACFF;ADIA;EACE,yBAAA;ACFF","sourcesContent":["\n.exhibition {\n  position: relative;\n  height: 100%;\n  padding-bottom: 50px;\n}\n.search {\n  padding: 10px;\n  .el-input,\n  .el-select {\n    width: 240px;\n    margin-right: 20px;\n  }\n}\n\n.table {\n  padding: 10px;\n  // max-height: 400px;\n  display: grid;\n}\n.pagination {\n  height: 30px;\n  position: absolute;\n  bottom: 20px;\n  right: 0px;\n  margin-right: 30px;\n}\n.operaIcon {\n  width: 16px;\n  height: 16px;\n  margin-right: 10px;\n  cursor: pointer;\n}\n.operaIcon:hover {\n  color: var(--text-color2);\n}\n",".exhibition {\n  position: relative;\n  height: 100%;\n  padding-bottom: 50px;\n}\n.search {\n  padding: 10px;\n}\n.search .el-input,\n.search .el-select {\n  width: 240px;\n  margin-right: 20px;\n}\n.table {\n  padding: 10px;\n  display: grid;\n}\n.pagination {\n  height: 30px;\n  position: absolute;\n  bottom: 20px;\n  right: 0px;\n  margin-right: 30px;\n}\n.operaIcon {\n  width: 16px;\n  height: 16px;\n  margin-right: 10px;\n  cursor: pointer;\n}\n.operaIcon:hover {\n  color: var(--text-color2);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 40048:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/businessList.vue?vue&type=script&setup=true&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var _components_creatRisk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/creatRisk */ 55473);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/dictionaries/business.json */ 56789);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ 62494);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'businessList',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    var dialogFormVisible = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(false);
    var formLabelWidth = "140px";
    var tableData = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)([]);
    var total = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(0);
    // console.log(dirct, "值");
    var dialogVisible = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(false);
    var activeRowid = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var creatRisk = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var form = (0,vue__WEBPACK_IMPORTED_MODULE_4__.reactive)({
      name: "",
      region: "",
      date1: "",
      date2: "",
      delivery: false,
      type: [],
      resource: "",
      desc: ""
    });
    var query = (0,vue__WEBPACK_IMPORTED_MODULE_4__.reactive)({
      name: "",
      user: "",
      status: ""
    });
    var pageSize = 10;
    var currentPage = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(1);
    var filterUtils = function filterUtils(value, flag) {
      return _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__[flag].find(function (item) {
        return item.value == value;
      }).label;
    };
    var options = [{
      value: 1,
      label: "运营"
    }, {
      value: 2,
      label: "审批"
    }, {
      value: 3,
      label: "冻结"
    }];
    var jumpAdd = function jumpAdd() {
      router.push({
        name: "newBusiness"
      });
    };
    var buttons = [{
      type: "",
      text: "编辑",
      value: "edit"
    }, {
      type: "",
      text: "删除",
      value: "delete"
    }];
    var reqList = function reqList() {
      var postData = {
        queryData: (0,vue__WEBPACK_IMPORTED_MODULE_4__.toRaw)(query),
        pageSize: pageSize,
        currentPage: currentPage.value
      };
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/business/list"), postData).then(function (res) {
        if (res.code === 200) {
          tableData.value = res.data.list;
          total.value = res.data.total;
        }
      });
    };
    var jumpEdit = function jumpEdit(value) {
      router.push({
        name: "businessEdit",
        query: {
          id: value.id
        }
      });
    };
    var deleteDialog = function deleteDialog(row) {
      activeRowid.value = row.id;
      dialogVisible.value = true;
    };
    var sure = function sure() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/business/delete"), {
        id: activeRowid.value
      }).then(function (res) {
        if (res.message === "success") {
          (0,element_plus__WEBPACK_IMPORTED_MODULE_6__.ElMessage)({
            type: "success",
            message: "删除成功"
          });
          cancel();
        }
      });
    };
    var cancel = function cancel() {
      dialogVisible.value = false;
      reqList();
    };
    var openRisk = function openRisk(record) {
      creatRisk.value.openDialog(record);
    };
    var addRiskSuccess = function addRiskSuccess() {
      reqList();
    };
    var test1 = function test1() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__["default"].get("/api/app/person/list").then(function (res) {
        console.log(res, "结果");
      });
    };
    var test2 = function test2() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__["default"].get("/newApi/app/person/list").then(function (res) {
        console.log(res, "结果");
      });
    };
    reqList();
    var __returned__ = {
      router: router,
      dialogFormVisible: dialogFormVisible,
      formLabelWidth: formLabelWidth,
      tableData: tableData,
      total: total,
      dialogVisible: dialogVisible,
      activeRowid: activeRowid,
      creatRisk: creatRisk,
      form: form,
      get query() {
        return query;
      },
      set query(v) {
        query = v;
      },
      get pageSize() {
        return pageSize;
      },
      set pageSize(v) {
        pageSize = v;
      },
      get currentPage() {
        return currentPage;
      },
      set currentPage(v) {
        currentPage = v;
      },
      filterUtils: filterUtils,
      options: options,
      jumpAdd: jumpAdd,
      buttons: buttons,
      reqList: reqList,
      jumpEdit: jumpEdit,
      deleteDialog: deleteDialog,
      sure: sure,
      cancel: cancel,
      openRisk: openRisk,
      addRiskSuccess: addRiskSuccess,
      test1: test1,
      test2: test2,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get Delete() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_7__.Delete;
      },
      get Edit() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_7__.Edit;
      },
      get WarnTriangleFilled() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_7__.WarnTriangleFilled;
      },
      get CreatRisk() {
        return _components_creatRisk__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_5__.useRouter;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_2__["default"];
      },
      get dirct() {
        return _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__;
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_6__.ElMessage;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 20321:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/businessList.vue?vue&type=template&id=7826de0c&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-7826de0c"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "exhibition"
};
var _hoisted_2 = {
  "class": "search"
};
var _hoisted_3 = {
  "class": "table"
};
var _hoisted_4 = {
  "class": "pagination"
};
var _hoisted_5 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "确定要删除这条资产吗?", -1 /* HOISTED */);
});
var _hoisted_6 = {
  "class": "dialog-footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_link = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-link");
  var _component_el_table_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table-column");
  var _component_el_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table");
  var _component_el_pagination = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-pagination");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  var _directive_btnRole = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveDirective)("btnRole");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    modelValue: $setup.query.name,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return $setup.query.name = $event;
    }),
    modelModifiers: {
      trim: true
    },
    placeholder: "输入业务领域名称",
    label: "业务领域名称",
    clearable: "",
    onChange: $setup.reqList
  }, null, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    modelValue: $setup.query.user,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
      return $setup.query.user = $event;
    }),
    modelModifiers: {
      trim: true
    },
    placeholder: "输入相关负责人",
    label: "相关负责人",
    clearable: "",
    onChange: $setup.reqList
  }, null, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
    modelValue: $setup.query.status,
    "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
      return $setup.query.status = $event;
    }),
    "class": "m-2",
    placeholder: "选择资产状态",
    onChange: $setup.reqList,
    clearable: ""
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.options, function (item) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_option, {
          key: item.value,
          label: item.label,
          value: item.value
        }, null, 8 /* PROPS */, ["label", "value"]);
      }), 64 /* STABLE_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.reqList
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("查询")];
    }),
    _: 1 /* STABLE */
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)(((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
    type: "primary",
    onClick: $setup.jumpAdd
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("新增")];
    }),
    _: 1 /* STABLE */
  })), [[_directive_btnRole, 'newBusiness']]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    onClick: $setup.test1
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("测试1")];
    }),
    _: 1 /* STABLE */
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    onClick: $setup.test2
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("测试2")];
    }),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table, {
    data: $setup.tableData,
    style: {
      "width": "100%"
    },
    border: true,
    stripe: ""
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "英文名称",
        width: "240",
        fixed: "left"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_link, {
            type: "primary"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row.name), 1 /* TEXT */)];
            }),

            _: 2 /* DYNAMIC */
          }, 1024 /* DYNAMIC_SLOTS */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        prop: "cname",
        label: "中文名称",
        width: "240"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        prop: "user",
        label: "负责人",
        width: "180"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <template #default=\"scope\">\r\n            <span>{{ filterUtils(scope.row.user, \"user\") }}</span>\r\n          </template> ")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        prop: "status",
        label: "状态",
        width: "width"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.filterUtils(scope.row.status, "status")), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <el-table-column prop=\"entiry\" label=\"关联实体\">\r\n          <template #default=\"scope\">\r\n            <span>{{ filterUtils(scope.row.entiry, \"entiry\") }}</span>\r\n          </template>\r\n        </el-table-column> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        prop: "uuid",
        label: "业务领域编号",
        width: "400"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        prop: "time",
        label: "最后操作时间",
        width: "240"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "操作",
        fixed: "right",
        width: "250"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)(((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
            type: "primary",
            link: "",
            onClick: function onClick($event) {
              return $setup.jumpEdit(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 编辑 ")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])), [[_directive_btnRole, 'businessEdit']]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)(((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
            type: "danger",
            link: "",
            onClick: function onClick($event) {
              return $setup.deleteDialog(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 删除 ")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])), [[_directive_btnRole, 'businessEdit']]), !scope.row.isRisk ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
            key: 0,
            type: "warning",
            link: "",
            onClick: function onClick($event) {
              return $setup.openRisk(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 标记风险 ")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_pagination, {
    small: "",
    background: "",
    layout: "prev, pager, next, jumper, ->, total",
    total: $setup.total,
    "class": "mt-4",
    "page-size": $setup.pageSize,
    "onUpdate:pageSize": _cache[3] || (_cache[3] = function ($event) {
      return $setup.pageSize = $event;
    }),
    "current-page": $setup.currentPage,
    "onUpdate:currentPage": _cache[4] || (_cache[4] = function ($event) {
      return $setup.currentPage = $event;
    }),
    onSizeChange: $setup.reqList,
    onCurrentChange: $setup.reqList,
    onPrevClick: $setup.reqList,
    onNextClick: $setup.reqList
  }, {
    "pager-text": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, "共 " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.total) + " 条数据", 1 /* TEXT */)];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["total", "page-size", "current-page"])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_dialog, {
    modelValue: $setup.dialogVisible,
    "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
      return $setup.dialogVisible = $event;
    }),
    title: "删除",
    width: "30%"
  }, {
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: $setup.cancel
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        type: "primary",
        onClick: $setup.sure
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("确定")];
        }),
        _: 1 /* STABLE */
      })])];
    }),

    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [_hoisted_5];
    }),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["CreatRisk"], {
    ref: "creatRisk",
    onAddRiskSuccess: $setup.addRiskSuccess
  }, null, 512 /* NEED_PATCH */)], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 55688:
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true */ 98906);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 60447:
/*!********************************************************!*\
  !*** ./src/pages/business/components/businessList.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _businessList_vue_vue_type_template_id_7826de0c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./businessList.vue?vue&type=template&id=7826de0c&scoped=true */ 70944);
/* harmony import */ var _businessList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./businessList.vue?vue&type=script&setup=true&lang=js */ 53713);
/* harmony import */ var _businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true */ 83338);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_businessList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_businessList_vue_vue_type_template_id_7826de0c_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-7826de0c"],['__file',"src/pages/business/components/businessList.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 53713:
/*!*******************************************************************************************!*\
  !*** ./src/pages/business/components/businessList.vue?vue&type=script&setup=true&lang=js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_businessList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_businessList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./businessList.vue?vue&type=script&setup=true&lang=js */ 40048);
 

/***/ }),

/***/ 70944:
/*!**************************************************************************************************!*\
  !*** ./src/pages/business/components/businessList.vue?vue&type=template&id=7826de0c&scoped=true ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_businessList_vue_vue_type_template_id_7826de0c_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_businessList_vue_vue_type_template_id_7826de0c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./businessList.vue?vue&type=template&id=7826de0c&scoped=true */ 20321);


/***/ }),

/***/ 83338:
/*!*****************************************************************************************************************!*\
  !*** ./src/pages/business/components/businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_businessList_vue_vue_type_style_index_0_id_7826de0c_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./businessList.vue?vue&type=style&index=0&id=7826de0c&lang=less&scoped=true */ 55688);


/***/ }),

/***/ 56789:
/*!****************************************!*\
  !*** ./src/dictionaries/business.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"status":[{"value":"1","label":"运营"},{"value":"2","label":"审核"},{"value":"3","label":"冻结"}],"user":[{"label":"王惊涛","value":"wjt"},{"label":"马师","value":"ms"}],"entiry":[{"label":"长城汽车","value":"1"},{"label":"富士康","value":"2"}],"type":[{"label":"金融资产","value":"1"},{"label":"不动产","value":"2"},{"label":"移动资产","value":"3"},{"label":"知识产权","value":"4"},{"label":"文艺资产","value":"5"},{"label":"公共基础设施","value":"6"}],"typeOptions":[{"value":1,"label":"精品"},{"value":2,"label":"标准"},{"value":3,"label":"草稿"}]}');

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2J1c2luZXNzX2NvbXBvbmVudHNfYnVzaW5lc3NMaXN0X3Z1ZS4xY2M3ODg4NDc5MDdmMWFhMjQyMS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ21IO0FBQ2pCO0FBQ2xHLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSx3RUFBd0UsdUJBQXVCLGlCQUFpQix5QkFBeUIsR0FBRyw0QkFBNEIsa0JBQWtCLEdBQUcsNEVBQTRFLGlCQUFpQix1QkFBdUIsR0FBRywyQkFBMkIsa0JBQWtCLGtCQUFrQixHQUFHLGdDQUFnQyxpQkFBaUIsdUJBQXVCLGlCQUFpQixlQUFlLHVCQUF1QixHQUFHLCtCQUErQixnQkFBZ0IsaUJBQWlCLHVCQUF1QixvQkFBb0IsR0FBRyxxQ0FBcUMsOEJBQThCLEdBQUcsU0FBUyxnSkFBZ0osV0FBVyxVQUFVLFdBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxNQUFNLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSyxVQUFVLFdBQVcsVUFBVSxVQUFVLFdBQVcsS0FBSyxLQUFLLFVBQVUsVUFBVSxXQUFXLFVBQVUsS0FBSyxLQUFLLFdBQVcsd0NBQXdDLHVCQUF1QixpQkFBaUIseUJBQXlCLEdBQUcsV0FBVyxrQkFBa0IsOEJBQThCLG1CQUFtQix5QkFBeUIsS0FBSyxHQUFHLFlBQVksa0JBQWtCLHlCQUF5QixrQkFBa0IsR0FBRyxlQUFlLGlCQUFpQix1QkFBdUIsaUJBQWlCLGVBQWUsdUJBQXVCLEdBQUcsY0FBYyxnQkFBZ0IsaUJBQWlCLHVCQUF1QixvQkFBb0IsR0FBRyxvQkFBb0IsOEJBQThCLEdBQUcsa0JBQWtCLHVCQUF1QixpQkFBaUIseUJBQXlCLEdBQUcsV0FBVyxrQkFBa0IsR0FBRywwQ0FBMEMsaUJBQWlCLHVCQUF1QixHQUFHLFVBQVUsa0JBQWtCLGtCQUFrQixHQUFHLGVBQWUsaUJBQWlCLHVCQUF1QixpQkFBaUIsZUFBZSx1QkFBdUIsR0FBRyxjQUFjLGdCQUFnQixpQkFBaUIsdUJBQXVCLG9CQUFvQixHQUFHLG9CQUFvQiw4QkFBOEIsR0FBRyxxQkFBcUI7QUFDM25FO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUFE7QUFDNEI7QUFDNUI7QUFDUjtBQUNJO0FBQ007QUFDUjs7O0FBQ3pDLGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIscURBQVM7QUFDMUIsNEJBQTRCLHdDQUFHO0FBQy9CO0FBQ0Esb0JBQW9CLHdDQUFHO0FBQ3ZCLGdCQUFnQix3Q0FBRztBQUNuQjtBQUNBLHdCQUF3Qix3Q0FBRztBQUMzQixzQkFBc0Isd0NBQUc7QUFDekIsb0JBQW9CLHdDQUFHO0FBQ3ZCLGVBQWUsNkNBQVE7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFRO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isd0NBQUc7QUFDekI7QUFDQSxhQUFhLHdEQUFLO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsMENBQUs7QUFDeEI7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLFVBQVUsdURBQVM7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSwrREFBVztBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sK0RBQVc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHdEQUFPO0FBQ3RCO0FBQ0E7QUFDQSxlQUFlLDJEQUFNO0FBQ3JCO0FBQ0E7QUFDQSxlQUFlLHlEQUFJO0FBQ25CO0FBQ0E7QUFDQSxlQUFlLHVFQUFrQjtBQUNqQztBQUNBO0FBQ0EsZUFBZSw2REFBUztBQUN4QjtBQUNBO0FBQ0EsZUFBZSxpREFBUztBQUN4QjtBQUNBO0FBQ0EsZUFBZSwyREFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSx3REFBSztBQUNwQjtBQUNBO0FBQ0EsZUFBZSxtREFBUztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUN4TU0sU0FBTTtBQUFZOztFQUNoQixTQUFNO0FBQVE7O0VBb0NkLFNBQU07QUFBTzs7RUF1RGIsU0FBTTtBQUFZOztzQkFxQnZCQSx1REFBQSxDQUF3QixjQUFsQixhQUFXO0FBQUE7O0VBRVQsU0FBTTtBQUFlOzs7Ozs7Ozs7Ozs7cUtBbkgvQkEsdURBQUEsQ0ErR00sT0EvR05DLFVBK0dNLEdBOUdKRCx1REFBQSxDQW1DTSxPQW5DTkUsVUFtQ00sR0FsQ0pDLGdEQUFBLENBTUVDLG1CQUFBO2dCQUxjQyxNQUFBLENBQUFDLEtBQUssQ0FBQ0MsSUFBSTs7YUFBVkYsTUFBQSxDQUFBQyxLQUFLLENBQUNDLElBQUksR0FBQUMsTUFBQTtJQUFBO29CQUF4QjtNQUFBQyxJQUFBO0lBQUEsQ0FBeUI7SUFDekJDLFdBQVcsRUFBQyxVQUFVO0lBQ3RCQyxLQUFLLEVBQUMsUUFBUTtJQUNkQyxTQUFTLEVBQVQsRUFBUztJQUNSQyxRQUFNLEVBQUVSLE1BQUEsQ0FBQVM7MkNBRVhYLGdEQUFBLENBTUVDLG1CQUFBO2dCQUxjQyxNQUFBLENBQUFDLEtBQUssQ0FBQ1MsSUFBSTs7YUFBVlYsTUFBQSxDQUFBQyxLQUFLLENBQUNTLElBQUksR0FBQVAsTUFBQTtJQUFBO29CQUF4QjtNQUFBQyxJQUFBO0lBQUEsQ0FBeUI7SUFDekJDLFdBQVcsRUFBQyxTQUFTO0lBQ3JCQyxLQUFLLEVBQUMsT0FBTztJQUNiQyxTQUFTLEVBQVQsRUFBUztJQUNSQyxRQUFNLEVBQUVSLE1BQUEsQ0FBQVM7MkNBRVhYLGdEQUFBLENBYVlhLG9CQUFBO2dCQVpEWCxNQUFBLENBQUFDLEtBQUssQ0FBQ1csTUFBTTs7YUFBWlosTUFBQSxDQUFBQyxLQUFLLENBQUNXLE1BQU0sR0FBQVQsTUFBQTtJQUFBO0lBQ3JCLFNBQU0sS0FBSztJQUNYRSxXQUFXLEVBQUMsUUFBUTtJQUNuQkcsUUFBTSxFQUFFUixNQUFBLENBQUFTLE9BQU87SUFDaEJGLFNBQVMsRUFBVDs7NERBR0U7TUFBQSxPQUF1QixvREFEekJNLHVEQUFBLENBS0VDLHlDQUFBLFFBQUFDLCtDQUFBLENBSmVmLE1BQUEsQ0FBQWdCLE9BQU8sWUFBZkMsSUFBSTtlQURibkIsZ0RBQUEsQ0FLRW9CLG9CQUFBO1VBSENDLEdBQUcsRUFBRUYsSUFBSSxDQUFDRyxLQUFLO1VBQ2ZkLEtBQUssRUFBRVcsSUFBSSxDQUFDWCxLQUFLO1VBQ2pCYyxLQUFLLEVBQUVILElBQUksQ0FBQ0c7Ozs7OztxQ0FHakJ0QixnREFBQSxDQUF5RHVCLG9CQUFBO0lBQTlDQyxJQUFJLEVBQUMsU0FBUztJQUFFQyxPQUFLLEVBQUV2QixNQUFBLENBQUFTOzs0REFBUztNQUFBLE9BQUUsc0RBQUYsSUFBRTs7OzZHQUM3Q2UsZ0RBQUEsQ0FFQ0gsb0JBQUE7SUFGVUMsSUFBSSxFQUFDLFNBQVM7SUFBRUMsT0FBSyxFQUFFdkIsTUFBQSxDQUFBeUI7OzREQUMvQjtNQUFBLE9BQUUsc0RBQUYsSUFBRTs7OzZCQURpRCxhQUFhLEtBR25FM0IsZ0RBQUEsQ0FBeUN1QixvQkFBQTtJQUE3QkUsT0FBSyxFQUFFdkIsTUFBQSxDQUFBMEI7RUFBSzs0REFBRTtNQUFBLE9BQUcsc0RBQUgsS0FBRzs7O01BQzdCNUIsZ0RBQUEsQ0FBeUN1QixvQkFBQTtJQUE3QkUsT0FBSyxFQUFFdkIsTUFBQSxDQUFBMkI7RUFBSzs0REFBRTtNQUFBLE9BQUcsc0RBQUgsS0FBRzs7O1FBRS9CaEMsdURBQUEsQ0FzRE0sT0F0RE5pQyxVQXNETSxHQXJESjlCLGdEQUFBLENBb0RXK0IsbUJBQUE7SUFwREFDLElBQUksRUFBRTlCLE1BQUEsQ0FBQStCLFNBQVM7SUFBRUMsS0FBbUIsRUFBbkI7TUFBQTtJQUFBLENBQW1CO0lBQUVDLE1BQU0sRUFBRSxJQUFJO0lBQUVDLE1BQU0sRUFBTjs7NERBQzdEO01BQUEsT0FJa0IsQ0FKbEJwQyxnREFBQSxDQUlrQnFDLDBCQUFBO1FBSkQ3QixLQUFLLEVBQUMsTUFBTTtRQUFDOEIsS0FBSyxFQUFDLEtBQUs7UUFBQ0MsS0FBSyxFQUFDOztRQUNuQyxXQUFPQyw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztVQUFBLFFBQ3ZCekMsZ0RBQUEsQ0FBc0QwQyxrQkFBQTtZQUE3Q2xCLElBQUksRUFBQztVQUFTO29FQUFDO2NBQUEsT0FBb0IsMkdBQWpCaUIsS0FBSyxDQUFDRSxHQUFHLENBQUN2QyxJQUFJOzs7Ozs7OztVQUc3Q0osZ0RBQUEsQ0FBeURxQywwQkFBQTtRQUF4Q08sSUFBSSxFQUFDLE9BQU87UUFBQ3BDLEtBQUssRUFBQyxNQUFNO1FBQUM4QixLQUFLLEVBQUM7VUFDakR0QyxnREFBQSxDQUlrQnFDLDBCQUFBO1FBSkRPLElBQUksRUFBQyxNQUFNO1FBQUNwQyxLQUFLLEVBQUMsS0FBSztRQUFDOEIsS0FBSyxFQUFDOztnRUFDN0M7VUFBQSxPQUVlLENBRmZPLHVEQUFBLG9JQUVlOzs7VUFFakI3QyxnREFBQSxDQUlrQnFDLDBCQUFBO1FBSkRPLElBQUksRUFBQyxRQUFRO1FBQUNwQyxLQUFLLEVBQUMsSUFBSTtRQUFDOEIsS0FBSyxFQUFDOztRQUNuQyxXQUFPRSw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztVQUFBLFFBQ3ZCNUMsdURBQUEsQ0FBMEQsY0FBQWlELG9EQUFBLENBQWpENUMsTUFBQSxDQUFBNkMsV0FBVyxDQUFDTixLQUFLLENBQUNFLEdBQUcsQ0FBQzdCLE1BQU07Ozs7VUFHekMrQix1REFBQSxvT0FJc0IsRUFDdEI3QyxnREFBQSxDQUEwRHFDLDBCQUFBO1FBQXpDTyxJQUFJLEVBQUMsTUFBTTtRQUFDcEMsS0FBSyxFQUFDLFFBQVE7UUFBQzhCLEtBQUssRUFBQztVQUNsRHRDLGdEQUFBLENBQTBEcUMsMEJBQUE7UUFBekNPLElBQUksRUFBQyxNQUFNO1FBQUNwQyxLQUFLLEVBQUMsUUFBUTtRQUFDOEIsS0FBSyxFQUFDO1VBQ2xEdEMsZ0RBQUEsQ0EyQmtCcUMsMEJBQUE7UUEzQkQ3QixLQUFLLEVBQUMsSUFBSTtRQUFDK0IsS0FBSyxFQUFDLE9BQU87UUFBQ0QsS0FBSyxFQUFDOztRQUNuQyxXQUFPRSw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztVQUFBLCtHQUN2QmYsZ0RBQUEsQ0FPWUgsb0JBQUE7WUFOVkMsSUFBSSxFQUFDLFNBQVM7WUFDZHdCLElBQUksRUFBSixFQUFJO1lBQ0h2QixPQUFLLFdBQUFBLFFBQUFwQixNQUFBO2NBQUEsT0FBRUgsTUFBQSxDQUFBK0MsUUFBUSxDQUFDUixLQUFLLENBQUNFLEdBQUc7WUFBQTs7b0VBRTNCO2NBQUEsT0FFRCxzREFGQyxNQUVEOzs7bUZBSGEsY0FBYyw0R0FJM0JqQixnREFBQSxDQU9ZSCxvQkFBQTtZQU5WQyxJQUFJLEVBQUMsUUFBUTtZQUNid0IsSUFBSSxFQUFKLEVBQUk7WUFDSHZCLE9BQUssV0FBQUEsUUFBQXBCLE1BQUE7Y0FBQSxPQUFFSCxNQUFBLENBQUFnRCxZQUFZLENBQUNULEtBQUssQ0FBQ0UsR0FBRztZQUFBOztvRUFFL0I7Y0FBQSxPQUVELHNEQUZDLE1BRUQ7OzttRkFIYSxjQUFjLE1BS2xCRixLQUFLLENBQUNFLEdBQUcsQ0FBQ1EsTUFBTSxzREFEekJ6QixnREFBQSxDQU9ZSCxvQkFBQTs7WUFMVkMsSUFBSSxFQUFDLFNBQVM7WUFDZHdCLElBQUksRUFBSixFQUFJO1lBQ0h2QixPQUFLLFdBQUFBLFFBQUFwQixNQUFBO2NBQUEsT0FBRUgsTUFBQSxDQUFBa0QsUUFBUSxDQUFDWCxLQUFLLENBQUNFLEdBQUc7WUFBQTs7b0VBQzNCO2NBQUEsT0FFRCxzREFGQyxRQUVEOzs7Ozs7Ozs7O2lDQUtSOUMsdURBQUEsQ0FrQk0sT0FsQk53RCxVQWtCTSxHQWpCSnJELGdEQUFBLENBZ0JnQnNELHdCQUFBO0lBZmRDLEtBQUssRUFBTCxFQUFLO0lBQ0xDLFVBQVUsRUFBVixFQUFVO0lBQ1ZDLE1BQU0sRUFBQyxzQ0FBc0M7SUFDNUNDLEtBQUssRUFBRXhELE1BQUEsQ0FBQXdELEtBQUs7SUFDYixTQUFNLE1BQU07SUFDSixXQUFTLEVBQUV4RCxNQUFBLENBQUF5RCxRQUFROzthQUFSekQsTUFBQSxDQUFBeUQsUUFBUSxHQUFBdEQsTUFBQTtJQUFBO0lBQ25CLGNBQVksRUFBRUgsTUFBQSxDQUFBMEQsV0FBVzs7YUFBWDFELE1BQUEsQ0FBQTBELFdBQVcsR0FBQXZELE1BQUE7SUFBQTtJQUNoQ3dELFlBQVcsRUFBRTNELE1BQUEsQ0FBQVMsT0FBTztJQUNwQm1ELGVBQWMsRUFBRTVELE1BQUEsQ0FBQVMsT0FBTztJQUN2Qm9ELFdBQVUsRUFBRTdELE1BQUEsQ0FBQVMsT0FBTztJQUNuQnFELFdBQVUsRUFBRTlELE1BQUEsQ0FBQVM7O0lBRUYsWUFBVSxFQUFBNkIsNENBQUEsQ0FDbkI7TUFBQSxPQUE4QixDQUE5QjNDLHVEQUFBLENBQThCLGNBQXhCLElBQUUsR0FBQWlELG9EQUFBLENBQUc1QyxNQUFBLENBQUF3RCxLQUFLLElBQUcsTUFBSTs7OztpRUFLL0IxRCxnREFBQSxDQVFZaUUsb0JBQUE7Z0JBUlEvRCxNQUFBLENBQUFnRSxhQUFhOzthQUFiaEUsTUFBQSxDQUFBZ0UsYUFBYSxHQUFBN0QsTUFBQTtJQUFBO0lBQUU4RCxLQUFLLEVBQUMsSUFBSTtJQUFDN0IsS0FBSyxFQUFDOztJQUV2QzhCLE1BQU0sRUFBQTVCLDRDQUFBLENBQ2Y7TUFBQSxPQUdPLENBSFAzQyx1REFBQSxDQUdPLFFBSFB3RSxVQUdPLEdBRkxyRSxnREFBQSxDQUF5Q3VCLG9CQUFBO1FBQTdCRSxPQUFLLEVBQUV2QixNQUFBLENBQUFvRTtNQUFNO2dFQUFFO1VBQUEsT0FBRSxzREFBRixJQUFFOzs7VUFDN0J0RSxnREFBQSxDQUFzRHVCLG9CQUFBO1FBQTNDQyxJQUFJLEVBQUMsU0FBUztRQUFFQyxPQUFLLEVBQUV2QixNQUFBLENBQUFxRTs7Z0VBQU07VUFBQSxPQUFFLHNEQUFGLElBQUU7Ozs7Ozs0REFKOUM7TUFBQSxPQUF3QixDQUF4QkMsVUFBd0I7OztxQ0FRMUJ4RSxnREFBQSxDQUF3RUUsTUFBQTtJQUE3RHVFLEdBQUcsRUFBQyxXQUFXO0lBQUVDLGdCQUFjLEVBQUV4RSxNQUFBLENBQUF5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekg5QyxNQUF3RztBQUN4RyxNQUE4RjtBQUM5RixNQUFxRztBQUNyRyxNQUF3SDtBQUN4SCxNQUFpSDtBQUNqSCxNQUFpSDtBQUNqSCxNQUF3VztBQUN4VztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDBTQUFPOzs7O0FBSWtUO0FBQzFVLE9BQU8saUVBQWUsMFNBQU8sSUFBSSxpVEFBYyxHQUFHLGlUQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCUTtBQUNYO0FBQ0w7O0FBRXJFLENBQW9GOztBQUU4QjtBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyw0RkFBTSxhQUFhLCtGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7OztBQ3hCd1giLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL2J1c2luZXNzTGlzdC52dWU/ZmE5OCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL2J1c2luZXNzTGlzdC52dWU/NDhjYyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL2J1c2luZXNzTGlzdC52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9idXNpbmVzc0xpc3QudnVlP2E5NjgiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9idXNpbmVzc0xpc3QudnVlP2NkNzgiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9idXNpbmVzc0xpc3QudnVlP2FiNzQiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9idXNpbmVzc0xpc3QudnVlP2ZhYzkiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9idXNpbmVzc0xpc3QudnVlPzdlYTIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIuZXhoaWJpdGlvbltkYXRhLXYtNzgyNmRlMGNdIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHBhZGRpbmctYm90dG9tOiA1MHB4O1xcbn1cXG4uc2VhcmNoW2RhdGEtdi03ODI2ZGUwY10ge1xcbiAgcGFkZGluZzogMTBweDtcXG59XFxuLnNlYXJjaCAuZWwtaW5wdXRbZGF0YS12LTc4MjZkZTBjXSxcXG4uc2VhcmNoIC5lbC1zZWxlY3RbZGF0YS12LTc4MjZkZTBjXSB7XFxuICB3aWR0aDogMjQwcHg7XFxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XFxufVxcbi50YWJsZVtkYXRhLXYtNzgyNmRlMGNdIHtcXG4gIHBhZGRpbmc6IDEwcHg7XFxuICBkaXNwbGF5OiBncmlkO1xcbn1cXG4ucGFnaW5hdGlvbltkYXRhLXYtNzgyNmRlMGNdIHtcXG4gIGhlaWdodDogMzBweDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGJvdHRvbTogMjBweDtcXG4gIHJpZ2h0OiAwcHg7XFxuICBtYXJnaW4tcmlnaHQ6IDMwcHg7XFxufVxcbi5vcGVyYUljb25bZGF0YS12LTc4MjZkZTBjXSB7XFxuICB3aWR0aDogMTZweDtcXG4gIGhlaWdodDogMTZweDtcXG4gIG1hcmdpbi1yaWdodDogMTBweDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLm9wZXJhSWNvbltkYXRhLXYtNzgyNmRlMGNdOmhvdmVyIHtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMik7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL2J1c2luZXNzTGlzdC52dWVcIixcIndlYnBhY2s6Ly8uL2J1c2luZXNzTGlzdC52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtBQ0FGO0FERUE7RUFDRSxhQUFBO0FDQUY7QUREQTs7RUFJSSxZQUFBO0VBQ0Esa0JBQUE7QUNDSjtBREdBO0VBQ0UsYUFBQTtFQUVBLGFBQUE7QUNGRjtBRElBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtBQ0ZGO0FESUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0ZGO0FESUE7RUFDRSx5QkFBQTtBQ0ZGXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcbi5leGhpYml0aW9uIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHBhZGRpbmctYm90dG9tOiA1MHB4O1xcbn1cXG4uc2VhcmNoIHtcXG4gIHBhZGRpbmc6IDEwcHg7XFxuICAuZWwtaW5wdXQsXFxuICAuZWwtc2VsZWN0IHtcXG4gICAgd2lkdGg6IDI0MHB4O1xcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XFxuICB9XFxufVxcblxcbi50YWJsZSB7XFxuICBwYWRkaW5nOiAxMHB4O1xcbiAgLy8gbWF4LWhlaWdodDogNDAwcHg7XFxuICBkaXNwbGF5OiBncmlkO1xcbn1cXG4ucGFnaW5hdGlvbiB7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBib3R0b206IDIwcHg7XFxuICByaWdodDogMHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xcbn1cXG4ub3BlcmFJY29uIHtcXG4gIHdpZHRoOiAxNnB4O1xcbiAgaGVpZ2h0OiAxNnB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4ub3BlcmFJY29uOmhvdmVyIHtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMik7XFxufVxcblwiLFwiLmV4aGliaXRpb24ge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgcGFkZGluZy1ib3R0b206IDUwcHg7XFxufVxcbi5zZWFyY2gge1xcbiAgcGFkZGluZzogMTBweDtcXG59XFxuLnNlYXJjaCAuZWwtaW5wdXQsXFxuLnNlYXJjaCAuZWwtc2VsZWN0IHtcXG4gIHdpZHRoOiAyNDBweDtcXG4gIG1hcmdpbi1yaWdodDogMjBweDtcXG59XFxuLnRhYmxlIHtcXG4gIHBhZGRpbmc6IDEwcHg7XFxuICBkaXNwbGF5OiBncmlkO1xcbn1cXG4ucGFnaW5hdGlvbiB7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBib3R0b206IDIwcHg7XFxuICByaWdodDogMHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xcbn1cXG4ub3BlcmFJY29uIHtcXG4gIHdpZHRoOiAxNnB4O1xcbiAgaGVpZ2h0OiAxNnB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4ub3BlcmFJY29uOmhvdmVyIHtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMik7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJpbXBvcnQgeyBlbnZuYW1lIH0gZnJvbSBcIkAvamF2YXNjcmlwdC9lbnZuYW1lXCI7XG5pbXBvcnQgeyBEZWxldGUsIEVkaXQsIFdhcm5UcmlhbmdsZUZpbGxlZCB9IGZyb20gXCJAZWxlbWVudC1wbHVzL2ljb25zLXZ1ZVwiO1xuaW1wb3J0IENyZWF0UmlzayBmcm9tIFwiQC9jb21wb25lbnRzL2NyZWF0Umlza1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcInZ1ZS1yb3V0ZXJcIjtcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xuaW1wb3J0IGRpcmN0IGZyb20gXCJAL2RpY3Rpb25hcmllcy9idXNpbmVzcy5qc29uXCI7XG5pbXBvcnQgeyBFbE1lc3NhZ2UgfSBmcm9tIFwiZWxlbWVudC1wbHVzXCI7XG5leHBvcnQgZGVmYXVsdCB7XG4gIF9fbmFtZTogJ2J1c2luZXNzTGlzdCcsXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlO1xuICAgIGV4cG9zZSgpO1xuICAgIHZhciByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgICB2YXIgZGlhbG9nRm9ybVZpc2libGUgPSByZWYoZmFsc2UpO1xuICAgIHZhciBmb3JtTGFiZWxXaWR0aCA9IFwiMTQwcHhcIjtcbiAgICB2YXIgdGFibGVEYXRhID0gcmVmKFtdKTtcbiAgICB2YXIgdG90YWwgPSByZWYoMCk7XG4gICAgLy8gY29uc29sZS5sb2coZGlyY3QsIFwi5YC8XCIpO1xuICAgIHZhciBkaWFsb2dWaXNpYmxlID0gcmVmKGZhbHNlKTtcbiAgICB2YXIgYWN0aXZlUm93aWQgPSByZWYobnVsbCk7XG4gICAgdmFyIGNyZWF0UmlzayA9IHJlZihudWxsKTtcbiAgICB2YXIgZm9ybSA9IHJlYWN0aXZlKHtcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICByZWdpb246IFwiXCIsXG4gICAgICBkYXRlMTogXCJcIixcbiAgICAgIGRhdGUyOiBcIlwiLFxuICAgICAgZGVsaXZlcnk6IGZhbHNlLFxuICAgICAgdHlwZTogW10sXG4gICAgICByZXNvdXJjZTogXCJcIixcbiAgICAgIGRlc2M6IFwiXCJcbiAgICB9KTtcbiAgICB2YXIgcXVlcnkgPSByZWFjdGl2ZSh7XG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgdXNlcjogXCJcIixcbiAgICAgIHN0YXR1czogXCJcIlxuICAgIH0pO1xuICAgIHZhciBwYWdlU2l6ZSA9IDEwO1xuICAgIHZhciBjdXJyZW50UGFnZSA9IHJlZigxKTtcbiAgICB2YXIgZmlsdGVyVXRpbHMgPSBmdW5jdGlvbiBmaWx0ZXJVdGlscyh2YWx1ZSwgZmxhZykge1xuICAgICAgcmV0dXJuIGRpcmN0W2ZsYWddLmZpbmQoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW0udmFsdWUgPT0gdmFsdWU7XG4gICAgICB9KS5sYWJlbDtcbiAgICB9O1xuICAgIHZhciBvcHRpb25zID0gW3tcbiAgICAgIHZhbHVlOiAxLFxuICAgICAgbGFiZWw6IFwi6L+Q6JClXCJcbiAgICB9LCB7XG4gICAgICB2YWx1ZTogMixcbiAgICAgIGxhYmVsOiBcIuWuoeaJuVwiXG4gICAgfSwge1xuICAgICAgdmFsdWU6IDMsXG4gICAgICBsYWJlbDogXCLlhrvnu5NcIlxuICAgIH1dO1xuICAgIHZhciBqdW1wQWRkID0gZnVuY3Rpb24ganVtcEFkZCgpIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgbmFtZTogXCJuZXdCdXNpbmVzc1wiXG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBidXR0b25zID0gW3tcbiAgICAgIHR5cGU6IFwiXCIsXG4gICAgICB0ZXh0OiBcIue8lui+kVwiLFxuICAgICAgdmFsdWU6IFwiZWRpdFwiXG4gICAgfSwge1xuICAgICAgdHlwZTogXCJcIixcbiAgICAgIHRleHQ6IFwi5Yig6ZmkXCIsXG4gICAgICB2YWx1ZTogXCJkZWxldGVcIlxuICAgIH1dO1xuICAgIHZhciByZXFMaXN0ID0gZnVuY3Rpb24gcmVxTGlzdCgpIHtcbiAgICAgIHZhciBwb3N0RGF0YSA9IHtcbiAgICAgICAgcXVlcnlEYXRhOiB0b1JhdyhxdWVyeSksXG4gICAgICAgIHBhZ2VTaXplOiBwYWdlU2l6ZSxcbiAgICAgICAgY3VycmVudFBhZ2U6IGN1cnJlbnRQYWdlLnZhbHVlXG4gICAgICB9O1xuICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvYnVzaW5lc3MvbGlzdFwiKSwgcG9zdERhdGEpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xuICAgICAgICAgIHRhYmxlRGF0YS52YWx1ZSA9IHJlcy5kYXRhLmxpc3Q7XG4gICAgICAgICAgdG90YWwudmFsdWUgPSByZXMuZGF0YS50b3RhbDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIganVtcEVkaXQgPSBmdW5jdGlvbiBqdW1wRWRpdCh2YWx1ZSkge1xuICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICBuYW1lOiBcImJ1c2luZXNzRWRpdFwiLFxuICAgICAgICBxdWVyeToge1xuICAgICAgICAgIGlkOiB2YWx1ZS5pZFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBkZWxldGVEaWFsb2cgPSBmdW5jdGlvbiBkZWxldGVEaWFsb2cocm93KSB7XG4gICAgICBhY3RpdmVSb3dpZC52YWx1ZSA9IHJvdy5pZDtcbiAgICAgIGRpYWxvZ1Zpc2libGUudmFsdWUgPSB0cnVlO1xuICAgIH07XG4gICAgdmFyIHN1cmUgPSBmdW5jdGlvbiBzdXJlKCkge1xuICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvYnVzaW5lc3MvZGVsZXRlXCIpLCB7XG4gICAgICAgIGlkOiBhY3RpdmVSb3dpZC52YWx1ZVxuICAgICAgfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMubWVzc2FnZSA9PT0gXCJzdWNjZXNzXCIpIHtcbiAgICAgICAgICBFbE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIuWIoOmZpOaIkOWKn1wiXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY2FuY2VsKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIGNhbmNlbCA9IGZ1bmN0aW9uIGNhbmNlbCgpIHtcbiAgICAgIGRpYWxvZ1Zpc2libGUudmFsdWUgPSBmYWxzZTtcbiAgICAgIHJlcUxpc3QoKTtcbiAgICB9O1xuICAgIHZhciBvcGVuUmlzayA9IGZ1bmN0aW9uIG9wZW5SaXNrKHJlY29yZCkge1xuICAgICAgY3JlYXRSaXNrLnZhbHVlLm9wZW5EaWFsb2cocmVjb3JkKTtcbiAgICB9O1xuICAgIHZhciBhZGRSaXNrU3VjY2VzcyA9IGZ1bmN0aW9uIGFkZFJpc2tTdWNjZXNzKCkge1xuICAgICAgcmVxTGlzdCgpO1xuICAgIH07XG4gICAgdmFyIHRlc3QxID0gZnVuY3Rpb24gdGVzdDEoKSB7XG4gICAgICByZXF1ZXN0LmdldChcIi9hcGkvYXBwL3BlcnNvbi9saXN0XCIpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBjb25zb2xlLmxvZyhyZXMsIFwi57uT5p6cXCIpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgdGVzdDIgPSBmdW5jdGlvbiB0ZXN0MigpIHtcbiAgICAgIHJlcXVlc3QuZ2V0KFwiL25ld0FwaS9hcHAvcGVyc29uL2xpc3RcIikudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcywgXCLnu5PmnpxcIik7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHJlcUxpc3QoKTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgcm91dGVyOiByb3V0ZXIsXG4gICAgICBkaWFsb2dGb3JtVmlzaWJsZTogZGlhbG9nRm9ybVZpc2libGUsXG4gICAgICBmb3JtTGFiZWxXaWR0aDogZm9ybUxhYmVsV2lkdGgsXG4gICAgICB0YWJsZURhdGE6IHRhYmxlRGF0YSxcbiAgICAgIHRvdGFsOiB0b3RhbCxcbiAgICAgIGRpYWxvZ1Zpc2libGU6IGRpYWxvZ1Zpc2libGUsXG4gICAgICBhY3RpdmVSb3dpZDogYWN0aXZlUm93aWQsXG4gICAgICBjcmVhdFJpc2s6IGNyZWF0UmlzayxcbiAgICAgIGZvcm06IGZvcm0sXG4gICAgICBnZXQgcXVlcnkoKSB7XG4gICAgICAgIHJldHVybiBxdWVyeTtcbiAgICAgIH0sXG4gICAgICBzZXQgcXVlcnkodikge1xuICAgICAgICBxdWVyeSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHBhZ2VTaXplKCkge1xuICAgICAgICByZXR1cm4gcGFnZVNpemU7XG4gICAgICB9LFxuICAgICAgc2V0IHBhZ2VTaXplKHYpIHtcbiAgICAgICAgcGFnZVNpemUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjdXJyZW50UGFnZSgpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnRQYWdlO1xuICAgICAgfSxcbiAgICAgIHNldCBjdXJyZW50UGFnZSh2KSB7XG4gICAgICAgIGN1cnJlbnRQYWdlID0gdjtcbiAgICAgIH0sXG4gICAgICBmaWx0ZXJVdGlsczogZmlsdGVyVXRpbHMsXG4gICAgICBvcHRpb25zOiBvcHRpb25zLFxuICAgICAganVtcEFkZDoganVtcEFkZCxcbiAgICAgIGJ1dHRvbnM6IGJ1dHRvbnMsXG4gICAgICByZXFMaXN0OiByZXFMaXN0LFxuICAgICAganVtcEVkaXQ6IGp1bXBFZGl0LFxuICAgICAgZGVsZXRlRGlhbG9nOiBkZWxldGVEaWFsb2csXG4gICAgICBzdXJlOiBzdXJlLFxuICAgICAgY2FuY2VsOiBjYW5jZWwsXG4gICAgICBvcGVuUmlzazogb3BlblJpc2ssXG4gICAgICBhZGRSaXNrU3VjY2VzczogYWRkUmlza1N1Y2Nlc3MsXG4gICAgICB0ZXN0MTogdGVzdDEsXG4gICAgICB0ZXN0MjogdGVzdDIsXG4gICAgICBnZXQgZW52bmFtZSgpIHtcbiAgICAgICAgcmV0dXJuIGVudm5hbWU7XG4gICAgICB9LFxuICAgICAgZ2V0IERlbGV0ZSgpIHtcbiAgICAgICAgcmV0dXJuIERlbGV0ZTtcbiAgICAgIH0sXG4gICAgICBnZXQgRWRpdCgpIHtcbiAgICAgICAgcmV0dXJuIEVkaXQ7XG4gICAgICB9LFxuICAgICAgZ2V0IFdhcm5UcmlhbmdsZUZpbGxlZCgpIHtcbiAgICAgICAgcmV0dXJuIFdhcm5UcmlhbmdsZUZpbGxlZDtcbiAgICAgIH0sXG4gICAgICBnZXQgQ3JlYXRSaXNrKCkge1xuICAgICAgICByZXR1cm4gQ3JlYXRSaXNrO1xuICAgICAgfSxcbiAgICAgIGdldCB1c2VSb3V0ZXIoKSB7XG4gICAgICAgIHJldHVybiB1c2VSb3V0ZXI7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0O1xuICAgICAgfSxcbiAgICAgIGdldCBkaXJjdCgpIHtcbiAgICAgICAgcmV0dXJuIGRpcmN0O1xuICAgICAgfSxcbiAgICAgIGdldCBFbE1lc3NhZ2UoKSB7XG4gICAgICAgIHJldHVybiBFbE1lc3NhZ2U7XG4gICAgICB9XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoX19yZXR1cm5lZF9fLCAnX19pc1NjcmlwdFNldHVwJywge1xuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB2YWx1ZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBfX3JldHVybmVkX187XG4gIH1cbn07IiwiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJleGhpYml0aW9uXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2VhcmNoXCI+XHJcbiAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgIHYtbW9kZWwudHJpbT1cInF1ZXJ5Lm5hbWVcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwi6L6T5YWl5Lia5Yqh6aKG5Z+f5ZCN56ewXCJcclxuICAgICAgICBsYWJlbD1cIuS4muWKoemihuWfn+WQjeensFwiXHJcbiAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgQGNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAvPlxyXG4gICAgICA8ZWwtaW5wdXRcclxuICAgICAgICB2LW1vZGVsLnRyaW09XCJxdWVyeS51c2VyXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIui+k+WFpeebuOWFs+i0n+i0o+S6ulwiXHJcbiAgICAgICAgbGFiZWw9XCLnm7jlhbPotJ/otKPkurpcIlxyXG4gICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgIEBjaGFuZ2U9XCJyZXFMaXN0XCJcclxuICAgICAgLz5cclxuICAgICAgPGVsLXNlbGVjdFxyXG4gICAgICAgIHYtbW9kZWw9XCJxdWVyeS5zdGF0dXNcIlxyXG4gICAgICAgIGNsYXNzPVwibS0yXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIumAieaLqei1hOS6p+eKtuaAgVwiXHJcbiAgICAgICAgQGNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICA+XHJcbiAgICAgICAgPGVsLW9wdGlvblxyXG4gICAgICAgICAgdi1mb3I9XCJpdGVtIGluIG9wdGlvbnNcIlxyXG4gICAgICAgICAgOmtleT1cIml0ZW0udmFsdWVcIlxyXG4gICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICA6dmFsdWU9XCJpdGVtLnZhbHVlXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2VsLXNlbGVjdD5cclxuICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cInJlcUxpc3RcIj7mn6Xor6I8L2VsLWJ1dHRvbj5cclxuICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cImp1bXBBZGRcIiB2LWJ0blJvbGU9XCInbmV3QnVzaW5lc3MnXCJcclxuICAgICAgICA+5paw5aKePC9lbC1idXR0b25cclxuICAgICAgPlxyXG4gICAgICA8ZWwtYnV0dG9uIEBjbGljaz1cInRlc3QxXCI+5rWL6K+VMTwvZWwtYnV0dG9uPlxyXG4gICAgICA8ZWwtYnV0dG9uIEBjbGljaz1cInRlc3QyXCI+5rWL6K+VMjwvZWwtYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwidGFibGVcIj5cclxuICAgICAgPGVsLXRhYmxlIDpkYXRhPVwidGFibGVEYXRhXCIgc3R5bGU9XCJ3aWR0aDogMTAwJVwiIDpib3JkZXI9XCJ0cnVlXCIgc3RyaXBlPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLoi7HmloflkI3np7BcIiB3aWR0aD1cIjI0MFwiIGZpeGVkPVwibGVmdFwiPlxyXG4gICAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwic2NvcGVcIj5cclxuICAgICAgICAgICAgPGVsLWxpbmsgdHlwZT1cInByaW1hcnlcIj57eyBzY29wZS5yb3cubmFtZSB9fTwvZWwtbGluaz5cclxuICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wPVwiY25hbWVcIiBsYWJlbD1cIuS4reaWh+WQjeensFwiIHdpZHRoPVwiMjQwXCIgLz5cclxuICAgICAgICA8ZWwtdGFibGUtY29sdW1uIHByb3A9XCJ1c2VyXCIgbGFiZWw9XCLotJ/otKPkurpcIiB3aWR0aD1cIjE4MFwiPlxyXG4gICAgICAgICAgPCEtLSA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgICA8c3Bhbj57eyBmaWx0ZXJVdGlscyhzY29wZS5yb3cudXNlciwgXCJ1c2VyXCIpIH19PC9zcGFuPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT4gLS0+XHJcbiAgICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wPVwic3RhdHVzXCIgbGFiZWw9XCLnirbmgIFcIiB3aWR0aD1cIndpZHRoXCI+XHJcbiAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgICA8c3Bhbj57eyBmaWx0ZXJVdGlscyhzY29wZS5yb3cuc3RhdHVzLCBcInN0YXR1c1wiKSB9fTwvc3Bhbj5cclxuICAgICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICAgICAgPCEtLSA8ZWwtdGFibGUtY29sdW1uIHByb3A9XCJlbnRpcnlcIiBsYWJlbD1cIuWFs+iBlOWunuS9k1wiPlxyXG4gICAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwic2NvcGVcIj5cclxuICAgICAgICAgICAgPHNwYW4+e3sgZmlsdGVyVXRpbHMoc2NvcGUucm93LmVudGlyeSwgXCJlbnRpcnlcIikgfX08L3NwYW4+XHJcbiAgICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgIDwvZWwtdGFibGUtY29sdW1uPiAtLT5cclxuICAgICAgICA8ZWwtdGFibGUtY29sdW1uIHByb3A9XCJ1dWlkXCIgbGFiZWw9XCLkuJrliqHpoobln5/nvJblj7dcIiB3aWR0aD1cIjQwMFwiIC8+XHJcbiAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wPVwidGltZVwiIGxhYmVsPVwi5pyA5ZCO5pON5L2c5pe26Ze0XCIgd2lkdGg9XCIyNDBcIiAvPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLmk43kvZxcIiBmaXhlZD1cInJpZ2h0XCIgd2lkdGg9XCIyNTBcIj5cclxuICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgIDxlbC1idXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgbGlua1xyXG4gICAgICAgICAgICAgIEBjbGljaz1cImp1bXBFZGl0KHNjb3BlLnJvdylcIlxyXG4gICAgICAgICAgICAgIHYtYnRuUm9sZT1cIididXNpbmVzc0VkaXQnXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIOe8lui+kVxyXG4gICAgICAgICAgICA8L2VsLWJ1dHRvbj5cclxuICAgICAgICAgICAgPGVsLWJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICAgIGxpbmtcclxuICAgICAgICAgICAgICBAY2xpY2s9XCJkZWxldGVEaWFsb2coc2NvcGUucm93KVwiXHJcbiAgICAgICAgICAgICAgdi1idG5Sb2xlPVwiJ2J1c2luZXNzRWRpdCdcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAg5Yig6ZmkXHJcbiAgICAgICAgICAgIDwvZWwtYnV0dG9uPlxyXG4gICAgICAgICAgICA8ZWwtYnV0dG9uXHJcbiAgICAgICAgICAgICAgdi1pZj1cIiFzY29wZS5yb3cuaXNSaXNrXCJcclxuICAgICAgICAgICAgICB0eXBlPVwid2FybmluZ1wiXHJcbiAgICAgICAgICAgICAgbGlua1xyXG4gICAgICAgICAgICAgIEBjbGljaz1cIm9wZW5SaXNrKHNjb3BlLnJvdylcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAg5qCH6K6w6aOO6ZmpXHJcbiAgICAgICAgICAgIDwvZWwtYnV0dG9uPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgPC9lbC10YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cInBhZ2luYXRpb25cIj5cclxuICAgICAgPGVsLXBhZ2luYXRpb25cclxuICAgICAgICBzbWFsbFxyXG4gICAgICAgIGJhY2tncm91bmRcclxuICAgICAgICBsYXlvdXQ9XCJwcmV2LCBwYWdlciwgbmV4dCwganVtcGVyLCAtPiwgdG90YWxcIlxyXG4gICAgICAgIDp0b3RhbD1cInRvdGFsXCJcclxuICAgICAgICBjbGFzcz1cIm10LTRcIlxyXG4gICAgICAgIHYtbW9kZWw6cGFnZS1zaXplPVwicGFnZVNpemVcIlxyXG4gICAgICAgIHYtbW9kZWw6Y3VycmVudC1wYWdlPVwiY3VycmVudFBhZ2VcIlxyXG4gICAgICAgIEBzaXplLWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBjdXJyZW50LWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBwcmV2LWNsaWNrPVwicmVxTGlzdFwiXHJcbiAgICAgICAgQG5leHQtY2xpY2s9XCJyZXFMaXN0XCJcclxuICAgICAgPlxyXG4gICAgICAgIDx0ZW1wbGF0ZSAjcGFnZXItdGV4dD5cclxuICAgICAgICAgIDxzcGFuPuWFsSB7eyB0b3RhbCB9fSDmnaHmlbDmja48L3NwYW4+XHJcbiAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgPC9lbC1wYWdpbmF0aW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgPGVsLWRpYWxvZyB2LW1vZGVsPVwiZGlhbG9nVmlzaWJsZVwiIHRpdGxlPVwi5Yig6ZmkXCIgd2lkdGg9XCIzMCVcIj5cclxuICAgIDxzcGFuPuehruWumuimgeWIoOmZpOi/meadoei1hOS6p+WQlz88L3NwYW4+XHJcbiAgICA8dGVtcGxhdGUgI2Zvb3Rlcj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJkaWFsb2ctZm9vdGVyXCI+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJjYW5jZWxcIj7lj5bmtog8L2VsLWJ1dHRvbj5cclxuICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgQGNsaWNrPVwic3VyZVwiPuehruWumjwvZWwtYnV0dG9uPlxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L3RlbXBsYXRlPlxyXG4gIDwvZWwtZGlhbG9nPlxyXG4gIDxDcmVhdFJpc2sgcmVmPVwiY3JlYXRSaXNrXCIgQGFkZFJpc2tTdWNjZXNzPVwiYWRkUmlza1N1Y2Nlc3NcIj48L0NyZWF0Umlzaz5cclxuPC90ZW1wbGF0ZT5cclxuPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHsgZW52bmFtZSB9IGZyb20gXCJAL2phdmFzY3JpcHQvZW52bmFtZVwiO1xyXG5pbXBvcnQgeyBEZWxldGUsIEVkaXQsIFdhcm5UcmlhbmdsZUZpbGxlZCB9IGZyb20gXCJAZWxlbWVudC1wbHVzL2ljb25zLXZ1ZVwiO1xyXG5pbXBvcnQgQ3JlYXRSaXNrIGZyb20gXCJAL2NvbXBvbmVudHMvY3JlYXRSaXNrXCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XHJcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xyXG5pbXBvcnQgZGlyY3QgZnJvbSBcIkAvZGljdGlvbmFyaWVzL2J1c2luZXNzLmpzb25cIjtcclxuaW1wb3J0IHsgRWxNZXNzYWdlIH0gZnJvbSBcImVsZW1lbnQtcGx1c1wiO1xyXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuY29uc3QgZGlhbG9nRm9ybVZpc2libGUgPSByZWYoZmFsc2UpO1xyXG5jb25zdCBmb3JtTGFiZWxXaWR0aCA9IFwiMTQwcHhcIjtcclxuY29uc3QgdGFibGVEYXRhID0gcmVmKFtdKTtcclxuY29uc3QgdG90YWwgPSByZWYoMCk7XHJcbi8vIGNvbnNvbGUubG9nKGRpcmN0LCBcIuWAvFwiKTtcclxuY29uc3QgZGlhbG9nVmlzaWJsZSA9IHJlZihmYWxzZSk7XHJcbmNvbnN0IGFjdGl2ZVJvd2lkID0gcmVmKG51bGwpO1xyXG5jb25zdCBjcmVhdFJpc2sgPSByZWYobnVsbCk7XHJcbmNvbnN0IGZvcm0gPSByZWFjdGl2ZSh7XHJcbiAgbmFtZTogXCJcIixcclxuICByZWdpb246IFwiXCIsXHJcbiAgZGF0ZTE6IFwiXCIsXHJcbiAgZGF0ZTI6IFwiXCIsXHJcbiAgZGVsaXZlcnk6IGZhbHNlLFxyXG4gIHR5cGU6IFtdLFxyXG4gIHJlc291cmNlOiBcIlwiLFxyXG4gIGRlc2M6IFwiXCIsXHJcbn0pO1xyXG5sZXQgcXVlcnkgPSByZWFjdGl2ZSh7XHJcbiAgbmFtZTogXCJcIixcclxuICB1c2VyOiBcIlwiLFxyXG4gIHN0YXR1czogXCJcIixcclxufSk7XHJcbmxldCBwYWdlU2l6ZSA9IDEwO1xyXG5sZXQgY3VycmVudFBhZ2UgPSByZWYoMSk7XHJcbmNvbnN0IGZpbHRlclV0aWxzID0gKHZhbHVlLCBmbGFnKSA9PiB7XHJcbiAgcmV0dXJuIGRpcmN0W2ZsYWddLmZpbmQoKGl0ZW0pID0+IGl0ZW0udmFsdWUgPT0gdmFsdWUpLmxhYmVsO1xyXG59O1xyXG5jb25zdCBvcHRpb25zID0gW1xyXG4gIHtcclxuICAgIHZhbHVlOiAxLFxyXG4gICAgbGFiZWw6IFwi6L+Q6JClXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICB2YWx1ZTogMixcclxuICAgIGxhYmVsOiBcIuWuoeaJuVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdmFsdWU6IDMsXHJcbiAgICBsYWJlbDogXCLlhrvnu5NcIixcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QganVtcEFkZCA9ICgpID0+IHtcclxuICByb3V0ZXIucHVzaCh7XHJcbiAgICBuYW1lOiBcIm5ld0J1c2luZXNzXCIsXHJcbiAgfSk7XHJcbn07XHJcbmNvbnN0IGJ1dHRvbnMgPSBbXHJcbiAgeyB0eXBlOiBcIlwiLCB0ZXh0OiBcIue8lui+kVwiLCB2YWx1ZTogXCJlZGl0XCIgfSxcclxuICB7IHR5cGU6IFwiXCIsIHRleHQ6IFwi5Yig6ZmkXCIsIHZhbHVlOiBcImRlbGV0ZVwiIH0sXHJcbl07XHJcbmNvbnN0IHJlcUxpc3QgPSAoKSA9PiB7XHJcbiAgbGV0IHBvc3REYXRhID0ge1xyXG4gICAgcXVlcnlEYXRhOiB0b1JhdyhxdWVyeSksXHJcbiAgICBwYWdlU2l6ZSxcclxuICAgIGN1cnJlbnRQYWdlOiBjdXJyZW50UGFnZS52YWx1ZSxcclxuICB9O1xyXG4gIHJlcXVlc3QucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL2J1c2luZXNzL2xpc3RgLCBwb3N0RGF0YSkudGhlbigocmVzKSA9PiB7XHJcbiAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICB0YWJsZURhdGEudmFsdWUgPSByZXMuZGF0YS5saXN0O1xyXG4gICAgICB0b3RhbC52YWx1ZSA9IHJlcy5kYXRhLnRvdGFsO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBqdW1wRWRpdCA9ICh2YWx1ZSkgPT4ge1xyXG4gIHJvdXRlci5wdXNoKHtcclxuICAgIG5hbWU6IFwiYnVzaW5lc3NFZGl0XCIsXHJcbiAgICBxdWVyeToge1xyXG4gICAgICBpZDogdmFsdWUuaWQsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBkZWxldGVEaWFsb2cgPSAocm93KSA9PiB7XHJcbiAgYWN0aXZlUm93aWQudmFsdWUgPSByb3cuaWQ7XHJcbiAgZGlhbG9nVmlzaWJsZS52YWx1ZSA9IHRydWU7XHJcbn07XHJcbmNvbnN0IHN1cmUgPSAoKSA9PiB7XHJcbiAgcmVxdWVzdFxyXG4gICAgLnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC9idXNpbmVzcy9kZWxldGVgLCB7IGlkOiBhY3RpdmVSb3dpZC52YWx1ZSB9KVxyXG4gICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICBpZiAocmVzLm1lc3NhZ2UgPT09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCLliKDpmaTmiJDlip9cIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBjYW5jZWwoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbn07XHJcbmNvbnN0IGNhbmNlbCA9ICgpID0+IHtcclxuICBkaWFsb2dWaXNpYmxlLnZhbHVlID0gZmFsc2U7XHJcbiAgcmVxTGlzdCgpO1xyXG59O1xyXG5jb25zdCBvcGVuUmlzayA9IChyZWNvcmQpID0+IHtcclxuICBjcmVhdFJpc2sudmFsdWUub3BlbkRpYWxvZyhyZWNvcmQpO1xyXG59O1xyXG5jb25zdCBhZGRSaXNrU3VjY2VzcyA9ICgpID0+IHtcclxuICByZXFMaXN0KCk7XHJcbn07XHJcbmNvbnN0IHRlc3QxID0gKCkgPT4ge1xyXG4gIHJlcXVlc3QuZ2V0KGAvYXBpL2FwcC9wZXJzb24vbGlzdGApLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgY29uc29sZS5sb2cocmVzLCBcIue7k+aenFwiKTtcclxuICB9KTtcclxufTtcclxuY29uc3QgdGVzdDIgPSAoKSA9PiB7XHJcbiAgcmVxdWVzdC5nZXQoYC9uZXdBcGkvYXBwL3BlcnNvbi9saXN0YCkudGhlbigocmVzKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhyZXMsIFwi57uT5p6cXCIpO1xyXG4gIH0pO1xyXG59O1xyXG5yZXFMaXN0KCk7XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4uZXhoaWJpdGlvbiB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogNTBweDtcclxufVxyXG4uc2VhcmNoIHtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIC5lbC1pbnB1dCxcclxuICAuZWwtc2VsZWN0IHtcclxuICAgIHdpZHRoOiAyNDBweDtcclxuICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICB9XHJcbn1cclxuXHJcbi50YWJsZSB7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICAvLyBtYXgtaGVpZ2h0OiA0MDBweDtcclxuICBkaXNwbGF5OiBncmlkO1xyXG59XHJcbi5wYWdpbmF0aW9uIHtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogMjBweDtcclxuICByaWdodDogMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMzBweDtcclxufVxyXG4ub3BlcmFJY29uIHtcclxuICB3aWR0aDogMTZweDtcclxuICBoZWlnaHQ6IDE2cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4ub3BlcmFJY29uOmhvdmVyIHtcclxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjIpO1xyXG59XHJcbjwvc3R5bGU+XHJcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD03ODI2ZGUwYyZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vYnVzaW5lc3NMaXN0LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTc4MjZkZTBjJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsImltcG9ydCB7IHJlbmRlciB9IGZyb20gXCIuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NzgyNmRlMGMmc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9idXNpbmVzc0xpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vYnVzaW5lc3NMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcblxuaW1wb3J0IFwiLi9idXNpbmVzc0xpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NzgyNmRlMGMmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtNzgyNmRlMGNcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvYnVzaW5lc3NMaXN0LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCI3ODI2ZGUwY1wiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzc4MjZkZTBjJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnNzgyNmRlMGMnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NzgyNmRlMGMmc2NvcGVkPXRydWVcIiwgKCkgPT4ge1xuICAgIGFwaS5yZXJlbmRlcignNzgyNmRlMGMnLCByZW5kZXIpXG4gIH0pXG5cbn1cblxuXG5leHBvcnQgZGVmYXVsdCBfX2V4cG9ydHNfXyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NzgyNmRlMGMmc2NvcGVkPXRydWVcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2J1c2luZXNzTGlzdC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD03ODI2ZGUwYyZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIiJdLCJuYW1lcyI6WyJfY3JlYXRlRWxlbWVudFZOb2RlIiwiX2hvaXN0ZWRfMSIsIl9ob2lzdGVkXzIiLCJfY3JlYXRlVk5vZGUiLCJfY29tcG9uZW50X2VsX2lucHV0IiwiJHNldHVwIiwicXVlcnkiLCJuYW1lIiwiJGV2ZW50IiwidHJpbSIsInBsYWNlaG9sZGVyIiwibGFiZWwiLCJjbGVhcmFibGUiLCJvbkNoYW5nZSIsInJlcUxpc3QiLCJ1c2VyIiwiX2NvbXBvbmVudF9lbF9zZWxlY3QiLCJzdGF0dXMiLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJvcHRpb25zIiwiaXRlbSIsIl9jb21wb25lbnRfZWxfb3B0aW9uIiwia2V5IiwidmFsdWUiLCJfY29tcG9uZW50X2VsX2J1dHRvbiIsInR5cGUiLCJvbkNsaWNrIiwiX2NyZWF0ZUJsb2NrIiwianVtcEFkZCIsInRlc3QxIiwidGVzdDIiLCJfaG9pc3RlZF8zIiwiX2NvbXBvbmVudF9lbF90YWJsZSIsImRhdGEiLCJ0YWJsZURhdGEiLCJzdHlsZSIsImJvcmRlciIsInN0cmlwZSIsIl9jb21wb25lbnRfZWxfdGFibGVfY29sdW1uIiwid2lkdGgiLCJmaXhlZCIsIl93aXRoQ3R4Iiwic2NvcGUiLCJfY29tcG9uZW50X2VsX2xpbmsiLCJyb3ciLCJwcm9wIiwiX2NyZWF0ZUNvbW1lbnRWTm9kZSIsIl90b0Rpc3BsYXlTdHJpbmciLCJmaWx0ZXJVdGlscyIsImxpbmsiLCJqdW1wRWRpdCIsImRlbGV0ZURpYWxvZyIsImlzUmlzayIsIm9wZW5SaXNrIiwiX2hvaXN0ZWRfNCIsIl9jb21wb25lbnRfZWxfcGFnaW5hdGlvbiIsInNtYWxsIiwiYmFja2dyb3VuZCIsImxheW91dCIsInRvdGFsIiwicGFnZVNpemUiLCJjdXJyZW50UGFnZSIsIm9uU2l6ZUNoYW5nZSIsIm9uQ3VycmVudENoYW5nZSIsIm9uUHJldkNsaWNrIiwib25OZXh0Q2xpY2siLCJfY29tcG9uZW50X2VsX2RpYWxvZyIsImRpYWxvZ1Zpc2libGUiLCJ0aXRsZSIsImZvb3RlciIsIl9ob2lzdGVkXzYiLCJjYW5jZWwiLCJzdXJlIiwiX2hvaXN0ZWRfNSIsInJlZiIsIm9uQWRkUmlza1N1Y2Nlc3MiLCJhZGRSaXNrU3VjY2VzcyJdLCJzb3VyY2VSb290IjoiIn0=