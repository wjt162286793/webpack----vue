"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_task_index_vue"],{

/***/ 82182:
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/task/index.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'index',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_1__.useRoute)();
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    if (route.name === "task") {
      router.push({
        name: "taskList"
      });
    }
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.watch)(route, function (newVal, oldVal) {
      // console.log(newVal, oldVal, "路由值变化");
      if (newVal.name === "task") {
        router.push({
          name: "taskList"
        });
      }
    });
    var __returned__ = {
      route: route,
      router: router,
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_1__.useRouter;
      },
      get useRoute() {
        return vue_router__WEBPACK_IMPORTED_MODULE_1__.useRoute;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 68592:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/task/index.vue?vue&type=template&id=dbacfd68 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_router_view = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("router-view");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_router_view);
}

/***/ }),

/***/ 63861:
/*!**********************************!*\
  !*** ./src/pages/task/index.vue ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_dbacfd68__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=dbacfd68 */ 92277);
/* harmony import */ var _index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&setup=true&lang=js */ 89313);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;
const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_index_vue_vue_type_template_id_dbacfd68__WEBPACK_IMPORTED_MODULE_0__.render],['__file',"src/pages/task/index.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 89313:
/*!*********************************************************************!*\
  !*** ./src/pages/task/index.vue?vue&type=script&setup=true&lang=js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=script&setup=true&lang=js */ 82182);
 

/***/ }),

/***/ 92277:
/*!****************************************************************!*\
  !*** ./src/pages/task/index.vue?vue&type=template&id=dbacfd68 ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_dbacfd68__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_dbacfd68__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=template&id=dbacfd68 */ 68592);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX3Rhc2tfaW5kZXhfdnVlLmY1MGVjMTZhYzlkZGViODMxYjZjLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFpRDs7O0FBQ2pELGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isb0RBQVE7QUFDeEIsaUJBQWlCLHFEQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDBDQUFLO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsaURBQVM7QUFDeEI7QUFDQTtBQUNBLGVBQWUsZ0RBQVE7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyRENwQ0NBLGdEQUFBLENBQTJCQyxzQkFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRHFDO0FBQ0M7QUFDTDs7QUFFOUQsQ0FBa0g7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMscUZBQU0sYUFBYSw0RUFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7QUN0QnFXIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvdGFzay9pbmRleC52dWU/Nzc5OSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy90YXNrL2luZGV4LnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy90YXNrL2luZGV4LnZ1ZT9lMTdmIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Rhc2svaW5kZXgudnVlPzQ1ODYiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvdGFzay9pbmRleC52dWU/MTQxMiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSb3V0ZXIsIHVzZVJvdXRlIH0gZnJvbSBcInZ1ZS1yb3V0ZXJcIjtcbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAnaW5kZXgnLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICBleHBvc2UoKTtcbiAgICB2YXIgcm91dGUgPSB1c2VSb3V0ZSgpO1xuICAgIHZhciByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgICBpZiAocm91dGUubmFtZSA9PT0gXCJ0YXNrXCIpIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgbmFtZTogXCJ0YXNrTGlzdFwiXG4gICAgICB9KTtcbiAgICB9XG4gICAgd2F0Y2gocm91dGUsIGZ1bmN0aW9uIChuZXdWYWwsIG9sZFZhbCkge1xuICAgICAgLy8gY29uc29sZS5sb2cobmV3VmFsLCBvbGRWYWwsIFwi6Lev55Sx5YC85Y+Y5YyWXCIpO1xuICAgICAgaWYgKG5ld1ZhbC5uYW1lID09PSBcInRhc2tcIikge1xuICAgICAgICByb3V0ZXIucHVzaCh7XG4gICAgICAgICAgbmFtZTogXCJ0YXNrTGlzdFwiXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHZhciBfX3JldHVybmVkX18gPSB7XG4gICAgICByb3V0ZTogcm91dGUsXG4gICAgICByb3V0ZXI6IHJvdXRlcixcbiAgICAgIGdldCB1c2VSb3V0ZXIoKSB7XG4gICAgICAgIHJldHVybiB1c2VSb3V0ZXI7XG4gICAgICB9LFxuICAgICAgZ2V0IHVzZVJvdXRlKCkge1xuICAgICAgICByZXR1cm4gdXNlUm91dGU7XG4gICAgICB9XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoX19yZXR1cm5lZF9fLCAnX19pc1NjcmlwdFNldHVwJywge1xuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB2YWx1ZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBfX3JldHVybmVkX187XG4gIH1cbn07IiwiPHRlbXBsYXRlPlxyXG4gIDxyb3V0ZXItdmlldz48L3JvdXRlci12aWV3PlxyXG48L3RlbXBsYXRlPlxyXG5cclxuPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHsgdXNlUm91dGVyLCB1c2VSb3V0ZSB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XHJcbmNvbnN0IHJvdXRlID0gdXNlUm91dGUoKTtcclxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbmlmIChyb3V0ZS5uYW1lID09PSBcInRhc2tcIikge1xyXG4gIHJvdXRlci5wdXNoKHtcclxuICAgIG5hbWU6IFwidGFza0xpc3RcIixcclxuICB9KTtcclxufVxyXG5cclxud2F0Y2gocm91dGUsIChuZXdWYWwsIG9sZFZhbCkgPT4ge1xyXG4gIC8vIGNvbnNvbGUubG9nKG5ld1ZhbCwgb2xkVmFsLCBcIui3r+eUseWAvOWPmOWMllwiKTtcclxuICBpZiAobmV3VmFsLm5hbWUgPT09IFwidGFza1wiKSB7XHJcbiAgICByb3V0ZXIucHVzaCh7XHJcbiAgICAgIG5hbWU6IFwidGFza0xpc3RcIixcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG48L3N0eWxlPlxyXG4iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9pbmRleC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9ZGJhY2ZkNjhcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9pbmRleC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9pbmRleC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL3Rhc2svaW5kZXgudnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcImRiYWNmZDY4XCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnZGJhY2ZkNjgnLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCdkYmFjZmQ2OCcsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWRiYWNmZDY4XCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJ2RiYWNmZDY4JywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9pbmRleC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2luZGV4LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWRiYWNmZDY4XCIiXSwibmFtZXMiOlsiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF9yb3V0ZXJfdmlldyJdLCJzb3VyY2VSb290IjoiIn0=