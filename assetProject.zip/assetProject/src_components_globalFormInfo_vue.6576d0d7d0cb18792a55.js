(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_components_globalFormInfo_vue"],{

/***/ 34207:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/getUrl.js */ 18393);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! @/assets/flowchartSvg/笔.svg */ 129), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".flowBox[data-v-5f7f1d01] {\n  width: 100%;\n  height: 800px;\n  display: flex;\n  position: relative;\n}\n.flowBox .legend[data-v-5f7f1d01],\n.flowBox .setting[data-v-5f7f1d01] {\n  padding-left: 10px;\n  width: 200px;\n  height: 800px;\n  background: #e0dede;\n  display: flex;\n  flex-direction: column;\n  align-content: center;\n}\n.flowBox .legend h4[data-v-5f7f1d01],\n.flowBox .setting h4[data-v-5f7f1d01] {\n  font-size: 18px;\n  margin: 10px auto;\n  border-bottom: #000 dashed 1px;\n}\n.flowBox .chartNormal[data-v-5f7f1d01] {\n  flex: 1;\n  border: 2px dashed #deec0e;\n  cursor: pointer;\n  box-sizing: border-box;\n}\n.flowBox .chartMode[data-v-5f7f1d01] {\n  flex: 1;\n  border: 2px dashed #deec0e;\n  box-sizing: border-box;\n  cursor: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") 0 32, auto;\n}\n.flowBox .lengendItemNormal[data-v-5f7f1d01] {\n  margin-top: 10px;\n  height: 60px;\n  margin: 10px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  cursor: pointer;\n}\n.flowBox .lengendItemActive[data-v-5f7f1d01] {\n  margin: 10px;\n  margin-top: 10px;\n  height: 60px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  border: #d81e06 1px dashed;\n  cursor: pointer;\n}\n", "",{"version":3,"sources":["webpack://./src/components/globalFlow.vue","webpack://./globalFlow.vue"],"names":[],"mappings":"AACA;EACE,WAAA;EACA,aAAA;EACA,aAAA;EACA,kBAAA;ACAF;ADJA;;EAOI,kBAAA;EACA,YAAA;EACA,aAAA;EACA,mBAAA;EACA,aAAA;EACA,sBAAA;EACA,qBAAA;ACCJ;ADdA;;EAeM,eAAA;EACA,iBAAA;EACA,8BAAA;ACGN;ADpBA;EAqBI,OAAA;EACA,0BAAA;EACA,eAAA;EACA,sBAAA;ACEJ;AD1BA;EA2BI,OAAA;EACA,0BAAA;EACA,sBAAA;EACA,0DAAA;ACEJ;ADhCA;EAiCI,gBAAA;EACA,YAAA;EACA,YAAA;EACA,aAAA;EACA,sBAAA;EACA,mBAAA;EACA,eAAA;ACEJ;ADzCA;EA0CI,YAAA;EACA,gBAAA;EACA,YAAA;EACA,aAAA;EACA,sBAAA;EACA,mBAAA;EACA,0BAAA;EACA,eAAA;ACEJ","sourcesContent":["\n.flowBox {\n  width: 100%;\n  height: 800px;\n  display: flex;\n  position: relative;\n  .legend,\n  .setting {\n    padding-left: 10px;\n    width: 200px;\n    height: 800px;\n    background: #e0dede;\n    display: flex;\n    flex-direction: column;\n    align-content: center;\n    h4 {\n      font-size: 18px;\n      margin: 10px auto;\n      border-bottom: #000 dashed 1px;\n    }\n  }\n  .chartNormal {\n    flex: 1;\n    border: 2px dashed #deec0e;\n    cursor: pointer;\n    box-sizing: border-box;\n  }\n  .chartMode {\n    flex: 1;\n    border: 2px dashed #deec0e;\n    box-sizing: border-box;\n    cursor: url(\"@/assets/flowchartSvg/笔.svg\") 0 32, auto;\n  }\n  .lengendItemNormal {\n    margin-top: 10px;\n    height: 60px;\n    margin: 10px;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    cursor: pointer;\n  }\n  .lengendItemActive {\n    margin: 10px;\n    margin-top: 10px;\n    height: 60px;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    border: #d81e06 1px dashed;\n    cursor: pointer;\n  }\n  // .setting{\n  //   cursor:url('@/assets/flowchartSvg/笔.svg') 0 32,auto;\n  // }\n}\n",".flowBox {\n  width: 100%;\n  height: 800px;\n  display: flex;\n  position: relative;\n}\n.flowBox .legend,\n.flowBox .setting {\n  padding-left: 10px;\n  width: 200px;\n  height: 800px;\n  background: #e0dede;\n  display: flex;\n  flex-direction: column;\n  align-content: center;\n}\n.flowBox .legend h4,\n.flowBox .setting h4 {\n  font-size: 18px;\n  margin: 10px auto;\n  border-bottom: #000 dashed 1px;\n}\n.flowBox .chartNormal {\n  flex: 1;\n  border: 2px dashed #deec0e;\n  cursor: pointer;\n  box-sizing: border-box;\n}\n.flowBox .chartMode {\n  flex: 1;\n  border: 2px dashed #deec0e;\n  box-sizing: border-box;\n  cursor: url(\"@/assets/flowchartSvg/笔.svg\") 0 32, auto;\n}\n.flowBox .lengendItemNormal {\n  margin-top: 10px;\n  height: 60px;\n  margin: 10px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  cursor: pointer;\n}\n.flowBox .lengendItemActive {\n  margin: 10px;\n  margin-top: 10px;\n  height: 60px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  border: #d81e06 1px dashed;\n  cursor: pointer;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 31650:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".mainBox[data-v-262d97e5] {\n  overflow: auto;\n  padding: 10px;\n  padding-bottom: 50px;\n  position: relative;\n}\n.mainBox .tem[data-v-262d97e5] {\n  border-bottom: 1px solid #eee;\n  margin-bottom: 20px;\n}\n.mainBox h4[data-v-262d97e5] {\n  font-size: 18px;\n  font-weight: 500;\n}\n.mainBox .formItem[data-v-262d97e5] {\n  width: 480px;\n}\n.mainBox .timeBox[data-v-262d97e5] {\n  width: 480px;\n  display: flex;\n}\n.mainBox[data-v-262d97e5] .el-form-item__content {\n  display: flex;\n  flex-wrap: nowrap;\n}\n.mainBox .iconBox[data-v-262d97e5] {\n  margin-left: 20px;\n  cursor: pointer;\n}\n.mainBox .footer[data-v-262d97e5] {\n  padding-top: 10px;\n  height: 40px;\n  width: 100%;\n  position: absolute;\n  bottom: 30px;\n  left: 0px;\n  display: flex;\n  padding-right: 20px;\n  justify-content: flex-end;\n}\n.fullDiaLog[data-v-262d97e5] .el-dialog__header {\n  height: 50px !important;\n}\n.fullDiaLog[data-v-262d97e5] .el-dialog__body {\n  padding: 0px !important;\n}\n", "",{"version":3,"sources":["webpack://./src/components/globalFormInfo.vue","webpack://./globalFormInfo.vue"],"names":[],"mappings":"AACA;EACE,cAAA;EACA,aAAA;EACA,oBAAA;EACA,kBAAA;ACAF;ADJA;EAOI,6BAAA;EACA,mBAAA;ACAJ;ADRA;EAYI,eAAA;EACA,gBAAA;ACDJ;ADZA;EAiBI,YAAA;ACFJ;ADfA;EAsBI,YAAA;EACA,aAAA;ACJJ;ADnBA;EA2BI,aAAA;EACA,iBAAA;ACLJ;ADvBA;EAgCI,iBAAA;EACA,eAAA;ACNJ;AD3BA;EAqCI,iBAAA;EACA,YAAA;EACA,WAAA;EACA,kBAAA;EACA,YAAA;EACA,SAAA;EACA,aAAA;EACA,mBAAA;EACA,yBAAA;ACPJ;ADUA;EAEI,uBAAA;ACTJ;ADOA;EAKI,uBAAA;ACTJ","sourcesContent":["\n.mainBox {\n  overflow: auto;\n  padding: 10px;\n  padding-bottom: 50px;\n  position: relative;\n\n  .tem {\n    border-bottom: 1px solid #eee;\n    margin-bottom: 20px;\n  }\n\n  h4 {\n    font-size: 18px;\n    font-weight: 500;\n  }\n\n  .formItem {\n    width: 480px;\n    // margin: 20px;\n    // display: flex;\n  }\n  .timeBox {\n    width: 480px;\n    display: flex;\n  }\n\n  ::v-deep(.el-form-item__content) {\n    display: flex;\n    flex-wrap: nowrap;\n  }\n\n  .iconBox {\n    margin-left: 20px;\n    cursor: pointer;\n  }\n\n  .footer {\n    padding-top: 10px;\n    height: 40px;\n    width: 100%;\n    position: absolute;\n    bottom: 30px;\n    left: 0px;\n    display: flex;\n    padding-right: 20px;\n    justify-content: flex-end;\n  }\n}\n.fullDiaLog {\n  ::v-deep(.el-dialog__header) {\n    height: 50px !important;\n  }\n  ::v-deep(.el-dialog__body) {\n    padding: 0px !important;\n  }\n}\n",".mainBox {\n  overflow: auto;\n  padding: 10px;\n  padding-bottom: 50px;\n  position: relative;\n}\n.mainBox .tem {\n  border-bottom: 1px solid #eee;\n  margin-bottom: 20px;\n}\n.mainBox h4 {\n  font-size: 18px;\n  font-weight: 500;\n}\n.mainBox .formItem {\n  width: 480px;\n}\n.mainBox .timeBox {\n  width: 480px;\n  display: flex;\n}\n.mainBox ::v-deep(.el-form-item__content) {\n  display: flex;\n  flex-wrap: nowrap;\n}\n.mainBox .iconBox {\n  margin-left: 20px;\n  cursor: pointer;\n}\n.mainBox .footer {\n  padding-top: 10px;\n  height: 40px;\n  width: 100%;\n  position: absolute;\n  bottom: 30px;\n  left: 0px;\n  display: flex;\n  padding-right: 20px;\n  justify-content: flex-end;\n}\n.fullDiaLog ::v-deep(.el-dialog__header) {\n  height: 50px !important;\n}\n.fullDiaLog ::v-deep(.el-dialog__body) {\n  padding: 0px !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 58199:
/*!*******************************************!*\
  !*** ./src/javascript/flowchartConfig.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var allConfig = {
  lengendList: [{
    name: 'mode',
    title: '模块',
    svgName: '范围'
  }, {
    name: 'entiry',
    title: '实物',
    svgName: '矩形'
  }, {
    name: 'ellipse',
    title: '供应商',
    svgName: '椭圆'
  }, {
    name: 'triangle',
    title: '业务线',
    svgName: '三角形'
  }, {
    name: 'label',
    title: '标注',
    svgName: '标注'
  },
  // {
  //    name:'flag',
  //    title:'关键点',
  //    svgName:'旗帜'
  // },
  // {
  //    name:'danger',
  //    title:'风险点',
  //    svgName:'注意'
  // },
  {
    name: 'link',
    title: '连接线',
    svgName: '连接'
  }],
  utilsList: [{
    name: 'allClear',
    title: '清除',
    svgName: '清除'
  }, {
    name: 'resetLengend',
    title: '重置',
    svgName: '重置'
  }]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (allConfig);

/***/ }),

/***/ 7948:
/*!*****************************************!*\
  !*** ./src/javascript/globalFlowFun.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createArcStroke": () => (/* binding */ createArcStroke),
/* harmony export */   "createLinkLine": () => (/* binding */ createLinkLine),
/* harmony export */   "createRectFill": () => (/* binding */ createRectFill),
/* harmony export */   "createRectStroke": () => (/* binding */ createRectStroke),
/* harmony export */   "createText": () => (/* binding */ createText),
/* harmony export */   "createTreeBox": () => (/* binding */ createTreeBox)
/* harmony export */ });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ 98170);

//创建一个填充矩形
var createRectFill = function createRectFill(position) {
  return {
    x: position.x - 202 - 100,
    y: position.y - 52 - 100,
    width: 200,
    height: 200,
    name: '实物',
    color: 'red',
    modeType: 'rectFill',
    styleType: 'fill',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 1,
    fromList: [],
    targetList: [],
    text: {
      info: '实物',
      color: '#fff'
    }
  };
};
//创建一个三角形
var createTreeBox = function createTreeBox(position) {
  return {
    x1: position.x - 200,
    y1: position.y - 50 - 100,
    x2: position.x - 200 - 100,
    y2: position.y - 50 + 100,
    x3: position.x - 200 + 100,
    y3: position.y - 50 + 100,
    name: '业务线',
    color: 'red',
    modeType: 'three',
    styleType: 'stroke',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 1,
    fromList: [],
    targetList: [],
    text: {
      info: '业务线',
      color: '#fff'
    }
  };
};
//创建一个描边矩形
var createRectStroke = function createRectStroke(position) {
  return {
    x: position.x - 202 - 100,
    y: position.y - 52 - 100,
    width: 200,
    height: 200,
    name: '模块',
    color: 'red',
    modeType: 'rectStroke',
    styleType: 'stroke',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 1,
    fromList: [],
    targetList: [],
    text: {
      info: '模块',
      color: 'red'
    }
  };
};
//创建一个圆形
var createArcStroke = function createArcStroke(position) {
  return {
    x: position.x - 202,
    y: position.y - 52,
    arcSize: 100,
    name: '供应商',
    color: 'red',
    modeType: 'arcFill',
    styleType: 'fill',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 1,
    fromList: [],
    targetList: [],
    text: {
      info: '供应商',
      color: 'red'
    }
  };
};
//创建连线
var createLinkLine = function createLinkLine(position) {
  return {
    fromX: position.x,
    fromY: position.y,
    targetX: null,
    targetY: null,
    lineWidth: 20,
    name: '连接线',
    color: 'red',
    modeType: 'linkLine',
    styleType: 'fill',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 0
  };
};
//创建一个文本
var createText = function createText(position) {
  console.log(position, '文本地址');
  return {
    textX: position.x,
    textY: position.y,
    color: 'red',
    modeType: 'text',
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])(),
    nodeIndex: 1000,
    info: ''
  };
};

/***/ }),

/***/ 78074:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalFlow.vue?vue&type=script&setup=true&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_flowchartConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../javascript/flowchartConfig */ 58199);
/* harmony import */ var vue_draggable_next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-draggable-next */ 70707);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! uuid */ 98170);
/* harmony import */ var _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/javascript/globalFlowFun.js */ 7948);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'globalFlow',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    var draggable = vue_draggable_next__WEBPACK_IMPORTED_MODULE_3__.VueDraggableNext; //拖拽组件
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_4__.useRoute)();
    var mousePosition = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({}); //
    var lengendList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)(_javascript_flowchartConfig__WEBPACK_IMPORTED_MODULE_0__["default"].lengendList); //图例集合
    var utilsList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)(_javascript_flowchartConfig__WEBPACK_IMPORTED_MODULE_0__["default"].utilsList); //工具集合
    var legendActiveItem = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(""); //当前选中图例
    var isMode = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false); //是否为模块
    var canvas = null; //画布
    var canvasMode = null; //画布实例
    var nodeList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]); //画布内容数组
    var activeNodeInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({}); //活动的组件信息
    var isLinkLine = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false); //是否为连线状态
    var activeLineId = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(undefined); //当前连线的id
    var linkLineFlag = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false); //连线标志
    var linkLineFrom = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(undefined); //线条起点
    var linkLineTarget = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(undefined); //线条终点
    var clickNodeFlag = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false); //是否点击节点
    var eventName = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(undefined); //当前处于什么事件
    var canvasStyleInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({
      background: "#fff",
      scale: 1
    });
    var imageName = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)("画布");
    var textareaValue = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)('');
    var textareaShow = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false);
    var textareaClass = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({
      position: 'absolute',
      left: '300px',
      top: '300px',
      index: 1000,
      width: '300px',
      border: '1px dashed #23cf7d',
      outline: 'none',
      rows: 5
    });
    //拖拽配置
    var dragOptions = {
      preventOnFilter: false,
      sort: false,
      disabled: false,
      ghostClass: "tt",
      forceFallback: true
    };

    //图例的样式
    var lengendClass = function lengendClass(name) {
      if (name !== legendActiveItem.value) {
        return "lengendItemNormal";
      } else {
        return "lengendItemActive";
      }
    };
    //点击图例事件
    var clickLengend = function clickLengend(name) {
      if (route.query.type === 'detail') {
        return;
      }
      textareaShow.value = false;
      legendActiveItem.value = name;
      isLinkLine.value = false;
      if (name === "mode") {
        // isMode.value = true
      } else if (name === "link") {
        isLinkLine.value = true;
      } else if (name === "allClear") {
        canvasMode.clearRect(0, 0, canvas.width, canvas.height);
        nodeList.value = [];
      } else if (name === "resetLengend") {
        legendActiveItem.value = undefined;
      } else if (name === 'label') {
        textareaShow.value = true;
      } else {}
    };
    //图例拖动开始
    var moveStart = function moveStart(el) {};
    //图例拖动结束
    var moveEnd = function moveEnd(el) {
      var position = {
        x: el.originalEvent.clientX,
        y: el.originalEvent.clientY
      };
      if (position.x < 202 + 100 || position.x > 1702 - 100 || position.y < 52 + 100 || position.y > 852 - 100) {
        (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
          message: "未拖入画布之中",
          type: "warning"
        });
      } else {
        changeNodeList(position);
        draw(null);
      }
    };
    //点击画布
    var clickCanvas = function clickCanvas(el) {};
    //画布中鼠标按下
    var canvasDown = function canvasDown(el) {
      if (route.query.type === 'detail') {
        return;
      }
      eventName.value = "mousedown";
      var position = canvas.getBoundingClientRect();
      var positionInfo = {
        x: el.clientX - position.left,
        y: el.clientY - position.top
      };
      if (isLinkLine.value === true) {
        linkLineFlag.value = true;
        changeNodeList(positionInfo);
      } else {
        clickNodeFlag.value = true;
      }
      draw(positionInfo);
    };
    //画布中鼠标抬起
    var canvasUp = function canvasUp(el) {
      eventName.value = "mouseup";
      linkLineFlag.value = false;
      clickNodeFlag.value = false;
      var position = canvas.getBoundingClientRect();
      var positionInfo = {
        x: el.clientX - position.left,
        y: el.clientY - position.top
      };
      textareaShow.value = false;
      if (legendActiveItem.value === 'label') {
        textareaShow.value = true;
        textareaClass.value.left = el.layerX + 'px';
        textareaClass.value.top = el.layerY + 'px';
      }
      draw(positionInfo);
    };
    //画布中鼠标移动
    var canvasMove = function canvasMove(el) {
      if (route.query.type === 'detail') {
        return;
      }
      eventName.value = "mousemove";
      if (isLinkLine.value === true) {
        if (linkLineFlag.value === true) {
          createLinkTarget(el);
          draw();
        }
      } else {
        if (clickNodeFlag.value === true) {
          switch (activeNodeInfo.value.modeType) {
            case "rectStroke":
              activeNodeInfo.value.x = el.offsetX - 100;
              activeNodeInfo.value.y = el.offsetY - 100;
              break;
            case "rectFill":
              activeNodeInfo.value.x = el.offsetX - 100;
              activeNodeInfo.value.y = el.offsetY - 100;
              break;
            case "arcFill":
              activeNodeInfo.value.x = el.offsetX;
              activeNodeInfo.value.y = el.offsetY;
              break;
            case "three":
              activeNodeInfo.value.x1 = el.offsetX;
              activeNodeInfo.value.y1 = el.offsetY - 100;
              activeNodeInfo.value.x2 = el.offsetX - 100;
              activeNodeInfo.value.y2 = el.offsetY + 100;
              activeNodeInfo.value.x3 = el.offsetX + 100;
              activeNodeInfo.value.y3 = el.offsetY + 100;
              break;
          }
          moveLineInfo(el);
          draw();
        }
      }
    };
    var canvasLeave = function canvasLeave(el) {
      legendActiveItem.value = undefined;
    };
    //节点移动时线条位置的改变
    var moveLineInfo = function moveLineInfo(el) {
      if (!activeNodeInfo.value || !activeNodeInfo.value.fromList) {
        return;
      }
      if (activeNodeInfo.value.fromList.length > 0) {
        activeNodeInfo.value.fromList.forEach(function (Item) {
          var line = nodeList.value.find(function (item) {
            return Item === item.id;
          });
          line.fromX = el.offsetX;
          line.fromY = el.offsetY;
        });
      }
      if (activeNodeInfo.value.targetList.length > 0) {
        activeNodeInfo.value.targetList.forEach(function (Item) {
          var line = nodeList.value.find(function (item) {
            return Item === item.id;
          });
          line.targetX = el.offsetX;
          line.targetY = el.offsetY;
        });
      }
    };
    //画布初始化
    var canvasInit = function canvasInit(list) {
      canvas = document.getElementById("canvas");
      canvasMode = canvas.getContext("2d");
      nodeList.value = list;
      draw(null);
    };
    //创建连接起始点
    var createLinkTarget = function createLinkTarget(el) {
      var linkLineInfo = nodeList.value[nodeList.value.findIndex(function (item) {
        return item.id === activeLineId.value;
      })];
      if (el.offsetX > 0 && el.offsetY > 0) {
        linkLineInfo.targetX = el.offsetX;
        linkLineInfo.targetY = el.offsetY;
        requestAnimationFrame(draw);
      }
    };
    //绘制图形(核心方法)
    var draw = function draw(positionInfo) {
      canvasMode.clearRect(0, 0, canvas.width, canvas.height);
      nodeList.value.forEach(function (item, index) {
        canvasMode.beginPath();
        canvasMode.lineWidth = 5;
        /**填充矩形(实物) */
        if (item.modeType === "rectFill") {
          canvasMode.rect(item.x, item.y, item.width, item.height);
          canvasMode.fillStyle = item.color;
          canvasMode.strokeStyle = item.color;
          canvasMode.fill();
          canvasMode.stroke();
          canvasMode.fillStyle = item.text.color;
          canvasMode.font = "18px Times";
          canvasMode.fillText(item.text.info, item.x + 80, item.y + 100);
        } else if (item.modeType === "three") {
          /**描边三角形(业务线)*/
          canvasMode.moveTo(item.x1, item.y1);
          canvasMode.lineTo(item.x2, item.y2);
          canvasMode.lineTo(item.x3, item.y3);
          canvasMode.lineTo(item.x1, item.y1);
          canvasMode.closePath();
          canvasMode.fillStyle = item.color;
          canvasMode.fill();
          canvasMode.fillStyle = item.text.color;
          canvasMode.font = "18px Times";
          canvasMode.fillText(item.text.info, item.x1 - 30, item.y1 + 130);
        } else if (item.modeType === "rectStroke") {
          /**描边矩形(模块)*/
          canvasMode.rect(item.x, item.y, item.width, item.height);
          canvasMode.fillStyle = "#fff";
          canvasMode.strokeStyle = item.color;
          canvasMode.fill();
          canvasMode.stroke();
          canvasMode.fillStyle = item.text.color;
          canvasMode.font = "18px Times";
          canvasMode.fillText(item.text.info, item.x + 80, item.y + 100);
        } else if (item.modeType === "arcFill") {
          /**圆形(供应商)*/
          canvasMode.arc(item.x, item.y, item.arcSize, 0, Math.PI * 2, false);
          canvasMode.fillStyle = "#fff";
          canvasMode.strokeStyle = item.color;
          canvasMode.fill();
          canvasMode.stroke();
          canvasMode.fillStyle = item.text.color;
          canvasMode.font = "18px Times";
          canvasMode.fillText(item.text.info, item.x - 30, item.y);
        } else if (item.modeType === "linkLine") {
          /**连线*/
          canvasMode.moveTo(item.fromX, item.fromY);
          if (item.targetX && item.targetY) {
            canvasMode.lineTo(item.targetX, item.targetY);
          } else {
            canvasMode.lineTo(item.fromX, item.fromY);
          }
          canvasMode.lineCap = "round";
          canvasMode.fillStyle = item.color;
          canvasMode.strokeStyle = item.color;
          canvasMode.fill();
          canvasMode.stroke();
        }
        /*绘制文本*/else if (item.modeType === "text") {
          canvasMode.strokeStyle = canvasStyleInfo.value.background;
          canvasMode.fillStyle = canvasStyleInfo.value.background;
          canvasMode.lineWidth = 1;
          var maxLength = item.info.reduce(function (newVal, oldVal) {
            return newVal.length > oldVal.length ? newVal.length : oldVal.length;
          });
          canvasMode.rect(item.textX - 200, item.textY - 50, (maxLength + 1) * 10, (item.info.length + 1) * 20);
          canvasMode.fill();
          canvasMode.stroke();
          canvasMode.fillStyle = item.color;
          canvasMode.font = "18px Times";
          item.info.forEach(function (m, n) {
            canvasMode.fillText(m, item.textX - 200, item.textY - 30 + 20 * n);
          });
        }

        //判断点击触发元素
        if (positionInfo) {
          var isTarget_path = canvasMode.isPointInPath(positionInfo.x, positionInfo.y);
          var isTarget_stroke = canvasMode.isPointInStroke(positionInfo.x, positionInfo.y);
          if (isTarget_path || isTarget_stroke) {
            console.log("点击到了某元素", item, index);
            activeNodeInfo.value = item;
            if (isLinkLine.value === true) {
              if (activeLineId.value) {
                if (eventName.value === "mousedown") {
                  if (item.modeType !== "linkLine") {
                    linkLineFrom.value = item.id;
                    item.fromList.push(activeLineId.value);
                  }
                } else if (eventName.value === "mouseup") {
                  if (item.modeType !== "linkLine") {
                    linkLineTarget.value = item.id;
                    item.targetList.push(activeLineId.value);
                  }
                }
              }
            }
            if (activeNodeInfo.value.modeType === 'text') {
              textareaShow.value = true;
              textareaClass.value.left = activeNodeInfo.value.textX + 'px';
              textareaClass.value.top = activeNodeInfo.value.textY - 50 + 'px';
              textareaClass.value.rows = 5;
              var str = activeNodeInfo.value.info.join('\n');
              textareaValue.value = "".concat(str);
            }
          }
        }
        canvasMode.closePath();
      });
    };
    //通过操作对节点列表数据进行修改
    var changeNodeList = function changeNodeList(position) {
      isLinkLine.value = false;
      switch (legendActiveItem.value) {
        case "entiry":
          nodeList.value.push((0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createRectFill)(position));
          break;
        case "triangle":
          nodeList.value.push((0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createTreeBox)(position));
          break;
        case "mode":
          nodeList.value.push((0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createRectStroke)(position));
          break;
        case "ellipse":
          nodeList.value.push((0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createArcStroke)(position));
          break;
        case "link":
          var lineInfo = (0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createLinkLine)(position);
          nodeList.value.push(lineInfo);
          activeLineId.value = lineInfo.id;
          isLinkLine.value = true;
          break;
        case "label":
          var Info = (0,_javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createText)(position);
          var textInfo = "".concat(textareaValue.value);
          Info.info = textInfo.split('\n');
          textareaValue.value = '';
          textareaShow.value = false;
          nodeList.value.push(Info);
          break;
      }
      var list0 = [];
      var list1 = [];
      var list2 = [];
      var list3 = [];
      nodeList.value.forEach(function (m) {
        if (m.nodeIndex === 0) {
          list0.push(m);
        } else if (m.nodeIndex === 1) {
          list1.push(m);
        } else if (m.nodeIndex === 2) {
          list2.push(m);
        } else if (m.nodeIndex === 1000) {
          list3.push(m);
        }
      });
      nodeList.value = [].concat(list0).concat(list1).concat(list2).concat(list3);
    };
    var changeScale = function changeScale() {
      requestAnimationFrame(draw);
    };
    //修改节点主题色
    var changeNodeThemeColor = function changeNodeThemeColor(value) {
      activeNodeInfo.value.color = value;
      requestAnimationFrame(draw);
    };
    //修改节点字体颜色
    var changeNodeTextColor = function changeNodeTextColor(value) {
      activeNodeInfo.value.text.color = value;
      requestAnimationFrame(draw);
    };
    //修改节点中的字体文字
    var changeNodeTextInfo = function changeNodeTextInfo(value) {
      activeNodeInfo.value.text.info = value;
      requestAnimationFrame(draw);
    };
    //删除当前选中节点
    var deleteNode = function deleteNode() {
      textareaShow.value = false;
      textareaValue.value = '';
      var index = nodeList.value.findIndex(function (item) {
        return item.id === activeNodeInfo.value.id;
      });
      nodeList.value.splice(index, 1);
      if (activeNodeInfo.value.fromList) {
        activeNodeInfo.value.fromList.forEach(function (m) {
          if (m) {
            deleteLinkLine(m);
          }
        });
      }
      if (activeNodeInfo.value.targetList) {
        activeNodeInfo.value.targetList.forEach(function (m) {
          if (m) {
            deleteLinkLine(m);
          }
        });
      }
      requestAnimationFrame(draw);
    };
    //删除当前选中连接线
    var deleteLine = function deleteLine() {
      deleteLinkLine(activeNodeInfo.value.id);
    };
    //删除节点附带的连接线
    var deleteLinkLine = function deleteLinkLine(id) {
      var index = nodeList.value.findIndex(function (m) {
        return m.id === id;
      });
      if (index !== -1) {
        nodeList.value.splice(index, 1);
      }
      nodeList.value.forEach(function (n) {
        if (n.fromList) {
          var fromIndex = n.fromList.findIndex(function (z) {
            return z === id;
          });
          if (fromIndex !== -1) {
            n.fromList.splice(fromIndex, 1);
          }
        }
        if (n.targetList) {
          var targetIndex = n.targetList.findIndex(function (z) {
            return z === id;
          });
          if (targetIndex !== -1) {
            n.targetList.splice(targetIndex, 1);
          }
        }
      });
      requestAnimationFrame(draw);
    };
    //文本框焦点消失时保存文本
    var saveTextareaValue = function saveTextareaValue() {
      textareaShow.value = false;
      changeNodeList({
        x: parseInt(textareaClass.value.left),
        y: parseInt(textareaClass.value.top) + 50
      });
    };
    //下载
    var downLoad = function downLoad() {
      var dataURL = canvas.toDataURL('image/png');

      // 创建img元素，用于预览图片
      var img = document.createElement('img');
      img.src = dataURL;
      document.body.appendChild(img);

      // 创建a元素，用于下载图片
      var link = document.createElement('a');
      link.href = dataURL;
      link.download = "".concat(imageName.value, ".png");

      // 添加a元素到DOM中，并触发点击事件以下载图片
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(img);
      document.body.removeChild(link);
    };
    expose({
      nodeList: nodeList,
      canvasInit: canvasInit
    });
    var __returned__ = {
      draggable: draggable,
      route: route,
      get mousePosition() {
        return mousePosition;
      },
      set mousePosition(v) {
        mousePosition = v;
      },
      get lengendList() {
        return lengendList;
      },
      set lengendList(v) {
        lengendList = v;
      },
      get utilsList() {
        return utilsList;
      },
      set utilsList(v) {
        utilsList = v;
      },
      get legendActiveItem() {
        return legendActiveItem;
      },
      set legendActiveItem(v) {
        legendActiveItem = v;
      },
      get isMode() {
        return isMode;
      },
      set isMode(v) {
        isMode = v;
      },
      get canvas() {
        return canvas;
      },
      set canvas(v) {
        canvas = v;
      },
      get canvasMode() {
        return canvasMode;
      },
      set canvasMode(v) {
        canvasMode = v;
      },
      get nodeList() {
        return nodeList;
      },
      set nodeList(v) {
        nodeList = v;
      },
      get activeNodeInfo() {
        return activeNodeInfo;
      },
      set activeNodeInfo(v) {
        activeNodeInfo = v;
      },
      get isLinkLine() {
        return isLinkLine;
      },
      set isLinkLine(v) {
        isLinkLine = v;
      },
      get activeLineId() {
        return activeLineId;
      },
      set activeLineId(v) {
        activeLineId = v;
      },
      get linkLineFlag() {
        return linkLineFlag;
      },
      set linkLineFlag(v) {
        linkLineFlag = v;
      },
      get linkLineFrom() {
        return linkLineFrom;
      },
      set linkLineFrom(v) {
        linkLineFrom = v;
      },
      get linkLineTarget() {
        return linkLineTarget;
      },
      set linkLineTarget(v) {
        linkLineTarget = v;
      },
      get clickNodeFlag() {
        return clickNodeFlag;
      },
      set clickNodeFlag(v) {
        clickNodeFlag = v;
      },
      get eventName() {
        return eventName;
      },
      set eventName(v) {
        eventName = v;
      },
      get canvasStyleInfo() {
        return canvasStyleInfo;
      },
      set canvasStyleInfo(v) {
        canvasStyleInfo = v;
      },
      get imageName() {
        return imageName;
      },
      set imageName(v) {
        imageName = v;
      },
      get textareaValue() {
        return textareaValue;
      },
      set textareaValue(v) {
        textareaValue = v;
      },
      get textareaShow() {
        return textareaShow;
      },
      set textareaShow(v) {
        textareaShow = v;
      },
      get textareaClass() {
        return textareaClass;
      },
      set textareaClass(v) {
        textareaClass = v;
      },
      dragOptions: dragOptions,
      get lengendClass() {
        return lengendClass;
      },
      set lengendClass(v) {
        lengendClass = v;
      },
      get clickLengend() {
        return clickLengend;
      },
      set clickLengend(v) {
        clickLengend = v;
      },
      moveStart: moveStart,
      moveEnd: moveEnd,
      clickCanvas: clickCanvas,
      canvasDown: canvasDown,
      canvasUp: canvasUp,
      canvasMove: canvasMove,
      canvasLeave: canvasLeave,
      moveLineInfo: moveLineInfo,
      get canvasInit() {
        return canvasInit;
      },
      set canvasInit(v) {
        canvasInit = v;
      },
      get createLinkTarget() {
        return createLinkTarget;
      },
      set createLinkTarget(v) {
        createLinkTarget = v;
      },
      draw: draw,
      changeNodeList: changeNodeList,
      changeScale: changeScale,
      changeNodeThemeColor: changeNodeThemeColor,
      changeNodeTextColor: changeNodeTextColor,
      changeNodeTextInfo: changeNodeTextInfo,
      deleteNode: deleteNode,
      deleteLine: deleteLine,
      deleteLinkLine: deleteLinkLine,
      saveTextareaValue: saveTextareaValue,
      downLoad: downLoad,
      get allConfig() {
        return _javascript_flowchartConfig__WEBPACK_IMPORTED_MODULE_0__["default"];
      },
      get VueDraggableNext() {
        return vue_draggable_next__WEBPACK_IMPORTED_MODULE_3__.VueDraggableNext;
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage;
      },
      get uuidv4() {
        return uuid__WEBPACK_IMPORTED_MODULE_6__["default"];
      },
      get createRectFill() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createRectFill;
      },
      get createTreeBox() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createTreeBox;
      },
      get createRectStroke() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createRectStroke;
      },
      get createArcStroke() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createArcStroke;
      },
      get createLinkLine() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createLinkLine;
      },
      get createText() {
        return _javascript_globalFlowFun_js__WEBPACK_IMPORTED_MODULE_1__.createText;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 74127:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalFormInfo.vue?vue&type=script&setup=true&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var _components_globalFlow_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/globalFlow.vue */ 44741);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'globalFormInfo',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_4__.useRoute)();
    var templateList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    var formData = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({});
    var rules = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({});
    var fileList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    var ruleFormRef = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(null);
    var dialogFlowChart = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false);
    var globalFlow = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(null);
    var reqTemplate = function reqTemplate() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicForm/template"), {
        type: route.query.mode
      }).then(function (res) {
        if (res.code === 200) {
          templateList.value = res.data;
          //组织数据
          templateList.value.forEach(function (item) {
            item.formList.forEach(function (val) {
              if (val.optionsSource && val.optionsSource === "request") {
                requestOPtions(val);
              }
              //表单数据汇总
              formData[val.name] = val["default"];
              if (val.rule) {
                var index = val.rule.findIndex(function (z) {
                  return z.pattern;
                });
                //匹配正则
                if (index !== -1) {
                  val.rule[index].pattern = new RegExp(val.rule[index].pattern);
                }
                //表单权限汇总
                rules[val.name] = val.rule;
              }
            });
          });
          console.log(route.query.uuid, "uuid的值");
          if (route.query.type !== "new") {
            reqFormData();
          }
        } else {
          (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
            message: res.message,
            type: "warning"
          });
        }
      });
    };
    var reqFormData = function reqFormData() {
      var query = {
        uuid: route.query.uuid,
        mode: route.query.mode
      };
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/detail"), query).then(function (res) {
        if (res.code === 200) {
          for (var val in res.data) {
            formData[val] = res.data[val];
          }
        }
      });
    };
    var setDisableDate = function setDisableDate(time) {
      return time.getTime() < Date.now();
    };
    var requestOPtions = function requestOPtions(item) {
      if (item.requestMethod === "get") {
        _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app").concat(item.requestName)).then(function (res) {
          if (res.code === 200) {
            item.options = res.data;
          } else {
            (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
              message: res.message,
              type: "warning"
            });
          }
        });
      } else {
        console.log(item, "???---探索");
        _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app").concat(item.requestName), item.query).then(function (res) {
          if (res.code === 200) {
            res.data.forEach(function (v) {
              console.log(v);
              item.options.push({
                label: v["".concat(item.query["mode"], "CnName")],
                value: v.uuid
              });
            });
          } else {
            (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
              message: res.message,
              type: "warning"
            });
          }
        });
      }
    };
    var requestFile = function requestFile(a, b) {
      console.log(a, b, "自上传文件");
      formData["upload"] = "youtube.com";
    };
    var add = function add(ruleFormRef) {
      formData.mode = route.query.mode;
      if (!ruleFormRef) return;
      ruleFormRef.validate(function (valid, fields) {
        if (valid) {
          _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/add"), formData).then(function (res) {
            if (res.code === 200) {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
                message: res.message,
                type: "success"
              });
              jumpToList();
            } else {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
                message: res.message,
                type: "warning"
              });
            }
          });
        } else {}
      });
    };
    var edit = function edit(ruleFormRef) {
      formData.mode = route.query.mode;
      if (!ruleFormRef) return;
      ruleFormRef.validate(function (valid, fields) {
        if (valid) {
          _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/edit"), formData).then(function (res) {
            if (res.code === 200) {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
                message: res.message,
                type: "success"
              });
              jumpToList();
            } else {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
                message: res.message,
                type: "warning"
              });
            }
          });
        } else {}
      });
    };
    var jumpToList = function jumpToList() {
      var list = route.path.split("/");
      list.pop();
      list.push("".concat(list[list.length - 1], "List"));
      var path = list.join("/");
      router.push({
        path: path
      });
    };
    var disabledFun = function disabledFun(flag) {
      if (route.query.type === "detail" || route.query.type !== "new" && flag === true) {
        return true;
      } else {
        return false;
      }
    };
    var openFlowChart = function openFlowChart() {
      dialogFlowChart.value = true;
      console.log(globalFlow, "组件");
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
        globalFlow.value.canvasInit(formData.flowChart);
      });
    };
    var handleClose = function handleClose() {
      dialogFlowChart.value = false;
    };
    var saveEntiryCanvas = function saveEntiryCanvas() {
      formData.flowChart = globalFlow.value.nodeList;
      dialogFlowChart.value = false;
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_2__.onMounted)(function () {
      reqTemplate();
    });
    var __returned__ = {
      router: router,
      route: route,
      get templateList() {
        return templateList;
      },
      set templateList(v) {
        templateList = v;
      },
      get formData() {
        return formData;
      },
      set formData(v) {
        formData = v;
      },
      get rules() {
        return rules;
      },
      set rules(v) {
        rules = v;
      },
      get fileList() {
        return fileList;
      },
      set fileList(v) {
        fileList = v;
      },
      get ruleFormRef() {
        return ruleFormRef;
      },
      set ruleFormRef(v) {
        ruleFormRef = v;
      },
      get dialogFlowChart() {
        return dialogFlowChart;
      },
      set dialogFlowChart(v) {
        dialogFlowChart = v;
      },
      get globalFlow() {
        return globalFlow;
      },
      set globalFlow(v) {
        globalFlow = v;
      },
      reqTemplate: reqTemplate,
      reqFormData: reqFormData,
      setDisableDate: setDisableDate,
      requestOPtions: requestOPtions,
      requestFile: requestFile,
      add: add,
      edit: edit,
      jumpToList: jumpToList,
      disabledFun: disabledFun,
      openFlowChart: openFlowChart,
      handleClose: handleClose,
      saveEntiryCanvas: saveEntiryCanvas,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_4__.useRouter;
      },
      get useRoute() {
        return vue_router__WEBPACK_IMPORTED_MODULE_4__.useRoute;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      nextTick: vue__WEBPACK_IMPORTED_MODULE_2__.nextTick,
      onMounted: vue__WEBPACK_IMPORTED_MODULE_2__.onMounted,
      reactive: vue__WEBPACK_IMPORTED_MODULE_2__.reactive,
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage;
      },
      GlobalFlow: _components_globalFlow_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 70205:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalFlow.vue?vue&type=template&id=5f7f1d01&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-5f7f1d01"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "flowBox"
};
var _hoisted_2 = {
  "class": "legend"
};
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "图例", -1 /* HOISTED */);
});
var _hoisted_4 = {
  "class": "legendBox",
  id: "legendBox"
};
var _hoisted_5 = ["node_type", "onMousedown"];
var _hoisted_6 = ["src"];
var _hoisted_7 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "工具", -1 /* HOISTED */);
});
var _hoisted_8 = ["node_type", "onMousedown"];
var _hoisted_9 = ["src"];
var _hoisted_10 = {
  "class": "setting"
};
var _hoisted_11 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "画布信息", -1 /* HOISTED */);
});
var _hoisted_12 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "画布背景色:", -1 /* HOISTED */);
});
var _hoisted_13 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "画布下载", -1 /* HOISTED */);
});
var _hoisted_14 = {
  style: {
    "display": "flex"
  }
};
var _hoisted_15 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "节点信息", -1 /* HOISTED */);
});
var _hoisted_16 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "节点主题颜色", -1 /* HOISTED */);
});
var _hoisted_17 = {
  key: 0
};
var _hoisted_18 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "节点字体颜色", -1 /* HOISTED */);
});
var _hoisted_19 = {
  key: 1
};
var _hoisted_20 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "节点文字信息", -1 /* HOISTED */);
});
var _hoisted_21 = {
  key: 2
};
var _hoisted_22 = {
  key: 3
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_col = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-col");
  var _component_el_row = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-row");
  var _component_el_color_picker = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-color-picker");
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [_hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["draggable"], {
        onStart: $setup.moveStart,
        onEnd: $setup.moveEnd,
        modelValue: $setup.lengendList,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
          return $setup.lengendList = $event;
        }),
        options: $setup.dragOptions,
        style: {
          "display": "contents"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.lengendList, function (legendItem, lengendIndex) {
            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_col, {
              span: 12,
              key: lengendIndex
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
                  "class": (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)($setup.lengendClass(legendItem.name)),
                  node_type: legendItem.name,
                  onMousedown: function onMousedown($event) {
                    return $setup.clickLengend(legendItem.name);
                  }
                }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
                  src: __webpack_require__(95219)("./".concat(legendItem.svgName, ".svg")),
                  alt: ""
                }, null, 8 /* PROPS */, _hoisted_6), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(legendItem.title), 1 /* TEXT */)], 42 /* CLASS, PROPS, HYDRATE_EVENTS */, _hoisted_5)];
              }),
              _: 2 /* DYNAMIC */
            }, 1024 /* DYNAMIC_SLOTS */);
          }), 128 /* KEYED_FRAGMENT */))];
        }),

        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["modelValue"])];
    }),
    _: 1 /* STABLE */
  })]), _hoisted_7, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.utilsList, function (utilName, lengendIndex) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_col, {
          span: 12,
          key: lengendIndex
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
              "class": (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)($setup.lengendClass(utilName.name)),
              node_type: utilName.name,
              onMousedown: function onMousedown($event) {
                return $setup.clickLengend(utilName.name);
              }
            }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
              src: __webpack_require__(95219)("./".concat(utilName.svgName, ".svg")),
              alt: ""
            }, null, 8 /* PROPS */, _hoisted_9), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(utilName.title), 1 /* TEXT */)], 42 /* CLASS, PROPS, HYDRATE_EVENTS */, _hoisted_8)];
          }),
          _: 2 /* DYNAMIC */
        }, 1024 /* DYNAMIC_SLOTS */);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    "class": (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(!$setup.isMode ? 'chartNormal' : 'chartMode')
  }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("canvas", {
    width: "1500",
    height: "800",
    id: "canvas",
    onMousedown: $setup.canvasDown,
    onMouseup: $setup.canvasUp,
    onMousemove: $setup.canvasMove,
    onClick: $setup.clickCanvas,
    style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)({
      background: $setup.canvasStyleInfo.background
    })
  }, null, 36 /* STYLE, HYDRATE_EVENTS */)], 2 /* CLASS */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_10, [_hoisted_11, _hoisted_12, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_color_picker, {
    modelValue: $setup.canvasStyleInfo.background,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
      return $setup.canvasStyleInfo.background = $event;
    }),
    disabled: $setup.route.query.type === 'detail'
  }, null, 8 /* PROPS */, ["modelValue", "disabled"]), _hoisted_13, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_14, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    modelValue: $setup.imageName,
    "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
      return $setup.imageName = $event;
    }),
    placeholder: "请输入图片名称",
    style: {
      "width": "140px"
    }
  }, null, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    style: {
      "width": "30px"
    },
    onClick: $setup.downLoad
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("下载")];
    }),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <p>画布缩放比例:</p>\r\n      <el-slider v-model=\"canvasStyleInfo.scale\" :show-tooltip=\"false\" :min=\"0\" :max=\"2\" :step=\"0.1\" style=\"width: 180px;\" @input=\"changeScale\"/> "), $setup.activeNodeInfo.id && $setup.nodeList.length > 0 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    key: 0
  }, [_hoisted_15, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [_hoisted_16, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_color_picker, {
    disabled: $setup.route.query.type === 'detail',
    modelValue: $setup.activeNodeInfo.color,
    "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
      return $setup.activeNodeInfo.color = $event;
    }),
    onActiveChange: $setup.changeNodeThemeColor
  }, null, 8 /* PROPS */, ["disabled", "modelValue"])]), $setup.activeNodeInfo.modeType !== 'linkLine' && $setup.activeNodeInfo.modeType !== 'text' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_17, [_hoisted_18, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_color_picker, {
    disabled: $setup.route.query.type === 'detail',
    modelValue: $setup.activeNodeInfo.text.color,
    "onUpdate:modelValue": _cache[4] || (_cache[4] = function ($event) {
      return $setup.activeNodeInfo.text.color = $event;
    }),
    onActiveChange: $setup.changeNodeTextColor
  }, null, 8 /* PROPS */, ["disabled", "modelValue"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.activeNodeInfo.modeType !== 'linkLine' && $setup.activeNodeInfo.modeType !== 'text' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_19, [_hoisted_20, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    disabled: $setup.route.query.type === 'detail',
    modelValue: $setup.activeNodeInfo.text.info,
    "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
      return $setup.activeNodeInfo.text.info = $event;
    }),
    style: {},
    onInput: $setup.changeNodeTextInfo
  }, null, 8 /* PROPS */, ["disabled", "modelValue"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.activeNodeInfo.modeType === 'linkLine' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_21, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.deleteLine,
    disabled: $setup.route.query.type === 'detail'
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("删除连线")];
    }),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["disabled"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.activeNodeInfo.modeType !== 'linkLine' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_22, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.deleteNode,
    disabled: $setup.route.query.type === 'detail'
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("删除节点")];
    }),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["disabled"])])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 64 /* STABLE_FRAGMENT */)) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    disabled: $setup.route.query.type === 'detail',
    onBlur: $setup.saveTextareaValue,
    style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)($setup.textareaClass),
    modelValue: $setup.textareaValue,
    "onUpdate:modelValue": _cache[6] || (_cache[6] = function ($event) {
      return $setup.textareaValue = $event;
    }),
    maxlength: "30",
    "show-word-limit": "",
    type: "textarea",
    rows: $setup.textareaClass.rows
  }, null, 8 /* PROPS */, ["disabled", "style", "modelValue", "rows"]), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.textareaShow]])]);
}

/***/ }),

/***/ 24315:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/globalFormInfo.vue?vue&type=template&id=262d97e5&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-262d97e5"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "mainBox"
};
var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("template", null, null, -1 /* HOISTED */);
});
var _hoisted_3 = {
  "class": "timeBox"
};
var _hoisted_4 = {
  "class": "timeBox"
};
var _hoisted_5 = {
  "class": "footer"
};
var _hoisted_6 = {
  "class": "fullDiaLog"
};
var _hoisted_7 = {
  "class": "dialog-footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_QuestionFilled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("QuestionFilled");
  var _component_el_icon = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-icon");
  var _component_el_tooltip = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-tooltip");
  var _component_el_form_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form-item");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_radio = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-radio");
  var _component_el_radio_group = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-radio-group");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_upload = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-upload");
  var _component_el_date_picker = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-date-picker");
  var _component_el_col = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-col");
  var _component_el_row = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-row");
  var _component_el_form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
    ref: "ruleFormRef",
    model: $setup.formData,
    rules: $setup.rules,
    "label-width": "120px",
    "class": "demo-ruleForm",
    "status-icon": ""
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.templateList, function (Item, Index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
          key: Index
        }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(Item.title), 1 /* TEXT */), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, {
          "class": "tem"
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(Item.formList, function (item, index) {
              return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_col, {
                span: 12,
                key: index,
                style: {
                  "margin": "10px 0"
                }
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [_hoisted_2, item.type === 'input' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 0,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        clearable: "",
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'textarea' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 1,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        rows: 4,
                        type: "textarea",
                        clearable: "",
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'select' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 2,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        clearable: "",
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item.options, function (m, n) {
                            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                              key: n,
                              label: m.label,
                              value: m.value
                            }, null, 8 /* PROPS */, ["label", "value"]);
                          }), 128 /* KEYED_FRAGMENT */))];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'radio' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 3,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_radio_group, {
                        "class": "ml-4",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item.options, function (m, n) {
                            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_radio, {
                              label: m.label,
                              size: "large",
                              key: n
                            }, {
                              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                                return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(m.text), 1 /* TEXT */)];
                              }),

                              _: 2 /* DYNAMIC */
                            }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label"]);
                          }), 128 /* KEYED_FRAGMENT */))];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'multiple_select' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 4,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        multiple: "",
                        clearable: "",
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item.options, function (m, n) {
                            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                              key: n,
                              label: m.label,
                              value: m.value
                            }, null, 8 /* PROPS */, ["label", "value"]);
                          }), 128 /* KEYED_FRAGMENT */))];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'upload' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 5,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_upload, {
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        "class": "formItem upload-demo",
                        "http-request": $setup.requestFile,
                        limit: 1,
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, {
                        tip: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, "文件地址:  " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.formData["upload"]), 1 /* TEXT */)];
                        }),

                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
                            type: "primary"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("上传文件")];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue", "disabled"]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'date' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 6,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_date_picker, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        type: "date",
                        "disabled-date": $setup.setDisableDate,
                        size: "default",
                        "value-format": "YYYY-MM-DD",
                        clearable: "",
                        disabled: $setup.disabledFun(item.editDisabled)
                      }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "disabled"])]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'timeRange' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 7,
                    label: item.label,
                    prop: item.name
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_date_picker, {
                        "class": "formItem",
                        modelValue: $setup.formData[item.name],
                        "onUpdate:modelValue": function onUpdateModelValue($event) {
                          return $setup.formData[item.name] = $event;
                        },
                        type: "daterange",
                        "disabled-date": $setup.setDisableDate,
                        size: "default",
                        "range-separator": "至",
                        "start-placeholder": "开始时间",
                        "end-placeholder": "结束时间",
                        disabled: $setup.disabledFun(item.editDisabled),
                        "value-format": "YYYY-MM-DD"
                      }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "disabled"])]), item.remark ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tooltip, {
                        key: 0,
                        "class": "box-item",
                        effect: "dark",
                        content: item.remark,
                        placement: "top"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
                            size: "20px",
                            "class": "iconBox"
                          }, {
                            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_QuestionFilled)];
                            }),
                            _: 1 /* STABLE */
                          })];
                        }),

                        _: 2 /* DYNAMIC */
                      }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["content"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                    }),
                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"])) : item.type === 'flowChart' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
                    key: 8,
                    label: item.label
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
                        onClick: $setup.openFlowChart,
                        type: "primary"
                      }, {
                        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("打开画布")];
                        }),
                        _: 1 /* STABLE */
                      })];
                    }),

                    _: 2 /* DYNAMIC */
                  }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
                }),
                _: 2 /* DYNAMIC */
              }, 1024 /* DYNAMIC_SLOTS */);
            }), 128 /* KEYED_FRAGMENT */))];
          }),

          _: 2 /* DYNAMIC */
        }, 1024 /* DYNAMIC_SLOTS */)], 64 /* STABLE_FRAGMENT */);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["model", "rules"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [$setup.route.query.type === 'new' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
    key: 0,
    type: "primary",
    onClick: _cache[0] || (_cache[0] = function ($event) {
      return $setup.add($setup.ruleFormRef);
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 创建 ")];
    }),
    _: 1 /* STABLE */
  })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.route.query.type === 'edit' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
    key: 1,
    type: "primary",
    onClick: _cache[1] || (_cache[1] = function ($event) {
      return $setup.edit($setup.ruleFormRef);
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 保存 ")];
    }),
    _: 1 /* STABLE */
  })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    onClick: $setup.jumpToList
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("返回")];
    }),
    _: 1 /* STABLE */
  })])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_dialog, {
    fullscreen: "",
    modelValue: $setup.dialogFlowChart,
    "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
      return $setup.dialogFlowChart = $event;
    }),
    title: "实体模型图",
    "before-close": $setup.handleClose
  }, {
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_7, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: _cache[2] || (_cache[2] = function ($event) {
          return $setup.dialogFlowChart = false;
        })
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("返回")];
        }),
        _: 1 /* STABLE */
      }), $setup.route.query.type !== 'detail' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
        key: 0,
        type: "primary",
        onClick: $setup.saveEntiryCanvas
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 保存 ")];
        }),
        _: 1 /* STABLE */
      })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)])];
    }),
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["GlobalFlow"], {
        ref: "globalFlow"
      }, null, 512 /* NEED_PATCH */)];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 92907:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true */ 34207);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 26428:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true */ 31650);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 44741:
/*!***************************************!*\
  !*** ./src/components/globalFlow.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _globalFlow_vue_vue_type_template_id_5f7f1d01_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./globalFlow.vue?vue&type=template&id=5f7f1d01&scoped=true */ 69553);
/* harmony import */ var _globalFlow_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globalFlow.vue?vue&type=script&setup=true&lang=js */ 26811);
/* harmony import */ var _globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true */ 29995);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_globalFlow_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_globalFlow_vue_vue_type_template_id_5f7f1d01_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-5f7f1d01"],['__file',"src/components/globalFlow.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 3286:
/*!*******************************************!*\
  !*** ./src/components/globalFormInfo.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _globalFormInfo_vue_vue_type_template_id_262d97e5_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./globalFormInfo.vue?vue&type=template&id=262d97e5&scoped=true */ 76638);
/* harmony import */ var _globalFormInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globalFormInfo.vue?vue&type=script&setup=true&lang=js */ 49661);
/* harmony import */ var _globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true */ 21176);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_globalFormInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_globalFormInfo_vue_vue_type_template_id_262d97e5_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-262d97e5"],['__file',"src/components/globalFormInfo.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 26811:
/*!**************************************************************************!*\
  !*** ./src/components/globalFlow.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFlow_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFlow_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalFlow.vue?vue&type=script&setup=true&lang=js */ 78074);
 

/***/ }),

/***/ 49661:
/*!******************************************************************************!*\
  !*** ./src/components/globalFormInfo.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFormInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFormInfo_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalFormInfo.vue?vue&type=script&setup=true&lang=js */ 74127);
 

/***/ }),

/***/ 69553:
/*!*********************************************************************************!*\
  !*** ./src/components/globalFlow.vue?vue&type=template&id=5f7f1d01&scoped=true ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFlow_vue_vue_type_template_id_5f7f1d01_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFlow_vue_vue_type_template_id_5f7f1d01_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalFlow.vue?vue&type=template&id=5f7f1d01&scoped=true */ 70205);


/***/ }),

/***/ 76638:
/*!*************************************************************************************!*\
  !*** ./src/components/globalFormInfo.vue?vue&type=template&id=262d97e5&scoped=true ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFormInfo_vue_vue_type_template_id_262d97e5_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_globalFormInfo_vue_vue_type_template_id_262d97e5_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./globalFormInfo.vue?vue&type=template&id=262d97e5&scoped=true */ 24315);


/***/ }),

/***/ 29995:
/*!************************************************************************************************!*\
  !*** ./src/components/globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFlow_vue_vue_type_style_index_0_id_5f7f1d01_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/style-loader/dist/cjs.js!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalFlow.vue?vue&type=style&index=0&id=5f7f1d01&lang=less&scoped=true */ 92907);


/***/ }),

/***/ 21176:
/*!****************************************************************************************************!*\
  !*** ./src/components/globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_globalFormInfo_vue_vue_type_style_index_0_id_262d97e5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/style-loader/dist/cjs.js!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./globalFormInfo.vue?vue&type=style&index=0&id=262d97e5&lang=less&scoped=true */ 26428);


/***/ }),

/***/ 95219:
/*!*****************************************************!*\
  !*** ./src/assets/flowchartSvg/ sync ^\.\/.*\.svg$ ***!
  \*****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./三角形.svg": 94813,
	"./旗帜.svg": 8611,
	"./标注.svg": 59621,
	"./椭圆.svg": 21512,
	"./注意.svg": 1241,
	"./清除.svg": 91863,
	"./矩形.svg": 35318,
	"./笔.svg": 129,
	"./范围.svg": 78638,
	"./连接.svg": 43127,
	"./重置.svg": 26480
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 95219;

/***/ }),

/***/ 94813:
/*!*****************************************!*\
  !*** ./src/assets/flowchartSvg/三角形.svg ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "fa6f4f55599d08ce55a0.svg";

/***/ }),

/***/ 8611:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/旗帜.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "19e176f12198dbb8bb69.svg";

/***/ }),

/***/ 59621:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/标注.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "c5d41410cffd74fdc1c6.svg";

/***/ }),

/***/ 21512:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/椭圆.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "d6f80d38071213867268.svg";

/***/ }),

/***/ 1241:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/注意.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "1108a83803b001a6bf53.svg";

/***/ }),

/***/ 91863:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/清除.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "0dc01401d7a9f4890996.svg";

/***/ }),

/***/ 35318:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/矩形.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "f005ec21afc751ecf323.svg";

/***/ }),

/***/ 129:
/*!***************************************!*\
  !*** ./src/assets/flowchartSvg/笔.svg ***!
  \***************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "5a16413f7b4d9023876d.svg";

/***/ }),

/***/ 78638:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/范围.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "9474d2c55a07b16cd1ce.svg";

/***/ }),

/***/ 43127:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/连接.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "5657b32fc18a98359445.svg";

/***/ }),

/***/ 26480:
/*!****************************************!*\
  !*** ./src/assets/flowchartSvg/重置.svg ***!
  \****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "a96e2150353ce51029d9.svg";

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2NvbXBvbmVudHNfZ2xvYmFsRm9ybUluZm9fdnVlLjY1NzZkMGQ3ZDBjYjE4NzkyYTU1LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUM2RztBQUNqQjtBQUNPO0FBQ25HLDRDQUE0QyxxR0FBOEM7QUFDMUYsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRix5Q0FBeUMsc0ZBQStCO0FBQ3hFO0FBQ0EscUVBQXFFLGdCQUFnQixrQkFBa0Isa0JBQWtCLHVCQUF1QixHQUFHLDBFQUEwRSx1QkFBdUIsaUJBQWlCLGtCQUFrQix3QkFBd0Isa0JBQWtCLDJCQUEyQiwwQkFBMEIsR0FBRyxnRkFBZ0Ysb0JBQW9CLHNCQUFzQixtQ0FBbUMsR0FBRywwQ0FBMEMsWUFBWSwrQkFBK0Isb0JBQW9CLDJCQUEyQixHQUFHLHdDQUF3QyxZQUFZLCtCQUErQiwyQkFBMkIsdUVBQXVFLEdBQUcsZ0RBQWdELHFCQUFxQixpQkFBaUIsaUJBQWlCLGtCQUFrQiwyQkFBMkIsd0JBQXdCLG9CQUFvQixHQUFHLGdEQUFnRCxpQkFBaUIscUJBQXFCLGlCQUFpQixrQkFBa0IsMkJBQTJCLHdCQUF3QiwrQkFBK0Isb0JBQW9CLEdBQUcsU0FBUyw2SEFBNkgsVUFBVSxVQUFVLFVBQVUsV0FBVyxLQUFLLE1BQU0sV0FBVyxVQUFVLFVBQVUsV0FBVyxVQUFVLFdBQVcsV0FBVyxLQUFLLE1BQU0sVUFBVSxXQUFXLFdBQVcsS0FBSyxNQUFNLFdBQVcsV0FBVyxVQUFVLFdBQVcsS0FBSyxNQUFNLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLFlBQVksVUFBVSxVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsS0FBSyxNQUFNLFdBQVcsV0FBVyxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsVUFBVSxxQ0FBcUMsZ0JBQWdCLGtCQUFrQixrQkFBa0IsdUJBQXVCLDBCQUEwQix5QkFBeUIsbUJBQW1CLG9CQUFvQiwwQkFBMEIsb0JBQW9CLDZCQUE2Qiw0QkFBNEIsVUFBVSx3QkFBd0IsMEJBQTBCLHVDQUF1QyxPQUFPLEtBQUssa0JBQWtCLGNBQWMsaUNBQWlDLHNCQUFzQiw2QkFBNkIsS0FBSyxnQkFBZ0IsY0FBYyxpQ0FBaUMsNkJBQTZCLDhEQUE4RCxLQUFLLHdCQUF3Qix1QkFBdUIsbUJBQW1CLG1CQUFtQixvQkFBb0IsNkJBQTZCLDBCQUEwQixzQkFBc0IsS0FBSyx3QkFBd0IsbUJBQW1CLHVCQUF1QixtQkFBbUIsb0JBQW9CLDZCQUE2QiwwQkFBMEIsaUNBQWlDLHNCQUFzQixLQUFLLGdCQUFnQiw2REFBNkQsUUFBUSxHQUFHLGVBQWUsZ0JBQWdCLGtCQUFrQixrQkFBa0IsdUJBQXVCLEdBQUcsd0NBQXdDLHVCQUF1QixpQkFBaUIsa0JBQWtCLHdCQUF3QixrQkFBa0IsMkJBQTJCLDBCQUEwQixHQUFHLDhDQUE4QyxvQkFBb0Isc0JBQXNCLG1DQUFtQyxHQUFHLHlCQUF5QixZQUFZLCtCQUErQixvQkFBb0IsMkJBQTJCLEdBQUcsdUJBQXVCLFlBQVksK0JBQStCLDJCQUEyQiw0REFBNEQsR0FBRywrQkFBK0IscUJBQXFCLGlCQUFpQixpQkFBaUIsa0JBQWtCLDJCQUEyQix3QkFBd0Isb0JBQW9CLEdBQUcsK0JBQStCLGlCQUFpQixxQkFBcUIsaUJBQWlCLGtCQUFrQiwyQkFBMkIsd0JBQXdCLCtCQUErQixvQkFBb0IsR0FBRyxxQkFBcUI7QUFDOWpJO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVnZDO0FBQzZHO0FBQ2pCO0FBQzVGLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxxRUFBcUUsbUJBQW1CLGtCQUFrQix5QkFBeUIsdUJBQXVCLEdBQUcsa0NBQWtDLGtDQUFrQyx3QkFBd0IsR0FBRyxnQ0FBZ0Msb0JBQW9CLHFCQUFxQixHQUFHLHVDQUF1QyxpQkFBaUIsR0FBRyxzQ0FBc0MsaUJBQWlCLGtCQUFrQixHQUFHLG9EQUFvRCxrQkFBa0Isc0JBQXNCLEdBQUcsc0NBQXNDLHNCQUFzQixvQkFBb0IsR0FBRyxxQ0FBcUMsc0JBQXNCLGlCQUFpQixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLGtCQUFrQix3QkFBd0IsOEJBQThCLEdBQUcsbURBQW1ELDRCQUE0QixHQUFHLGlEQUFpRCw0QkFBNEIsR0FBRyxTQUFTLHFJQUFxSSxVQUFVLFVBQVUsV0FBVyxXQUFXLEtBQUssS0FBSyxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsV0FBVyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssV0FBVyxVQUFVLEtBQUssTUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLFlBQVksVUFBVSxLQUFLLE1BQU0sWUFBWSxVQUFVLFVBQVUsV0FBVyxVQUFVLFVBQVUsVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFdBQVcscUNBQXFDLG1CQUFtQixrQkFBa0IseUJBQXlCLHVCQUF1QixZQUFZLG9DQUFvQywwQkFBMEIsS0FBSyxVQUFVLHNCQUFzQix1QkFBdUIsS0FBSyxpQkFBaUIsbUJBQW1CLHNCQUFzQix1QkFBdUIsS0FBSyxjQUFjLG1CQUFtQixvQkFBb0IsS0FBSyx3Q0FBd0Msb0JBQW9CLHdCQUF3QixLQUFLLGdCQUFnQix3QkFBd0Isc0JBQXNCLEtBQUssZUFBZSx3QkFBd0IsbUJBQW1CLGtCQUFrQix5QkFBeUIsbUJBQW1CLGdCQUFnQixvQkFBb0IsMEJBQTBCLGdDQUFnQyxLQUFLLEdBQUcsZUFBZSxrQ0FBa0MsOEJBQThCLEtBQUssZ0NBQWdDLDhCQUE4QixLQUFLLEdBQUcsZUFBZSxtQkFBbUIsa0JBQWtCLHlCQUF5Qix1QkFBdUIsR0FBRyxpQkFBaUIsa0NBQWtDLHdCQUF3QixHQUFHLGVBQWUsb0JBQW9CLHFCQUFxQixHQUFHLHNCQUFzQixpQkFBaUIsR0FBRyxxQkFBcUIsaUJBQWlCLGtCQUFrQixHQUFHLDZDQUE2QyxrQkFBa0Isc0JBQXNCLEdBQUcscUJBQXFCLHNCQUFzQixvQkFBb0IsR0FBRyxvQkFBb0Isc0JBQXNCLGlCQUFpQixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLGtCQUFrQix3QkFBd0IsOEJBQThCLEdBQUcsNENBQTRDLDRCQUE0QixHQUFHLDBDQUEwQyw0QkFBNEIsR0FBRyxxQkFBcUI7QUFDOXdHO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQdkMsSUFBTUEsU0FBUyxHQUFHO0VBQ2RDLFdBQVcsRUFBQyxDQUNSO0lBQ0dDLElBQUksRUFBQyxNQUFNO0lBQ1hDLEtBQUssRUFBQyxJQUFJO0lBQ1ZDLE9BQU8sRUFBQztFQUNYLENBQUMsRUFDRDtJQUNJRixJQUFJLEVBQUMsUUFBUTtJQUNiQyxLQUFLLEVBQUMsSUFBSTtJQUNWQyxPQUFPLEVBQUM7RUFDWCxDQUFDLEVBQ0Q7SUFDR0YsSUFBSSxFQUFDLFNBQVM7SUFDZEMsS0FBSyxFQUFDLEtBQUs7SUFDWEMsT0FBTyxFQUFDO0VBQ1gsQ0FBQyxFQUNEO0lBQ0dGLElBQUksRUFBQyxVQUFVO0lBQ2ZDLEtBQUssRUFBQyxLQUFLO0lBQ1hDLE9BQU8sRUFBQztFQUNYLENBQUMsRUFDRDtJQUNHRixJQUFJLEVBQUMsT0FBTztJQUNaQyxLQUFLLEVBQUMsSUFBSTtJQUNWQyxPQUFPLEVBQUM7RUFDWCxDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtJQUNHRixJQUFJLEVBQUMsTUFBTTtJQUNYQyxLQUFLLEVBQUMsS0FBSztJQUNYQyxPQUFPLEVBQUM7RUFDWCxDQUFDLENBQ0w7RUFDREMsU0FBUyxFQUFDLENBQ1I7SUFDR0gsSUFBSSxFQUFDLFVBQVU7SUFDZkMsS0FBSyxFQUFDLElBQUk7SUFDVkMsT0FBTyxFQUFDO0VBQ1gsQ0FBQyxFQUNEO0lBQ0dGLElBQUksRUFBQyxjQUFjO0lBQ25CQyxLQUFLLEVBQUMsSUFBSTtJQUNWQyxPQUFPLEVBQUM7RUFDWCxDQUFDO0FBRVAsQ0FBQztBQUNELGlFQUFlSixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RFc7QUFDbkM7QUFDTyxJQUFJUSxjQUFjLEdBQUcsU0FBakJBLGNBQWNBLENBQUlDLFFBQVEsRUFBSztFQUN2QyxPQUFPO0lBQ0pDLENBQUMsRUFBRUQsUUFBUSxDQUFDQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUc7SUFDekJDLENBQUMsRUFBRUYsUUFBUSxDQUFDRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUc7SUFDeEJDLEtBQUssRUFBRSxHQUFHO0lBQ1ZDLE1BQU0sRUFBRSxHQUFHO0lBQ1hYLElBQUksRUFBRSxJQUFJO0lBQ1ZZLEtBQUssRUFBRSxLQUFLO0lBQ1pDLFFBQVEsRUFBRSxVQUFVO0lBQ3BCQyxTQUFTLEVBQUUsTUFBTTtJQUNqQkMsRUFBRSxFQUFFVixnREFBTSxFQUFFO0lBQ1pXLFNBQVMsRUFBQyxDQUFDO0lBQ1hDLFFBQVEsRUFBQyxFQUFFO0lBQ1hDLFVBQVUsRUFBQyxFQUFFO0lBQ2JDLElBQUksRUFBQztNQUNGQyxJQUFJLEVBQUMsSUFBSTtNQUNUUixLQUFLLEVBQUM7SUFDVDtFQUNILENBQUM7QUFDSixDQUFDO0FBQ0Q7QUFDTyxJQUFJUyxhQUFhLEdBQUcsU0FBaEJBLGFBQWFBLENBQUlkLFFBQVEsRUFBSztFQUN0QyxPQUFPO0lBQ0plLEVBQUUsRUFBRWYsUUFBUSxDQUFDQyxDQUFDLEdBQUcsR0FBRztJQUNwQmUsRUFBRSxFQUFFaEIsUUFBUSxDQUFDRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUc7SUFDekJlLEVBQUUsRUFBRWpCLFFBQVEsQ0FBQ0MsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQzFCaUIsRUFBRSxFQUFFbEIsUUFBUSxDQUFDRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUc7SUFDekJpQixFQUFFLEVBQUVuQixRQUFRLENBQUNDLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRztJQUMxQm1CLEVBQUUsRUFBRXBCLFFBQVEsQ0FBQ0UsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHO0lBQ3pCVCxJQUFJLEVBQUUsS0FBSztJQUNYWSxLQUFLLEVBQUUsS0FBSztJQUNaQyxRQUFRLEVBQUUsT0FBTztJQUNqQkMsU0FBUyxFQUFFLFFBQVE7SUFDbkJDLEVBQUUsRUFBRVYsZ0RBQU0sRUFBRTtJQUNaVyxTQUFTLEVBQUMsQ0FBQztJQUNYQyxRQUFRLEVBQUMsRUFBRTtJQUNYQyxVQUFVLEVBQUMsRUFBRTtJQUNiQyxJQUFJLEVBQUM7TUFDRkMsSUFBSSxFQUFDLEtBQUs7TUFDVlIsS0FBSyxFQUFDO0lBQ1Q7RUFDSCxDQUFDO0FBQ0osQ0FBQztBQUNEO0FBQ08sSUFBSWdCLGdCQUFnQixHQUFHLFNBQW5CQSxnQkFBZ0JBLENBQUlyQixRQUFRLEVBQUs7RUFDekMsT0FBTztJQUNKQyxDQUFDLEVBQUVELFFBQVEsQ0FBQ0MsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQ3pCQyxDQUFDLEVBQUVGLFFBQVEsQ0FBQ0UsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHO0lBQ3hCQyxLQUFLLEVBQUUsR0FBRztJQUNWQyxNQUFNLEVBQUUsR0FBRztJQUNYWCxJQUFJLEVBQUUsSUFBSTtJQUNWWSxLQUFLLEVBQUUsS0FBSztJQUNaQyxRQUFRLEVBQUUsWUFBWTtJQUN0QkMsU0FBUyxFQUFFLFFBQVE7SUFDbkJDLEVBQUUsRUFBRVYsZ0RBQU0sRUFBRTtJQUNaVyxTQUFTLEVBQUMsQ0FBQztJQUNYQyxRQUFRLEVBQUMsRUFBRTtJQUNYQyxVQUFVLEVBQUMsRUFBRTtJQUNiQyxJQUFJLEVBQUM7TUFDRkMsSUFBSSxFQUFDLElBQUk7TUFDVFIsS0FBSyxFQUFDO0lBQ1Q7RUFDSCxDQUFDO0FBQ0osQ0FBQztBQUNEO0FBQ08sSUFBSWlCLGVBQWUsR0FBRyxTQUFsQkEsZUFBZUEsQ0FBSXRCLFFBQVEsRUFBSztFQUN4QyxPQUFPO0lBQ0pDLENBQUMsRUFBRUQsUUFBUSxDQUFDQyxDQUFDLEdBQUcsR0FBRztJQUNuQkMsQ0FBQyxFQUFFRixRQUFRLENBQUNFLENBQUMsR0FBRyxFQUFFO0lBQ2xCcUIsT0FBTyxFQUFFLEdBQUc7SUFDWjlCLElBQUksRUFBRSxLQUFLO0lBQ1hZLEtBQUssRUFBRSxLQUFLO0lBQ1pDLFFBQVEsRUFBRSxTQUFTO0lBQ25CQyxTQUFTLEVBQUUsTUFBTTtJQUNqQkMsRUFBRSxFQUFFVixnREFBTSxFQUFFO0lBQ1pXLFNBQVMsRUFBQyxDQUFDO0lBQ1hDLFFBQVEsRUFBQyxFQUFFO0lBQ1hDLFVBQVUsRUFBQyxFQUFFO0lBQ2JDLElBQUksRUFBQztNQUNGQyxJQUFJLEVBQUMsS0FBSztNQUNWUixLQUFLLEVBQUM7SUFDVDtFQUNILENBQUM7QUFDSixDQUFDO0FBQ0Q7QUFDTyxJQUFJbUIsY0FBYyxHQUFHLFNBQWpCQSxjQUFjQSxDQUFJeEIsUUFBUSxFQUFLO0VBQ3ZDLE9BQU87SUFDSnlCLEtBQUssRUFBRXpCLFFBQVEsQ0FBQ0MsQ0FBQztJQUNqQnlCLEtBQUssRUFBRTFCLFFBQVEsQ0FBQ0UsQ0FBQztJQUNqQnlCLE9BQU8sRUFBRSxJQUFJO0lBQ2JDLE9BQU8sRUFBRSxJQUFJO0lBQ2JDLFNBQVMsRUFBRSxFQUFFO0lBQ2JwQyxJQUFJLEVBQUUsS0FBSztJQUNYWSxLQUFLLEVBQUUsS0FBSztJQUNaQyxRQUFRLEVBQUUsVUFBVTtJQUNwQkMsU0FBUyxFQUFFLE1BQU07SUFDakJDLEVBQUUsRUFBRVYsZ0RBQU0sRUFBRTtJQUNaVyxTQUFTLEVBQUM7RUFDYixDQUFDO0FBQ0osQ0FBQztBQUNEO0FBQ08sSUFBSXFCLFVBQVUsR0FBRyxTQUFiQSxVQUFVQSxDQUFJOUIsUUFBUSxFQUFJO0VBQ2xDK0IsT0FBTyxDQUFDQyxHQUFHLENBQUNoQyxRQUFRLEVBQUMsTUFBTSxDQUFDO0VBQzVCLE9BQU87SUFDSmlDLEtBQUssRUFBQ2pDLFFBQVEsQ0FBQ0MsQ0FBQztJQUNoQmlDLEtBQUssRUFBQ2xDLFFBQVEsQ0FBQ0UsQ0FBQztJQUNoQkcsS0FBSyxFQUFDLEtBQUs7SUFDWEMsUUFBUSxFQUFDLE1BQU07SUFDZkUsRUFBRSxFQUFDVixnREFBTSxFQUFFO0lBQ1hXLFNBQVMsRUFBQyxJQUFJO0lBQ2RJLElBQUksRUFBQztFQUNSLENBQUM7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEhxRDtBQUNBO0FBQ2I7QUFDTDtBQUN5Rzs7OztBQUM3SSxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixnRUFBZ0I7QUFDcEMsZ0JBQWdCLG9EQUFRO0FBQ3hCLHdCQUF3Qix3Q0FBRztBQUMzQixzQkFBc0IsNkNBQVEsQ0FBQywrRUFBcUI7QUFDcEQsb0JBQW9CLDZDQUFRLENBQUMsNkVBQW1CO0FBQ2hELDJCQUEyQix3Q0FBRztBQUM5QixpQkFBaUIsd0NBQUc7QUFDcEI7QUFDQTtBQUNBLG1CQUFtQix3Q0FBRztBQUN0Qix5QkFBeUIsd0NBQUc7QUFDNUIscUJBQXFCLHdDQUFHO0FBQ3hCLHVCQUF1Qix3Q0FBRztBQUMxQix1QkFBdUIsd0NBQUc7QUFDMUIsdUJBQXVCLHdDQUFHO0FBQzFCLHlCQUF5Qix3Q0FBRztBQUM1Qix3QkFBd0Isd0NBQUc7QUFDM0Isb0JBQW9CLHdDQUFHO0FBQ3ZCLDBCQUEwQix3Q0FBRztBQUM3QjtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkIsd0JBQXdCLHdDQUFHO0FBQzNCLHVCQUF1Qix3Q0FBRztBQUMxQix3QkFBd0Isd0NBQUc7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsdURBQVM7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4Qiw0RUFBYztBQUM1QztBQUNBO0FBQ0EsOEJBQThCLDJFQUFhO0FBQzNDO0FBQ0E7QUFDQSw4QkFBOEIsOEVBQWdCO0FBQzlDO0FBQ0E7QUFDQSw4QkFBOEIsNkVBQWU7QUFDN0M7QUFDQTtBQUNBLHlCQUF5Qiw0RUFBYztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLHdFQUFVO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxtRUFBUztBQUN4QjtBQUNBO0FBQ0EsZUFBZSxnRUFBZ0I7QUFDL0I7QUFDQTtBQUNBLGVBQWUsbURBQVM7QUFDeEI7QUFDQTtBQUNBLGVBQWUsNENBQU07QUFDckI7QUFDQTtBQUNBLGVBQWUsd0VBQWM7QUFDN0I7QUFDQTtBQUNBLGVBQWUsdUVBQWE7QUFDNUI7QUFDQTtBQUNBLGVBQWUsMEVBQWdCO0FBQy9CO0FBQ0E7QUFDQSxlQUFlLHlFQUFlO0FBQzlCO0FBQ0E7QUFDQSxlQUFlLHdFQUFjO0FBQzdCO0FBQ0E7QUFDQSxlQUFlLG9FQUFVO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5ckI4QztBQUNFO0FBQ047QUFDUztBQUNYO0FBQ1k7OztBQUNyRCxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLHFEQUFTO0FBQzFCLGdCQUFnQixvREFBUTtBQUN4Qix1QkFBdUIsd0NBQUc7QUFDMUIsbUJBQW1CLDZDQUFRO0FBQzNCLGdCQUFnQiw2Q0FBUTtBQUN4QixtQkFBbUIsd0NBQUc7QUFDdEIsc0JBQXNCLHdDQUFHO0FBQ3pCLDBCQUEwQix3Q0FBRztBQUM3QixxQkFBcUIsd0NBQUc7QUFDeEI7QUFDQSxNQUFNLGdFQUFZLFdBQVcsK0RBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSx1REFBUztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsK0RBQVcsV0FBVywrREFBYztBQUM1QztBQUNBO0FBQ0E7QUFDQSxZQUFZLHVEQUFTO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxnRUFBWSxXQUFXLCtEQUFjO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksdURBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLGdFQUFZLFdBQVcsK0RBQWM7QUFDL0M7QUFDQSxjQUFjLHVEQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLHVEQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSxnRUFBWSxXQUFXLCtEQUFjO0FBQy9DO0FBQ0EsY0FBYyx1REFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyx1REFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLDZDQUFRO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhDQUFTO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3REFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSxpREFBUztBQUN4QjtBQUNBO0FBQ0EsZUFBZSxnREFBUTtBQUN2QjtBQUNBO0FBQ0EsZUFBZSwyREFBTztBQUN0QjtBQUNBLGdCQUFnQix5Q0FBUTtBQUN4QixpQkFBaUIsMENBQVM7QUFDMUIsZ0JBQWdCLHlDQUFRO0FBQ3hCO0FBQ0EsZUFBZSxtREFBUztBQUN4QjtBQUNBLGtCQUFrQixrRUFBVTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQzlRTSxTQUFNO0FBQVM7O0VBQ2IsU0FBTTtBQUFROztzQkFDakJzQix1REFBQSxDQUFXLFlBQVAsSUFBRTtBQUFBOztFQUNELFNBQU0sV0FBVztFQUFDM0IsRUFBRSxFQUFDOzs7OztzQkErQjFCMkIsdURBQUEsQ0FBVyxZQUFQLElBQUU7QUFBQTs7OztFQWlDSCxTQUFNO0FBQVM7O3NCQUNsQkEsdURBQUEsQ0FBYSxZQUFULE1BQUk7QUFBQTs7c0JBQ1JBLHVEQUFBLENBQWEsV0FBVixRQUFNO0FBQUE7O3NCQUVUQSx1REFBQSxDQUFXLFdBQVIsTUFBSTtBQUFBOztFQUNGQyxLQUFxQixFQUFyQjtJQUFBO0VBQUE7QUFBcUI7O3NCQVl4QkQsdURBQUEsQ0FBYSxZQUFULE1BQUk7QUFBQTs7c0JBRU5BLHVEQUFBLENBQWEsV0FBVixRQUFNO0FBQUE7Ozs7O3NCQVFUQSx1REFBQSxDQUFhLFdBQVYsUUFBTTtBQUFBOzs7OztzQkFRVEEsdURBQUEsQ0FBYSxXQUFWLFFBQU07QUFBQTs7Ozs7Ozs7Ozs7OzsyREF0R2pCRSx1REFBQSxDQWlJTSxPQWpJTkMsVUFpSU0sR0FoSUpILHVEQUFBLENBcURNLE9BckROSSxVQXFETSxHQXBESkMsVUFBVyxFQUNYTCx1REFBQSxDQThCTSxPQTlCTk0sVUE4Qk0sR0E3QkpDLGdEQUFBLENBNEJTQyxpQkFBQTs0REEzQlA7TUFBQSxPQTBCWSxDQTFCWkQsZ0RBQUEsQ0EwQllFLE1BQUE7UUF6QlRDLE9BQUssRUFBRUQsTUFBQSxDQUFBRSxTQUFTO1FBQ2hCQyxLQUFHLEVBQUVILE1BQUEsQ0FBQUksT0FBTztvQkFDSkosTUFBQSxDQUFBcEQsV0FBVzs7aUJBQVhvRCxNQUFBLENBQUFwRCxXQUFXLEdBQUF5RCxNQUFBO1FBQUE7UUFDbkJDLE9BQU8sRUFBRU4sTUFBQSxDQUFBTyxXQUFXO1FBQ3JCZixLQUF5QixFQUF6QjtVQUFBO1FBQUE7O2dFQUlFO1VBQUEsT0FBaUQsd0RBRm5EQyx1REFBQSxDQWtCU2UseUNBQUEsUUFBQUMsK0NBQUEsQ0FoQjhCVCxNQUFBLENBQUFwRCxXQUFXLFlBQXhDOEQsVUFBVSxFQUFFQyxZQUFZO3FFQUZsQ0MsZ0RBQUEsQ0FrQlNDLGlCQUFBO2NBakJOQyxJQUFJLEVBQUUsRUFBRTtjQUVSQyxHQUFHLEVBQUVKOztzRUFFTjtnQkFBQSxPQVlNLENBWk5wQix1REFBQSxDQVlNO2tCQVhILFNBQUt5QixtREFBQSxDQUFFaEIsTUFBQSxDQUFBaUIsWUFBWSxDQUFDUCxVQUFVLENBQUM3RCxJQUFJO2tCQUNuQ3FFLFNBQVMsRUFBRVIsVUFBVSxDQUFDN0QsSUFBSTtrQkFDMUJzRSxXQUFTLFdBQUFBLFlBQUFkLE1BQUE7b0JBQUEsT0FBRUwsTUFBQSxDQUFBb0IsWUFBWSxDQUFDVixVQUFVLENBQUM3RCxJQUFJO2tCQUFBO29CQUV4QzBDLHVEQUFBLENBS0U7a0JBSkM4QixHQUFHLEVBQXdCQywyQkFBTyxLQUFBQyxNQUFBLENBQTBCYixVQUFVLENBQUMzRCxPQUFPO2tCQUcvRXlFLEdBQUcsRUFBQztxREFFTmpDLHVEQUFBLENBQW1DLGNBQUFrQyxvREFBQSxDQUExQmYsVUFBVSxDQUFDNUQsS0FBSzs7Ozs7Ozs7Ozs7UUFNbkM0RSxVQUFXLEVBQ1g1QixnREFBQSxDQWtCU0MsaUJBQUE7NERBZkw7TUFBQSxPQUE2Qyx3REFGL0NOLHVEQUFBLENBZ0JTZSx5Q0FBQSxRQUFBQywrQ0FBQSxDQWQ0QlQsTUFBQSxDQUFBaEQsU0FBUyxZQUFwQzJFLFFBQVEsRUFBRWhCLFlBQVk7aUVBRmhDQyxnREFBQSxDQWdCU0MsaUJBQUE7VUFmTkMsSUFBSSxFQUFFLEVBQUU7VUFFUkMsR0FBRyxFQUFFSjs7a0VBRU47WUFBQSxPQVVNLENBVk5wQix1REFBQSxDQVVNO2NBVEgsU0FBS3lCLG1EQUFBLENBQUVoQixNQUFBLENBQUFpQixZQUFZLENBQUNVLFFBQVEsQ0FBQzlFLElBQUk7Y0FDakNxRSxTQUFTLEVBQUVTLFFBQVEsQ0FBQzlFLElBQUk7Y0FDeEJzRSxXQUFTLFdBQUFBLFlBQUFkLE1BQUE7Z0JBQUEsT0FBRUwsTUFBQSxDQUFBb0IsWUFBWSxDQUFDTyxRQUFRLENBQUM5RSxJQUFJO2NBQUE7Z0JBRXRDMEMsdURBQUEsQ0FHRTtjQUZDOEIsR0FBRyxFQUFFQywyQkFBUSxLQUFEQyxNQUFBLENBQTBCSSxRQUFRLENBQUM1RSxPQUFPO2NBQ3ZEeUUsR0FBRyxFQUFDO2lEQUVOakMsdURBQUEsQ0FBaUMsY0FBQWtDLG9EQUFBLENBQXhCRSxRQUFRLENBQUM3RSxLQUFLOzs7Ozs7OztRQUsvQnlDLHVEQUFBLENBV007SUFYQSxTQUFLeUIsbURBQUEsRUFBR2hCLE1BQUEsQ0FBQTRCLE1BQU07TUFDbEJyQyx1REFBQSxDQVNVO0lBUlJoQyxLQUFLLEVBQUMsTUFBTTtJQUNaQyxNQUFNLEVBQUMsS0FBSztJQUNaSSxFQUFFLEVBQUMsUUFBUTtJQUNWdUQsV0FBUyxFQUFFbkIsTUFBQSxDQUFBNkIsVUFBVTtJQUNyQkMsU0FBTyxFQUFFOUIsTUFBQSxDQUFBK0IsUUFBUTtJQUNqQkMsV0FBUyxFQUFFaEMsTUFBQSxDQUFBaUMsVUFBVTtJQUNyQkMsT0FBSyxFQUFFbEMsTUFBQSxDQUFBbUMsV0FBVztJQUNsQjNDLEtBQUssRUFBQTRDLG1EQUFBO01BQUFDLFVBQUEsRUFBZ0JyQyxNQUFBLENBQUFzQyxlQUFlLENBQUNEO0lBQVU7NkRBR3BEOUMsdURBQUEsQ0FrRE0sT0FsRE5nRCxXQWtETSxHQWpESkMsV0FBYSxFQUNiQyxXQUFhLEVBQ2IzQyxnREFBQSxDQUFpRzRDLDBCQUFBO2dCQUF2RTFDLE1BQUEsQ0FBQXNDLGVBQWUsQ0FBQ0QsVUFBVTs7YUFBMUJyQyxNQUFBLENBQUFzQyxlQUFlLENBQUNELFVBQVUsR0FBQWhDLE1BQUE7SUFBQTtJQUFHc0MsUUFBUSxFQUFFM0MsTUFBQSxDQUFBNEMsS0FBSyxDQUFDQyxLQUFLLENBQUNDLElBQUk7dURBQ2pGQyxXQUFXLEVBQ1h4RCx1REFBQSxDQU9NLE9BUE55RCxXQU9NLEdBTkpsRCxnREFBQSxDQUlZbUQsbUJBQUE7Z0JBSERqRCxNQUFBLENBQUFrRCxTQUFTOzthQUFUbEQsTUFBQSxDQUFBa0QsU0FBUyxHQUFBN0MsTUFBQTtJQUFBO0lBQ2xCOEMsV0FBVyxFQUFDLFNBQVM7SUFDckIzRCxLQUFvQixFQUFwQjtNQUFBO0lBQUE7MkNBRUZNLGdEQUFBLENBQThFc0Qsb0JBQUE7SUFBbkVOLElBQUksRUFBQyxTQUFTO0lBQUN0RCxLQUFtQixFQUFuQjtNQUFBO0lBQUEsQ0FBbUI7SUFBRTBDLE9BQUssRUFBRWxDLE1BQUEsQ0FBQXFEOzs0REFBVTtNQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1FBR3BFQyx1REFBQSx1TEFDK0ksRUFDL0h0RCxNQUFBLENBQUF1RCxjQUFjLENBQUMzRixFQUFFLElBQUlvQyxNQUFBLENBQUF3RCxRQUFRLENBQUNDLE1BQU0sMERBQXBEaEUsdURBQUEsQ0FpQ1dlLHlDQUFBO0lBQUFPLEdBQUE7RUFBQSxJQWhDVDJDLFdBQWEsRUFDYm5FLHVEQUFBLENBT00sY0FOSm9FLFdBQWEsRUFDYjdELGdEQUFBLENBSUU0QywwQkFBQTtJQUhEQyxRQUFRLEVBQUUzQyxNQUFBLENBQUE0QyxLQUFLLENBQUNDLEtBQUssQ0FBQ0MsSUFBSTtnQkFDaEI5QyxNQUFBLENBQUF1RCxjQUFjLENBQUM5RixLQUFLOzthQUFwQnVDLE1BQUEsQ0FBQXVELGNBQWMsQ0FBQzlGLEtBQUssR0FBQTRDLE1BQUE7SUFBQTtJQUM1QnVELGNBQWEsRUFBRTVELE1BQUEsQ0FBQTZEO3lEQUdUN0QsTUFBQSxDQUFBdUQsY0FBYyxDQUFDN0YsUUFBUSxtQkFBbUJzQyxNQUFBLENBQUF1RCxjQUFjLENBQUM3RixRQUFRLGlFQUE1RStCLHVEQUFBLENBT00sT0FBQXFFLFdBQUEsR0FOSkMsV0FBYSxFQUNiakUsZ0RBQUEsQ0FJRTRDLDBCQUFBO0lBSERDLFFBQVEsRUFBRTNDLE1BQUEsQ0FBQTRDLEtBQUssQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJO2dCQUNoQjlDLE1BQUEsQ0FBQXVELGNBQWMsQ0FBQ3ZGLElBQUksQ0FBQ1AsS0FBSzs7YUFBekJ1QyxNQUFBLENBQUF1RCxjQUFjLENBQUN2RixJQUFJLENBQUNQLEtBQUssR0FBQTRDLE1BQUE7SUFBQTtJQUNqQ3VELGNBQWEsRUFBRTVELE1BQUEsQ0FBQWdFO2tJQUdUaEUsTUFBQSxDQUFBdUQsY0FBYyxDQUFDN0YsUUFBUSxtQkFBbUJzQyxNQUFBLENBQUF1RCxjQUFjLENBQUM3RixRQUFRLGlFQUE1RStCLHVEQUFBLENBUU0sT0FBQXdFLFdBQUEsR0FQSkMsV0FBYSxFQUNicEUsZ0RBQUEsQ0FLWW1ELG1CQUFBO0lBSlhOLFFBQVEsRUFBRTNDLE1BQUEsQ0FBQTRDLEtBQUssQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJO2dCQUNoQjlDLE1BQUEsQ0FBQXVELGNBQWMsQ0FBQ3ZGLElBQUksQ0FBQ0MsSUFBSTs7YUFBeEIrQixNQUFBLENBQUF1RCxjQUFjLENBQUN2RixJQUFJLENBQUNDLElBQUksR0FBQW9DLE1BQUE7SUFBQTtJQUNqQ2IsS0FBYSxFQUFiLEVBQWE7SUFDWjJFLE9BQUssRUFBRW5FLE1BQUEsQ0FBQW9FO2tJQUdEcEUsTUFBQSxDQUFBdUQsY0FBYyxDQUFDN0YsUUFBUSxxRUFBbEMrQix1REFBQSxDQUVNLE9BQUE0RSxXQUFBLEdBREp2RSxnREFBQSxDQUF3R3NELG9CQUFBO0lBQTdGTixJQUFJLEVBQUMsU0FBUztJQUFFWixPQUFLLEVBQUVsQyxNQUFBLENBQUFzRSxVQUFVO0lBQUczQixRQUFRLEVBQUUzQyxNQUFBLENBQUE0QyxLQUFLLENBQUNDLEtBQUssQ0FBQ0MsSUFBSTs7NERBQWU7TUFBQSxPQUFJLHNEQUFKLE1BQUk7Ozs4R0FFbkY5QyxNQUFBLENBQUF1RCxjQUFjLENBQUM3RixRQUFRLHFFQUFsQytCLHVEQUFBLENBRU0sT0FBQThFLFdBQUEsR0FESnpFLGdEQUFBLENBQXdHc0Qsb0JBQUE7SUFBN0ZOLElBQUksRUFBQyxTQUFTO0lBQUVaLE9BQUssRUFBRWxDLE1BQUEsQ0FBQXdFLFVBQVU7SUFBRzdCLFFBQVEsRUFBRTNDLE1BQUEsQ0FBQTRDLEtBQUssQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJOzs0REFBZTtNQUFBLE9BQUksc0RBQUosTUFBSTs7O3lRQUlsR2hELGdEQUFBLENBVUFtRCxtQkFBQTtJQVRDTixRQUFRLEVBQUUzQyxNQUFBLENBQUE0QyxLQUFLLENBQUNDLEtBQUssQ0FBQ0MsSUFBSTtJQUMxQjJCLE1BQUksRUFBRXpFLE1BQUEsQ0FBQTBFLGlCQUFpQjtJQUV2QmxGLEtBQUssRUFBQTRDLG1EQUFBLENBQUVwQyxNQUFBLENBQUEyRSxhQUFhO2dCQUNaM0UsTUFBQSxDQUFBNEUsYUFBYTs7YUFBYjVFLE1BQUEsQ0FBQTRFLGFBQWEsR0FBQXZFLE1BQUE7SUFBQTtJQUN0QndFLFNBQVMsRUFBQyxJQUFJO0lBQ2QsaUJBQWUsRUFBZixFQUFlO0lBQ2YvQixJQUFJLEVBQUMsVUFBVTtJQUNkZ0MsSUFBSSxFQUFFOUUsTUFBQSxDQUFBMkUsYUFBYSxDQUFDRztrSEFOYjlFLE1BQUEsQ0FBQStFLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUN6SGpCLFNBQU07QUFBUzs7c0JBa0JWeEYsdURBQUEsQ0FBcUI7QUFBQTs7RUE4S2QsU0FBTTtBQUFTOztFQTZCZixTQUFNO0FBQVM7O0VBc0N6QixTQUFNO0FBQVE7O0VBa0JoQixTQUFNO0FBQVk7O0VBU1gsU0FBTTtBQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7cUtBOVJqQ0EsdURBQUEsQ0FvUk0sT0FwUk5HLFVBb1JNLEdBblJKSSxnREFBQSxDQWlRVWtGLGtCQUFBO0lBaFFSQyxHQUFHLEVBQUMsYUFBYTtJQUNoQkMsS0FBSyxFQUFFbEYsTUFBQSxDQUFBbUYsUUFBUTtJQUNmQyxLQUFLLEVBQUVwRixNQUFBLENBQUFvRixLQUFLO0lBQ2IsYUFBVyxFQUFDLE9BQU87SUFDbkIsU0FBTSxlQUFlO0lBQ3JCLGFBQVcsRUFBWDs7NERBRVU7TUFBQSxPQUFxQyx3REFBL0MzRix1REFBQSxDQXdQV2UseUNBQUEsUUFBQUMsK0NBQUEsQ0F4UHVCVCxNQUFBLENBQUFxRixZQUFZLFlBQTVCQyxJQUFJLEVBQUVDLEtBQUs7O2VBQXlCQTtRQUFLLElBQ3pEaEcsdURBQUEsQ0FBeUIsWUFBQWtDLG9EQUFBLENBQWxCNkQsSUFBSSxDQUFDeEksS0FBSyxrQkFDakJnRCxnREFBQSxDQXFQU0MsaUJBQUE7VUFyUEQsU0FBTTtRQUFLO2tFQUdmO1lBQUEsT0FBc0Msd0RBRnhDTix1REFBQSxDQW1QU2UseUNBQUEsUUFBQUMsK0NBQUEsQ0FqUGlCNkUsSUFBSSxDQUFDRSxRQUFRLFlBQTdCQyxJQUFJLEVBQUVDLEtBQUs7dUVBRnJCOUUsZ0RBQUEsQ0FtUFNDLGlCQUFBO2dCQWxQTkMsSUFBSSxFQUFFLEVBQUU7Z0JBRVJDLEdBQUcsRUFBRTJFLEtBQUs7Z0JBQ1hsRyxLQUFzQixFQUF0QjtrQkFBQTtnQkFBQTs7d0VBRUE7a0JBQUEsT0FBcUIsQ0FBckJHLFVBQXFCLEVBRWI4RixJQUFJLENBQUMzQyxJQUFJLGtFQURqQmxDLGdEQUFBLENBc0JlK0UsdUJBQUE7O29CQXBCWkMsS0FBSyxFQUFFSCxJQUFJLENBQUNHLEtBQUs7b0JBQ2pCQyxJQUFJLEVBQUVKLElBQUksQ0FBQzVJOzs0RUFFWjtzQkFBQSxPQUtZLENBTFppRCxnREFBQSxDQUtZbUQsbUJBQUE7d0JBSlYsU0FBTSxVQUFVO29DQUNQakQsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJOztpQ0FBbEJtRCxNQUFBLENBQUFtRixRQUFRLENBQUNNLElBQUksQ0FBQzVJLElBQUksSUFBQXdELE1BQUE7d0JBQUE7d0JBQzNCeUYsU0FBUyxFQUFULEVBQVM7d0JBQ1JuRCxRQUFRLEVBQUUzQyxNQUFBLENBQUErRixXQUFXLENBQUNOLElBQUksQ0FBQ08sWUFBWTtrR0FHbENQLElBQUksQ0FBQ1EsTUFBTSxzREFEbkJyRixnREFBQSxDQVVhc0YscUJBQUE7O3dCQVJYLFNBQU0sVUFBVTt3QkFDaEJDLE1BQU0sRUFBQyxNQUFNO3dCQUNaQyxPQUFPLEVBQUVYLElBQUksQ0FBQ1EsTUFBTTt3QkFDckJJLFNBQVMsRUFBQzs7Z0ZBRVY7MEJBQUEsT0FFVSxDQUZWdkcsZ0RBQUEsQ0FFVXdHLGtCQUFBOzRCQUZEQyxJQUFJLEVBQUMsTUFBTTs0QkFBQyxTQUFNOztvRkFDekI7OEJBQUEsT0FBa0IsQ0FBbEJ6RyxnREFBQSxDQUFrQjBHLHlCQUFBOzs7Ozs7Ozs7OzRFQUtYZixJQUFJLENBQUMzQyxJQUFJLHFFQUR0QmxDLGdEQUFBLENBd0JlK0UsdUJBQUE7O29CQXRCWkMsS0FBSyxFQUFFSCxJQUFJLENBQUNHLEtBQUs7b0JBQ2pCQyxJQUFJLEVBQUVKLElBQUksQ0FBQzVJOzs0RUFFWjtzQkFBQSxPQU9FLENBUEZpRCxnREFBQSxDQU9FbUQsbUJBQUE7d0JBTkEsU0FBTSxVQUFVO29DQUNQakQsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJOztpQ0FBbEJtRCxNQUFBLENBQUFtRixRQUFRLENBQUNNLElBQUksQ0FBQzVJLElBQUksSUFBQXdELE1BQUE7d0JBQUE7d0JBQzFCeUUsSUFBSSxFQUFFLENBQUM7d0JBQ1JoQyxJQUFJLEVBQUMsVUFBVTt3QkFDZmdELFNBQVMsRUFBVCxFQUFTO3dCQUNSbkQsUUFBUSxFQUFFM0MsTUFBQSxDQUFBK0YsV0FBVyxDQUFDTixJQUFJLENBQUNPLFlBQVk7a0dBR2xDUCxJQUFJLENBQUNRLE1BQU0sc0RBRG5CckYsZ0RBQUEsQ0FVYXNGLHFCQUFBOzt3QkFSWCxTQUFNLFVBQVU7d0JBQ2hCQyxNQUFNLEVBQUMsTUFBTTt3QkFDWkMsT0FBTyxFQUFFWCxJQUFJLENBQUNRLE1BQU07d0JBQ3JCSSxTQUFTLEVBQUM7O2dGQUVWOzBCQUFBLE9BRVUsQ0FGVnZHLGdEQUFBLENBRVV3RyxrQkFBQTs0QkFGREMsSUFBSSxFQUFDLE1BQU07NEJBQUMsU0FBTTs7b0ZBQ3pCOzhCQUFBLE9BQWtCLENBQWxCekcsZ0RBQUEsQ0FBa0IwRyx5QkFBQTs7Ozs7Ozs7Ozs0RUFLWGYsSUFBSSxDQUFDM0MsSUFBSSxtRUFEdEJsQyxnREFBQSxDQTZCZStFLHVCQUFBOztvQkEzQlpDLEtBQUssRUFBRUgsSUFBSSxDQUFDRyxLQUFLO29CQUNqQkMsSUFBSSxFQUFFSixJQUFJLENBQUM1STs7NEVBRVo7c0JBQUEsT0FZWSxDQVpaaUQsZ0RBQUEsQ0FZWTJHLG9CQUFBO3dCQVhWLFNBQU0sVUFBVTtvQ0FDUHpHLE1BQUEsQ0FBQW1GLFFBQVEsQ0FBQ00sSUFBSSxDQUFDNUksSUFBSTs7aUNBQWxCbUQsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJLElBQUF3RCxNQUFBO3dCQUFBO3dCQUMzQnlGLFNBQVMsRUFBVCxFQUFTO3dCQUNSbkQsUUFBUSxFQUFFM0MsTUFBQSxDQUFBK0YsV0FBVyxDQUFDTixJQUFJLENBQUNPLFlBQVk7O2dGQUd0QzswQkFBQSxPQUE4Qix3REFEaEN2Ryx1REFBQSxDQUthZSx5Q0FBQSxRQUFBQywrQ0FBQSxDQUpNZ0YsSUFBSSxDQUFDbkYsT0FBTyxZQUFyQm9HLENBQUMsRUFBRUMsQ0FBQztxRkFEZC9GLGdEQUFBLENBS2FnRyxvQkFBQTs4QkFIVjdGLEdBQUcsRUFBRTRGLENBQUM7OEJBQ05mLEtBQUssRUFBRWMsQ0FBQyxDQUFDZCxLQUFLOzhCQUNkaUIsS0FBSyxFQUFFSCxDQUFDLENBQUNHOzs7Ozs7OEdBSU5wQixJQUFJLENBQUNRLE1BQU0sc0RBRG5CckYsZ0RBQUEsQ0FVYXNGLHFCQUFBOzt3QkFSWCxTQUFNLFVBQVU7d0JBQ2hCQyxNQUFNLEVBQUMsTUFBTTt3QkFDWkMsT0FBTyxFQUFFWCxJQUFJLENBQUNRLE1BQU07d0JBQ3JCSSxTQUFTLEVBQUM7O2dGQUVWOzBCQUFBLE9BRVUsQ0FGVnZHLGdEQUFBLENBRVV3RyxrQkFBQTs0QkFGREMsSUFBSSxFQUFDLE1BQU07NEJBQUMsU0FBTTs7b0ZBQ3pCOzhCQUFBLE9BQWtCLENBQWxCekcsZ0RBQUEsQ0FBa0IwRyx5QkFBQTs7Ozs7Ozs7Ozs0RUFLWGYsSUFBSSxDQUFDM0MsSUFBSSxrRUFEdEJsQyxnREFBQSxDQTZCZStFLHVCQUFBOztvQkEzQlpDLEtBQUssRUFBRUgsSUFBSSxDQUFDRyxLQUFLO29CQUNqQkMsSUFBSSxFQUFFSixJQUFJLENBQUM1STs7NEVBRVo7c0JBQUEsT0FZaUIsQ0FaakJpRCxnREFBQSxDQVlpQmdILHlCQUFBO3dCQVhmLFNBQU0sTUFBTTtvQ0FDSDlHLE1BQUEsQ0FBQW1GLFFBQVEsQ0FBQ00sSUFBSSxDQUFDNUksSUFBSTs7aUNBQWxCbUQsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJLElBQUF3RCxNQUFBO3dCQUFBO3dCQUMxQnNDLFFBQVEsRUFBRTNDLE1BQUEsQ0FBQStGLFdBQVcsQ0FBQ04sSUFBSSxDQUFDTyxZQUFZOztnRkFLdEM7MEJBQUEsT0FBOEIsd0RBSGhDdkcsdURBQUEsQ0FNQ2UseUNBQUEsUUFBQUMsK0NBQUEsQ0FIa0JnRixJQUFJLENBQUNuRixPQUFPLFlBQXJCb0csQ0FBQyxFQUFFQyxDQUFDO3FGQUhkL0YsZ0RBQUEsQ0FNQ21HLG1CQUFBOzhCQUxFbkIsS0FBSyxFQUFFYyxDQUFDLENBQUNkLEtBQUs7OEJBQ2ZXLElBQUksRUFBQyxPQUFPOzhCQUVYeEYsR0FBRyxFQUFFNEY7O3NGQUNMO2dDQUFBLE9BQVksMkdBQVRELENBQUMsQ0FBQzFJLElBQUk7Ozs7Ozs7Ozs4R0FJTnlILElBQUksQ0FBQ1EsTUFBTSxzREFEbkJyRixnREFBQSxDQVVhc0YscUJBQUE7O3dCQVJYLFNBQU0sVUFBVTt3QkFDaEJDLE1BQU0sRUFBQyxNQUFNO3dCQUNaQyxPQUFPLEVBQUVYLElBQUksQ0FBQ1EsTUFBTTt3QkFDckJJLFNBQVMsRUFBQzs7Z0ZBRVY7MEJBQUEsT0FFVSxDQUZWdkcsZ0RBQUEsQ0FFVXdHLGtCQUFBOzRCQUZEQyxJQUFJLEVBQUMsTUFBTTs0QkFBQyxTQUFNOztvRkFDekI7OEJBQUEsT0FBa0IsQ0FBbEJ6RyxnREFBQSxDQUFrQjBHLHlCQUFBOzs7Ozs7Ozs7OzRFQUtYZixJQUFJLENBQUMzQyxJQUFJLDRFQUR0QmxDLGdEQUFBLENBOEJlK0UsdUJBQUE7O29CQTVCWkMsS0FBSyxFQUFFSCxJQUFJLENBQUNHLEtBQUs7b0JBQ2pCQyxJQUFJLEVBQUVKLElBQUksQ0FBQzVJOzs0RUFFWjtzQkFBQSxPQWFZLENBYlppRCxnREFBQSxDQWFZMkcsb0JBQUE7d0JBWlYsU0FBTSxVQUFVO29DQUNQekcsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJOztpQ0FBbEJtRCxNQUFBLENBQUFtRixRQUFRLENBQUNNLElBQUksQ0FBQzVJLElBQUksSUFBQXdELE1BQUE7d0JBQUE7d0JBQzNCMkcsUUFBUSxFQUFSLEVBQVE7d0JBQ1JsQixTQUFTLEVBQVQsRUFBUzt3QkFDUm5ELFFBQVEsRUFBRTNDLE1BQUEsQ0FBQStGLFdBQVcsQ0FBQ04sSUFBSSxDQUFDTyxZQUFZOztnRkFHdEM7MEJBQUEsT0FBOEIsd0RBRGhDdkcsdURBQUEsQ0FLYWUseUNBQUEsUUFBQUMsK0NBQUEsQ0FKTWdGLElBQUksQ0FBQ25GLE9BQU8sWUFBckJvRyxDQUFDLEVBQUVDLENBQUM7cUZBRGQvRixnREFBQSxDQUthZ0csb0JBQUE7OEJBSFY3RixHQUFHLEVBQUU0RixDQUFDOzhCQUNOZixLQUFLLEVBQUVjLENBQUMsQ0FBQ2QsS0FBSzs4QkFDZGlCLEtBQUssRUFBRUgsQ0FBQyxDQUFDRzs7Ozs7OzhHQUlOcEIsSUFBSSxDQUFDUSxNQUFNLHNEQURuQnJGLGdEQUFBLENBVWFzRixxQkFBQTs7d0JBUlgsU0FBTSxVQUFVO3dCQUNoQkMsTUFBTSxFQUFDLE1BQU07d0JBQ1pDLE9BQU8sRUFBRVgsSUFBSSxDQUFDUSxNQUFNO3dCQUNyQkksU0FBUyxFQUFDOztnRkFFVjswQkFBQSxPQUVVLENBRlZ2RyxnREFBQSxDQUVVd0csa0JBQUE7NEJBRkRDLElBQUksRUFBQyxNQUFNOzRCQUFDLFNBQU07O29GQUN6Qjs4QkFBQSxPQUFrQixDQUFsQnpHLGdEQUFBLENBQWtCMEcseUJBQUE7Ozs7Ozs7Ozs7NEVBS1hmLElBQUksQ0FBQzNDLElBQUksbUVBRHRCbEMsZ0RBQUEsQ0E0QmUrRSx1QkFBQTs7b0JBMUJaQyxLQUFLLEVBQUVILElBQUksQ0FBQ0csS0FBSztvQkFDakJDLElBQUksRUFBRUosSUFBSSxDQUFDNUk7OzRFQUVaO3NCQUFBLE9BV1ksQ0FYWmlELGdEQUFBLENBV1ltSCxvQkFBQTtvQ0FWRGpILE1BQUEsQ0FBQW1GLFFBQVEsQ0FBQ00sSUFBSSxDQUFDNUksSUFBSTs7aUNBQWxCbUQsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJLElBQUF3RCxNQUFBO3dCQUFBO3dCQUMzQixTQUFNLHNCQUFzQjt3QkFDM0IsY0FBWSxFQUFFTCxNQUFBLENBQUFrSCxXQUFXO3dCQUN6QkMsS0FBSyxFQUFFLENBQUM7d0JBQ1J4RSxRQUFRLEVBQUUzQyxNQUFBLENBQUErRixXQUFXLENBQUNOLElBQUksQ0FBQ08sWUFBWTs7d0JBRzdCb0IsR0FBRyxFQUFBQyw0Q0FBQSxDQUNaOzBCQUFBLE9BQW9ELENBQXBEOUgsdURBQUEsQ0FBb0QsYUFBL0MsU0FBaUIsR0FBQWtDLG9EQUFBLENBQUd6QixNQUFBLENBQUFtRixRQUFROzs7Z0ZBRm5DOzBCQUFBLE9BQTBDLENBQTFDckYsZ0RBQUEsQ0FBMENzRCxvQkFBQTs0QkFBL0JOLElBQUksRUFBQzswQkFBUztvRkFBQzs4QkFBQSxPQUFJLHNEQUFKLE1BQUk7Ozs7Ozs7OEdBTXhCMkMsSUFBSSxDQUFDUSxNQUFNLHNEQURuQnJGLGdEQUFBLENBVWFzRixxQkFBQTs7d0JBUlgsU0FBTSxVQUFVO3dCQUNoQkMsTUFBTSxFQUFDLE1BQU07d0JBQ1pDLE9BQU8sRUFBRVgsSUFBSSxDQUFDUSxNQUFNO3dCQUNyQkksU0FBUyxFQUFDOztnRkFFVjswQkFBQSxPQUVVLENBRlZ2RyxnREFBQSxDQUVVd0csa0JBQUE7NEJBRkRDLElBQUksRUFBQyxNQUFNOzRCQUFDLFNBQU07O29GQUN6Qjs4QkFBQSxPQUFrQixDQUFsQnpHLGdEQUFBLENBQWtCMEcseUJBQUE7Ozs7Ozs7Ozs7NEVBS1hmLElBQUksQ0FBQzNDLElBQUksaUVBRHRCbEMsZ0RBQUEsQ0E0QmUrRSx1QkFBQTs7b0JBMUJaQyxLQUFLLEVBQUVILElBQUksQ0FBQ0csS0FBSztvQkFDakJDLElBQUksRUFBRUosSUFBSSxDQUFDNUk7OzRFQUVaO3NCQUFBLE9BV00sQ0FYTjBDLHVEQUFBLENBV00sT0FYTkssVUFXTSxHQVZKRSxnREFBQSxDQVNFd0gseUJBQUE7d0JBUkEsU0FBTSxVQUFVO29DQUNQdEgsTUFBQSxDQUFBbUYsUUFBUSxDQUFDTSxJQUFJLENBQUM1SSxJQUFJOztpQ0FBbEJtRCxNQUFBLENBQUFtRixRQUFRLENBQUNNLElBQUksQ0FBQzVJLElBQUksSUFBQXdELE1BQUE7d0JBQUE7d0JBQzNCeUMsSUFBSSxFQUFDLE1BQU07d0JBQ1YsZUFBYSxFQUFFOUMsTUFBQSxDQUFBdUgsY0FBYzt3QkFDOUJoQixJQUFJLEVBQUMsU0FBUzt3QkFDZCxjQUFZLEVBQUMsWUFBWTt3QkFDekJULFNBQVMsRUFBVCxFQUFTO3dCQUNSbkQsUUFBUSxFQUFFM0MsTUFBQSxDQUFBK0YsV0FBVyxDQUFDTixJQUFJLENBQUNPLFlBQVk7b0dBSXBDUCxJQUFJLENBQUNRLE1BQU0sc0RBRG5CckYsZ0RBQUEsQ0FVYXNGLHFCQUFBOzt3QkFSWCxTQUFNLFVBQVU7d0JBQ2hCQyxNQUFNLEVBQUMsTUFBTTt3QkFDWkMsT0FBTyxFQUFFWCxJQUFJLENBQUNRLE1BQU07d0JBQ3JCSSxTQUFTLEVBQUM7O2dGQUVWOzBCQUFBLE9BRVUsQ0FGVnZHLGdEQUFBLENBRVV3RyxrQkFBQTs0QkFGREMsSUFBSSxFQUFDLE1BQU07NEJBQUMsU0FBTTs7b0ZBQ3pCOzhCQUFBLE9BQWtCLENBQWxCekcsZ0RBQUEsQ0FBa0IwRyx5QkFBQTs7Ozs7Ozs7Ozs0RUFLWGYsSUFBSSxDQUFDM0MsSUFBSSxzRUFEdEJsQyxnREFBQSxDQThCZStFLHVCQUFBOztvQkE1QlpDLEtBQUssRUFBRUgsSUFBSSxDQUFDRyxLQUFLO29CQUNqQkMsSUFBSSxFQUFFSixJQUFJLENBQUM1STs7NEVBRVo7c0JBQUEsT0FhTSxDQWJOMEMsdURBQUEsQ0FhTSxPQWJOTSxVQWFNLEdBWkpDLGdEQUFBLENBV0V3SCx5QkFBQTt3QkFWQSxTQUFNLFVBQVU7b0NBQ1B0SCxNQUFBLENBQUFtRixRQUFRLENBQUNNLElBQUksQ0FBQzVJLElBQUk7O2lDQUFsQm1ELE1BQUEsQ0FBQW1GLFFBQVEsQ0FBQ00sSUFBSSxDQUFDNUksSUFBSSxJQUFBd0QsTUFBQTt3QkFBQTt3QkFDM0J5QyxJQUFJLEVBQUMsV0FBVzt3QkFDZixlQUFhLEVBQUU5QyxNQUFBLENBQUF1SCxjQUFjO3dCQUM5QmhCLElBQUksRUFBQyxTQUFTO3dCQUNkLGlCQUFlLEVBQUMsR0FBRzt3QkFDbkIsbUJBQWlCLEVBQUMsTUFBTTt3QkFDeEIsaUJBQWUsRUFBQyxNQUFNO3dCQUNyQjVELFFBQVEsRUFBRTNDLE1BQUEsQ0FBQStGLFdBQVcsQ0FBQ04sSUFBSSxDQUFDTyxZQUFZO3dCQUN4QyxjQUFZLEVBQUM7b0dBSVRQLElBQUksQ0FBQ1EsTUFBTSxzREFEbkJyRixnREFBQSxDQVVhc0YscUJBQUE7O3dCQVJYLFNBQU0sVUFBVTt3QkFDaEJDLE1BQU0sRUFBQyxNQUFNO3dCQUNaQyxPQUFPLEVBQUVYLElBQUksQ0FBQ1EsTUFBTTt3QkFDckJJLFNBQVMsRUFBQzs7Z0ZBRVY7MEJBQUEsT0FFVSxDQUZWdkcsZ0RBQUEsQ0FFVXdHLGtCQUFBOzRCQUZEQyxJQUFJLEVBQUMsTUFBTTs0QkFBQyxTQUFNOztvRkFDekI7OEJBQUEsT0FBa0IsQ0FBbEJ6RyxnREFBQSxDQUFrQjBHLHlCQUFBOzs7Ozs7Ozs7OzRFQUtYZixJQUFJLENBQUMzQyxJQUFJLHNFQUR0QmxDLGdEQUFBLENBT2UrRSx1QkFBQTs7b0JBTFpDLEtBQUssRUFBRUgsSUFBSSxDQUFDRzs7NEVBRWI7c0JBQUEsT0FFQyxDQUZEOUYsZ0RBQUEsQ0FFQ3NELG9CQUFBO3dCQUZXbEIsT0FBSyxFQUFFbEMsTUFBQSxDQUFBd0gsYUFBYTt3QkFBRTFFLElBQUksRUFBQzs7Z0ZBQ3BDOzBCQUFBLE9BQUksc0RBQUosTUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUNBT2pCdkQsdURBQUEsQ0FnQk0sT0FoQk5rSSxVQWdCTSxHQVpJekgsTUFBQSxDQUFBNEMsS0FBSyxDQUFDQyxLQUFLLENBQUNDLElBQUksZ0VBSHhCbEMsZ0RBQUEsQ0FNWXdDLG9CQUFBOztJQUxWTixJQUFJLEVBQUMsU0FBUztJQUNiWixPQUFLLEVBQUF3RixNQUFBLFFBQUFBLE1BQUEsZ0JBQUFySCxNQUFBO01BQUEsT0FBRUwsTUFBQSxDQUFBMkgsR0FBRyxDQUFDM0gsTUFBQSxDQUFBNEgsV0FBVztJQUFBOzs0REFFeEI7TUFBQSxPQUVELHNEQUZDLE1BRUQ7OzsrRUFJUTVILE1BQUEsQ0FBQTRDLEtBQUssQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJLGlFQUh4QmxDLGdEQUFBLENBTVl3QyxvQkFBQTs7SUFMVk4sSUFBSSxFQUFDLFNBQVM7SUFDYlosT0FBSyxFQUFBd0YsTUFBQSxRQUFBQSxNQUFBLGdCQUFBckgsTUFBQTtNQUFBLE9BQUVMLE1BQUEsQ0FBQTZILElBQUksQ0FBQzdILE1BQUEsQ0FBQTRILFdBQVc7SUFBQTs7NERBRXpCO01BQUEsT0FFRCxzREFGQyxNQUVEOzs7K0VBQ0E5SCxnREFBQSxDQUE2Q3NELG9CQUFBO0lBQWpDbEIsT0FBSyxFQUFFbEMsTUFBQSxDQUFBOEg7RUFBVTs0REFBRTtNQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1VBR3JDdkksdURBQUEsQ0FxQk0sT0FyQk53SSxVQXFCTSxHQXBCSmpJLGdEQUFBLENBbUJZa0ksb0JBQUE7SUFsQlZDLFVBQVUsRUFBVixFQUFVO2dCQUNEakksTUFBQSxDQUFBa0ksZUFBZTs7YUFBZmxJLE1BQUEsQ0FBQWtJLGVBQWUsR0FBQTdILE1BQUE7SUFBQTtJQUN4QnZELEtBQUssRUFBQyxPQUFPO0lBQ1osY0FBWSxFQUFFa0QsTUFBQSxDQUFBbUk7O0lBR0pDLE1BQU0sRUFBQWYsNENBQUEsQ0FDZjtNQUFBLE9BU08sQ0FUUDlILHVEQUFBLENBU08sUUFUUG1DLFVBU08sR0FSTDVCLGdEQUFBLENBQTBEc0Qsb0JBQUE7UUFBOUNsQixPQUFLLEVBQUF3RixNQUFBLFFBQUFBLE1BQUEsZ0JBQUFySCxNQUFBO1VBQUEsT0FBRUwsTUFBQSxDQUFBa0ksZUFBZTtRQUFBOztnRUFBVTtVQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1VBSXRDbEksTUFBQSxDQUFBNEMsS0FBSyxDQUFDQyxLQUFLLENBQUNDLElBQUksbUVBSHhCbEMsZ0RBQUEsQ0FNWXdDLG9CQUFBOztRQUxWTixJQUFJLEVBQUMsU0FBUztRQUNiWixPQUFLLEVBQUVsQyxNQUFBLENBQUFxSTs7Z0VBRVQ7VUFBQSxPQUVELHNEQUZDLE1BRUQ7Ozs7OzREQVZKO01BQUEsT0FBMEMsQ0FBMUN2SSxnREFBQSxDQUEwQ0UsTUFBQTtRQUE5QmlGLEdBQUcsRUFBQztNQUFZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNVJsQyxNQUFrRztBQUNsRyxNQUF3RjtBQUN4RixNQUErRjtBQUMvRixNQUFrSDtBQUNsSCxNQUEyRztBQUMzRyxNQUEyRztBQUMzRyxNQUE4VTtBQUM5VTtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLHdTQUFPOzs7O0FBSXdSO0FBQ2hULE9BQU8saUVBQWUsd1NBQU8sSUFBSSwrU0FBYyxHQUFHLCtTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFrRztBQUNsRyxNQUF3RjtBQUN4RixNQUErRjtBQUMvRixNQUFrSDtBQUNsSCxNQUEyRztBQUMzRyxNQUEyRztBQUMzRyxNQUFrVjtBQUNsVjtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLDRTQUFPOzs7O0FBSTRSO0FBQ3BULE9BQU8saUVBQWUsNFNBQU8sSUFBSSxtVEFBYyxHQUFHLG1UQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQk07QUFDWDtBQUNMOztBQUVuRSxDQUFrRjs7QUFFZ0M7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsMEZBQU0sYUFBYSw2RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEJ3RTtBQUNYO0FBQ0w7O0FBRXZFLENBQXNGOztBQUU0QjtBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyw4RkFBTSxhQUFhLGlHQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QjhWOzs7Ozs7Ozs7Ozs7Ozs7O0FDQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FLQWpYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlPzUwNjIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/MDAyMCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9qYXZhc2NyaXB0L2Zsb3djaGFydENvbmZpZy5qcyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9qYXZhc2NyaXB0L2dsb2JhbEZsb3dGdW4uanMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGbG93LnZ1ZT9iOWFiIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL2NvbXBvbmVudHMvZ2xvYmFsRm9ybUluZm8udnVlP2MwYzEiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGbG93LnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZvcm1JbmZvLnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlP2E4N2QiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/ZmNlYyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlPzg0ZWYiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/YzY5MiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlP2IxZWIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/Njg5MCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlP2QwNjMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/MmVmOSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2dsb2JhbEZsb3cudnVlPzUyMTAiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWU/NTc5MSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9hc3NldHMvZmxvd2NoYXJ0U3ZnLyBzeW5jIF5cXC5cXC8uKlxcLnN2ZyQiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2dldFVybC5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8wX19fID0gbmV3IFVSTChcIkAvYXNzZXRzL2Zsb3djaGFydFN2Zy/nrJQuc3ZnXCIsIGltcG9ydC5tZXRhLnVybCk7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfMF9fXyA9IF9fX0NTU19MT0FERVJfR0VUX1VSTF9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzBfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiLmZsb3dCb3hbZGF0YS12LTVmN2YxZDAxXSB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogODAwcHg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4uZmxvd0JveCAubGVnZW5kW2RhdGEtdi01ZjdmMWQwMV0sXFxuLmZsb3dCb3ggLnNldHRpbmdbZGF0YS12LTVmN2YxZDAxXSB7XFxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XFxuICB3aWR0aDogMjAwcHg7XFxuICBoZWlnaHQ6IDgwMHB4O1xcbiAgYmFja2dyb3VuZDogI2UwZGVkZTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xcbn1cXG4uZmxvd0JveCAubGVnZW5kIGg0W2RhdGEtdi01ZjdmMWQwMV0sXFxuLmZsb3dCb3ggLnNldHRpbmcgaDRbZGF0YS12LTVmN2YxZDAxXSB7XFxuICBmb250LXNpemU6IDE4cHg7XFxuICBtYXJnaW46IDEwcHggYXV0bztcXG4gIGJvcmRlci1ib3R0b206ICMwMDAgZGFzaGVkIDFweDtcXG59XFxuLmZsb3dCb3ggLmNoYXJ0Tm9ybWFsW2RhdGEtdi01ZjdmMWQwMV0ge1xcbiAgZmxleDogMTtcXG4gIGJvcmRlcjogMnB4IGRhc2hlZCAjZGVlYzBlO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG59XFxuLmZsb3dCb3ggLmNoYXJ0TW9kZVtkYXRhLXYtNWY3ZjFkMDFdIHtcXG4gIGZsZXg6IDE7XFxuICBib3JkZXI6IDJweCBkYXNoZWQgI2RlZWMwZTtcXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBjdXJzb3I6IHVybChcIiArIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzBfX18gKyBcIikgMCAzMiwgYXV0bztcXG59XFxuLmZsb3dCb3ggLmxlbmdlbmRJdGVtTm9ybWFsW2RhdGEtdi01ZjdmMWQwMV0ge1xcbiAgbWFyZ2luLXRvcDogMTBweDtcXG4gIGhlaWdodDogNjBweDtcXG4gIG1hcmdpbjogMTBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmZsb3dCb3ggLmxlbmdlbmRJdGVtQWN0aXZlW2RhdGEtdi01ZjdmMWQwMV0ge1xcbiAgbWFyZ2luOiAxMHB4O1xcbiAgbWFyZ2luLXRvcDogMTBweDtcXG4gIGhlaWdodDogNjBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcXG4gIGJvcmRlcjogI2Q4MWUwNiAxcHggZGFzaGVkO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGbG93LnZ1ZVwiLFwid2VicGFjazovLy4vZ2xvYmFsRmxvdy52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQ0FGO0FESkE7O0VBT0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7QUNDSjtBRGRBOztFQWVNLGVBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FDR047QURwQkE7RUFxQkksT0FBQTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0FDRUo7QUQxQkE7RUEyQkksT0FBQTtFQUNBLDBCQUFBO0VBQ0Esc0JBQUE7RUFDQSwwREFBQTtBQ0VKO0FEaENBO0VBaUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUNFSjtBRHpDQTtFQTBDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7QUNFSlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4uZmxvd0JveCB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogODAwcHg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgLmxlZ2VuZCxcXG4gIC5zZXR0aW5nIHtcXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xcbiAgICB3aWR0aDogMjAwcHg7XFxuICAgIGhlaWdodDogODAwcHg7XFxuICAgIGJhY2tncm91bmQ6ICNlMGRlZGU7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XFxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcXG4gICAgaDQge1xcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcXG4gICAgICBtYXJnaW46IDEwcHggYXV0bztcXG4gICAgICBib3JkZXItYm90dG9tOiAjMDAwIGRhc2hlZCAxcHg7XFxuICAgIH1cXG4gIH1cXG4gIC5jaGFydE5vcm1hbCB7XFxuICAgIGZsZXg6IDE7XFxuICAgIGJvcmRlcjogMnB4IGRhc2hlZCAjZGVlYzBlO1xcbiAgICBjdXJzb3I6IHBvaW50ZXI7XFxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICB9XFxuICAuY2hhcnRNb2RlIHtcXG4gICAgZmxleDogMTtcXG4gICAgYm9yZGVyOiAycHggZGFzaGVkICNkZWVjMGU7XFxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgIGN1cnNvcjogdXJsKFxcXCJAL2Fzc2V0cy9mbG93Y2hhcnRTdmcv56yULnN2Z1xcXCIpIDAgMzIsIGF1dG87XFxuICB9XFxuICAubGVuZ2VuZEl0ZW1Ob3JtYWwge1xcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgICBoZWlnaHQ6IDYwcHg7XFxuICAgIG1hcmdpbjogMTBweDtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcXG4gICAgY3Vyc29yOiBwb2ludGVyO1xcbiAgfVxcbiAgLmxlbmdlbmRJdGVtQWN0aXZlIHtcXG4gICAgbWFyZ2luOiAxMHB4O1xcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgICBoZWlnaHQ6IDYwcHg7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XFxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICAgIGJvcmRlcjogI2Q4MWUwNiAxcHggZGFzaGVkO1xcbiAgICBjdXJzb3I6IHBvaW50ZXI7XFxuICB9XFxuICAvLyAuc2V0dGluZ3tcXG4gIC8vICAgY3Vyc29yOnVybCgnQC9hc3NldHMvZmxvd2NoYXJ0U3ZnL+eslC5zdmcnKSAwIDMyLGF1dG87XFxuICAvLyB9XFxufVxcblwiLFwiLmZsb3dCb3gge1xcbiAgd2lkdGg6IDEwMCU7XFxuICBoZWlnaHQ6IDgwMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmZsb3dCb3ggLmxlZ2VuZCxcXG4uZmxvd0JveCAuc2V0dGluZyB7XFxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XFxuICB3aWR0aDogMjAwcHg7XFxuICBoZWlnaHQ6IDgwMHB4O1xcbiAgYmFja2dyb3VuZDogI2UwZGVkZTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xcbn1cXG4uZmxvd0JveCAubGVnZW5kIGg0LFxcbi5mbG93Qm94IC5zZXR0aW5nIGg0IHtcXG4gIGZvbnQtc2l6ZTogMThweDtcXG4gIG1hcmdpbjogMTBweCBhdXRvO1xcbiAgYm9yZGVyLWJvdHRvbTogIzAwMCBkYXNoZWQgMXB4O1xcbn1cXG4uZmxvd0JveCAuY2hhcnROb3JtYWwge1xcbiAgZmxleDogMTtcXG4gIGJvcmRlcjogMnB4IGRhc2hlZCAjZGVlYzBlO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG59XFxuLmZsb3dCb3ggLmNoYXJ0TW9kZSB7XFxuICBmbGV4OiAxO1xcbiAgYm9yZGVyOiAycHggZGFzaGVkICNkZWVjMGU7XFxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgY3Vyc29yOiB1cmwoXFxcIkAvYXNzZXRzL2Zsb3djaGFydFN2Zy/nrJQuc3ZnXFxcIikgMCAzMiwgYXV0bztcXG59XFxuLmZsb3dCb3ggLmxlbmdlbmRJdGVtTm9ybWFsIHtcXG4gIG1hcmdpbi10b3A6IDEwcHg7XFxuICBoZWlnaHQ6IDYwcHg7XFxuICBtYXJnaW46IDEwcHg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5mbG93Qm94IC5sZW5nZW5kSXRlbUFjdGl2ZSB7XFxuICBtYXJnaW46IDEwcHg7XFxuICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgaGVpZ2h0OiA2MHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XFxuICBhbGlnbi1pdGVtczogY2VudGVyO1xcbiAgYm9yZGVyOiAjZDgxZTA2IDFweCBkYXNoZWQ7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5tYWluQm94W2RhdGEtdi0yNjJkOTdlNV0ge1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxuICBwYWRkaW5nOiAxMHB4O1xcbiAgcGFkZGluZy1ib3R0b206IDUwcHg7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxufVxcbi5tYWluQm94IC50ZW1bZGF0YS12LTI2MmQ5N2U1XSB7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5tYWluQm94IGg0W2RhdGEtdi0yNjJkOTdlNV0ge1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG59XFxuLm1haW5Cb3ggLmZvcm1JdGVtW2RhdGEtdi0yNjJkOTdlNV0ge1xcbiAgd2lkdGg6IDQ4MHB4O1xcbn1cXG4ubWFpbkJveCAudGltZUJveFtkYXRhLXYtMjYyZDk3ZTVdIHtcXG4gIHdpZHRoOiA0ODBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5tYWluQm94W2RhdGEtdi0yNjJkOTdlNV0gLmVsLWZvcm0taXRlbV9fY29udGVudCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC13cmFwOiBub3dyYXA7XFxufVxcbi5tYWluQm94IC5pY29uQm94W2RhdGEtdi0yNjJkOTdlNV0ge1xcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5tYWluQm94IC5mb290ZXJbZGF0YS12LTI2MmQ5N2U1XSB7XFxuICBwYWRkaW5nLXRvcDogMTBweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgYm90dG9tOiAzMHB4O1xcbiAgbGVmdDogMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbn1cXG4uZnVsbERpYUxvZ1tkYXRhLXYtMjYyZDk3ZTVdIC5lbC1kaWFsb2dfX2hlYWRlciB7XFxuICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcXG59XFxuLmZ1bGxEaWFMb2dbZGF0YS12LTI2MmQ5N2U1XSAuZWwtZGlhbG9nX19ib2R5IHtcXG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvY29tcG9uZW50cy9nbG9iYWxGb3JtSW5mby52dWVcIixcIndlYnBhY2s6Ly8uL2dsb2JhbEZvcm1JbmZvLnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGNBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ0FGO0FESkE7RUFPSSw2QkFBQTtFQUNBLG1CQUFBO0FDQUo7QURSQTtFQVlJLGVBQUE7RUFDQSxnQkFBQTtBQ0RKO0FEWkE7RUFpQkksWUFBQTtBQ0ZKO0FEZkE7RUFzQkksWUFBQTtFQUNBLGFBQUE7QUNKSjtBRG5CQTtFQTJCSSxhQUFBO0VBQ0EsaUJBQUE7QUNMSjtBRHZCQTtFQWdDSSxpQkFBQTtFQUNBLGVBQUE7QUNOSjtBRDNCQTtFQXFDSSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FDUEo7QURVQTtFQUVJLHVCQUFBO0FDVEo7QURPQTtFQUtJLHVCQUFBO0FDVEpcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxuLm1haW5Cb3gge1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxuICBwYWRkaW5nOiAxMHB4O1xcbiAgcGFkZGluZy1ib3R0b206IDUwcHg7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuXFxuICAudGVtIHtcXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWU7XFxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XFxuICB9XFxuXFxuICBoNCB7XFxuICAgIGZvbnQtc2l6ZTogMThweDtcXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcXG4gIH1cXG5cXG4gIC5mb3JtSXRlbSB7XFxuICAgIHdpZHRoOiA0ODBweDtcXG4gICAgLy8gbWFyZ2luOiAyMHB4O1xcbiAgICAvLyBkaXNwbGF5OiBmbGV4O1xcbiAgfVxcbiAgLnRpbWVCb3gge1xcbiAgICB3aWR0aDogNDgwcHg7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuICB9XFxuXFxuICA6OnYtZGVlcCguZWwtZm9ybS1pdGVtX19jb250ZW50KSB7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgIGZsZXgtd3JhcDogbm93cmFwO1xcbiAgfVxcblxcbiAgLmljb25Cb3gge1xcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcXG4gICAgY3Vyc29yOiBwb2ludGVyO1xcbiAgfVxcblxcbiAgLmZvb3RlciB7XFxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xcbiAgICBoZWlnaHQ6IDQwcHg7XFxuICAgIHdpZHRoOiAxMDAlO1xcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICAgIGJvdHRvbTogMzBweDtcXG4gICAgbGVmdDogMHB4O1xcbiAgICBkaXNwbGF5OiBmbGV4O1xcbiAgICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbiAgfVxcbn1cXG4uZnVsbERpYUxvZyB7XFxuICA6OnYtZGVlcCguZWwtZGlhbG9nX19oZWFkZXIpIHtcXG4gICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XFxuICB9XFxuICA6OnYtZGVlcCguZWwtZGlhbG9nX19ib2R5KSB7XFxuICAgIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xcbiAgfVxcbn1cXG5cIixcIi5tYWluQm94IHtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgcGFkZGluZzogMTBweDtcXG4gIHBhZGRpbmctYm90dG9tOiA1MHB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4ubWFpbkJveCAudGVtIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVlO1xcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcXG59XFxuLm1haW5Cb3ggaDQge1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG59XFxuLm1haW5Cb3ggLmZvcm1JdGVtIHtcXG4gIHdpZHRoOiA0ODBweDtcXG59XFxuLm1haW5Cb3ggLnRpbWVCb3gge1xcbiAgd2lkdGg6IDQ4MHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLm1haW5Cb3ggOjp2LWRlZXAoLmVsLWZvcm0taXRlbV9fY29udGVudCkge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtd3JhcDogbm93cmFwO1xcbn1cXG4ubWFpbkJveCAuaWNvbkJveCB7XFxuICBtYXJnaW4tbGVmdDogMjBweDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLm1haW5Cb3ggLmZvb3RlciB7XFxuICBwYWRkaW5nLXRvcDogMTBweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgYm90dG9tOiAzMHB4O1xcbiAgbGVmdDogMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbn1cXG4uZnVsbERpYUxvZyA6OnYtZGVlcCguZWwtZGlhbG9nX19oZWFkZXIpIHtcXG4gIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xcbn1cXG4uZnVsbERpYUxvZyA6OnYtZGVlcCguZWwtZGlhbG9nX19ib2R5KSB7XFxuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsImNvbnN0IGFsbENvbmZpZyA9IHtcclxuICAgIGxlbmdlbmRMaXN0OltcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgbmFtZTonbW9kZScsXHJcbiAgICAgICAgICAgdGl0bGU6J+aooeWdlycsXHJcbiAgICAgICAgICAgc3ZnTmFtZTon6IyD5Zu0J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOidlbnRpcnknLFxyXG4gICAgICAgICAgICB0aXRsZTon5a6e54mpJyxcclxuICAgICAgICAgICAgc3ZnTmFtZTon55+p5b2iJ1xyXG4gICAgICAgICB9LFxyXG4gICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6J2VsbGlwc2UnLFxyXG4gICAgICAgICAgICB0aXRsZTon5L6b5bqU5ZWGJyxcclxuICAgICAgICAgICAgc3ZnTmFtZTon5qSt5ZyGJ1xyXG4gICAgICAgICB9LFxyXG4gICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6J3RyaWFuZ2xlJyxcclxuICAgICAgICAgICAgdGl0bGU6J+S4muWKoee6vycsXHJcbiAgICAgICAgICAgIHN2Z05hbWU6J+S4ieinkuW9oidcclxuICAgICAgICAgfSxcclxuICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOidsYWJlbCcsXHJcbiAgICAgICAgICAgIHRpdGxlOifmoIfms6gnLFxyXG4gICAgICAgICAgICBzdmdOYW1lOifmoIfms6gnXHJcbiAgICAgICAgIH0sXHJcbiAgICAgICAgIC8vIHtcclxuICAgICAgICAgLy8gICAgbmFtZTonZmxhZycsXHJcbiAgICAgICAgIC8vICAgIHRpdGxlOiflhbPplK7ngrknLFxyXG4gICAgICAgICAvLyAgICBzdmdOYW1lOifml5fluJwnXHJcbiAgICAgICAgIC8vIH0sXHJcbiAgICAgICAgIC8vIHtcclxuICAgICAgICAgLy8gICAgbmFtZTonZGFuZ2VyJyxcclxuICAgICAgICAgLy8gICAgdGl0bGU6J+mjjumZqeeCuScsXHJcbiAgICAgICAgIC8vICAgIHN2Z05hbWU6J+azqOaEjydcclxuICAgICAgICAgLy8gfSxcclxuICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOidsaW5rJyxcclxuICAgICAgICAgICAgdGl0bGU6J+i/nuaOpee6vycsXHJcbiAgICAgICAgICAgIHN2Z05hbWU6J+i/nuaOpSdcclxuICAgICAgICAgfSxcclxuICAgIF0sXHJcbiAgICB1dGlsc0xpc3Q6W1xyXG4gICAgICB7XHJcbiAgICAgICAgIG5hbWU6J2FsbENsZWFyJyxcclxuICAgICAgICAgdGl0bGU6J+a4hemZpCcsXHJcbiAgICAgICAgIHN2Z05hbWU6J+a4hemZpCdcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgICBuYW1lOidyZXNldExlbmdlbmQnLFxyXG4gICAgICAgICB0aXRsZTon6YeN572uJyxcclxuICAgICAgICAgc3ZnTmFtZTon6YeN572uJ1xyXG4gICAgICB9LFxyXG4gICAgXVxyXG59XHJcbmV4cG9ydCBkZWZhdWx0IGFsbENvbmZpZyIsImltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnXHJcbi8v5Yib5bu65LiA5Liq5aGr5YWF55+p5b2iXHJcbmV4cG9ydCBsZXQgY3JlYXRlUmVjdEZpbGwgPSAocG9zaXRpb24pID0+IHtcclxuICAgcmV0dXJuIHtcclxuICAgICAgeDogcG9zaXRpb24ueCAtIDIwMiAtIDEwMCxcclxuICAgICAgeTogcG9zaXRpb24ueSAtIDUyIC0gMTAwLFxyXG4gICAgICB3aWR0aDogMjAwLFxyXG4gICAgICBoZWlnaHQ6IDIwMCxcclxuICAgICAgbmFtZTogJ+WunueJqScsXHJcbiAgICAgIGNvbG9yOiAncmVkJyxcclxuICAgICAgbW9kZVR5cGU6ICdyZWN0RmlsbCcsXHJcbiAgICAgIHN0eWxlVHlwZTogJ2ZpbGwnLFxyXG4gICAgICBpZDogdXVpZHY0KCksXHJcbiAgICAgIG5vZGVJbmRleDoxLFxyXG4gICAgICBmcm9tTGlzdDpbXSxcclxuICAgICAgdGFyZ2V0TGlzdDpbXSxcclxuICAgICAgdGV4dDp7XHJcbiAgICAgICAgIGluZm86J+WunueJqScsXHJcbiAgICAgICAgIGNvbG9yOicjZmZmJ1xyXG4gICAgICB9XHJcbiAgIH1cclxufVxyXG4vL+WIm+W7uuS4gOS4quS4ieinkuW9olxyXG5leHBvcnQgbGV0IGNyZWF0ZVRyZWVCb3ggPSAocG9zaXRpb24pID0+IHtcclxuICAgcmV0dXJuIHtcclxuICAgICAgeDE6IHBvc2l0aW9uLnggLSAyMDAsXHJcbiAgICAgIHkxOiBwb3NpdGlvbi55IC0gNTAgLSAxMDAsXHJcbiAgICAgIHgyOiBwb3NpdGlvbi54IC0gMjAwIC0gMTAwLFxyXG4gICAgICB5MjogcG9zaXRpb24ueSAtIDUwICsgMTAwLFxyXG4gICAgICB4MzogcG9zaXRpb24ueCAtIDIwMCArIDEwMCxcclxuICAgICAgeTM6IHBvc2l0aW9uLnkgLSA1MCArIDEwMCxcclxuICAgICAgbmFtZTogJ+S4muWKoee6vycsXHJcbiAgICAgIGNvbG9yOiAncmVkJyxcclxuICAgICAgbW9kZVR5cGU6ICd0aHJlZScsXHJcbiAgICAgIHN0eWxlVHlwZTogJ3N0cm9rZScsXHJcbiAgICAgIGlkOiB1dWlkdjQoKSxcclxuICAgICAgbm9kZUluZGV4OjEsXHJcbiAgICAgIGZyb21MaXN0OltdLFxyXG4gICAgICB0YXJnZXRMaXN0OltdLFxyXG4gICAgICB0ZXh0OntcclxuICAgICAgICAgaW5mbzon5Lia5Yqh57q/JyxcclxuICAgICAgICAgY29sb3I6JyNmZmYnXHJcbiAgICAgIH1cclxuICAgfVxyXG59XHJcbi8v5Yib5bu65LiA5Liq5o+P6L6555+p5b2iXHJcbmV4cG9ydCBsZXQgY3JlYXRlUmVjdFN0cm9rZSA9IChwb3NpdGlvbikgPT4ge1xyXG4gICByZXR1cm4ge1xyXG4gICAgICB4OiBwb3NpdGlvbi54IC0gMjAyIC0gMTAwLFxyXG4gICAgICB5OiBwb3NpdGlvbi55IC0gNTIgLSAxMDAsXHJcbiAgICAgIHdpZHRoOiAyMDAsXHJcbiAgICAgIGhlaWdodDogMjAwLFxyXG4gICAgICBuYW1lOiAn5qih5Z2XJyxcclxuICAgICAgY29sb3I6ICdyZWQnLFxyXG4gICAgICBtb2RlVHlwZTogJ3JlY3RTdHJva2UnLFxyXG4gICAgICBzdHlsZVR5cGU6ICdzdHJva2UnLFxyXG4gICAgICBpZDogdXVpZHY0KCksXHJcbiAgICAgIG5vZGVJbmRleDoxLFxyXG4gICAgICBmcm9tTGlzdDpbXSxcclxuICAgICAgdGFyZ2V0TGlzdDpbXSxcclxuICAgICAgdGV4dDp7XHJcbiAgICAgICAgIGluZm86J+aooeWdlycsXHJcbiAgICAgICAgIGNvbG9yOidyZWQnXHJcbiAgICAgIH1cclxuICAgfVxyXG59XHJcbi8v5Yib5bu65LiA5Liq5ZyG5b2iXHJcbmV4cG9ydCBsZXQgY3JlYXRlQXJjU3Ryb2tlID0gKHBvc2l0aW9uKSA9PiB7XHJcbiAgIHJldHVybiB7XHJcbiAgICAgIHg6IHBvc2l0aW9uLnggLSAyMDIsXHJcbiAgICAgIHk6IHBvc2l0aW9uLnkgLSA1MixcclxuICAgICAgYXJjU2l6ZTogMTAwLFxyXG4gICAgICBuYW1lOiAn5L6b5bqU5ZWGJyxcclxuICAgICAgY29sb3I6ICdyZWQnLFxyXG4gICAgICBtb2RlVHlwZTogJ2FyY0ZpbGwnLFxyXG4gICAgICBzdHlsZVR5cGU6ICdmaWxsJyxcclxuICAgICAgaWQ6IHV1aWR2NCgpLFxyXG4gICAgICBub2RlSW5kZXg6MSxcclxuICAgICAgZnJvbUxpc3Q6W10sXHJcbiAgICAgIHRhcmdldExpc3Q6W10sXHJcbiAgICAgIHRleHQ6e1xyXG4gICAgICAgICBpbmZvOifkvpvlupTllYYnLFxyXG4gICAgICAgICBjb2xvcjoncmVkJ1xyXG4gICAgICB9XHJcbiAgIH1cclxufVxyXG4vL+WIm+W7uui/nue6v1xyXG5leHBvcnQgbGV0IGNyZWF0ZUxpbmtMaW5lID0gKHBvc2l0aW9uKSA9PiB7XHJcbiAgIHJldHVybiB7XHJcbiAgICAgIGZyb21YOiBwb3NpdGlvbi54LFxyXG4gICAgICBmcm9tWTogcG9zaXRpb24ueSxcclxuICAgICAgdGFyZ2V0WDogbnVsbCxcclxuICAgICAgdGFyZ2V0WTogbnVsbCxcclxuICAgICAgbGluZVdpZHRoOiAyMCxcclxuICAgICAgbmFtZTogJ+i/nuaOpee6vycsXHJcbiAgICAgIGNvbG9yOiAncmVkJyxcclxuICAgICAgbW9kZVR5cGU6ICdsaW5rTGluZScsXHJcbiAgICAgIHN0eWxlVHlwZTogJ2ZpbGwnLFxyXG4gICAgICBpZDogdXVpZHY0KCksXHJcbiAgICAgIG5vZGVJbmRleDowXHJcbiAgIH1cclxufVxyXG4vL+WIm+W7uuS4gOS4quaWh+acrFxyXG5leHBvcnQgbGV0IGNyZWF0ZVRleHQgPSAocG9zaXRpb24pID0+e1xyXG4gICBjb25zb2xlLmxvZyhwb3NpdGlvbiwn5paH5pys5Zyw5Z2AJylcclxuICAgcmV0dXJuIHtcclxuICAgICAgdGV4dFg6cG9zaXRpb24ueCxcclxuICAgICAgdGV4dFk6cG9zaXRpb24ueSxcclxuICAgICAgY29sb3I6J3JlZCcsXHJcbiAgICAgIG1vZGVUeXBlOid0ZXh0JyxcclxuICAgICAgaWQ6dXVpZHY0KCksXHJcbiAgICAgIG5vZGVJbmRleDoxMDAwLFxyXG4gICAgICBpbmZvOicnLFxyXG4gICB9XHJcbn0iLCJpbXBvcnQgYWxsQ29uZmlnIGZyb20gXCIuLi9qYXZhc2NyaXB0L2Zsb3djaGFydENvbmZpZ1wiO1xuaW1wb3J0IHsgVnVlRHJhZ2dhYmxlTmV4dCB9IGZyb20gXCJ2dWUtZHJhZ2dhYmxlLW5leHRcIjtcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XG5pbXBvcnQgeyBjcmVhdGVSZWN0RmlsbCwgY3JlYXRlVHJlZUJveCwgY3JlYXRlUmVjdFN0cm9rZSwgY3JlYXRlQXJjU3Ryb2tlLCBjcmVhdGVMaW5rTGluZSwgY3JlYXRlVGV4dCB9IGZyb20gXCJAL2phdmFzY3JpcHQvZ2xvYmFsRmxvd0Z1bi5qc1wiO1xuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdnbG9iYWxGbG93JyxcbiAgc2V0dXA6IGZ1bmN0aW9uIHNldHVwKF9fcHJvcHMsIF9yZWYpIHtcbiAgICB2YXIgZXhwb3NlID0gX3JlZi5leHBvc2U7XG4gICAgdmFyIGRyYWdnYWJsZSA9IFZ1ZURyYWdnYWJsZU5leHQ7IC8v5ouW5ou957uE5Lu2XG4gICAgdmFyIHJvdXRlID0gdXNlUm91dGUoKTtcbiAgICB2YXIgbW91c2VQb3NpdGlvbiA9IHJlZih7fSk7IC8vXG4gICAgdmFyIGxlbmdlbmRMaXN0ID0gcmVhY3RpdmUoYWxsQ29uZmlnLmxlbmdlbmRMaXN0KTsgLy/lm77kvovpm4blkIhcbiAgICB2YXIgdXRpbHNMaXN0ID0gcmVhY3RpdmUoYWxsQ29uZmlnLnV0aWxzTGlzdCk7IC8v5bel5YW36ZuG5ZCIXG4gICAgdmFyIGxlZ2VuZEFjdGl2ZUl0ZW0gPSByZWYoXCJcIik7IC8v5b2T5YmN6YCJ5Lit5Zu+5L6LXG4gICAgdmFyIGlzTW9kZSA9IHJlZihmYWxzZSk7IC8v5piv5ZCm5Li65qih5Z2XXG4gICAgdmFyIGNhbnZhcyA9IG51bGw7IC8v55S75biDXG4gICAgdmFyIGNhbnZhc01vZGUgPSBudWxsOyAvL+eUu+W4g+WunuS+i1xuICAgIHZhciBub2RlTGlzdCA9IHJlZihbXSk7IC8v55S75biD5YaF5a655pWw57uEXG4gICAgdmFyIGFjdGl2ZU5vZGVJbmZvID0gcmVmKHt9KTsgLy/mtLvliqjnmoTnu4Tku7bkv6Hmga9cbiAgICB2YXIgaXNMaW5rTGluZSA9IHJlZihmYWxzZSk7IC8v5piv5ZCm5Li66L+e57q/54q25oCBXG4gICAgdmFyIGFjdGl2ZUxpbmVJZCA9IHJlZih1bmRlZmluZWQpOyAvL+W9k+WJjei/nue6v+eahGlkXG4gICAgdmFyIGxpbmtMaW5lRmxhZyA9IHJlZihmYWxzZSk7IC8v6L+e57q/5qCH5b+XXG4gICAgdmFyIGxpbmtMaW5lRnJvbSA9IHJlZih1bmRlZmluZWQpOyAvL+e6v+adoei1t+eCuVxuICAgIHZhciBsaW5rTGluZVRhcmdldCA9IHJlZih1bmRlZmluZWQpOyAvL+e6v+adoee7iOeCuVxuICAgIHZhciBjbGlja05vZGVGbGFnID0gcmVmKGZhbHNlKTsgLy/mmK/lkKbngrnlh7voioLngrlcbiAgICB2YXIgZXZlbnROYW1lID0gcmVmKHVuZGVmaW5lZCk7IC8v5b2T5YmN5aSE5LqO5LuA5LmI5LqL5Lu2XG4gICAgdmFyIGNhbnZhc1N0eWxlSW5mbyA9IHJlZih7XG4gICAgICBiYWNrZ3JvdW5kOiBcIiNmZmZcIixcbiAgICAgIHNjYWxlOiAxXG4gICAgfSk7XG4gICAgdmFyIGltYWdlTmFtZSA9IHJlZihcIueUu+W4g1wiKTtcbiAgICB2YXIgdGV4dGFyZWFWYWx1ZSA9IHJlZignJyk7XG4gICAgdmFyIHRleHRhcmVhU2hvdyA9IHJlZihmYWxzZSk7XG4gICAgdmFyIHRleHRhcmVhQ2xhc3MgPSByZWYoe1xuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICBsZWZ0OiAnMzAwcHgnLFxuICAgICAgdG9wOiAnMzAwcHgnLFxuICAgICAgaW5kZXg6IDEwMDAsXG4gICAgICB3aWR0aDogJzMwMHB4JyxcbiAgICAgIGJvcmRlcjogJzFweCBkYXNoZWQgIzIzY2Y3ZCcsXG4gICAgICBvdXRsaW5lOiAnbm9uZScsXG4gICAgICByb3dzOiA1XG4gICAgfSk7XG4gICAgLy/mi5bmi73phY3nva5cbiAgICB2YXIgZHJhZ09wdGlvbnMgPSB7XG4gICAgICBwcmV2ZW50T25GaWx0ZXI6IGZhbHNlLFxuICAgICAgc29ydDogZmFsc2UsXG4gICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICBnaG9zdENsYXNzOiBcInR0XCIsXG4gICAgICBmb3JjZUZhbGxiYWNrOiB0cnVlXG4gICAgfTtcblxuICAgIC8v5Zu+5L6L55qE5qC35byPXG4gICAgdmFyIGxlbmdlbmRDbGFzcyA9IGZ1bmN0aW9uIGxlbmdlbmRDbGFzcyhuYW1lKSB7XG4gICAgICBpZiAobmFtZSAhPT0gbGVnZW5kQWN0aXZlSXRlbS52YWx1ZSkge1xuICAgICAgICByZXR1cm4gXCJsZW5nZW5kSXRlbU5vcm1hbFwiO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFwibGVuZ2VuZEl0ZW1BY3RpdmVcIjtcbiAgICAgIH1cbiAgICB9O1xuICAgIC8v54K55Ye75Zu+5L6L5LqL5Lu2XG4gICAgdmFyIGNsaWNrTGVuZ2VuZCA9IGZ1bmN0aW9uIGNsaWNrTGVuZ2VuZChuYW1lKSB7XG4gICAgICBpZiAocm91dGUucXVlcnkudHlwZSA9PT0gJ2RldGFpbCcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdGV4dGFyZWFTaG93LnZhbHVlID0gZmFsc2U7XG4gICAgICBsZWdlbmRBY3RpdmVJdGVtLnZhbHVlID0gbmFtZTtcbiAgICAgIGlzTGlua0xpbmUudmFsdWUgPSBmYWxzZTtcbiAgICAgIGlmIChuYW1lID09PSBcIm1vZGVcIikge1xuICAgICAgICAvLyBpc01vZGUudmFsdWUgPSB0cnVlXG4gICAgICB9IGVsc2UgaWYgKG5hbWUgPT09IFwibGlua1wiKSB7XG4gICAgICAgIGlzTGlua0xpbmUudmFsdWUgPSB0cnVlO1xuICAgICAgfSBlbHNlIGlmIChuYW1lID09PSBcImFsbENsZWFyXCIpIHtcbiAgICAgICAgY2FudmFzTW9kZS5jbGVhclJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICAgICAgbm9kZUxpc3QudmFsdWUgPSBbXTtcbiAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gXCJyZXNldExlbmdlbmRcIikge1xuICAgICAgICBsZWdlbmRBY3RpdmVJdGVtLnZhbHVlID0gdW5kZWZpbmVkO1xuICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAnbGFiZWwnKSB7XG4gICAgICAgIHRleHRhcmVhU2hvdy52YWx1ZSA9IHRydWU7XG4gICAgICB9IGVsc2Uge31cbiAgICB9O1xuICAgIC8v5Zu+5L6L5ouW5Yqo5byA5aeLXG4gICAgdmFyIG1vdmVTdGFydCA9IGZ1bmN0aW9uIG1vdmVTdGFydChlbCkge307XG4gICAgLy/lm77kvovmi5bliqjnu5PmnZ9cbiAgICB2YXIgbW92ZUVuZCA9IGZ1bmN0aW9uIG1vdmVFbmQoZWwpIHtcbiAgICAgIHZhciBwb3NpdGlvbiA9IHtcbiAgICAgICAgeDogZWwub3JpZ2luYWxFdmVudC5jbGllbnRYLFxuICAgICAgICB5OiBlbC5vcmlnaW5hbEV2ZW50LmNsaWVudFlcbiAgICAgIH07XG4gICAgICBpZiAocG9zaXRpb24ueCA8IDIwMiArIDEwMCB8fCBwb3NpdGlvbi54ID4gMTcwMiAtIDEwMCB8fCBwb3NpdGlvbi55IDwgNTIgKyAxMDAgfHwgcG9zaXRpb24ueSA+IDg1MiAtIDEwMCkge1xuICAgICAgICBFbE1lc3NhZ2Uoe1xuICAgICAgICAgIG1lc3NhZ2U6IFwi5pyq5ouW5YWl55S75biD5LmL5LitXCIsXG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCJcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjaGFuZ2VOb2RlTGlzdChwb3NpdGlvbik7XG4gICAgICAgIGRyYXcobnVsbCk7XG4gICAgICB9XG4gICAgfTtcbiAgICAvL+eCueWHu+eUu+W4g1xuICAgIHZhciBjbGlja0NhbnZhcyA9IGZ1bmN0aW9uIGNsaWNrQ2FudmFzKGVsKSB7fTtcbiAgICAvL+eUu+W4g+S4rem8oOagh+aMieS4i1xuICAgIHZhciBjYW52YXNEb3duID0gZnVuY3Rpb24gY2FudmFzRG93bihlbCkge1xuICAgICAgaWYgKHJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGV2ZW50TmFtZS52YWx1ZSA9IFwibW91c2Vkb3duXCI7XG4gICAgICB2YXIgcG9zaXRpb24gPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICB2YXIgcG9zaXRpb25JbmZvID0ge1xuICAgICAgICB4OiBlbC5jbGllbnRYIC0gcG9zaXRpb24ubGVmdCxcbiAgICAgICAgeTogZWwuY2xpZW50WSAtIHBvc2l0aW9uLnRvcFxuICAgICAgfTtcbiAgICAgIGlmIChpc0xpbmtMaW5lLnZhbHVlID09PSB0cnVlKSB7XG4gICAgICAgIGxpbmtMaW5lRmxhZy52YWx1ZSA9IHRydWU7XG4gICAgICAgIGNoYW5nZU5vZGVMaXN0KHBvc2l0aW9uSW5mbyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjbGlja05vZGVGbGFnLnZhbHVlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGRyYXcocG9zaXRpb25JbmZvKTtcbiAgICB9O1xuICAgIC8v55S75biD5Lit6byg5qCH5oqs6LW3XG4gICAgdmFyIGNhbnZhc1VwID0gZnVuY3Rpb24gY2FudmFzVXAoZWwpIHtcbiAgICAgIGV2ZW50TmFtZS52YWx1ZSA9IFwibW91c2V1cFwiO1xuICAgICAgbGlua0xpbmVGbGFnLnZhbHVlID0gZmFsc2U7XG4gICAgICBjbGlja05vZGVGbGFnLnZhbHVlID0gZmFsc2U7XG4gICAgICB2YXIgcG9zaXRpb24gPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICB2YXIgcG9zaXRpb25JbmZvID0ge1xuICAgICAgICB4OiBlbC5jbGllbnRYIC0gcG9zaXRpb24ubGVmdCxcbiAgICAgICAgeTogZWwuY2xpZW50WSAtIHBvc2l0aW9uLnRvcFxuICAgICAgfTtcbiAgICAgIHRleHRhcmVhU2hvdy52YWx1ZSA9IGZhbHNlO1xuICAgICAgaWYgKGxlZ2VuZEFjdGl2ZUl0ZW0udmFsdWUgPT09ICdsYWJlbCcpIHtcbiAgICAgICAgdGV4dGFyZWFTaG93LnZhbHVlID0gdHJ1ZTtcbiAgICAgICAgdGV4dGFyZWFDbGFzcy52YWx1ZS5sZWZ0ID0gZWwubGF5ZXJYICsgJ3B4JztcbiAgICAgICAgdGV4dGFyZWFDbGFzcy52YWx1ZS50b3AgPSBlbC5sYXllclkgKyAncHgnO1xuICAgICAgfVxuICAgICAgZHJhdyhwb3NpdGlvbkluZm8pO1xuICAgIH07XG4gICAgLy/nlLvluIPkuK3pvKDmoIfnp7vliqhcbiAgICB2YXIgY2FudmFzTW92ZSA9IGZ1bmN0aW9uIGNhbnZhc01vdmUoZWwpIHtcbiAgICAgIGlmIChyb3V0ZS5xdWVyeS50eXBlID09PSAnZGV0YWlsJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBldmVudE5hbWUudmFsdWUgPSBcIm1vdXNlbW92ZVwiO1xuICAgICAgaWYgKGlzTGlua0xpbmUudmFsdWUgPT09IHRydWUpIHtcbiAgICAgICAgaWYgKGxpbmtMaW5lRmxhZy52YWx1ZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgIGNyZWF0ZUxpbmtUYXJnZXQoZWwpO1xuICAgICAgICAgIGRyYXcoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKGNsaWNrTm9kZUZsYWcudmFsdWUgPT09IHRydWUpIHtcbiAgICAgICAgICBzd2l0Y2ggKGFjdGl2ZU5vZGVJbmZvLnZhbHVlLm1vZGVUeXBlKSB7XG4gICAgICAgICAgICBjYXNlIFwicmVjdFN0cm9rZVwiOlxuICAgICAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54ID0gZWwub2Zmc2V0WCAtIDEwMDtcbiAgICAgICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueSA9IGVsLm9mZnNldFkgLSAxMDA7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcInJlY3RGaWxsXCI6XG4gICAgICAgICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnggPSBlbC5vZmZzZXRYIC0gMTAwO1xuICAgICAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55ID0gZWwub2Zmc2V0WSAtIDEwMDtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwiYXJjRmlsbFwiOlxuICAgICAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54ID0gZWwub2Zmc2V0WDtcbiAgICAgICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueSA9IGVsLm9mZnNldFk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcInRocmVlXCI6XG4gICAgICAgICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLngxID0gZWwub2Zmc2V0WDtcbiAgICAgICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueTEgPSBlbC5vZmZzZXRZIC0gMTAwO1xuICAgICAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54MiA9IGVsLm9mZnNldFggLSAxMDA7XG4gICAgICAgICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnkyID0gZWwub2Zmc2V0WSArIDEwMDtcbiAgICAgICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueDMgPSBlbC5vZmZzZXRYICsgMTAwO1xuICAgICAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55MyA9IGVsLm9mZnNldFkgKyAxMDA7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgICBtb3ZlTGluZUluZm8oZWwpO1xuICAgICAgICAgIGRyYXcoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgdmFyIGNhbnZhc0xlYXZlID0gZnVuY3Rpb24gY2FudmFzTGVhdmUoZWwpIHtcbiAgICAgIGxlZ2VuZEFjdGl2ZUl0ZW0udmFsdWUgPSB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICAvL+iKgueCueenu+WKqOaXtue6v+adoeS9jee9rueahOaUueWPmFxuICAgIHZhciBtb3ZlTGluZUluZm8gPSBmdW5jdGlvbiBtb3ZlTGluZUluZm8oZWwpIHtcbiAgICAgIGlmICghYWN0aXZlTm9kZUluZm8udmFsdWUgfHwgIWFjdGl2ZU5vZGVJbmZvLnZhbHVlLmZyb21MaXN0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChhY3RpdmVOb2RlSW5mby52YWx1ZS5mcm9tTGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLmZyb21MaXN0LmZvckVhY2goZnVuY3Rpb24gKEl0ZW0pIHtcbiAgICAgICAgICB2YXIgbGluZSA9IG5vZGVMaXN0LnZhbHVlLmZpbmQoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIHJldHVybiBJdGVtID09PSBpdGVtLmlkO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGxpbmUuZnJvbVggPSBlbC5vZmZzZXRYO1xuICAgICAgICAgIGxpbmUuZnJvbVkgPSBlbC5vZmZzZXRZO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChhY3RpdmVOb2RlSW5mby52YWx1ZS50YXJnZXRMaXN0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUudGFyZ2V0TGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChJdGVtKSB7XG4gICAgICAgICAgdmFyIGxpbmUgPSBub2RlTGlzdC52YWx1ZS5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gSXRlbSA9PT0gaXRlbS5pZDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsaW5lLnRhcmdldFggPSBlbC5vZmZzZXRYO1xuICAgICAgICAgIGxpbmUudGFyZ2V0WSA9IGVsLm9mZnNldFk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG4gICAgLy/nlLvluIPliJ3lp4vljJZcbiAgICB2YXIgY2FudmFzSW5pdCA9IGZ1bmN0aW9uIGNhbnZhc0luaXQobGlzdCkge1xuICAgICAgY2FudmFzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW52YXNcIik7XG4gICAgICBjYW52YXNNb2RlID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcbiAgICAgIG5vZGVMaXN0LnZhbHVlID0gbGlzdDtcbiAgICAgIGRyYXcobnVsbCk7XG4gICAgfTtcbiAgICAvL+WIm+W7uui/nuaOpei1t+Wni+eCuVxuICAgIHZhciBjcmVhdGVMaW5rVGFyZ2V0ID0gZnVuY3Rpb24gY3JlYXRlTGlua1RhcmdldChlbCkge1xuICAgICAgdmFyIGxpbmtMaW5lSW5mbyA9IG5vZGVMaXN0LnZhbHVlW25vZGVMaXN0LnZhbHVlLmZpbmRJbmRleChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICByZXR1cm4gaXRlbS5pZCA9PT0gYWN0aXZlTGluZUlkLnZhbHVlO1xuICAgICAgfSldO1xuICAgICAgaWYgKGVsLm9mZnNldFggPiAwICYmIGVsLm9mZnNldFkgPiAwKSB7XG4gICAgICAgIGxpbmtMaW5lSW5mby50YXJnZXRYID0gZWwub2Zmc2V0WDtcbiAgICAgICAgbGlua0xpbmVJbmZvLnRhcmdldFkgPSBlbC5vZmZzZXRZO1xuICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XG4gICAgICB9XG4gICAgfTtcbiAgICAvL+e7mOWItuWbvuW9oijmoLjlv4Pmlrnms5UpXG4gICAgdmFyIGRyYXcgPSBmdW5jdGlvbiBkcmF3KHBvc2l0aW9uSW5mbykge1xuICAgICAgY2FudmFzTW9kZS5jbGVhclJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICAgIG5vZGVMaXN0LnZhbHVlLmZvckVhY2goZnVuY3Rpb24gKGl0ZW0sIGluZGV4KSB7XG4gICAgICAgIGNhbnZhc01vZGUuYmVnaW5QYXRoKCk7XG4gICAgICAgIGNhbnZhc01vZGUubGluZVdpZHRoID0gNTtcbiAgICAgICAgLyoq5aGr5YWF55+p5b2iKOWunueJqSkgKi9cbiAgICAgICAgaWYgKGl0ZW0ubW9kZVR5cGUgPT09IFwicmVjdEZpbGxcIikge1xuICAgICAgICAgIGNhbnZhc01vZGUucmVjdChpdGVtLngsIGl0ZW0ueSwgaXRlbS53aWR0aCwgaXRlbS5oZWlnaHQpO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLnN0cm9rZVN0eWxlID0gaXRlbS5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGwoKTtcbiAgICAgICAgICBjYW52YXNNb2RlLnN0cm9rZSgpO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS50ZXh0LmNvbG9yO1xuICAgICAgICAgIGNhbnZhc01vZGUuZm9udCA9IFwiMThweCBUaW1lc1wiO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFRleHQoaXRlbS50ZXh0LmluZm8sIGl0ZW0ueCArIDgwLCBpdGVtLnkgKyAxMDApO1xuICAgICAgICB9IGVsc2UgaWYgKGl0ZW0ubW9kZVR5cGUgPT09IFwidGhyZWVcIikge1xuICAgICAgICAgIC8qKuaPj+i+ueS4ieinkuW9oijkuJrliqHnur8pKi9cbiAgICAgICAgICBjYW52YXNNb2RlLm1vdmVUbyhpdGVtLngxLCBpdGVtLnkxKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLngyLCBpdGVtLnkyKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLngzLCBpdGVtLnkzKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLngxLCBpdGVtLnkxKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmNsb3NlUGF0aCgpO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGwoKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0udGV4dC5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZvbnQgPSBcIjE4cHggVGltZXNcIjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KGl0ZW0udGV4dC5pbmZvLCBpdGVtLngxIC0gMzAsIGl0ZW0ueTEgKyAxMzApO1xuICAgICAgICB9IGVsc2UgaWYgKGl0ZW0ubW9kZVR5cGUgPT09IFwicmVjdFN0cm9rZVwiKSB7XG4gICAgICAgICAgLyoq5o+P6L6555+p5b2iKOaooeWdlykqL1xuICAgICAgICAgIGNhbnZhc01vZGUucmVjdChpdGVtLngsIGl0ZW0ueSwgaXRlbS53aWR0aCwgaXRlbS5oZWlnaHQpO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gXCIjZmZmXCI7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2VTdHlsZSA9IGl0ZW0uY29sb3I7XG4gICAgICAgICAgY2FudmFzTW9kZS5maWxsKCk7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2UoKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0udGV4dC5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZvbnQgPSBcIjE4cHggVGltZXNcIjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KGl0ZW0udGV4dC5pbmZvLCBpdGVtLnggKyA4MCwgaXRlbS55ICsgMTAwKTtcbiAgICAgICAgfSBlbHNlIGlmIChpdGVtLm1vZGVUeXBlID09PSBcImFyY0ZpbGxcIikge1xuICAgICAgICAgIC8qKuWchuW9oijkvpvlupTllYYpKi9cbiAgICAgICAgICBjYW52YXNNb2RlLmFyYyhpdGVtLngsIGl0ZW0ueSwgaXRlbS5hcmNTaXplLCAwLCBNYXRoLlBJICogMiwgZmFsc2UpO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gXCIjZmZmXCI7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2VTdHlsZSA9IGl0ZW0uY29sb3I7XG4gICAgICAgICAgY2FudmFzTW9kZS5maWxsKCk7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2UoKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0udGV4dC5jb2xvcjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZvbnQgPSBcIjE4cHggVGltZXNcIjtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KGl0ZW0udGV4dC5pbmZvLCBpdGVtLnggLSAzMCwgaXRlbS55KTtcbiAgICAgICAgfSBlbHNlIGlmIChpdGVtLm1vZGVUeXBlID09PSBcImxpbmtMaW5lXCIpIHtcbiAgICAgICAgICAvKirov57nur8qL1xuICAgICAgICAgIGNhbnZhc01vZGUubW92ZVRvKGl0ZW0uZnJvbVgsIGl0ZW0uZnJvbVkpO1xuICAgICAgICAgIGlmIChpdGVtLnRhcmdldFggJiYgaXRlbS50YXJnZXRZKSB7XG4gICAgICAgICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLnRhcmdldFgsIGl0ZW0udGFyZ2V0WSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhbnZhc01vZGUubGluZVRvKGl0ZW0uZnJvbVgsIGl0ZW0uZnJvbVkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYW52YXNNb2RlLmxpbmVDYXAgPSBcInJvdW5kXCI7XG4gICAgICAgICAgY2FudmFzTW9kZS5maWxsU3R5bGUgPSBpdGVtLmNvbG9yO1xuICAgICAgICAgIGNhbnZhc01vZGUuc3Ryb2tlU3R5bGUgPSBpdGVtLmNvbG9yO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbCgpO1xuICAgICAgICAgIGNhbnZhc01vZGUuc3Ryb2tlKCk7XG4gICAgICAgIH1cbiAgICAgICAgLyrnu5jliLbmlofmnKwqL2Vsc2UgaWYgKGl0ZW0ubW9kZVR5cGUgPT09IFwidGV4dFwiKSB7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2VTdHlsZSA9IGNhbnZhc1N0eWxlSW5mby52YWx1ZS5iYWNrZ3JvdW5kO1xuICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gY2FudmFzU3R5bGVJbmZvLnZhbHVlLmJhY2tncm91bmQ7XG4gICAgICAgICAgY2FudmFzTW9kZS5saW5lV2lkdGggPSAxO1xuICAgICAgICAgIHZhciBtYXhMZW5ndGggPSBpdGVtLmluZm8ucmVkdWNlKGZ1bmN0aW9uIChuZXdWYWwsIG9sZFZhbCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ld1ZhbC5sZW5ndGggPiBvbGRWYWwubGVuZ3RoID8gbmV3VmFsLmxlbmd0aCA6IG9sZFZhbC5sZW5ndGg7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY2FudmFzTW9kZS5yZWN0KGl0ZW0udGV4dFggLSAyMDAsIGl0ZW0udGV4dFkgLSA1MCwgKG1heExlbmd0aCArIDEpICogMTAsIChpdGVtLmluZm8ubGVuZ3RoICsgMSkgKiAyMCk7XG4gICAgICAgICAgY2FudmFzTW9kZS5maWxsKCk7XG4gICAgICAgICAgY2FudmFzTW9kZS5zdHJva2UoKTtcbiAgICAgICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0uY29sb3I7XG4gICAgICAgICAgY2FudmFzTW9kZS5mb250ID0gXCIxOHB4IFRpbWVzXCI7XG4gICAgICAgICAgaXRlbS5pbmZvLmZvckVhY2goZnVuY3Rpb24gKG0sIG4pIHtcbiAgICAgICAgICAgIGNhbnZhc01vZGUuZmlsbFRleHQobSwgaXRlbS50ZXh0WCAtIDIwMCwgaXRlbS50ZXh0WSAtIDMwICsgMjAgKiBuKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8v5Yik5pat54K55Ye76Kem5Y+R5YWD57SgXG4gICAgICAgIGlmIChwb3NpdGlvbkluZm8pIHtcbiAgICAgICAgICB2YXIgaXNUYXJnZXRfcGF0aCA9IGNhbnZhc01vZGUuaXNQb2ludEluUGF0aChwb3NpdGlvbkluZm8ueCwgcG9zaXRpb25JbmZvLnkpO1xuICAgICAgICAgIHZhciBpc1RhcmdldF9zdHJva2UgPSBjYW52YXNNb2RlLmlzUG9pbnRJblN0cm9rZShwb3NpdGlvbkluZm8ueCwgcG9zaXRpb25JbmZvLnkpO1xuICAgICAgICAgIGlmIChpc1RhcmdldF9wYXRoIHx8IGlzVGFyZ2V0X3N0cm9rZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCLngrnlh7vliLDkuobmn5DlhYPntKBcIiwgaXRlbSwgaW5kZXgpO1xuICAgICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUgPSBpdGVtO1xuICAgICAgICAgICAgaWYgKGlzTGlua0xpbmUudmFsdWUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgaWYgKGFjdGl2ZUxpbmVJZC52YWx1ZSkge1xuICAgICAgICAgICAgICAgIGlmIChldmVudE5hbWUudmFsdWUgPT09IFwibW91c2Vkb3duXCIpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChpdGVtLm1vZGVUeXBlICE9PSBcImxpbmtMaW5lXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbGlua0xpbmVGcm9tLnZhbHVlID0gaXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5mcm9tTGlzdC5wdXNoKGFjdGl2ZUxpbmVJZC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChldmVudE5hbWUudmFsdWUgPT09IFwibW91c2V1cFwiKSB7XG4gICAgICAgICAgICAgICAgICBpZiAoaXRlbS5tb2RlVHlwZSAhPT0gXCJsaW5rTGluZVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIGxpbmtMaW5lVGFyZ2V0LnZhbHVlID0gaXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS50YXJnZXRMaXN0LnB1c2goYWN0aXZlTGluZUlkLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChhY3RpdmVOb2RlSW5mby52YWx1ZS5tb2RlVHlwZSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgICAgIHRleHRhcmVhU2hvdy52YWx1ZSA9IHRydWU7XG4gICAgICAgICAgICAgIHRleHRhcmVhQ2xhc3MudmFsdWUubGVmdCA9IGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnRleHRYICsgJ3B4JztcbiAgICAgICAgICAgICAgdGV4dGFyZWFDbGFzcy52YWx1ZS50b3AgPSBhY3RpdmVOb2RlSW5mby52YWx1ZS50ZXh0WSAtIDUwICsgJ3B4JztcbiAgICAgICAgICAgICAgdGV4dGFyZWFDbGFzcy52YWx1ZS5yb3dzID0gNTtcbiAgICAgICAgICAgICAgdmFyIHN0ciA9IGFjdGl2ZU5vZGVJbmZvLnZhbHVlLmluZm8uam9pbignXFxuJyk7XG4gICAgICAgICAgICAgIHRleHRhcmVhVmFsdWUudmFsdWUgPSBcIlwiLmNvbmNhdChzdHIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYW52YXNNb2RlLmNsb3NlUGF0aCgpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICAvL+mAmui/h+aTjeS9nOWvueiKgueCueWIl+ihqOaVsOaNrui/m+ihjOS/ruaUuVxuICAgIHZhciBjaGFuZ2VOb2RlTGlzdCA9IGZ1bmN0aW9uIGNoYW5nZU5vZGVMaXN0KHBvc2l0aW9uKSB7XG4gICAgICBpc0xpbmtMaW5lLnZhbHVlID0gZmFsc2U7XG4gICAgICBzd2l0Y2ggKGxlZ2VuZEFjdGl2ZUl0ZW0udmFsdWUpIHtcbiAgICAgICAgY2FzZSBcImVudGlyeVwiOlxuICAgICAgICAgIG5vZGVMaXN0LnZhbHVlLnB1c2goY3JlYXRlUmVjdEZpbGwocG9zaXRpb24pKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInRyaWFuZ2xlXCI6XG4gICAgICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVUcmVlQm94KHBvc2l0aW9uKSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJtb2RlXCI6XG4gICAgICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVSZWN0U3Ryb2tlKHBvc2l0aW9uKSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJlbGxpcHNlXCI6XG4gICAgICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVBcmNTdHJva2UocG9zaXRpb24pKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImxpbmtcIjpcbiAgICAgICAgICB2YXIgbGluZUluZm8gPSBjcmVhdGVMaW5rTGluZShwb3NpdGlvbik7XG4gICAgICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChsaW5lSW5mbyk7XG4gICAgICAgICAgYWN0aXZlTGluZUlkLnZhbHVlID0gbGluZUluZm8uaWQ7XG4gICAgICAgICAgaXNMaW5rTGluZS52YWx1ZSA9IHRydWU7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJsYWJlbFwiOlxuICAgICAgICAgIHZhciBJbmZvID0gY3JlYXRlVGV4dChwb3NpdGlvbik7XG4gICAgICAgICAgdmFyIHRleHRJbmZvID0gXCJcIi5jb25jYXQodGV4dGFyZWFWYWx1ZS52YWx1ZSk7XG4gICAgICAgICAgSW5mby5pbmZvID0gdGV4dEluZm8uc3BsaXQoJ1xcbicpO1xuICAgICAgICAgIHRleHRhcmVhVmFsdWUudmFsdWUgPSAnJztcbiAgICAgICAgICB0ZXh0YXJlYVNob3cudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICBub2RlTGlzdC52YWx1ZS5wdXNoKEluZm8pO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgdmFyIGxpc3QwID0gW107XG4gICAgICB2YXIgbGlzdDEgPSBbXTtcbiAgICAgIHZhciBsaXN0MiA9IFtdO1xuICAgICAgdmFyIGxpc3QzID0gW107XG4gICAgICBub2RlTGlzdC52YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uIChtKSB7XG4gICAgICAgIGlmIChtLm5vZGVJbmRleCA9PT0gMCkge1xuICAgICAgICAgIGxpc3QwLnB1c2gobSk7XG4gICAgICAgIH0gZWxzZSBpZiAobS5ub2RlSW5kZXggPT09IDEpIHtcbiAgICAgICAgICBsaXN0MS5wdXNoKG0pO1xuICAgICAgICB9IGVsc2UgaWYgKG0ubm9kZUluZGV4ID09PSAyKSB7XG4gICAgICAgICAgbGlzdDIucHVzaChtKTtcbiAgICAgICAgfSBlbHNlIGlmIChtLm5vZGVJbmRleCA9PT0gMTAwMCkge1xuICAgICAgICAgIGxpc3QzLnB1c2gobSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgbm9kZUxpc3QudmFsdWUgPSBbXS5jb25jYXQobGlzdDApLmNvbmNhdChsaXN0MSkuY29uY2F0KGxpc3QyKS5jb25jYXQobGlzdDMpO1xuICAgIH07XG4gICAgdmFyIGNoYW5nZVNjYWxlID0gZnVuY3Rpb24gY2hhbmdlU2NhbGUoKSB7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XG4gICAgfTtcbiAgICAvL+S/ruaUueiKgueCueS4u+mimOiJslxuICAgIHZhciBjaGFuZ2VOb2RlVGhlbWVDb2xvciA9IGZ1bmN0aW9uIGNoYW5nZU5vZGVUaGVtZUNvbG9yKHZhbHVlKSB7XG4gICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS5jb2xvciA9IHZhbHVlO1xuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGRyYXcpO1xuICAgIH07XG4gICAgLy/kv67mlLnoioLngrnlrZfkvZPpopzoibJcbiAgICB2YXIgY2hhbmdlTm9kZVRleHRDb2xvciA9IGZ1bmN0aW9uIGNoYW5nZU5vZGVUZXh0Q29sb3IodmFsdWUpIHtcbiAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnRleHQuY29sb3IgPSB2YWx1ZTtcbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShkcmF3KTtcbiAgICB9O1xuICAgIC8v5L+u5pS56IqC54K55Lit55qE5a2X5L2T5paH5a2XXG4gICAgdmFyIGNoYW5nZU5vZGVUZXh0SW5mbyA9IGZ1bmN0aW9uIGNoYW5nZU5vZGVUZXh0SW5mbyh2YWx1ZSkge1xuICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUudGV4dC5pbmZvID0gdmFsdWU7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XG4gICAgfTtcbiAgICAvL+WIoOmZpOW9k+WJjemAieS4reiKgueCuVxuICAgIHZhciBkZWxldGVOb2RlID0gZnVuY3Rpb24gZGVsZXRlTm9kZSgpIHtcbiAgICAgIHRleHRhcmVhU2hvdy52YWx1ZSA9IGZhbHNlO1xuICAgICAgdGV4dGFyZWFWYWx1ZS52YWx1ZSA9ICcnO1xuICAgICAgdmFyIGluZGV4ID0gbm9kZUxpc3QudmFsdWUuZmluZEluZGV4KGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLmlkID09PSBhY3RpdmVOb2RlSW5mby52YWx1ZS5pZDtcbiAgICAgIH0pO1xuICAgICAgbm9kZUxpc3QudmFsdWUuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgIGlmIChhY3RpdmVOb2RlSW5mby52YWx1ZS5mcm9tTGlzdCkge1xuICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS5mcm9tTGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChtKSB7XG4gICAgICAgICAgaWYgKG0pIHtcbiAgICAgICAgICAgIGRlbGV0ZUxpbmtMaW5lKG0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAoYWN0aXZlTm9kZUluZm8udmFsdWUudGFyZ2V0TGlzdCkge1xuICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS50YXJnZXRMaXN0LmZvckVhY2goZnVuY3Rpb24gKG0pIHtcbiAgICAgICAgICBpZiAobSkge1xuICAgICAgICAgICAgZGVsZXRlTGlua0xpbmUobSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShkcmF3KTtcbiAgICB9O1xuICAgIC8v5Yig6Zmk5b2T5YmN6YCJ5Lit6L+e5o6l57q/XG4gICAgdmFyIGRlbGV0ZUxpbmUgPSBmdW5jdGlvbiBkZWxldGVMaW5lKCkge1xuICAgICAgZGVsZXRlTGlua0xpbmUoYWN0aXZlTm9kZUluZm8udmFsdWUuaWQpO1xuICAgIH07XG4gICAgLy/liKDpmaToioLngrnpmYTluKbnmoTov57mjqXnur9cbiAgICB2YXIgZGVsZXRlTGlua0xpbmUgPSBmdW5jdGlvbiBkZWxldGVMaW5rTGluZShpZCkge1xuICAgICAgdmFyIGluZGV4ID0gbm9kZUxpc3QudmFsdWUuZmluZEluZGV4KGZ1bmN0aW9uIChtKSB7XG4gICAgICAgIHJldHVybiBtLmlkID09PSBpZDtcbiAgICAgIH0pO1xuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICBub2RlTGlzdC52YWx1ZS5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgfVxuICAgICAgbm9kZUxpc3QudmFsdWUuZm9yRWFjaChmdW5jdGlvbiAobikge1xuICAgICAgICBpZiAobi5mcm9tTGlzdCkge1xuICAgICAgICAgIHZhciBmcm9tSW5kZXggPSBuLmZyb21MaXN0LmZpbmRJbmRleChmdW5jdGlvbiAoeikge1xuICAgICAgICAgICAgcmV0dXJuIHogPT09IGlkO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChmcm9tSW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICBuLmZyb21MaXN0LnNwbGljZShmcm9tSW5kZXgsIDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAobi50YXJnZXRMaXN0KSB7XG4gICAgICAgICAgdmFyIHRhcmdldEluZGV4ID0gbi50YXJnZXRMaXN0LmZpbmRJbmRleChmdW5jdGlvbiAoeikge1xuICAgICAgICAgICAgcmV0dXJuIHogPT09IGlkO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmICh0YXJnZXRJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgIG4udGFyZ2V0TGlzdC5zcGxpY2UodGFyZ2V0SW5kZXgsIDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XG4gICAgfTtcbiAgICAvL+aWh+acrOahhueEpueCuea2iOWkseaXtuS/neWtmOaWh+acrFxuICAgIHZhciBzYXZlVGV4dGFyZWFWYWx1ZSA9IGZ1bmN0aW9uIHNhdmVUZXh0YXJlYVZhbHVlKCkge1xuICAgICAgdGV4dGFyZWFTaG93LnZhbHVlID0gZmFsc2U7XG4gICAgICBjaGFuZ2VOb2RlTGlzdCh7XG4gICAgICAgIHg6IHBhcnNlSW50KHRleHRhcmVhQ2xhc3MudmFsdWUubGVmdCksXG4gICAgICAgIHk6IHBhcnNlSW50KHRleHRhcmVhQ2xhc3MudmFsdWUudG9wKSArIDUwXG4gICAgICB9KTtcbiAgICB9O1xuICAgIC8v5LiL6L29XG4gICAgdmFyIGRvd25Mb2FkID0gZnVuY3Rpb24gZG93bkxvYWQoKSB7XG4gICAgICB2YXIgZGF0YVVSTCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL3BuZycpO1xuXG4gICAgICAvLyDliJvlu7ppbWflhYPntKDvvIznlKjkuo7pooTop4jlm77niYdcbiAgICAgIHZhciBpbWcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbWcnKTtcbiAgICAgIGltZy5zcmMgPSBkYXRhVVJMO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChpbWcpO1xuXG4gICAgICAvLyDliJvlu7ph5YWD57Sg77yM55So5LqO5LiL6L295Zu+54mHXG4gICAgICB2YXIgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGxpbmsuaHJlZiA9IGRhdGFVUkw7XG4gICAgICBsaW5rLmRvd25sb2FkID0gXCJcIi5jb25jYXQoaW1hZ2VOYW1lLnZhbHVlLCBcIi5wbmdcIik7XG5cbiAgICAgIC8vIOa3u+WKoGHlhYPntKDliLBET03kuK3vvIzlubbop6blj5Hngrnlh7vkuovku7bku6XkuIvovb3lm77niYdcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICBsaW5rLmNsaWNrKCk7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGltZyk7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xuICAgIH07XG4gICAgZXhwb3NlKHtcbiAgICAgIG5vZGVMaXN0OiBub2RlTGlzdCxcbiAgICAgIGNhbnZhc0luaXQ6IGNhbnZhc0luaXRcbiAgICB9KTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgZHJhZ2dhYmxlOiBkcmFnZ2FibGUsXG4gICAgICByb3V0ZTogcm91dGUsXG4gICAgICBnZXQgbW91c2VQb3NpdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIG1vdXNlUG9zaXRpb247XG4gICAgICB9LFxuICAgICAgc2V0IG1vdXNlUG9zaXRpb24odikge1xuICAgICAgICBtb3VzZVBvc2l0aW9uID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgbGVuZ2VuZExpc3QoKSB7XG4gICAgICAgIHJldHVybiBsZW5nZW5kTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgbGVuZ2VuZExpc3Qodikge1xuICAgICAgICBsZW5nZW5kTGlzdCA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHV0aWxzTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIHV0aWxzTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgdXRpbHNMaXN0KHYpIHtcbiAgICAgICAgdXRpbHNMaXN0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgbGVnZW5kQWN0aXZlSXRlbSgpIHtcbiAgICAgICAgcmV0dXJuIGxlZ2VuZEFjdGl2ZUl0ZW07XG4gICAgICB9LFxuICAgICAgc2V0IGxlZ2VuZEFjdGl2ZUl0ZW0odikge1xuICAgICAgICBsZWdlbmRBY3RpdmVJdGVtID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgaXNNb2RlKCkge1xuICAgICAgICByZXR1cm4gaXNNb2RlO1xuICAgICAgfSxcbiAgICAgIHNldCBpc01vZGUodikge1xuICAgICAgICBpc01vZGUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjYW52YXMoKSB7XG4gICAgICAgIHJldHVybiBjYW52YXM7XG4gICAgICB9LFxuICAgICAgc2V0IGNhbnZhcyh2KSB7XG4gICAgICAgIGNhbnZhcyA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGNhbnZhc01vZGUoKSB7XG4gICAgICAgIHJldHVybiBjYW52YXNNb2RlO1xuICAgICAgfSxcbiAgICAgIHNldCBjYW52YXNNb2RlKHYpIHtcbiAgICAgICAgY2FudmFzTW9kZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IG5vZGVMaXN0KCkge1xuICAgICAgICByZXR1cm4gbm9kZUxpc3Q7XG4gICAgICB9LFxuICAgICAgc2V0IG5vZGVMaXN0KHYpIHtcbiAgICAgICAgbm9kZUxpc3QgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBhY3RpdmVOb2RlSW5mbygpIHtcbiAgICAgICAgcmV0dXJuIGFjdGl2ZU5vZGVJbmZvO1xuICAgICAgfSxcbiAgICAgIHNldCBhY3RpdmVOb2RlSW5mbyh2KSB7XG4gICAgICAgIGFjdGl2ZU5vZGVJbmZvID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgaXNMaW5rTGluZSgpIHtcbiAgICAgICAgcmV0dXJuIGlzTGlua0xpbmU7XG4gICAgICB9LFxuICAgICAgc2V0IGlzTGlua0xpbmUodikge1xuICAgICAgICBpc0xpbmtMaW5lID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgYWN0aXZlTGluZUlkKCkge1xuICAgICAgICByZXR1cm4gYWN0aXZlTGluZUlkO1xuICAgICAgfSxcbiAgICAgIHNldCBhY3RpdmVMaW5lSWQodikge1xuICAgICAgICBhY3RpdmVMaW5lSWQgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBsaW5rTGluZUZsYWcoKSB7XG4gICAgICAgIHJldHVybiBsaW5rTGluZUZsYWc7XG4gICAgICB9LFxuICAgICAgc2V0IGxpbmtMaW5lRmxhZyh2KSB7XG4gICAgICAgIGxpbmtMaW5lRmxhZyA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGxpbmtMaW5lRnJvbSgpIHtcbiAgICAgICAgcmV0dXJuIGxpbmtMaW5lRnJvbTtcbiAgICAgIH0sXG4gICAgICBzZXQgbGlua0xpbmVGcm9tKHYpIHtcbiAgICAgICAgbGlua0xpbmVGcm9tID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgbGlua0xpbmVUYXJnZXQoKSB7XG4gICAgICAgIHJldHVybiBsaW5rTGluZVRhcmdldDtcbiAgICAgIH0sXG4gICAgICBzZXQgbGlua0xpbmVUYXJnZXQodikge1xuICAgICAgICBsaW5rTGluZVRhcmdldCA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGNsaWNrTm9kZUZsYWcoKSB7XG4gICAgICAgIHJldHVybiBjbGlja05vZGVGbGFnO1xuICAgICAgfSxcbiAgICAgIHNldCBjbGlja05vZGVGbGFnKHYpIHtcbiAgICAgICAgY2xpY2tOb2RlRmxhZyA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGV2ZW50TmFtZSgpIHtcbiAgICAgICAgcmV0dXJuIGV2ZW50TmFtZTtcbiAgICAgIH0sXG4gICAgICBzZXQgZXZlbnROYW1lKHYpIHtcbiAgICAgICAgZXZlbnROYW1lID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgY2FudmFzU3R5bGVJbmZvKCkge1xuICAgICAgICByZXR1cm4gY2FudmFzU3R5bGVJbmZvO1xuICAgICAgfSxcbiAgICAgIHNldCBjYW52YXNTdHlsZUluZm8odikge1xuICAgICAgICBjYW52YXNTdHlsZUluZm8gPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBpbWFnZU5hbWUoKSB7XG4gICAgICAgIHJldHVybiBpbWFnZU5hbWU7XG4gICAgICB9LFxuICAgICAgc2V0IGltYWdlTmFtZSh2KSB7XG4gICAgICAgIGltYWdlTmFtZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHRleHRhcmVhVmFsdWUoKSB7XG4gICAgICAgIHJldHVybiB0ZXh0YXJlYVZhbHVlO1xuICAgICAgfSxcbiAgICAgIHNldCB0ZXh0YXJlYVZhbHVlKHYpIHtcbiAgICAgICAgdGV4dGFyZWFWYWx1ZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHRleHRhcmVhU2hvdygpIHtcbiAgICAgICAgcmV0dXJuIHRleHRhcmVhU2hvdztcbiAgICAgIH0sXG4gICAgICBzZXQgdGV4dGFyZWFTaG93KHYpIHtcbiAgICAgICAgdGV4dGFyZWFTaG93ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgdGV4dGFyZWFDbGFzcygpIHtcbiAgICAgICAgcmV0dXJuIHRleHRhcmVhQ2xhc3M7XG4gICAgICB9LFxuICAgICAgc2V0IHRleHRhcmVhQ2xhc3Modikge1xuICAgICAgICB0ZXh0YXJlYUNsYXNzID0gdjtcbiAgICAgIH0sXG4gICAgICBkcmFnT3B0aW9uczogZHJhZ09wdGlvbnMsXG4gICAgICBnZXQgbGVuZ2VuZENsYXNzKCkge1xuICAgICAgICByZXR1cm4gbGVuZ2VuZENsYXNzO1xuICAgICAgfSxcbiAgICAgIHNldCBsZW5nZW5kQ2xhc3Modikge1xuICAgICAgICBsZW5nZW5kQ2xhc3MgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjbGlja0xlbmdlbmQoKSB7XG4gICAgICAgIHJldHVybiBjbGlja0xlbmdlbmQ7XG4gICAgICB9LFxuICAgICAgc2V0IGNsaWNrTGVuZ2VuZCh2KSB7XG4gICAgICAgIGNsaWNrTGVuZ2VuZCA9IHY7XG4gICAgICB9LFxuICAgICAgbW92ZVN0YXJ0OiBtb3ZlU3RhcnQsXG4gICAgICBtb3ZlRW5kOiBtb3ZlRW5kLFxuICAgICAgY2xpY2tDYW52YXM6IGNsaWNrQ2FudmFzLFxuICAgICAgY2FudmFzRG93bjogY2FudmFzRG93bixcbiAgICAgIGNhbnZhc1VwOiBjYW52YXNVcCxcbiAgICAgIGNhbnZhc01vdmU6IGNhbnZhc01vdmUsXG4gICAgICBjYW52YXNMZWF2ZTogY2FudmFzTGVhdmUsXG4gICAgICBtb3ZlTGluZUluZm86IG1vdmVMaW5lSW5mbyxcbiAgICAgIGdldCBjYW52YXNJbml0KCkge1xuICAgICAgICByZXR1cm4gY2FudmFzSW5pdDtcbiAgICAgIH0sXG4gICAgICBzZXQgY2FudmFzSW5pdCh2KSB7XG4gICAgICAgIGNhbnZhc0luaXQgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjcmVhdGVMaW5rVGFyZ2V0KCkge1xuICAgICAgICByZXR1cm4gY3JlYXRlTGlua1RhcmdldDtcbiAgICAgIH0sXG4gICAgICBzZXQgY3JlYXRlTGlua1RhcmdldCh2KSB7XG4gICAgICAgIGNyZWF0ZUxpbmtUYXJnZXQgPSB2O1xuICAgICAgfSxcbiAgICAgIGRyYXc6IGRyYXcsXG4gICAgICBjaGFuZ2VOb2RlTGlzdDogY2hhbmdlTm9kZUxpc3QsXG4gICAgICBjaGFuZ2VTY2FsZTogY2hhbmdlU2NhbGUsXG4gICAgICBjaGFuZ2VOb2RlVGhlbWVDb2xvcjogY2hhbmdlTm9kZVRoZW1lQ29sb3IsXG4gICAgICBjaGFuZ2VOb2RlVGV4dENvbG9yOiBjaGFuZ2VOb2RlVGV4dENvbG9yLFxuICAgICAgY2hhbmdlTm9kZVRleHRJbmZvOiBjaGFuZ2VOb2RlVGV4dEluZm8sXG4gICAgICBkZWxldGVOb2RlOiBkZWxldGVOb2RlLFxuICAgICAgZGVsZXRlTGluZTogZGVsZXRlTGluZSxcbiAgICAgIGRlbGV0ZUxpbmtMaW5lOiBkZWxldGVMaW5rTGluZSxcbiAgICAgIHNhdmVUZXh0YXJlYVZhbHVlOiBzYXZlVGV4dGFyZWFWYWx1ZSxcbiAgICAgIGRvd25Mb2FkOiBkb3duTG9hZCxcbiAgICAgIGdldCBhbGxDb25maWcoKSB7XG4gICAgICAgIHJldHVybiBhbGxDb25maWc7XG4gICAgICB9LFxuICAgICAgZ2V0IFZ1ZURyYWdnYWJsZU5leHQoKSB7XG4gICAgICAgIHJldHVybiBWdWVEcmFnZ2FibGVOZXh0O1xuICAgICAgfSxcbiAgICAgIGdldCBFbE1lc3NhZ2UoKSB7XG4gICAgICAgIHJldHVybiBFbE1lc3NhZ2U7XG4gICAgICB9LFxuICAgICAgZ2V0IHV1aWR2NCgpIHtcbiAgICAgICAgcmV0dXJuIHV1aWR2NDtcbiAgICAgIH0sXG4gICAgICBnZXQgY3JlYXRlUmVjdEZpbGwoKSB7XG4gICAgICAgIHJldHVybiBjcmVhdGVSZWN0RmlsbDtcbiAgICAgIH0sXG4gICAgICBnZXQgY3JlYXRlVHJlZUJveCgpIHtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRyZWVCb3g7XG4gICAgICB9LFxuICAgICAgZ2V0IGNyZWF0ZVJlY3RTdHJva2UoKSB7XG4gICAgICAgIHJldHVybiBjcmVhdGVSZWN0U3Ryb2tlO1xuICAgICAgfSxcbiAgICAgIGdldCBjcmVhdGVBcmNTdHJva2UoKSB7XG4gICAgICAgIHJldHVybiBjcmVhdGVBcmNTdHJva2U7XG4gICAgICB9LFxuICAgICAgZ2V0IGNyZWF0ZUxpbmtMaW5lKCkge1xuICAgICAgICByZXR1cm4gY3JlYXRlTGlua0xpbmU7XG4gICAgICB9LFxuICAgICAgZ2V0IGNyZWF0ZVRleHQoKSB7XG4gICAgICAgIHJldHVybiBjcmVhdGVUZXh0O1xuICAgICAgfVxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsImltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcbmltcG9ydCB7IHVzZVJvdXRlciwgdXNlUm91dGUgfSBmcm9tIFwidnVlLXJvdXRlclwiO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSBcIkAvdXRpbHMvcmVxdWVzdFV0aWxzXCI7XG5pbXBvcnQgeyBuZXh0VGljaywgb25Nb3VudGVkLCByZWFjdGl2ZSB9IGZyb20gXCJ2dWVcIjtcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcbmltcG9ydCBHbG9iYWxGbG93IGZyb20gXCJAL2NvbXBvbmVudHMvZ2xvYmFsRmxvdy52dWVcIjtcbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAnZ2xvYmFsRm9ybUluZm8nLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICBleHBvc2UoKTtcbiAgICB2YXIgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gICAgdmFyIHJvdXRlID0gdXNlUm91dGUoKTtcbiAgICB2YXIgdGVtcGxhdGVMaXN0ID0gcmVmKFtdKTtcbiAgICB2YXIgZm9ybURhdGEgPSByZWFjdGl2ZSh7fSk7XG4gICAgdmFyIHJ1bGVzID0gcmVhY3RpdmUoe30pO1xuICAgIHZhciBmaWxlTGlzdCA9IHJlZihbXSk7XG4gICAgdmFyIHJ1bGVGb3JtUmVmID0gcmVmKG51bGwpO1xuICAgIHZhciBkaWFsb2dGbG93Q2hhcnQgPSByZWYoZmFsc2UpO1xuICAgIHZhciBnbG9iYWxGbG93ID0gcmVmKG51bGwpO1xuICAgIHZhciByZXFUZW1wbGF0ZSA9IGZ1bmN0aW9uIHJlcVRlbXBsYXRlKCkge1xuICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvcHVibGljRm9ybS90ZW1wbGF0ZVwiKSwge1xuICAgICAgICB0eXBlOiByb3V0ZS5xdWVyeS5tb2RlXG4gICAgICB9KS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICB0ZW1wbGF0ZUxpc3QudmFsdWUgPSByZXMuZGF0YTtcbiAgICAgICAgICAvL+e7hOe7h+aVsOaNrlxuICAgICAgICAgIHRlbXBsYXRlTGlzdC52YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICBpdGVtLmZvcm1MaXN0LmZvckVhY2goZnVuY3Rpb24gKHZhbCkge1xuICAgICAgICAgICAgICBpZiAodmFsLm9wdGlvbnNTb3VyY2UgJiYgdmFsLm9wdGlvbnNTb3VyY2UgPT09IFwicmVxdWVzdFwiKSB7XG4gICAgICAgICAgICAgICAgcmVxdWVzdE9QdGlvbnModmFsKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAvL+ihqOWNleaVsOaNruaxh+aAu1xuICAgICAgICAgICAgICBmb3JtRGF0YVt2YWwubmFtZV0gPSB2YWxbXCJkZWZhdWx0XCJdO1xuICAgICAgICAgICAgICBpZiAodmFsLnJ1bGUpIHtcbiAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSB2YWwucnVsZS5maW5kSW5kZXgoZnVuY3Rpb24gKHopIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB6LnBhdHRlcm47XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgLy/ljLnphY3mraPliJlcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICB2YWwucnVsZVtpbmRleF0ucGF0dGVybiA9IG5ldyBSZWdFeHAodmFsLnJ1bGVbaW5kZXhdLnBhdHRlcm4pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvL+ihqOWNleadg+mZkOaxh+aAu1xuICAgICAgICAgICAgICAgIHJ1bGVzW3ZhbC5uYW1lXSA9IHZhbC5ydWxlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhyb3V0ZS5xdWVyeS51dWlkLCBcInV1aWTnmoTlgLxcIik7XG4gICAgICAgICAgaWYgKHJvdXRlLnF1ZXJ5LnR5cGUgIT09IFwibmV3XCIpIHtcbiAgICAgICAgICAgIHJlcUZvcm1EYXRhKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIEVsTWVzc2FnZSh7XG4gICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcbiAgICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIHJlcUZvcm1EYXRhID0gZnVuY3Rpb24gcmVxRm9ybURhdGEoKSB7XG4gICAgICB2YXIgcXVlcnkgPSB7XG4gICAgICAgIHV1aWQ6IHJvdXRlLnF1ZXJ5LnV1aWQsXG4gICAgICAgIG1vZGU6IHJvdXRlLnF1ZXJ5Lm1vZGVcbiAgICAgIH07XG4gICAgICByZXF1ZXN0LnBvc3QoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcC9wdWJsaWNBcGkvZGV0YWlsXCIpLCBxdWVyeSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgZm9yICh2YXIgdmFsIGluIHJlcy5kYXRhKSB7XG4gICAgICAgICAgICBmb3JtRGF0YVt2YWxdID0gcmVzLmRhdGFbdmFsXTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIHNldERpc2FibGVEYXRlID0gZnVuY3Rpb24gc2V0RGlzYWJsZURhdGUodGltZSkge1xuICAgICAgcmV0dXJuIHRpbWUuZ2V0VGltZSgpIDwgRGF0ZS5ub3coKTtcbiAgICB9O1xuICAgIHZhciByZXF1ZXN0T1B0aW9ucyA9IGZ1bmN0aW9uIHJlcXVlc3RPUHRpb25zKGl0ZW0pIHtcbiAgICAgIGlmIChpdGVtLnJlcXVlc3RNZXRob2QgPT09IFwiZ2V0XCIpIHtcbiAgICAgICAgcmVxdWVzdC5nZXQoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcFwiKS5jb25jYXQoaXRlbS5yZXF1ZXN0TmFtZSkpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgICBpdGVtLm9wdGlvbnMgPSByZXMuZGF0YTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgbWVzc2FnZTogcmVzLm1lc3NhZ2UsXG4gICAgICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coaXRlbSwgXCI/Pz8tLS3mjqLntKJcIik7XG4gICAgICAgIHJlcXVlc3QucG9zdChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwXCIpLmNvbmNhdChpdGVtLnJlcXVlc3ROYW1lKSwgaXRlbS5xdWVyeSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICAgIHJlcy5kYXRhLmZvckVhY2goZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2codik7XG4gICAgICAgICAgICAgIGl0ZW0ub3B0aW9ucy5wdXNoKHtcbiAgICAgICAgICAgICAgICBsYWJlbDogdltcIlwiLmNvbmNhdChpdGVtLnF1ZXJ5W1wibW9kZVwiXSwgXCJDbk5hbWVcIildLFxuICAgICAgICAgICAgICAgIHZhbHVlOiB2LnV1aWRcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgbWVzc2FnZTogcmVzLm1lc3NhZ2UsXG4gICAgICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG4gICAgdmFyIHJlcXVlc3RGaWxlID0gZnVuY3Rpb24gcmVxdWVzdEZpbGUoYSwgYikge1xuICAgICAgY29uc29sZS5sb2coYSwgYiwgXCLoh6rkuIrkvKDmlofku7ZcIik7XG4gICAgICBmb3JtRGF0YVtcInVwbG9hZFwiXSA9IFwieW91dHViZS5jb21cIjtcbiAgICB9O1xuICAgIHZhciBhZGQgPSBmdW5jdGlvbiBhZGQocnVsZUZvcm1SZWYpIHtcbiAgICAgIGZvcm1EYXRhLm1vZGUgPSByb3V0ZS5xdWVyeS5tb2RlO1xuICAgICAgaWYgKCFydWxlRm9ybVJlZikgcmV0dXJuO1xuICAgICAgcnVsZUZvcm1SZWYudmFsaWRhdGUoZnVuY3Rpb24gKHZhbGlkLCBmaWVsZHMpIHtcbiAgICAgICAgaWYgKHZhbGlkKSB7XG4gICAgICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvcHVibGljQXBpL2FkZFwiKSwgZm9ybURhdGEpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcbiAgICAgICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIlxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAganVtcFRvTGlzdCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcbiAgICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIlxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHt9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBlZGl0ID0gZnVuY3Rpb24gZWRpdChydWxlRm9ybVJlZikge1xuICAgICAgZm9ybURhdGEubW9kZSA9IHJvdXRlLnF1ZXJ5Lm1vZGU7XG4gICAgICBpZiAoIXJ1bGVGb3JtUmVmKSByZXR1cm47XG4gICAgICBydWxlRm9ybVJlZi52YWxpZGF0ZShmdW5jdGlvbiAodmFsaWQsIGZpZWxkcykge1xuICAgICAgICBpZiAodmFsaWQpIHtcbiAgICAgICAgICByZXF1ZXN0LnBvc3QoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcC9wdWJsaWNBcGkvZWRpdFwiKSwgZm9ybURhdGEpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcbiAgICAgICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIlxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAganVtcFRvTGlzdCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcbiAgICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIlxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHt9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBqdW1wVG9MaXN0ID0gZnVuY3Rpb24ganVtcFRvTGlzdCgpIHtcbiAgICAgIHZhciBsaXN0ID0gcm91dGUucGF0aC5zcGxpdChcIi9cIik7XG4gICAgICBsaXN0LnBvcCgpO1xuICAgICAgbGlzdC5wdXNoKFwiXCIuY29uY2F0KGxpc3RbbGlzdC5sZW5ndGggLSAxXSwgXCJMaXN0XCIpKTtcbiAgICAgIHZhciBwYXRoID0gbGlzdC5qb2luKFwiL1wiKTtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgcGF0aDogcGF0aFxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgZGlzYWJsZWRGdW4gPSBmdW5jdGlvbiBkaXNhYmxlZEZ1bihmbGFnKSB7XG4gICAgICBpZiAocm91dGUucXVlcnkudHlwZSA9PT0gXCJkZXRhaWxcIiB8fCByb3V0ZS5xdWVyeS50eXBlICE9PSBcIm5ld1wiICYmIGZsYWcgPT09IHRydWUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfTtcbiAgICB2YXIgb3BlbkZsb3dDaGFydCA9IGZ1bmN0aW9uIG9wZW5GbG93Q2hhcnQoKSB7XG4gICAgICBkaWFsb2dGbG93Q2hhcnQudmFsdWUgPSB0cnVlO1xuICAgICAgY29uc29sZS5sb2coZ2xvYmFsRmxvdywgXCLnu4Tku7ZcIik7XG4gICAgICBuZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgIGdsb2JhbEZsb3cudmFsdWUuY2FudmFzSW5pdChmb3JtRGF0YS5mbG93Q2hhcnQpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgaGFuZGxlQ2xvc2UgPSBmdW5jdGlvbiBoYW5kbGVDbG9zZSgpIHtcbiAgICAgIGRpYWxvZ0Zsb3dDaGFydC52YWx1ZSA9IGZhbHNlO1xuICAgIH07XG4gICAgdmFyIHNhdmVFbnRpcnlDYW52YXMgPSBmdW5jdGlvbiBzYXZlRW50aXJ5Q2FudmFzKCkge1xuICAgICAgZm9ybURhdGEuZmxvd0NoYXJ0ID0gZ2xvYmFsRmxvdy52YWx1ZS5ub2RlTGlzdDtcbiAgICAgIGRpYWxvZ0Zsb3dDaGFydC52YWx1ZSA9IGZhbHNlO1xuICAgIH07XG4gICAgb25Nb3VudGVkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHJlcVRlbXBsYXRlKCk7XG4gICAgfSk7XG4gICAgdmFyIF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIHJvdXRlcjogcm91dGVyLFxuICAgICAgcm91dGU6IHJvdXRlLFxuICAgICAgZ2V0IHRlbXBsYXRlTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIHRlbXBsYXRlTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgdGVtcGxhdGVMaXN0KHYpIHtcbiAgICAgICAgdGVtcGxhdGVMaXN0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgZm9ybURhdGEoKSB7XG4gICAgICAgIHJldHVybiBmb3JtRGF0YTtcbiAgICAgIH0sXG4gICAgICBzZXQgZm9ybURhdGEodikge1xuICAgICAgICBmb3JtRGF0YSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJ1bGVzKCkge1xuICAgICAgICByZXR1cm4gcnVsZXM7XG4gICAgICB9LFxuICAgICAgc2V0IHJ1bGVzKHYpIHtcbiAgICAgICAgcnVsZXMgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBmaWxlTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIGZpbGVMaXN0O1xuICAgICAgfSxcbiAgICAgIHNldCBmaWxlTGlzdCh2KSB7XG4gICAgICAgIGZpbGVMaXN0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgcnVsZUZvcm1SZWYoKSB7XG4gICAgICAgIHJldHVybiBydWxlRm9ybVJlZjtcbiAgICAgIH0sXG4gICAgICBzZXQgcnVsZUZvcm1SZWYodikge1xuICAgICAgICBydWxlRm9ybVJlZiA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGRpYWxvZ0Zsb3dDaGFydCgpIHtcbiAgICAgICAgcmV0dXJuIGRpYWxvZ0Zsb3dDaGFydDtcbiAgICAgIH0sXG4gICAgICBzZXQgZGlhbG9nRmxvd0NoYXJ0KHYpIHtcbiAgICAgICAgZGlhbG9nRmxvd0NoYXJ0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgZ2xvYmFsRmxvdygpIHtcbiAgICAgICAgcmV0dXJuIGdsb2JhbEZsb3c7XG4gICAgICB9LFxuICAgICAgc2V0IGdsb2JhbEZsb3codikge1xuICAgICAgICBnbG9iYWxGbG93ID0gdjtcbiAgICAgIH0sXG4gICAgICByZXFUZW1wbGF0ZTogcmVxVGVtcGxhdGUsXG4gICAgICByZXFGb3JtRGF0YTogcmVxRm9ybURhdGEsXG4gICAgICBzZXREaXNhYmxlRGF0ZTogc2V0RGlzYWJsZURhdGUsXG4gICAgICByZXF1ZXN0T1B0aW9uczogcmVxdWVzdE9QdGlvbnMsXG4gICAgICByZXF1ZXN0RmlsZTogcmVxdWVzdEZpbGUsXG4gICAgICBhZGQ6IGFkZCxcbiAgICAgIGVkaXQ6IGVkaXQsXG4gICAgICBqdW1wVG9MaXN0OiBqdW1wVG9MaXN0LFxuICAgICAgZGlzYWJsZWRGdW46IGRpc2FibGVkRnVuLFxuICAgICAgb3BlbkZsb3dDaGFydDogb3BlbkZsb3dDaGFydCxcbiAgICAgIGhhbmRsZUNsb3NlOiBoYW5kbGVDbG9zZSxcbiAgICAgIHNhdmVFbnRpcnlDYW52YXM6IHNhdmVFbnRpcnlDYW52YXMsXG4gICAgICBnZXQgZW52bmFtZSgpIHtcbiAgICAgICAgcmV0dXJuIGVudm5hbWU7XG4gICAgICB9LFxuICAgICAgZ2V0IHVzZVJvdXRlcigpIHtcbiAgICAgICAgcmV0dXJuIHVzZVJvdXRlcjtcbiAgICAgIH0sXG4gICAgICBnZXQgdXNlUm91dGUoKSB7XG4gICAgICAgIHJldHVybiB1c2VSb3V0ZTtcbiAgICAgIH0sXG4gICAgICBnZXQgcmVxdWVzdCgpIHtcbiAgICAgICAgcmV0dXJuIHJlcXVlc3Q7XG4gICAgICB9LFxuICAgICAgbmV4dFRpY2s6IG5leHRUaWNrLFxuICAgICAgb25Nb3VudGVkOiBvbk1vdW50ZWQsXG4gICAgICByZWFjdGl2ZTogcmVhY3RpdmUsXG4gICAgICBnZXQgRWxNZXNzYWdlKCkge1xuICAgICAgICByZXR1cm4gRWxNZXNzYWdlO1xuICAgICAgfSxcbiAgICAgIEdsb2JhbEZsb3c6IEdsb2JhbEZsb3dcbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImZsb3dCb3hcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJsZWdlbmRcIj5cclxuICAgICAgPGg0PuWbvuS+izwvaDQ+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmRCb3hcIiBpZD1cImxlZ2VuZEJveFwiPlxyXG4gICAgICAgIDxlbC1yb3c+XHJcbiAgICAgICAgICA8ZHJhZ2dhYmxlXHJcbiAgICAgICAgICAgIEBzdGFydD1cIm1vdmVTdGFydFwiXHJcbiAgICAgICAgICAgIEBlbmQ9XCJtb3ZlRW5kXCJcclxuICAgICAgICAgICAgdi1tb2RlbD1cImxlbmdlbmRMaXN0XCJcclxuICAgICAgICAgICAgOm9wdGlvbnM9XCJkcmFnT3B0aW9uc1wiXHJcbiAgICAgICAgICAgIHN0eWxlPVwiZGlzcGxheTogY29udGVudHNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZWwtY29sXHJcbiAgICAgICAgICAgICAgOnNwYW49XCIxMlwiXHJcbiAgICAgICAgICAgICAgdi1mb3I9XCIobGVnZW5kSXRlbSwgbGVuZ2VuZEluZGV4KSBpbiBsZW5nZW5kTGlzdFwiXHJcbiAgICAgICAgICAgICAgOmtleT1cImxlbmdlbmRJbmRleFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICA6Y2xhc3M9XCJsZW5nZW5kQ2xhc3MobGVnZW5kSXRlbS5uYW1lKVwiXHJcbiAgICAgICAgICAgICAgICA6bm9kZV90eXBlPVwibGVnZW5kSXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgICAgIEBtb3VzZWRvd249XCJjbGlja0xlbmdlbmQobGVnZW5kSXRlbS5uYW1lKVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICA6c3JjPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZShgQC9hc3NldHMvZmxvd2NoYXJ0U3ZnLyR7bGVnZW5kSXRlbS5zdmdOYW1lfS5zdmdgKVxyXG4gICAgICAgICAgICAgICAgICBcIlxyXG4gICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPnt7IGxlZ2VuZEl0ZW0udGl0bGUgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPC9kcmFnZ2FibGU+XHJcbiAgICAgICAgPC9lbC1yb3c+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8aDQ+5bel5YW3PC9oND5cclxuICAgICAgPGVsLXJvdz5cclxuICAgICAgICA8ZWwtY29sXHJcbiAgICAgICAgICA6c3Bhbj1cIjEyXCJcclxuICAgICAgICAgIHYtZm9yPVwiKHV0aWxOYW1lLCBsZW5nZW5kSW5kZXgpIGluIHV0aWxzTGlzdFwiXHJcbiAgICAgICAgICA6a2V5PVwibGVuZ2VuZEluZGV4XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIDpjbGFzcz1cImxlbmdlbmRDbGFzcyh1dGlsTmFtZS5uYW1lKVwiXHJcbiAgICAgICAgICAgIDpub2RlX3R5cGU9XCJ1dGlsTmFtZS5uYW1lXCJcclxuICAgICAgICAgICAgQG1vdXNlZG93bj1cImNsaWNrTGVuZ2VuZCh1dGlsTmFtZS5uYW1lKVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICA6c3JjPVwicmVxdWlyZShgQC9hc3NldHMvZmxvd2NoYXJ0U3ZnLyR7dXRpbE5hbWUuc3ZnTmFtZX0uc3ZnYClcIlxyXG4gICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPnt7IHV0aWxOYW1lLnRpdGxlIH19PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgIDwvZWwtcm93PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IDpjbGFzcz1cIiFpc01vZGUgPyAnY2hhcnROb3JtYWwnIDogJ2NoYXJ0TW9kZSdcIj5cclxuICAgICAgPGNhbnZhc1xyXG4gICAgICAgIHdpZHRoPVwiMTUwMFwiXHJcbiAgICAgICAgaGVpZ2h0PVwiODAwXCJcclxuICAgICAgICBpZD1cImNhbnZhc1wiXHJcbiAgICAgICAgQG1vdXNlZG93bj1cImNhbnZhc0Rvd25cIlxyXG4gICAgICAgIEBtb3VzZXVwPVwiY2FudmFzVXBcIlxyXG4gICAgICAgIEBtb3VzZW1vdmU9XCJjYW52YXNNb3ZlXCJcclxuICAgICAgICBAY2xpY2s9XCJjbGlja0NhbnZhc1wiXHJcbiAgICAgICAgOnN0eWxlPVwieyBiYWNrZ3JvdW5kOiBjYW52YXNTdHlsZUluZm8uYmFja2dyb3VuZCB9XCJcclxuICAgICAgPjwvY2FudmFzPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2V0dGluZ1wiPlxyXG4gICAgICA8aDQ+55S75biD5L+h5oGvPC9oND5cclxuICAgICAgPHA+55S75biD6IOM5pmv6ImyOjwvcD5cclxuICAgICAgPGVsLWNvbG9yLXBpY2tlciB2LW1vZGVsPVwiY2FudmFzU3R5bGVJbmZvLmJhY2tncm91bmRcIiA6ZGlzYWJsZWQ9XCJyb3V0ZS5xdWVyeS50eXBlID09PSAnZGV0YWlsJ1wiLz5cclxuICAgICAgPHA+55S75biD5LiL6L29PC9wPlxyXG4gICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleFwiPlxyXG4gICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgdi1tb2RlbD1cImltYWdlTmFtZVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeWbvueJh+WQjeensFwiXHJcbiAgICAgICAgICBzdHlsZT1cIndpZHRoOiAxNDBweFwiXHJcbiAgICAgICAgPjwvZWwtaW5wdXQ+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIHN0eWxlPVwid2lkdGg6IDMwcHhcIiBAY2xpY2s9XCJkb3duTG9hZFwiPuS4i+i9vTwvZWwtYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwhLS0gPHA+55S75biD57yp5pS+5q+U5L6LOjwvcD5cclxuICAgICAgPGVsLXNsaWRlciB2LW1vZGVsPVwiY2FudmFzU3R5bGVJbmZvLnNjYWxlXCIgOnNob3ctdG9vbHRpcD1cImZhbHNlXCIgOm1pbj1cIjBcIiA6bWF4PVwiMlwiIDpzdGVwPVwiMC4xXCIgc3R5bGU9XCJ3aWR0aDogMTgwcHg7XCIgQGlucHV0PVwiY2hhbmdlU2NhbGVcIi8+IC0tPlxyXG4gICAgICA8dGVtcGxhdGUgdi1pZj1cImFjdGl2ZU5vZGVJbmZvLmlkICYmIG5vZGVMaXN0Lmxlbmd0aD4wXCI+XHJcbiAgICAgICAgPGg0PuiKgueCueS/oeaBrzwvaDQ+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxwPuiKgueCueS4u+mimOminOiJsjwvcD5cclxuICAgICAgICAgIDxlbC1jb2xvci1waWNrZXJcclxuICAgICAgICAgIDpkaXNhYmxlZD1cInJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnXCJcclxuICAgICAgICAgICAgdi1tb2RlbD1cImFjdGl2ZU5vZGVJbmZvLmNvbG9yXCJcclxuICAgICAgICAgICAgQGFjdGl2ZS1jaGFuZ2U9XCJjaGFuZ2VOb2RlVGhlbWVDb2xvclwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgdi1pZj1cImFjdGl2ZU5vZGVJbmZvLm1vZGVUeXBlICE9PSAnbGlua0xpbmUnICYmIGFjdGl2ZU5vZGVJbmZvLm1vZGVUeXBlICE9PSAndGV4dCdcIj5cclxuICAgICAgICAgIDxwPuiKgueCueWtl+S9k+minOiJsjwvcD5cclxuICAgICAgICAgIDxlbC1jb2xvci1waWNrZXJcclxuICAgICAgICAgIDpkaXNhYmxlZD1cInJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnXCJcclxuICAgICAgICAgICAgdi1tb2RlbD1cImFjdGl2ZU5vZGVJbmZvLnRleHQuY29sb3JcIlxyXG4gICAgICAgICAgICBAYWN0aXZlLWNoYW5nZT1cImNoYW5nZU5vZGVUZXh0Q29sb3JcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IHYtaWY9XCJhY3RpdmVOb2RlSW5mby5tb2RlVHlwZSAhPT0gJ2xpbmtMaW5lJyAmJiBhY3RpdmVOb2RlSW5mby5tb2RlVHlwZSAhPT0gJ3RleHQnXCI+XHJcbiAgICAgICAgICA8cD7oioLngrnmloflrZfkv6Hmga88L3A+XHJcbiAgICAgICAgICA8ZWwtaW5wdXRcclxuICAgICAgICAgIDpkaXNhYmxlZD1cInJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnXCJcclxuICAgICAgICAgICAgdi1tb2RlbD1cImFjdGl2ZU5vZGVJbmZvLnRleHQuaW5mb1wiXHJcbiAgICAgICAgICAgIHN0eWxlPVwiMTgwcHhcIlxyXG4gICAgICAgICAgICBAaW5wdXQ9XCJjaGFuZ2VOb2RlVGV4dEluZm9cIlxyXG4gICAgICAgICAgPjwvZWwtaW5wdXQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiB2LWlmPVwiYWN0aXZlTm9kZUluZm8ubW9kZVR5cGUgPT09ICdsaW5rTGluZSdcIj5cclxuICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiBAY2xpY2s9XCJkZWxldGVMaW5lXCIgOmRpc2FibGVkPVwicm91dGUucXVlcnkudHlwZSA9PT0gJ2RldGFpbCdcIj7liKDpmaTov57nur88L2VsLWJ1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IHYtaWY9XCJhY3RpdmVOb2RlSW5mby5tb2RlVHlwZSAhPT0gJ2xpbmtMaW5lJ1wiPlxyXG4gICAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cImRlbGV0ZU5vZGVcIiA6ZGlzYWJsZWQ9XCJyb3V0ZS5xdWVyeS50eXBlID09PSAnZGV0YWlsJ1wiPuWIoOmZpOiKgueCuTwvZWwtYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3RlbXBsYXRlPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZWwtaW5wdXRcclxuICAgIDpkaXNhYmxlZD1cInJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnXCJcclxuICAgIEBibHVyPVwic2F2ZVRleHRhcmVhVmFsdWVcIlxyXG4gICAgdi1zaG93PVwidGV4dGFyZWFTaG93XCJcclxuICAgIDpzdHlsZT1cInRleHRhcmVhQ2xhc3NcIlxyXG4gICAgdi1tb2RlbD1cInRleHRhcmVhVmFsdWVcIlxyXG4gICAgbWF4bGVuZ3RoPVwiMzBcIlxyXG4gICAgc2hvdy13b3JkLWxpbWl0XHJcbiAgICB0eXBlPVwidGV4dGFyZWFcIlxyXG4gICAgOnJvd3M9XCJ0ZXh0YXJlYUNsYXNzLnJvd3NcIlxyXG4gIC8+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCBhbGxDb25maWcgZnJvbSBcIi4uL2phdmFzY3JpcHQvZmxvd2NoYXJ0Q29uZmlnXCI7XHJcbmltcG9ydCB7IFZ1ZURyYWdnYWJsZU5leHQgfSBmcm9tIFwidnVlLWRyYWdnYWJsZS1uZXh0XCI7XHJcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcclxuaW1wb3J0IHsgdjQgYXMgdXVpZHY0IH0gZnJvbSBcInV1aWRcIjtcclxuaW1wb3J0IHtcclxuICBjcmVhdGVSZWN0RmlsbCxcclxuICBjcmVhdGVUcmVlQm94LFxyXG4gIGNyZWF0ZVJlY3RTdHJva2UsXHJcbiAgY3JlYXRlQXJjU3Ryb2tlLFxyXG4gIGNyZWF0ZUxpbmtMaW5lLFxyXG4gIGNyZWF0ZVRleHRcclxufSBmcm9tIFwiQC9qYXZhc2NyaXB0L2dsb2JhbEZsb3dGdW4uanNcIjtcclxuY29uc3QgZHJhZ2dhYmxlID0gVnVlRHJhZ2dhYmxlTmV4dDsgLy/mi5bmi73nu4Tku7ZcclxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpXHJcbmxldCBtb3VzZVBvc2l0aW9uID0gcmVmKHt9KSAvL1xyXG5sZXQgbGVuZ2VuZExpc3QgPSByZWFjdGl2ZShhbGxDb25maWcubGVuZ2VuZExpc3QpOyAvL+WbvuS+i+mbhuWQiFxyXG5sZXQgdXRpbHNMaXN0ID0gcmVhY3RpdmUoYWxsQ29uZmlnLnV0aWxzTGlzdCk7IC8v5bel5YW36ZuG5ZCIXHJcbmxldCBsZWdlbmRBY3RpdmVJdGVtID0gcmVmKFwiXCIpOyAvL+W9k+WJjemAieS4reWbvuS+i1xyXG5sZXQgaXNNb2RlID0gcmVmKGZhbHNlKTsgLy/mmK/lkKbkuLrmqKHlnZdcclxubGV0IGNhbnZhcyA9IG51bGw7IC8v55S75biDXHJcbmxldCBjYW52YXNNb2RlID0gbnVsbDsgLy/nlLvluIPlrp7kvotcclxubGV0IG5vZGVMaXN0ID0gcmVmKFtdKTsgLy/nlLvluIPlhoXlrrnmlbDnu4RcclxubGV0IGFjdGl2ZU5vZGVJbmZvID0gcmVmKHt9KTsgLy/mtLvliqjnmoTnu4Tku7bkv6Hmga9cclxubGV0IGlzTGlua0xpbmUgPSByZWYoZmFsc2UpOyAvL+aYr+WQpuS4uui/nue6v+eKtuaAgVxyXG5sZXQgYWN0aXZlTGluZUlkID0gcmVmKHVuZGVmaW5lZCk7IC8v5b2T5YmN6L+e57q/55qEaWRcclxubGV0IGxpbmtMaW5lRmxhZyA9IHJlZihmYWxzZSk7IC8v6L+e57q/5qCH5b+XXHJcbmxldCBsaW5rTGluZUZyb20gPSByZWYodW5kZWZpbmVkKTsgLy/nur/mnaHotbfngrlcclxubGV0IGxpbmtMaW5lVGFyZ2V0ID0gcmVmKHVuZGVmaW5lZCk7IC8v57q/5p2h57uI54K5XHJcbmxldCBjbGlja05vZGVGbGFnID0gcmVmKGZhbHNlKTsgLy/mmK/lkKbngrnlh7voioLngrlcclxubGV0IGV2ZW50TmFtZSA9IHJlZih1bmRlZmluZWQpOyAvL+W9k+WJjeWkhOS6juS7gOS5iOS6i+S7tlxyXG5sZXQgY2FudmFzU3R5bGVJbmZvID0gcmVmKHtcclxuICBiYWNrZ3JvdW5kOiBcIiNmZmZcIixcclxuICBzY2FsZTogMSxcclxufSk7XHJcbmxldCBpbWFnZU5hbWUgPSByZWYoXCLnlLvluINcIik7XHJcbmxldCB0ZXh0YXJlYVZhbHVlID0gcmVmKCcnKVxyXG5sZXQgdGV4dGFyZWFTaG93ID0gcmVmKGZhbHNlKVxyXG5sZXQgdGV4dGFyZWFDbGFzcyA9IHJlZih7XHJcbiAgcG9zaXRpb246J2Fic29sdXRlJyxcclxuICBsZWZ0OiczMDBweCcsXHJcbiAgdG9wOiczMDBweCcsXHJcbiAgaW5kZXg6MTAwMCxcclxuICB3aWR0aDonMzAwcHgnLFxyXG4gIGJvcmRlcjonMXB4IGRhc2hlZCAjMjNjZjdkJyxcclxuICBvdXRsaW5lOidub25lJyxcclxuICByb3dzOjVcclxufSlcclxuLy/mi5bmi73phY3nva5cclxuY29uc3QgZHJhZ09wdGlvbnMgPSB7XHJcbiAgcHJldmVudE9uRmlsdGVyOiBmYWxzZSxcclxuICBzb3J0OiBmYWxzZSxcclxuICBkaXNhYmxlZDogZmFsc2UsXHJcbiAgZ2hvc3RDbGFzczogXCJ0dFwiLFxyXG4gIGZvcmNlRmFsbGJhY2s6IHRydWUsXHJcbn07XHJcblxyXG4vL+WbvuS+i+eahOagt+W8j1xyXG5sZXQgbGVuZ2VuZENsYXNzID0gKG5hbWUpID0+IHtcclxuICBpZiAobmFtZSAhPT0gbGVnZW5kQWN0aXZlSXRlbS52YWx1ZSkge1xyXG4gICAgcmV0dXJuIFwibGVuZ2VuZEl0ZW1Ob3JtYWxcIjtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIFwibGVuZ2VuZEl0ZW1BY3RpdmVcIjtcclxuICB9XHJcbn07XHJcbi8v54K55Ye75Zu+5L6L5LqL5Lu2XHJcbmxldCBjbGlja0xlbmdlbmQgPSAobmFtZSkgPT4ge1xyXG4gICAgaWYocm91dGUucXVlcnkudHlwZSA9PT0gJ2RldGFpbCcpe1xyXG4gICAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gIHRleHRhcmVhU2hvdy52YWx1ZSA9IGZhbHNlXHJcbiAgbGVnZW5kQWN0aXZlSXRlbS52YWx1ZSA9IG5hbWU7XHJcbiAgaXNMaW5rTGluZS52YWx1ZSA9IGZhbHNlO1xyXG4gIGlmIChuYW1lID09PSBcIm1vZGVcIikge1xyXG4gICAgLy8gaXNNb2RlLnZhbHVlID0gdHJ1ZVxyXG4gIH0gZWxzZSBpZiAobmFtZSA9PT0gXCJsaW5rXCIpIHtcclxuICAgIGlzTGlua0xpbmUudmFsdWUgPSB0cnVlO1xyXG4gIH0gZWxzZSBpZiAobmFtZSA9PT0gXCJhbGxDbGVhclwiKSB7XHJcbiAgICBjYW52YXNNb2RlLmNsZWFyUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xyXG4gICAgbm9kZUxpc3QudmFsdWUgPSBbXTtcclxuICB9IGVsc2UgaWYgKG5hbWUgPT09IFwicmVzZXRMZW5nZW5kXCIpIHtcclxuICAgIGxlZ2VuZEFjdGl2ZUl0ZW0udmFsdWUgPSB1bmRlZmluZWQ7XHJcbiAgfSBlbHNlIGlmKG5hbWUgPT09ICdsYWJlbCcpe1xyXG4gICAgdGV4dGFyZWFTaG93LnZhbHVlID0gdHJ1ZVxyXG4gIH1cclxuICBlbHNlIHtcclxuICB9XHJcbn07XHJcbi8v5Zu+5L6L5ouW5Yqo5byA5aeLXHJcbmNvbnN0IG1vdmVTdGFydCA9IChlbCkgPT4ge1xyXG59O1xyXG4vL+WbvuS+i+aLluWKqOe7k+adn1xyXG5jb25zdCBtb3ZlRW5kID0gKGVsKSA9PiB7XHJcbiAgbGV0IHBvc2l0aW9uID0ge1xyXG4gICAgeDogZWwub3JpZ2luYWxFdmVudC5jbGllbnRYLFxyXG4gICAgeTogZWwub3JpZ2luYWxFdmVudC5jbGllbnRZLFxyXG4gIH07XHJcbiAgaWYgKFxyXG4gICAgcG9zaXRpb24ueCA8IDIwMiArIDEwMCB8fFxyXG4gICAgcG9zaXRpb24ueCA+IDE3MDIgLSAxMDAgfHxcclxuICAgIHBvc2l0aW9uLnkgPCA1MiArIDEwMCB8fFxyXG4gICAgcG9zaXRpb24ueSA+IDg1MiAtIDEwMFxyXG4gICkge1xyXG4gICAgRWxNZXNzYWdlKHtcclxuICAgICAgbWVzc2FnZTogXCLmnKrmi5blhaXnlLvluIPkuYvkuK1cIixcclxuICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2hhbmdlTm9kZUxpc3QocG9zaXRpb24pO1xyXG4gICAgZHJhdyhudWxsKTtcclxuICB9XHJcbn07XHJcbi8v54K55Ye755S75biDXHJcbmNvbnN0IGNsaWNrQ2FudmFzID0gKGVsKSA9PiB7fTtcclxuLy/nlLvluIPkuK3pvKDmoIfmjInkuItcclxuY29uc3QgY2FudmFzRG93biA9IChlbCkgPT4ge1xyXG4gICAgICAgIGlmKHJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnKXtcclxuICAgICAgICByZXR1cm5cclxuICAgIH1cclxuICBldmVudE5hbWUudmFsdWUgPSBcIm1vdXNlZG93blwiO1xyXG4gIGxldCBwb3NpdGlvbiA9IGNhbnZhcy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICBsZXQgcG9zaXRpb25JbmZvID0ge1xyXG4gICAgeDogZWwuY2xpZW50WCAtIHBvc2l0aW9uLmxlZnQsXHJcbiAgICB5OiBlbC5jbGllbnRZIC0gcG9zaXRpb24udG9wLFxyXG4gIH07XHJcbiAgaWYgKGlzTGlua0xpbmUudmFsdWUgPT09IHRydWUpIHtcclxuICAgIGxpbmtMaW5lRmxhZy52YWx1ZSA9IHRydWU7XHJcbiAgICBjaGFuZ2VOb2RlTGlzdChwb3NpdGlvbkluZm8pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjbGlja05vZGVGbGFnLnZhbHVlID0gdHJ1ZTtcclxuICB9XHJcbiAgZHJhdyhwb3NpdGlvbkluZm8pO1xyXG59O1xyXG4vL+eUu+W4g+S4rem8oOagh+aKrOi1t1xyXG5jb25zdCBjYW52YXNVcCA9IChlbCkgPT4ge1xyXG4gIGV2ZW50TmFtZS52YWx1ZSA9IFwibW91c2V1cFwiO1xyXG4gIGxpbmtMaW5lRmxhZy52YWx1ZSA9IGZhbHNlO1xyXG4gIGNsaWNrTm9kZUZsYWcudmFsdWUgPSBmYWxzZTtcclxuICBsZXQgcG9zaXRpb24gPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgbGV0IHBvc2l0aW9uSW5mbyA9IHtcclxuICAgIHg6IGVsLmNsaWVudFggLSBwb3NpdGlvbi5sZWZ0LFxyXG4gICAgeTogZWwuY2xpZW50WSAtIHBvc2l0aW9uLnRvcCxcclxuICB9O1xyXG4gIHRleHRhcmVhU2hvdy52YWx1ZSA9IGZhbHNlXHJcbiAgaWYobGVnZW5kQWN0aXZlSXRlbS52YWx1ZSA9PT0gJ2xhYmVsJyl7XHJcbiAgICB0ZXh0YXJlYVNob3cudmFsdWUgPSB0cnVlXHJcbiAgICB0ZXh0YXJlYUNsYXNzLnZhbHVlLmxlZnQgPSBlbC5sYXllclgrJ3B4J1xyXG4gICAgdGV4dGFyZWFDbGFzcy52YWx1ZS50b3AgPSBlbC5sYXllclkrJ3B4J1xyXG4gIH1cclxuICBkcmF3KHBvc2l0aW9uSW5mbyk7XHJcbn07XHJcbi8v55S75biD5Lit6byg5qCH56e75YqoXHJcbmNvbnN0IGNhbnZhc01vdmUgPSAoZWwpID0+IHtcclxuICAgIGlmKHJvdXRlLnF1ZXJ5LnR5cGUgPT09ICdkZXRhaWwnKXtcclxuICAgICAgICByZXR1cm5cclxuICAgIH1cclxuICBldmVudE5hbWUudmFsdWUgPSBcIm1vdXNlbW92ZVwiO1xyXG4gIGlmIChpc0xpbmtMaW5lLnZhbHVlID09PSB0cnVlKSB7XHJcbiAgICBpZiAobGlua0xpbmVGbGFnLnZhbHVlID09PSB0cnVlKSB7XHJcbiAgICAgIGNyZWF0ZUxpbmtUYXJnZXQoZWwpO1xyXG4gICAgICBkcmF3KCk7XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIGlmIChjbGlja05vZGVGbGFnLnZhbHVlID09PSB0cnVlKSB7XHJcbiAgICAgIHN3aXRjaCAoYWN0aXZlTm9kZUluZm8udmFsdWUubW9kZVR5cGUpIHtcclxuICAgICAgICBjYXNlIFwicmVjdFN0cm9rZVwiOlxyXG4gICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueCA9IGVsLm9mZnNldFggLSAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55ID0gZWwub2Zmc2V0WSAtIDEwMDtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJyZWN0RmlsbFwiOlxyXG4gICAgICAgICAgYWN0aXZlTm9kZUluZm8udmFsdWUueCA9IGVsLm9mZnNldFggLSAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55ID0gZWwub2Zmc2V0WSAtIDEwMDtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJhcmNGaWxsXCI6XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54ID0gZWwub2Zmc2V0WDtcclxuICAgICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnkgPSBlbC5vZmZzZXRZO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcInRocmVlXCI6XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54MSA9IGVsLm9mZnNldFg7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55MSA9IGVsLm9mZnNldFkgLSAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54MiA9IGVsLm9mZnNldFggLSAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55MiA9IGVsLm9mZnNldFkgKyAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS54MyA9IGVsLm9mZnNldFggKyAxMDA7XHJcbiAgICAgICAgICBhY3RpdmVOb2RlSW5mby52YWx1ZS55MyA9IGVsLm9mZnNldFkgKyAxMDA7XHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICAgIG1vdmVMaW5lSW5mbyhlbCk7XHJcbiAgICAgIGRyYXcoKTtcclxuICAgIH1cclxuICB9XHJcbn07XHJcbmNvbnN0IGNhbnZhc0xlYXZlID0gKGVsKSA9PntcclxuICBsZWdlbmRBY3RpdmVJdGVtLnZhbHVlID0gdW5kZWZpbmVkXHJcbn1cclxuLy/oioLngrnnp7vliqjml7bnur/mnaHkvY3nva7nmoTmlLnlj5hcclxuY29uc3QgbW92ZUxpbmVJbmZvID0gKGVsKSA9PiB7XHJcbiAgaWYgKCFhY3RpdmVOb2RlSW5mby52YWx1ZSB8fCAhYWN0aXZlTm9kZUluZm8udmFsdWUuZnJvbUxpc3QpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKGFjdGl2ZU5vZGVJbmZvLnZhbHVlLmZyb21MaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLmZyb21MaXN0LmZvckVhY2goKEl0ZW0pID0+IHtcclxuICAgICAgbGV0IGxpbmUgPSBub2RlTGlzdC52YWx1ZS5maW5kKChpdGVtKSA9PiBJdGVtID09PSBpdGVtLmlkKTtcclxuICAgICAgbGluZS5mcm9tWCA9IGVsLm9mZnNldFg7XHJcbiAgICAgIGxpbmUuZnJvbVkgPSBlbC5vZmZzZXRZO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGlmIChhY3RpdmVOb2RlSW5mby52YWx1ZS50YXJnZXRMaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnRhcmdldExpc3QuZm9yRWFjaCgoSXRlbSkgPT4ge1xyXG4gICAgICBsZXQgbGluZSA9IG5vZGVMaXN0LnZhbHVlLmZpbmQoKGl0ZW0pID0+IEl0ZW0gPT09IGl0ZW0uaWQpO1xyXG4gICAgICBsaW5lLnRhcmdldFggPSBlbC5vZmZzZXRYO1xyXG4gICAgICBsaW5lLnRhcmdldFkgPSBlbC5vZmZzZXRZO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59O1xyXG4vL+eUu+W4g+WIneWni+WMllxyXG5sZXQgY2FudmFzSW5pdCA9IChsaXN0KSA9PiB7XHJcbiAgY2FudmFzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW52YXNcIik7XHJcbiAgY2FudmFzTW9kZSA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcbiAgbm9kZUxpc3QudmFsdWUgPSBsaXN0XHJcbiAgZHJhdyhudWxsKTtcclxufTtcclxuLy/liJvlu7rov57mjqXotbflp4vngrlcclxubGV0IGNyZWF0ZUxpbmtUYXJnZXQgPSAoZWwpID0+IHtcclxuICBsZXQgbGlua0xpbmVJbmZvID1cclxuICAgIG5vZGVMaXN0LnZhbHVlW1xyXG4gICAgICBub2RlTGlzdC52YWx1ZS5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGFjdGl2ZUxpbmVJZC52YWx1ZSlcclxuICAgIF07XHJcbiAgaWYgKGVsLm9mZnNldFggPiAwICYmIGVsLm9mZnNldFkgPiAwKSB7XHJcbiAgICBsaW5rTGluZUluZm8udGFyZ2V0WCA9IGVsLm9mZnNldFg7XHJcbiAgICBsaW5rTGluZUluZm8udGFyZ2V0WSA9IGVsLm9mZnNldFk7XHJcbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XHJcbiAgfVxyXG59O1xyXG4vL+e7mOWItuWbvuW9oijmoLjlv4Pmlrnms5UpXHJcbmNvbnN0IGRyYXcgPSAocG9zaXRpb25JbmZvKSA9PiB7XHJcbiAgY2FudmFzTW9kZS5jbGVhclJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcclxuICBub2RlTGlzdC52YWx1ZS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgY2FudmFzTW9kZS5iZWdpblBhdGgoKTtcclxuICAgIGNhbnZhc01vZGUubGluZVdpZHRoID0gNTtcclxuICAgIC8qKuWhq+WFheefqeW9oijlrp7niakpICovXHJcbiAgICBpZiAoaXRlbS5tb2RlVHlwZSA9PT0gXCJyZWN0RmlsbFwiKSB7XHJcbiAgICAgIGNhbnZhc01vZGUucmVjdChpdGVtLngsIGl0ZW0ueSwgaXRlbS53aWR0aCwgaXRlbS5oZWlnaHQpO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0uY29sb3I7XHJcbiAgICAgIGNhbnZhc01vZGUuc3Ryb2tlU3R5bGUgPSBpdGVtLmNvbG9yO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGwoKTtcclxuICAgICAgY2FudmFzTW9kZS5zdHJva2UoKTtcclxuICAgICAgY2FudmFzTW9kZS5maWxsU3R5bGUgPSBpdGVtLnRleHQuY29sb3I7XHJcbiAgICAgIGNhbnZhc01vZGUuZm9udCA9IFwiMThweCBUaW1lc1wiO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KGl0ZW0udGV4dC5pbmZvLCBpdGVtLnggKyA4MCwgaXRlbS55ICsgMTAwKTtcclxuICAgIH0gZWxzZSBpZiAoaXRlbS5tb2RlVHlwZSA9PT0gXCJ0aHJlZVwiKSB7XHJcbiAgICAgIC8qKuaPj+i+ueS4ieinkuW9oijkuJrliqHnur8pKi9cclxuICAgICAgY2FudmFzTW9kZS5tb3ZlVG8oaXRlbS54MSwgaXRlbS55MSk7XHJcbiAgICAgIGNhbnZhc01vZGUubGluZVRvKGl0ZW0ueDIsIGl0ZW0ueTIpO1xyXG4gICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLngzLCBpdGVtLnkzKTtcclxuICAgICAgY2FudmFzTW9kZS5saW5lVG8oaXRlbS54MSwgaXRlbS55MSk7XHJcbiAgICAgIGNhbnZhc01vZGUuY2xvc2VQYXRoKCk7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS5jb2xvcjtcclxuICAgICAgY2FudmFzTW9kZS5maWxsKCk7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS50ZXh0LmNvbG9yO1xyXG4gICAgICBjYW52YXNNb2RlLmZvbnQgPSBcIjE4cHggVGltZXNcIjtcclxuICAgICAgY2FudmFzTW9kZS5maWxsVGV4dChpdGVtLnRleHQuaW5mbywgaXRlbS54MSAtIDMwLCBpdGVtLnkxICsgMTMwKTtcclxuICAgIH0gZWxzZSBpZiAoaXRlbS5tb2RlVHlwZSA9PT0gXCJyZWN0U3Ryb2tlXCIpIHtcclxuICAgICAgLyoq5o+P6L6555+p5b2iKOaooeWdlykqL1xyXG4gICAgICBjYW52YXNNb2RlLnJlY3QoaXRlbS54LCBpdGVtLnksIGl0ZW0ud2lkdGgsIGl0ZW0uaGVpZ2h0KTtcclxuICAgICAgY2FudmFzTW9kZS5maWxsU3R5bGUgPSBcIiNmZmZcIjtcclxuICAgICAgY2FudmFzTW9kZS5zdHJva2VTdHlsZSA9IGl0ZW0uY29sb3I7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbCgpO1xyXG4gICAgICBjYW52YXNNb2RlLnN0cm9rZSgpO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGl0ZW0udGV4dC5jb2xvcjtcclxuICAgICAgY2FudmFzTW9kZS5mb250ID0gXCIxOHB4IFRpbWVzXCI7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbFRleHQoaXRlbS50ZXh0LmluZm8sIGl0ZW0ueCArIDgwLCBpdGVtLnkgKyAxMDApO1xyXG4gICAgfSBlbHNlIGlmIChpdGVtLm1vZGVUeXBlID09PSBcImFyY0ZpbGxcIikge1xyXG4gICAgICAvKirlnIblvaIo5L6b5bqU5ZWGKSovXHJcbiAgICAgIGNhbnZhc01vZGUuYXJjKGl0ZW0ueCwgaXRlbS55LCBpdGVtLmFyY1NpemUsIDAsIE1hdGguUEkgKiAyLCBmYWxzZSk7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gXCIjZmZmXCI7XHJcbiAgICAgIGNhbnZhc01vZGUuc3Ryb2tlU3R5bGUgPSBpdGVtLmNvbG9yO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGwoKTtcclxuICAgICAgY2FudmFzTW9kZS5zdHJva2UoKTtcclxuICAgICAgY2FudmFzTW9kZS5maWxsU3R5bGUgPSBpdGVtLnRleHQuY29sb3I7XHJcbiAgICAgIGNhbnZhc01vZGUuZm9udCA9IFwiMThweCBUaW1lc1wiO1xyXG4gICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KGl0ZW0udGV4dC5pbmZvLCBpdGVtLnggLSAzMCwgaXRlbS55KTtcclxuICAgIH0gZWxzZSBpZiAoaXRlbS5tb2RlVHlwZSA9PT0gXCJsaW5rTGluZVwiKSB7XHJcbiAgICAgIC8qKui/nue6vyovXHJcbiAgICAgIGNhbnZhc01vZGUubW92ZVRvKGl0ZW0uZnJvbVgsIGl0ZW0uZnJvbVkpO1xyXG4gICAgICBpZiAoaXRlbS50YXJnZXRYICYmIGl0ZW0udGFyZ2V0WSkge1xyXG4gICAgICAgIGNhbnZhc01vZGUubGluZVRvKGl0ZW0udGFyZ2V0WCwgaXRlbS50YXJnZXRZKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjYW52YXNNb2RlLmxpbmVUbyhpdGVtLmZyb21YLCBpdGVtLmZyb21ZKTtcclxuICAgICAgfVxyXG4gICAgICBjYW52YXNNb2RlLmxpbmVDYXAgPSBcInJvdW5kXCI7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbFN0eWxlID0gaXRlbS5jb2xvcjtcclxuICAgICAgY2FudmFzTW9kZS5zdHJva2VTdHlsZSA9IGl0ZW0uY29sb3I7XHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbCgpO1xyXG4gICAgICBjYW52YXNNb2RlLnN0cm9rZSgpO1xyXG4gICAgfVxyXG4gICAgLyrnu5jliLbmlofmnKwqL1xyXG4gICAgZWxzZSBpZihpdGVtLm1vZGVUeXBlID09PSBcInRleHRcIil7XHJcbiAgICAgIGNhbnZhc01vZGUuc3Ryb2tlU3R5bGUgPSBjYW52YXNTdHlsZUluZm8udmFsdWUuYmFja2dyb3VuZFxyXG4gICAgICBjYW52YXNNb2RlLmZpbGxTdHlsZSA9IGNhbnZhc1N0eWxlSW5mby52YWx1ZS5iYWNrZ3JvdW5kXHJcbiAgICAgIGNhbnZhc01vZGUubGluZVdpZHRoID0gMVxyXG4gICAgICBsZXQgbWF4TGVuZ3RoID0gaXRlbS5pbmZvLnJlZHVjZShmdW5jdGlvbihuZXdWYWwsb2xkVmFsKXtcclxuICAgICAgIHJldHVybiBuZXdWYWwubGVuZ3RoPm9sZFZhbC5sZW5ndGg/bmV3VmFsLmxlbmd0aDpvbGRWYWwubGVuZ3RoXHJcbiAgICAgIH0pXHJcbiAgICAgIGNhbnZhc01vZGUucmVjdChpdGVtLnRleHRYLTIwMCxpdGVtLnRleHRZLTUwLChtYXhMZW5ndGgrMSkqMTAsKGl0ZW0uaW5mby5sZW5ndGgrMSkqMjApXHJcbiAgICAgIGNhbnZhc01vZGUuZmlsbCgpXHJcbiAgICAgIGNhbnZhc01vZGUuc3Ryb2tlKClcclxuICAgICAgY2FudmFzTW9kZS5maWxsU3R5bGUgPSBpdGVtLmNvbG9yO1xyXG4gICAgICBjYW52YXNNb2RlLmZvbnQgPSBcIjE4cHggVGltZXNcIjtcclxuICAgICAgaXRlbS5pbmZvLmZvckVhY2goKG0sbik9PntcclxuICAgICAgICBjYW52YXNNb2RlLmZpbGxUZXh0KG0saXRlbS50ZXh0WC0yMDAsaXRlbS50ZXh0WS0zMCsyMCpuKVxyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIC8v5Yik5pat54K55Ye76Kem5Y+R5YWD57SgXHJcbiAgICBpZiAocG9zaXRpb25JbmZvKSB7XHJcbiAgICAgIGNvbnN0IGlzVGFyZ2V0X3BhdGggPSBjYW52YXNNb2RlLmlzUG9pbnRJblBhdGgoXHJcbiAgICAgICAgcG9zaXRpb25JbmZvLngsXHJcbiAgICAgICAgcG9zaXRpb25JbmZvLnlcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgaXNUYXJnZXRfc3Ryb2tlID0gY2FudmFzTW9kZS5pc1BvaW50SW5TdHJva2UoXHJcbiAgICAgICAgcG9zaXRpb25JbmZvLngsXHJcbiAgICAgICAgcG9zaXRpb25JbmZvLnlcclxuICAgICAgKTtcclxuICAgICAgaWYgKGlzVGFyZ2V0X3BhdGggfHwgaXNUYXJnZXRfc3Ryb2tlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCLngrnlh7vliLDkuobmn5DlhYPntKBcIiwgaXRlbSwgaW5kZXgpO1xyXG4gICAgICAgIGFjdGl2ZU5vZGVJbmZvLnZhbHVlID0gaXRlbTtcclxuICAgICAgICBpZiAoaXNMaW5rTGluZS52YWx1ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgaWYgKGFjdGl2ZUxpbmVJZC52YWx1ZSkge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnROYW1lLnZhbHVlID09PSBcIm1vdXNlZG93blwiKSB7XHJcbiAgICAgICAgICAgICAgaWYgKGl0ZW0ubW9kZVR5cGUgIT09IFwibGlua0xpbmVcIikge1xyXG4gICAgICAgICAgICAgICAgbGlua0xpbmVGcm9tLnZhbHVlID0gaXRlbS5pZDtcclxuICAgICAgICAgICAgICAgIGl0ZW0uZnJvbUxpc3QucHVzaChhY3RpdmVMaW5lSWQudmFsdWUpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmIChldmVudE5hbWUudmFsdWUgPT09IFwibW91c2V1cFwiKSB7XHJcbiAgICAgICAgICAgICAgaWYgKGl0ZW0ubW9kZVR5cGUgIT09IFwibGlua0xpbmVcIikge1xyXG4gICAgICAgICAgICAgICAgbGlua0xpbmVUYXJnZXQudmFsdWUgPSBpdGVtLmlkO1xyXG4gICAgICAgICAgICAgICAgaXRlbS50YXJnZXRMaXN0LnB1c2goYWN0aXZlTGluZUlkLnZhbHVlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoYWN0aXZlTm9kZUluZm8udmFsdWUubW9kZVR5cGUgPT09ICd0ZXh0Jyl7XHJcbiAgICAgICAgICB0ZXh0YXJlYVNob3cudmFsdWUgPSB0cnVlXHJcbiAgICAgICAgICB0ZXh0YXJlYUNsYXNzLnZhbHVlLmxlZnQgPSBhY3RpdmVOb2RlSW5mby52YWx1ZS50ZXh0WCArJ3B4J1xyXG4gICAgICAgICAgdGV4dGFyZWFDbGFzcy52YWx1ZS50b3AgPSBhY3RpdmVOb2RlSW5mby52YWx1ZS50ZXh0WS01MCArICdweCdcclxuICAgICAgICAgIHRleHRhcmVhQ2xhc3MudmFsdWUucm93cyA9IDVcclxuICAgICAgICAgIGxldCBzdHIgPSBhY3RpdmVOb2RlSW5mby52YWx1ZS5pbmZvLmpvaW4oJ1xcbicpXHJcbiAgICAgICAgdGV4dGFyZWFWYWx1ZS52YWx1ZSA9IGAke3N0cn1gXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY2FudmFzTW9kZS5jbG9zZVBhdGgoKTtcclxuICB9KTtcclxufTtcclxuLy/pgJrov4fmk43kvZzlr7noioLngrnliJfooajmlbDmja7ov5vooYzkv67mlLlcclxuY29uc3QgY2hhbmdlTm9kZUxpc3QgPSAocG9zaXRpb24pID0+IHtcclxuICBpc0xpbmtMaW5lLnZhbHVlID0gZmFsc2U7XHJcbiAgc3dpdGNoIChsZWdlbmRBY3RpdmVJdGVtLnZhbHVlKSB7XHJcbiAgICBjYXNlIFwiZW50aXJ5XCI6XHJcbiAgICAgIG5vZGVMaXN0LnZhbHVlLnB1c2goY3JlYXRlUmVjdEZpbGwocG9zaXRpb24pKTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwidHJpYW5nbGVcIjpcclxuICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVUcmVlQm94KHBvc2l0aW9uKSk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcIm1vZGVcIjpcclxuICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVSZWN0U3Ryb2tlKHBvc2l0aW9uKSk7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcImVsbGlwc2VcIjpcclxuICAgICAgbm9kZUxpc3QudmFsdWUucHVzaChjcmVhdGVBcmNTdHJva2UocG9zaXRpb24pKTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwibGlua1wiOlxyXG4gICAgICBsZXQgbGluZUluZm8gPSBjcmVhdGVMaW5rTGluZShwb3NpdGlvbik7XHJcbiAgICAgIG5vZGVMaXN0LnZhbHVlLnB1c2gobGluZUluZm8pO1xyXG4gICAgICBhY3RpdmVMaW5lSWQudmFsdWUgPSBsaW5lSW5mby5pZDtcclxuICAgICAgaXNMaW5rTGluZS52YWx1ZSA9IHRydWU7XHJcbiAgICAgIGJyZWFrXHJcbiAgICBjYXNlIFwibGFiZWxcIjpcclxuICAgICAgbGV0IEluZm8gPSBjcmVhdGVUZXh0KHBvc2l0aW9uKVxyXG4gICAgICBsZXQgdGV4dEluZm8gPSBgJHt0ZXh0YXJlYVZhbHVlLnZhbHVlfWBcclxuICAgICAgSW5mby5pbmZvID0gdGV4dEluZm8uc3BsaXQoJ1xcbicpXHJcbiAgICAgIHRleHRhcmVhVmFsdWUudmFsdWUgPSAnJ1xyXG4gICAgICB0ZXh0YXJlYVNob3cudmFsdWUgPSBmYWxzZVxyXG4gICAgICBub2RlTGlzdC52YWx1ZS5wdXNoKEluZm8pO1xyXG4gICAgICBicmVha1xyXG4gIH1cclxuICBsZXQgbGlzdDAgPSBbXTtcclxuICBsZXQgbGlzdDEgPSBbXTtcclxuICBsZXQgbGlzdDIgPSBbXTtcclxuICBsZXQgbGlzdDMgPSBbXVxyXG4gIG5vZGVMaXN0LnZhbHVlLmZvckVhY2goKG0pID0+IHtcclxuICAgIGlmIChtLm5vZGVJbmRleCA9PT0gMCkge1xyXG4gICAgICBsaXN0MC5wdXNoKG0pO1xyXG4gICAgfSBlbHNlIGlmIChtLm5vZGVJbmRleCA9PT0gMSkge1xyXG4gICAgICBsaXN0MS5wdXNoKG0pO1xyXG4gICAgfSBlbHNlIGlmIChtLm5vZGVJbmRleCA9PT0gMikge1xyXG4gICAgICBsaXN0Mi5wdXNoKG0pO1xyXG4gICAgfWVsc2UgaWYgKG0ubm9kZUluZGV4ID09PSAxMDAwKSB7XHJcbiAgICAgICBsaXN0My5wdXNoKG0pXHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgbm9kZUxpc3QudmFsdWUgPSBbXS5jb25jYXQobGlzdDApLmNvbmNhdChsaXN0MSkuY29uY2F0KGxpc3QyKS5jb25jYXQobGlzdDMpO1xyXG59O1xyXG5jb25zdCBjaGFuZ2VTY2FsZSA9ICgpID0+IHtcclxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XHJcbn07XHJcbi8v5L+u5pS56IqC54K55Li76aKY6ImyXHJcbmNvbnN0IGNoYW5nZU5vZGVUaGVtZUNvbG9yID0gKHZhbHVlKSA9PiB7XHJcbiAgYWN0aXZlTm9kZUluZm8udmFsdWUuY29sb3IgPSB2YWx1ZTtcclxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XHJcbn07XHJcbi8v5L+u5pS56IqC54K55a2X5L2T6aKc6ImyXHJcbmNvbnN0IGNoYW5nZU5vZGVUZXh0Q29sb3IgPSAodmFsdWUpID0+IHtcclxuICBhY3RpdmVOb2RlSW5mby52YWx1ZS50ZXh0LmNvbG9yID0gdmFsdWU7XHJcbiAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGRyYXcpO1xyXG59O1xyXG4vL+S/ruaUueiKgueCueS4reeahOWtl+S9k+aWh+Wtl1xyXG5jb25zdCBjaGFuZ2VOb2RlVGV4dEluZm8gPSAodmFsdWUpID0+IHtcclxuICBhY3RpdmVOb2RlSW5mby52YWx1ZS50ZXh0LmluZm8gPSB2YWx1ZTtcclxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XHJcbn07XHJcbi8v5Yig6Zmk5b2T5YmN6YCJ5Lit6IqC54K5XHJcbmNvbnN0IGRlbGV0ZU5vZGUgPSAoKSA9PiB7XHJcbiAgdGV4dGFyZWFTaG93LnZhbHVlID0gZmFsc2VcclxuICB0ZXh0YXJlYVZhbHVlLnZhbHVlID0gJydcclxuICBsZXQgaW5kZXggPSBub2RlTGlzdC52YWx1ZS5maW5kSW5kZXgoXHJcbiAgICAoaXRlbSkgPT4gaXRlbS5pZCA9PT0gYWN0aXZlTm9kZUluZm8udmFsdWUuaWRcclxuICApO1xyXG4gIG5vZGVMaXN0LnZhbHVlLnNwbGljZShpbmRleCwgMSk7XHJcbiAgaWYoYWN0aXZlTm9kZUluZm8udmFsdWUuZnJvbUxpc3Qpe1xyXG4gICAgYWN0aXZlTm9kZUluZm8udmFsdWUuZnJvbUxpc3QuZm9yRWFjaCgobSkgPT4ge1xyXG4gICAgaWYgKG0pIHtcclxuICAgICAgZGVsZXRlTGlua0xpbmUobSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgfVxyXG4gIGlmKGFjdGl2ZU5vZGVJbmZvLnZhbHVlLnRhcmdldExpc3Qpe1xyXG4gICAgYWN0aXZlTm9kZUluZm8udmFsdWUudGFyZ2V0TGlzdC5mb3JFYWNoKChtKSA9PiB7XHJcbiAgICBpZiAobSkge1xyXG4gICAgICBkZWxldGVMaW5rTGluZShtKTtcclxuICAgIH1cclxuICB9KTtcclxuICB9XHJcblxyXG4gIHJlcXVlc3RBbmltYXRpb25GcmFtZShkcmF3KTtcclxufTtcclxuLy/liKDpmaTlvZPliY3pgInkuK3ov57mjqXnur9cclxuY29uc3QgZGVsZXRlTGluZSA9ICgpID0+IHtcclxuICBkZWxldGVMaW5rTGluZShhY3RpdmVOb2RlSW5mby52YWx1ZS5pZCk7XHJcbn07XHJcbi8v5Yig6Zmk6IqC54K56ZmE5bim55qE6L+e5o6l57q/XHJcbmNvbnN0IGRlbGV0ZUxpbmtMaW5lID0gKGlkKSA9PiB7XHJcbiAgbGV0IGluZGV4ID0gbm9kZUxpc3QudmFsdWUuZmluZEluZGV4KChtKSA9PiBtLmlkID09PSBpZCk7XHJcbiAgaWYgKGluZGV4ICE9PSAtMSkge1xyXG4gICAgbm9kZUxpc3QudmFsdWUuc3BsaWNlKGluZGV4LCAxKTtcclxuICB9XHJcbiAgbm9kZUxpc3QudmFsdWUuZm9yRWFjaCgobikgPT4ge1xyXG4gICAgaWYgKG4uZnJvbUxpc3QpIHtcclxuICAgICAgbGV0IGZyb21JbmRleCA9IG4uZnJvbUxpc3QuZmluZEluZGV4KCh6KSA9PiB6ID09PSBpZCk7XHJcbiAgICAgIGlmIChmcm9tSW5kZXggIT09IC0xKSB7XHJcbiAgICAgICAgbi5mcm9tTGlzdC5zcGxpY2UoZnJvbUluZGV4LCAxKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKG4udGFyZ2V0TGlzdCkge1xyXG4gICAgICBsZXQgdGFyZ2V0SW5kZXggPSBuLnRhcmdldExpc3QuZmluZEluZGV4KCh6KSA9PiB6ID09PSBpZCk7XHJcblxyXG4gICAgICBpZiAodGFyZ2V0SW5kZXggIT09IC0xKSB7XHJcbiAgICAgICAgbi50YXJnZXRMaXN0LnNwbGljZSh0YXJnZXRJbmRleCwgMSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9KTtcclxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhdyk7XHJcbn07XHJcbi8v5paH5pys5qGG54Sm54K55raI5aSx5pe25L+d5a2Y5paH5pysXHJcbmNvbnN0IHNhdmVUZXh0YXJlYVZhbHVlID0gKCk9PntcclxuICB0ZXh0YXJlYVNob3cudmFsdWUgPSBmYWxzZVxyXG4gIGNoYW5nZU5vZGVMaXN0KHtcclxuICAgIHg6cGFyc2VJbnQodGV4dGFyZWFDbGFzcy52YWx1ZS5sZWZ0KSxcclxuICAgIHk6cGFyc2VJbnQodGV4dGFyZWFDbGFzcy52YWx1ZS50b3ApKzUwXHJcbiAgfSkgICBcclxufVxyXG4vL+S4i+i9vVxyXG5jb25zdCBkb3duTG9hZCA9ICgpPT57XHJcbiAgICBjb25zdCBkYXRhVVJMID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvcG5nJyk7XHJcblx0XHJcblx0Ly8g5Yib5bu6aW1n5YWD57Sg77yM55So5LqO6aKE6KeI5Zu+54mHXHJcblx0Y29uc3QgaW1nID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJyk7XHJcblx0aW1nLnNyYyA9IGRhdGFVUkw7XHJcblx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChpbWcpO1xyXG5cdFxyXG5cdC8vIOWIm+W7umHlhYPntKDvvIznlKjkuo7kuIvovb3lm77niYdcclxuXHRjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG5cdGxpbmsuaHJlZiA9IGRhdGFVUkw7XHJcblx0bGluay5kb3dubG9hZCA9IGAke2ltYWdlTmFtZS52YWx1ZX0ucG5nYDtcclxuXHRcclxuXHQvLyDmt7vliqBh5YWD57Sg5YiwRE9N5Lit77yM5bm26Kem5Y+R54K55Ye75LqL5Lu25Lul5LiL6L295Zu+54mHXHJcblx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcclxuXHRsaW5rLmNsaWNrKCk7XHJcbiAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChpbWcpXHJcbiAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKVxyXG59XHJcbmRlZmluZUV4cG9zZSh7XHJcbm5vZGVMaXN0LFxyXG5jYW52YXNJbml0XHJcbn0pXHJcbjwvc2NyaXB0PlxyXG48c3R5bGUgbGFuZz1cImxlc3NcIiBzY29wZWQ+XHJcbi5mbG93Qm94IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDgwMHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC5sZWdlbmQsXHJcbiAgLnNldHRpbmcge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgaGVpZ2h0OiA4MDBweDtcclxuICAgIGJhY2tncm91bmQ6ICNlMGRlZGU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGg0IHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBtYXJnaW46IDEwcHggYXV0bztcclxuICAgICAgYm9yZGVyLWJvdHRvbTogIzAwMCBkYXNoZWQgMXB4O1xyXG4gICAgfVxyXG4gIH1cclxuICAuY2hhcnROb3JtYWwge1xyXG4gICAgZmxleDogMTtcclxuICAgIGJvcmRlcjogMnB4IGRhc2hlZCAjZGVlYzBlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICB9XHJcbiAgLmNoYXJ0TW9kZSB7XHJcbiAgICBmbGV4OiAxO1xyXG4gICAgYm9yZGVyOiAycHggZGFzaGVkICNkZWVjMGU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgY3Vyc29yOiB1cmwoXCJAL2Fzc2V0cy9mbG93Y2hhcnRTdmcv56yULnN2Z1wiKSAwIDMyLCBhdXRvO1xyXG4gIH1cclxuICAubGVuZ2VuZEl0ZW1Ob3JtYWwge1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgLmxlbmdlbmRJdGVtQWN0aXZlIHtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBib3JkZXI6ICNkODFlMDYgMXB4IGRhc2hlZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgLy8gLnNldHRpbmd7XHJcbiAgLy8gICBjdXJzb3I6dXJsKCdAL2Fzc2V0cy9mbG93Y2hhcnRTdmcv56yULnN2ZycpIDAgMzIsYXV0bztcclxuICAvLyB9XHJcbn1cclxuPC9zdHlsZT4iLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cIm1haW5Cb3hcIj5cclxuICAgIDxlbC1mb3JtXHJcbiAgICAgIHJlZj1cInJ1bGVGb3JtUmVmXCJcclxuICAgICAgOm1vZGVsPVwiZm9ybURhdGFcIlxyXG4gICAgICA6cnVsZXM9XCJydWxlc1wiXHJcbiAgICAgIGxhYmVsLXdpZHRoPVwiMTIwcHhcIlxyXG4gICAgICBjbGFzcz1cImRlbW8tcnVsZUZvcm1cIlxyXG4gICAgICBzdGF0dXMtaWNvblxyXG4gICAgPlxyXG4gICAgICA8dGVtcGxhdGUgdi1mb3I9XCIoSXRlbSwgSW5kZXgpIGluIHRlbXBsYXRlTGlzdFwiIDprZXk9XCJJbmRleFwiPlxyXG4gICAgICAgIDxoND57eyBJdGVtLnRpdGxlIH19PC9oND5cclxuICAgICAgICA8ZWwtcm93IGNsYXNzPVwidGVtXCI+XHJcbiAgICAgICAgICA8ZWwtY29sXHJcbiAgICAgICAgICAgIDpzcGFuPVwiMTJcIlxyXG4gICAgICAgICAgICB2LWZvcj1cIihpdGVtLCBpbmRleCkgaW4gSXRlbS5mb3JtTGlzdFwiXHJcbiAgICAgICAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICAgICAgICAgIHN0eWxlPVwibWFyZ2luOiAxMHB4IDBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8dGVtcGxhdGU+PC90ZW1wbGF0ZT5cclxuICAgICAgICAgICAgPGVsLWZvcm0taXRlbVxyXG4gICAgICAgICAgICAgIHYtaWY9XCJpdGVtLnR5cGUgPT09ICdpbnB1dCdcIlxyXG4gICAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICAgIDpwcm9wPVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybURhdGFbaXRlbS5uYW1lXVwiXHJcbiAgICAgICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgICAgIDpkaXNhYmxlZD1cImRpc2FibGVkRnVuKGl0ZW0uZWRpdERpc2FibGVkKVwiXHJcbiAgICAgICAgICAgICAgPjwvZWwtaW5wdXQ+XHJcbiAgICAgICAgICAgICAgPGVsLXRvb2x0aXBcclxuICAgICAgICAgICAgICAgIHYtaWY9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJveC1pdGVtXCJcclxuICAgICAgICAgICAgICAgIGVmZmVjdD1cImRhcmtcIlxyXG4gICAgICAgICAgICAgICAgOmNvbnRlbnQ9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJ0b3BcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxlbC1pY29uIHNpemU9XCIyMHB4XCIgY2xhc3M9XCJpY29uQm94XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxRdWVzdGlvbkZpbGxlZCAvPlxyXG4gICAgICAgICAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICAgICAgICAgIDwvZWwtdG9vbHRpcD5cclxuICAgICAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgICAgIDxlbC1mb3JtLWl0ZW1cclxuICAgICAgICAgICAgICB2LWVsc2UtaWY9XCJpdGVtLnR5cGUgPT09ICd0ZXh0YXJlYSdcIlxyXG4gICAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICAgIDpwcm9wPVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybURhdGFbaXRlbS5uYW1lXVwiXHJcbiAgICAgICAgICAgICAgICA6cm93cz1cIjRcIlxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRhcmVhXCJcclxuICAgICAgICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgICAgICAgOmRpc2FibGVkPVwiZGlzYWJsZWRGdW4oaXRlbS5lZGl0RGlzYWJsZWQpXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxlbC10b29sdGlwXHJcbiAgICAgICAgICAgICAgICB2LWlmPVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib3gtaXRlbVwiXHJcbiAgICAgICAgICAgICAgICBlZmZlY3Q9XCJkYXJrXCJcclxuICAgICAgICAgICAgICAgIDpjb250ZW50PVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwidG9wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZWwtaWNvbiBzaXplPVwiMjBweFwiIGNsYXNzPVwiaWNvbkJveFwiPlxyXG4gICAgICAgICAgICAgICAgICA8UXVlc3Rpb25GaWxsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvZWwtaWNvbj5cclxuICAgICAgICAgICAgICA8L2VsLXRvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgICAgICA8ZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnc2VsZWN0J1wiXHJcbiAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgOnByb3A9XCJpdGVtLm5hbWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGVsLXNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybURhdGFbaXRlbS5uYW1lXVwiXHJcbiAgICAgICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgICAgIDpkaXNhYmxlZD1cImRpc2FibGVkRnVuKGl0ZW0uZWRpdERpc2FibGVkKVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGVsLW9wdGlvblxyXG4gICAgICAgICAgICAgICAgICB2LWZvcj1cIihtLCBuKSBpbiBpdGVtLm9wdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgICA6a2V5PVwiblwiXHJcbiAgICAgICAgICAgICAgICAgIDpsYWJlbD1cIm0ubGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICA6dmFsdWU9XCJtLnZhbHVlXCJcclxuICAgICAgICAgICAgICAgID48L2VsLW9wdGlvbj5cclxuICAgICAgICAgICAgICA8L2VsLXNlbGVjdD5cclxuICAgICAgICAgICAgICA8ZWwtdG9vbHRpcFxyXG4gICAgICAgICAgICAgICAgdi1pZj1cIml0ZW0ucmVtYXJrXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYm94LWl0ZW1cIlxyXG4gICAgICAgICAgICAgICAgZWZmZWN0PVwiZGFya1wiXHJcbiAgICAgICAgICAgICAgICA6Y29udGVudD1cIml0ZW0ucmVtYXJrXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInRvcFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGVsLWljb24gc2l6ZT1cIjIwcHhcIiBjbGFzcz1cImljb25Cb3hcIj5cclxuICAgICAgICAgICAgICAgICAgPFF1ZXN0aW9uRmlsbGVkIC8+XHJcbiAgICAgICAgICAgICAgICA8L2VsLWljb24+XHJcbiAgICAgICAgICAgICAgPC9lbC10b29sdGlwPlxyXG4gICAgICAgICAgICA8L2VsLWZvcm0taXRlbT5cclxuICAgICAgICAgICAgPGVsLWZvcm0taXRlbVxyXG4gICAgICAgICAgICAgIHYtZWxzZS1pZj1cIml0ZW0udHlwZSA9PT0gJ3JhZGlvJ1wiXHJcbiAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgOnByb3A9XCJpdGVtLm5hbWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGVsLXJhZGlvLWdyb3VwXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cIm1sLTRcIlxyXG4gICAgICAgICAgICAgICAgdi1tb2RlbD1cImZvcm1EYXRhW2l0ZW0ubmFtZV1cIlxyXG4gICAgICAgICAgICAgICAgOmRpc2FibGVkPVwiZGlzYWJsZWRGdW4oaXRlbS5lZGl0RGlzYWJsZWQpXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZWwtcmFkaW9cclxuICAgICAgICAgICAgICAgICAgOmxhYmVsPVwibS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHYtZm9yPVwiKG0sIG4pIGluIGl0ZW0ub3B0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICAgIDprZXk9XCJuXCJcclxuICAgICAgICAgICAgICAgICAgPnt7IG0udGV4dCB9fTwvZWwtcmFkaW9cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8L2VsLXJhZGlvLWdyb3VwPlxyXG4gICAgICAgICAgICAgIDxlbC10b29sdGlwXHJcbiAgICAgICAgICAgICAgICB2LWlmPVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib3gtaXRlbVwiXHJcbiAgICAgICAgICAgICAgICBlZmZlY3Q9XCJkYXJrXCJcclxuICAgICAgICAgICAgICAgIDpjb250ZW50PVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwidG9wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZWwtaWNvbiBzaXplPVwiMjBweFwiIGNsYXNzPVwiaWNvbkJveFwiPlxyXG4gICAgICAgICAgICAgICAgICA8UXVlc3Rpb25GaWxsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvZWwtaWNvbj5cclxuICAgICAgICAgICAgICA8L2VsLXRvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgICAgICA8ZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnbXVsdGlwbGVfc2VsZWN0J1wiXHJcbiAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgOnByb3A9XCJpdGVtLm5hbWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGVsLXNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybURhdGFbaXRlbS5uYW1lXVwiXHJcbiAgICAgICAgICAgICAgICBtdWx0aXBsZVxyXG4gICAgICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJkaXNhYmxlZEZ1bihpdGVtLmVkaXREaXNhYmxlZClcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxlbC1vcHRpb25cclxuICAgICAgICAgICAgICAgICAgdi1mb3I9XCIobSwgbikgaW4gaXRlbS5vcHRpb25zXCJcclxuICAgICAgICAgICAgICAgICAgOmtleT1cIm5cIlxyXG4gICAgICAgICAgICAgICAgICA6bGFiZWw9XCJtLmxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgOnZhbHVlPVwibS52YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICA+PC9lbC1vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9lbC1zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPGVsLXRvb2x0aXBcclxuICAgICAgICAgICAgICAgIHYtaWY9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJveC1pdGVtXCJcclxuICAgICAgICAgICAgICAgIGVmZmVjdD1cImRhcmtcIlxyXG4gICAgICAgICAgICAgICAgOmNvbnRlbnQ9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJ0b3BcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxlbC1pY29uIHNpemU9XCIyMHB4XCIgY2xhc3M9XCJpY29uQm94XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxRdWVzdGlvbkZpbGxlZCAvPlxyXG4gICAgICAgICAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICAgICAgICAgIDwvZWwtdG9vbHRpcD5cclxuICAgICAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgICAgIDxlbC1mb3JtLWl0ZW1cclxuICAgICAgICAgICAgICB2LWVsc2UtaWY9XCJpdGVtLnR5cGUgPT09ICd1cGxvYWQnXCJcclxuICAgICAgICAgICAgICA6bGFiZWw9XCJpdGVtLmxhYmVsXCJcclxuICAgICAgICAgICAgICA6cHJvcD1cIml0ZW0ubmFtZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZWwtdXBsb2FkXHJcbiAgICAgICAgICAgICAgICB2LW1vZGVsPVwiZm9ybURhdGFbaXRlbS5uYW1lXVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm1JdGVtIHVwbG9hZC1kZW1vXCJcclxuICAgICAgICAgICAgICAgIDpodHRwLXJlcXVlc3Q9XCJyZXF1ZXN0RmlsZVwiXHJcbiAgICAgICAgICAgICAgICA6bGltaXQ9XCIxXCJcclxuICAgICAgICAgICAgICAgIDpkaXNhYmxlZD1cImRpc2FibGVkRnVuKGl0ZW0uZWRpdERpc2FibGVkKVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiPuS4iuS8oOaWh+S7tjwvZWwtYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPHRlbXBsYXRlICN0aXA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+5paH5Lu25Zyw5Z2AOiZuYnNwOyZuYnNwO3t7IGZvcm1EYXRhW1widXBsb2FkXCJdIH19PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgICAgICAgIDwvZWwtdXBsb2FkPlxyXG4gICAgICAgICAgICAgIDxlbC10b29sdGlwXHJcbiAgICAgICAgICAgICAgICB2LWlmPVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib3gtaXRlbVwiXHJcbiAgICAgICAgICAgICAgICBlZmZlY3Q9XCJkYXJrXCJcclxuICAgICAgICAgICAgICAgIDpjb250ZW50PVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwidG9wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZWwtaWNvbiBzaXplPVwiMjBweFwiIGNsYXNzPVwiaWNvbkJveFwiPlxyXG4gICAgICAgICAgICAgICAgICA8UXVlc3Rpb25GaWxsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvZWwtaWNvbj5cclxuICAgICAgICAgICAgICA8L2VsLXRvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgICAgICA8ZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnZGF0ZSdcIlxyXG4gICAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICAgIDpwcm9wPVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0aW1lQm94XCI+XHJcbiAgICAgICAgICAgICAgICA8ZWwtZGF0ZS1waWNrZXJcclxuICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgICAgIHYtbW9kZWw9XCJmb3JtRGF0YVtpdGVtLm5hbWVdXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA6ZGlzYWJsZWQtZGF0ZT1cInNldERpc2FibGVEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZS1mb3JtYXQ9XCJZWVlZLU1NLUREXCJcclxuICAgICAgICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAgICAgICAgIDpkaXNhYmxlZD1cImRpc2FibGVkRnVuKGl0ZW0uZWRpdERpc2FibGVkKVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxlbC10b29sdGlwXHJcbiAgICAgICAgICAgICAgICB2LWlmPVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib3gtaXRlbVwiXHJcbiAgICAgICAgICAgICAgICBlZmZlY3Q9XCJkYXJrXCJcclxuICAgICAgICAgICAgICAgIDpjb250ZW50PVwiaXRlbS5yZW1hcmtcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwidG9wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZWwtaWNvbiBzaXplPVwiMjBweFwiIGNsYXNzPVwiaWNvbkJveFwiPlxyXG4gICAgICAgICAgICAgICAgICA8UXVlc3Rpb25GaWxsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvZWwtaWNvbj5cclxuICAgICAgICAgICAgICA8L2VsLXRvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgICAgICA8ZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAndGltZVJhbmdlJ1wiXHJcbiAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgOnByb3A9XCJpdGVtLm5hbWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRpbWVCb3hcIj5cclxuICAgICAgICAgICAgICAgIDxlbC1kYXRlLXBpY2tlclxyXG4gICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm1JdGVtXCJcclxuICAgICAgICAgICAgICAgICAgdi1tb2RlbD1cImZvcm1EYXRhW2l0ZW0ubmFtZV1cIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXJhbmdlXCJcclxuICAgICAgICAgICAgICAgICAgOmRpc2FibGVkLWRhdGU9XCJzZXREaXNhYmxlRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJkZWZhdWx0XCJcclxuICAgICAgICAgICAgICAgICAgcmFuZ2Utc2VwYXJhdG9yPVwi6IezXCJcclxuICAgICAgICAgICAgICAgICAgc3RhcnQtcGxhY2Vob2xkZXI9XCLlvIDlp4vml7bpl7RcIlxyXG4gICAgICAgICAgICAgICAgICBlbmQtcGxhY2Vob2xkZXI9XCLnu5PmnZ/ml7bpl7RcIlxyXG4gICAgICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJkaXNhYmxlZEZ1bihpdGVtLmVkaXREaXNhYmxlZClcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZS1mb3JtYXQ9XCJZWVlZLU1NLUREXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGVsLXRvb2x0aXBcclxuICAgICAgICAgICAgICAgIHYtaWY9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJveC1pdGVtXCJcclxuICAgICAgICAgICAgICAgIGVmZmVjdD1cImRhcmtcIlxyXG4gICAgICAgICAgICAgICAgOmNvbnRlbnQ9XCJpdGVtLnJlbWFya1wiXHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJ0b3BcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxlbC1pY29uIHNpemU9XCIyMHB4XCIgY2xhc3M9XCJpY29uQm94XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxRdWVzdGlvbkZpbGxlZCAvPlxyXG4gICAgICAgICAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICAgICAgICAgIDwvZWwtdG9vbHRpcD5cclxuICAgICAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgICAgIDxlbC1mb3JtLWl0ZW1cclxuICAgICAgICAgICAgICB2LWVsc2UtaWY9XCJpdGVtLnR5cGUgPT09ICdmbG93Q2hhcnQnXCJcclxuICAgICAgICAgICAgICA6bGFiZWw9XCJpdGVtLmxhYmVsXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxlbC1idXR0b24gQGNsaWNrPVwib3BlbkZsb3dDaGFydFwiIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgID7miZPlvIDnlLvluIM8L2VsLWJ1dHRvblxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICA8L2VsLXJvdz5cclxuICAgICAgPC90ZW1wbGF0ZT5cclxuICAgIDwvZWwtZm9ybT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb290ZXJcIj5cclxuICAgICAgPGVsLWJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICBAY2xpY2s9XCJhZGQocnVsZUZvcm1SZWYpXCJcclxuICAgICAgICB2LWlmPVwicm91dGUucXVlcnkudHlwZSA9PT0gJ25ldydcIlxyXG4gICAgICA+XHJcbiAgICAgICAg5Yib5bu6XHJcbiAgICAgIDwvZWwtYnV0dG9uPlxyXG4gICAgICA8ZWwtYnV0dG9uXHJcbiAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgIEBjbGljaz1cImVkaXQocnVsZUZvcm1SZWYpXCJcclxuICAgICAgICB2LWlmPVwicm91dGUucXVlcnkudHlwZSA9PT0gJ2VkaXQnXCJcclxuICAgICAgPlxyXG4gICAgICAgIOS/neWtmFxyXG4gICAgICA8L2VsLWJ1dHRvbj5cclxuICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJqdW1wVG9MaXN0XCI+6L+U5ZuePC9lbC1idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8ZGl2IGNsYXNzPVwiZnVsbERpYUxvZ1wiPlxyXG4gICAgPGVsLWRpYWxvZ1xyXG4gICAgICBmdWxsc2NyZWVuXHJcbiAgICAgIHYtbW9kZWw9XCJkaWFsb2dGbG93Q2hhcnRcIlxyXG4gICAgICB0aXRsZT1cIuWunuS9k+aooeWei+WbvlwiXHJcbiAgICAgIDpiZWZvcmUtY2xvc2U9XCJoYW5kbGVDbG9zZVwiXHJcbiAgICA+XHJcbiAgICAgIDxHbG9iYWxGbG93IHJlZj1cImdsb2JhbEZsb3dcIj48L0dsb2JhbEZsb3c+XHJcbiAgICAgIDx0ZW1wbGF0ZSAjZm9vdGVyPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwiZGlhbG9nLWZvb3RlclwiPlxyXG4gICAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJkaWFsb2dGbG93Q2hhcnQgPSBmYWxzZVwiPui/lOWbnjwvZWwtYnV0dG9uPlxyXG4gICAgICAgICAgPGVsLWJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIEBjbGljaz1cInNhdmVFbnRpcnlDYW52YXNcIlxyXG4gICAgICAgICAgICB2LWlmPVwicm91dGUucXVlcnkudHlwZSAhPT0gJ2RldGFpbCdcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICDkv53lrZhcclxuICAgICAgICAgIDwvZWwtYnV0dG9uPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC90ZW1wbGF0ZT5cclxuICAgIDwvZWwtZGlhbG9nPlxyXG4gIDwvZGl2PlxyXG48L3RlbXBsYXRlPlxyXG48c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgeyBlbnZuYW1lIH0gZnJvbSBcIkAvamF2YXNjcmlwdC9lbnZuYW1lXCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciwgdXNlUm91dGUgfSBmcm9tIFwidnVlLXJvdXRlclwiO1xyXG5pbXBvcnQgcmVxdWVzdCBmcm9tIFwiQC91dGlscy9yZXF1ZXN0VXRpbHNcIjtcclxuaW1wb3J0IHsgbmV4dFRpY2ssIG9uTW91bnRlZCwgcmVhY3RpdmUgfSBmcm9tIFwidnVlXCI7XHJcbmltcG9ydCB7IEVsTWVzc2FnZSB9IGZyb20gXCJlbGVtZW50LXBsdXNcIjtcclxuaW1wb3J0IEdsb2JhbEZsb3cgZnJvbSBcIkAvY29tcG9uZW50cy9nbG9iYWxGbG93LnZ1ZVwiO1xyXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpO1xyXG5sZXQgdGVtcGxhdGVMaXN0ID0gcmVmKFtdKTtcclxubGV0IGZvcm1EYXRhID0gcmVhY3RpdmUoe30pO1xyXG5sZXQgcnVsZXMgPSByZWFjdGl2ZSh7fSk7XHJcbmxldCBmaWxlTGlzdCA9IHJlZihbXSk7XHJcbmxldCBydWxlRm9ybVJlZiA9IHJlZihudWxsKTtcclxubGV0IGRpYWxvZ0Zsb3dDaGFydCA9IHJlZihmYWxzZSk7XHJcbmxldCBnbG9iYWxGbG93ID0gcmVmKG51bGwpO1xyXG5jb25zdCByZXFUZW1wbGF0ZSA9ICgpID0+IHtcclxuICByZXF1ZXN0XHJcbiAgICAucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3B1YmxpY0Zvcm0vdGVtcGxhdGVgLCB7XHJcbiAgICAgIHR5cGU6IHJvdXRlLnF1ZXJ5Lm1vZGUsXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgIHRlbXBsYXRlTGlzdC52YWx1ZSA9IHJlcy5kYXRhO1xyXG4gICAgICAgIC8v57uE57uH5pWw5o2uXHJcbiAgICAgICAgdGVtcGxhdGVMaXN0LnZhbHVlLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGl0ZW0uZm9ybUxpc3QuZm9yRWFjaCgodmFsKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh2YWwub3B0aW9uc1NvdXJjZSAmJiB2YWwub3B0aW9uc1NvdXJjZSA9PT0gXCJyZXF1ZXN0XCIpIHtcclxuICAgICAgICAgICAgICByZXF1ZXN0T1B0aW9ucyh2YWwpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8v6KGo5Y2V5pWw5o2u5rGH5oC7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhW3ZhbC5uYW1lXSA9IHZhbC5kZWZhdWx0O1xyXG4gICAgICAgICAgICBpZiAodmFsLnJ1bGUpIHtcclxuICAgICAgICAgICAgICBsZXQgaW5kZXggPSB2YWwucnVsZS5maW5kSW5kZXgoKHopID0+IHoucGF0dGVybik7XHJcbiAgICAgICAgICAgICAgLy/ljLnphY3mraPliJlcclxuICAgICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICB2YWwucnVsZVtpbmRleF0ucGF0dGVybiA9IG5ldyBSZWdFeHAodmFsLnJ1bGVbaW5kZXhdLnBhdHRlcm4pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvL+ihqOWNleadg+mZkOaxh+aAu1xyXG4gICAgICAgICAgICAgIHJ1bGVzW3ZhbC5uYW1lXSA9IHZhbC5ydWxlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zb2xlLmxvZyhyb3V0ZS5xdWVyeS51dWlkLCBcInV1aWTnmoTlgLxcIik7XHJcbiAgICAgICAgaWYgKHJvdXRlLnF1ZXJ5LnR5cGUgIT09IFwibmV3XCIpIHtcclxuICAgICAgICAgIHJlcUZvcm1EYXRhKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIEVsTWVzc2FnZSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxufTtcclxuY29uc3QgcmVxRm9ybURhdGEgPSAoKSA9PiB7XHJcbiAgbGV0IHF1ZXJ5ID0ge1xyXG4gICAgdXVpZDogcm91dGUucXVlcnkudXVpZCxcclxuICAgIG1vZGU6IHJvdXRlLnF1ZXJ5Lm1vZGUsXHJcbiAgfTtcclxuICByZXF1ZXN0LnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC9wdWJsaWNBcGkvZGV0YWlsYCwgcXVlcnkpLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgZm9yIChsZXQgdmFsIGluIHJlcy5kYXRhKSB7XHJcbiAgICAgICAgZm9ybURhdGFbdmFsXSA9IHJlcy5kYXRhW3ZhbF07XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9KTtcclxufTtcclxuY29uc3Qgc2V0RGlzYWJsZURhdGUgPSAodGltZSkgPT4ge1xyXG4gIHJldHVybiB0aW1lLmdldFRpbWUoKSA8IERhdGUubm93KCk7XHJcbn07XHJcblxyXG5jb25zdCByZXF1ZXN0T1B0aW9ucyA9IChpdGVtKSA9PiB7XHJcbiAgaWYgKGl0ZW0ucmVxdWVzdE1ldGhvZCA9PT0gXCJnZXRcIikge1xyXG4gICAgcmVxdWVzdC5nZXQoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcCR7aXRlbS5yZXF1ZXN0TmFtZX1gKS50aGVuKChyZXMpID0+IHtcclxuICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgICBpdGVtLm9wdGlvbnMgPSByZXMuZGF0YTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBFbE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgbWVzc2FnZTogcmVzLm1lc3NhZ2UsXHJcbiAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnNvbGUubG9nKGl0ZW0sIFwiPz8/LS0t5o6i57SiXCIpO1xyXG4gICAgcmVxdWVzdFxyXG4gICAgICAucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwJHtpdGVtLnJlcXVlc3ROYW1lfWAsIGl0ZW0ucXVlcnkpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgICAgcmVzLmRhdGEuZm9yRWFjaCgodikgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh2KTtcclxuICAgICAgICAgICAgaXRlbS5vcHRpb25zLnB1c2goe1xyXG4gICAgICAgICAgICAgIGxhYmVsOiB2W2Ake2l0ZW0ucXVlcnlbXCJtb2RlXCJdfUNuTmFtZWBdLFxyXG4gICAgICAgICAgICAgIHZhbHVlOiB2LnV1aWQsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIEVsTWVzc2FnZSh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IHJlcy5tZXNzYWdlLFxyXG4gICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfVxyXG59O1xyXG5jb25zdCByZXF1ZXN0RmlsZSA9IChhLCBiKSA9PiB7XHJcbiAgY29uc29sZS5sb2coYSwgYiwgXCLoh6rkuIrkvKDmlofku7ZcIik7XHJcbiAgZm9ybURhdGFbXCJ1cGxvYWRcIl0gPSBcInlvdXR1YmUuY29tXCI7XHJcbn07XHJcbmNvbnN0IGFkZCA9IChydWxlRm9ybVJlZikgPT4ge1xyXG4gIGZvcm1EYXRhLm1vZGUgPSByb3V0ZS5xdWVyeS5tb2RlO1xyXG4gIGlmICghcnVsZUZvcm1SZWYpIHJldHVybjtcclxuICBydWxlRm9ybVJlZi52YWxpZGF0ZSgodmFsaWQsIGZpZWxkcykgPT4ge1xyXG4gICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgIHJlcXVlc3RcclxuICAgICAgICAucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3B1YmxpY0FwaS9hZGRgLCBmb3JtRGF0YSlcclxuICAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgICAgICBFbE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IHJlcy5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAganVtcFRvTGlzdCgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcclxuICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBlZGl0ID0gKHJ1bGVGb3JtUmVmKSA9PiB7XHJcbiAgZm9ybURhdGEubW9kZSA9IHJvdXRlLnF1ZXJ5Lm1vZGU7XHJcbiAgaWYgKCFydWxlRm9ybVJlZikgcmV0dXJuO1xyXG4gIHJ1bGVGb3JtUmVmLnZhbGlkYXRlKCh2YWxpZCwgZmllbGRzKSA9PiB7XHJcbiAgICBpZiAodmFsaWQpIHtcclxuICAgICAgcmVxdWVzdFxyXG4gICAgICAgIC5wb3N0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvcHVibGljQXBpL2VkaXRgLCBmb3JtRGF0YSlcclxuICAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgICAgICBFbE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IHJlcy5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAganVtcFRvTGlzdCgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcclxuICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBqdW1wVG9MaXN0ID0gKCkgPT4ge1xyXG4gIGxldCBsaXN0ID0gcm91dGUucGF0aC5zcGxpdChcIi9cIik7XHJcbiAgbGlzdC5wb3AoKTtcclxuICBsaXN0LnB1c2goYCR7bGlzdFtsaXN0Lmxlbmd0aCAtIDFdfUxpc3RgKTtcclxuICBsZXQgcGF0aCA9IGxpc3Quam9pbihcIi9cIik7XHJcbiAgcm91dGVyLnB1c2goe1xyXG4gICAgcGF0aCxcclxuICB9KTtcclxufTtcclxuY29uc3QgZGlzYWJsZWRGdW4gPSAoZmxhZykgPT4ge1xyXG4gIGlmIChcclxuICAgIHJvdXRlLnF1ZXJ5LnR5cGUgPT09IFwiZGV0YWlsXCIgfHxcclxuICAgIChyb3V0ZS5xdWVyeS50eXBlICE9PSBcIm5ld1wiICYmIGZsYWcgPT09IHRydWUpXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufTtcclxuY29uc3Qgb3BlbkZsb3dDaGFydCA9ICgpID0+IHtcclxuICBkaWFsb2dGbG93Q2hhcnQudmFsdWUgPSB0cnVlO1xyXG4gIGNvbnNvbGUubG9nKGdsb2JhbEZsb3csIFwi57uE5Lu2XCIpO1xyXG4gIG5leHRUaWNrKCgpID0+IHtcclxuICAgIGdsb2JhbEZsb3cudmFsdWUuY2FudmFzSW5pdChmb3JtRGF0YS5mbG93Q2hhcnQpO1xyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBoYW5kbGVDbG9zZSA9ICgpID0+IHtcclxuICBkaWFsb2dGbG93Q2hhcnQudmFsdWUgPSBmYWxzZTtcclxufTtcclxuY29uc3Qgc2F2ZUVudGlyeUNhbnZhcyA9ICgpID0+IHtcclxuICBmb3JtRGF0YS5mbG93Q2hhcnQgPSBnbG9iYWxGbG93LnZhbHVlLm5vZGVMaXN0O1xyXG4gIGRpYWxvZ0Zsb3dDaGFydC52YWx1ZSA9IGZhbHNlO1xyXG59O1xyXG5vbk1vdW50ZWQoKCkgPT4ge1xyXG4gIHJlcVRlbXBsYXRlKCk7XHJcbn0pO1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4ubWFpbkJveCB7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBwYWRkaW5nLWJvdHRvbTogNTBweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gIC50ZW0ge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgaDQge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICB9XHJcblxyXG4gIC5mb3JtSXRlbSB7XHJcbiAgICB3aWR0aDogNDgwcHg7XHJcbiAgICAvLyBtYXJnaW46IDIwcHg7XHJcbiAgICAvLyBkaXNwbGF5OiBmbGV4O1xyXG4gIH1cclxuICAudGltZUJveCB7XHJcbiAgICB3aWR0aDogNDgwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gIH1cclxuXHJcbiAgOjp2LWRlZXAoLmVsLWZvcm0taXRlbV9fY29udGVudCkge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtd3JhcDogbm93cmFwO1xyXG4gIH1cclxuXHJcbiAgLmljb25Cb3gge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG5cclxuICAuZm9vdGVyIHtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDMwcHg7XHJcbiAgICBsZWZ0OiAwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMjBweDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgfVxyXG59XHJcbi5mdWxsRGlhTG9nIHtcclxuICA6OnYtZGVlcCguZWwtZGlhbG9nX19oZWFkZXIpIHtcclxuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICA6OnYtZGVlcCguZWwtZGlhbG9nX19ib2R5KSB7XHJcbiAgICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuPC9zdHlsZT4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9nbG9iYWxGbG93LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTVmN2YxZDAxJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9nbG9iYWxGbG93LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTVmN2YxZDAxJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2dsb2JhbEZvcm1JbmZvLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTI2MmQ5N2U1Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9nbG9iYWxGb3JtSW5mby52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yNjJkOTdlNSZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9nbG9iYWxGbG93LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD01ZjdmMWQwMSZzY29wZWQ9dHJ1ZVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL2dsb2JhbEZsb3cudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vZ2xvYmFsRmxvdy52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vZ2xvYmFsRmxvdy52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD01ZjdmMWQwMSZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCJEOlxcXFzpobnnm65cXFxcd2VicGFjay12dWVcXFxcd2VicGFjay0tLS12dWVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1sb2FkZXJcXFxcZGlzdFxcXFxleHBvcnRIZWxwZXIuanNcIlxuY29uc3QgX19leHBvcnRzX18gPSAvKiNfX1BVUkVfXyovZXhwb3J0Q29tcG9uZW50KHNjcmlwdCwgW1sncmVuZGVyJyxyZW5kZXJdLFsnX19zY29wZUlkJyxcImRhdGEtdi01ZjdmMWQwMVwiXSxbJ19fZmlsZScsXCJzcmMvY29tcG9uZW50cy9nbG9iYWxGbG93LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCI1ZjdmMWQwMVwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzVmN2YxZDAxJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnNWY3ZjFkMDEnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2dsb2JhbEZsb3cudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTVmN2YxZDAxJnNjb3BlZD10cnVlXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJzVmN2YxZDAxJywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9nbG9iYWxGb3JtSW5mby52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MjYyZDk3ZTUmc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9nbG9iYWxGb3JtSW5mby52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9nbG9iYWxGb3JtSW5mby52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vZ2xvYmFsRm9ybUluZm8udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MjYyZDk3ZTUmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtMjYyZDk3ZTVcIl0sWydfX2ZpbGUnLFwic3JjL2NvbXBvbmVudHMvZ2xvYmFsRm9ybUluZm8udnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcIjI2MmQ5N2U1XCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnMjYyZDk3ZTUnLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCcyNjJkOTdlNScsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vZ2xvYmFsRm9ybUluZm8udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTI2MmQ5N2U1JnNjb3BlZD10cnVlXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJzI2MmQ5N2U1JywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9nbG9iYWxGbG93LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZ2xvYmFsRmxvdy52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZ2xvYmFsRm9ybUluZm8udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9nbG9iYWxGb3JtSW5mby52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2dsb2JhbEZsb3cudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTVmN2YxZDAxJnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZ2xvYmFsRm9ybUluZm8udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTI2MmQ5N2U1JnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9nbG9iYWxGbG93LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTVmN2YxZDAxJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vZ2xvYmFsRm9ybUluZm8udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MjYyZDk3ZTUmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiLCJ2YXIgbWFwID0ge1xuXHRcIi4v5LiJ6KeS5b2iLnN2Z1wiOiA5NDgxMyxcblx0XCIuL+aXl+W4nC5zdmdcIjogODYxMSxcblx0XCIuL+agh+azqC5zdmdcIjogNTk2MjEsXG5cdFwiLi/mpK3lnIYuc3ZnXCI6IDIxNTEyLFxuXHRcIi4v5rOo5oSPLnN2Z1wiOiAxMjQxLFxuXHRcIi4v5riF6ZmkLnN2Z1wiOiA5MTg2Myxcblx0XCIuL+efqeW9oi5zdmdcIjogMzUzMTgsXG5cdFwiLi/nrJQuc3ZnXCI6IDEyOSxcblx0XCIuL+iMg+WbtC5zdmdcIjogNzg2MzgsXG5cdFwiLi/ov57mjqUuc3ZnXCI6IDQzMTI3LFxuXHRcIi4v6YeN572uLnN2Z1wiOiAyNjQ4MFxufTtcblxuXG5mdW5jdGlvbiB3ZWJwYWNrQ29udGV4dChyZXEpIHtcblx0dmFyIGlkID0gd2VicGFja0NvbnRleHRSZXNvbHZlKHJlcSk7XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKGlkKTtcbn1cbmZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0UmVzb2x2ZShyZXEpIHtcblx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhtYXAsIHJlcSkpIHtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0cmV0dXJuIG1hcFtyZXFdO1xufVxud2VicGFja0NvbnRleHQua2V5cyA9IGZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0S2V5cygpIHtcblx0cmV0dXJuIE9iamVjdC5rZXlzKG1hcCk7XG59O1xud2VicGFja0NvbnRleHQucmVzb2x2ZSA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZTtcbm1vZHVsZS5leHBvcnRzID0gd2VicGFja0NvbnRleHQ7XG53ZWJwYWNrQ29udGV4dC5pZCA9IDk1MjE5OyJdLCJuYW1lcyI6WyJhbGxDb25maWciLCJsZW5nZW5kTGlzdCIsIm5hbWUiLCJ0aXRsZSIsInN2Z05hbWUiLCJ1dGlsc0xpc3QiLCJ2NCIsInV1aWR2NCIsImNyZWF0ZVJlY3RGaWxsIiwicG9zaXRpb24iLCJ4IiwieSIsIndpZHRoIiwiaGVpZ2h0IiwiY29sb3IiLCJtb2RlVHlwZSIsInN0eWxlVHlwZSIsImlkIiwibm9kZUluZGV4IiwiZnJvbUxpc3QiLCJ0YXJnZXRMaXN0IiwidGV4dCIsImluZm8iLCJjcmVhdGVUcmVlQm94IiwieDEiLCJ5MSIsIngyIiwieTIiLCJ4MyIsInkzIiwiY3JlYXRlUmVjdFN0cm9rZSIsImNyZWF0ZUFyY1N0cm9rZSIsImFyY1NpemUiLCJjcmVhdGVMaW5rTGluZSIsImZyb21YIiwiZnJvbVkiLCJ0YXJnZXRYIiwidGFyZ2V0WSIsImxpbmVXaWR0aCIsImNyZWF0ZVRleHQiLCJjb25zb2xlIiwibG9nIiwidGV4dFgiLCJ0ZXh0WSIsIl9jcmVhdGVFbGVtZW50Vk5vZGUiLCJzdHlsZSIsIl9jcmVhdGVFbGVtZW50QmxvY2siLCJfaG9pc3RlZF8xIiwiX2hvaXN0ZWRfMiIsIl9ob2lzdGVkXzMiLCJfaG9pc3RlZF80IiwiX2NyZWF0ZVZOb2RlIiwiX2NvbXBvbmVudF9lbF9yb3ciLCIkc2V0dXAiLCJvblN0YXJ0IiwibW92ZVN0YXJ0Iiwib25FbmQiLCJtb3ZlRW5kIiwiJGV2ZW50Iiwib3B0aW9ucyIsImRyYWdPcHRpb25zIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJsZWdlbmRJdGVtIiwibGVuZ2VuZEluZGV4IiwiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF9lbF9jb2wiLCJzcGFuIiwia2V5IiwiX25vcm1hbGl6ZUNsYXNzIiwibGVuZ2VuZENsYXNzIiwibm9kZV90eXBlIiwib25Nb3VzZWRvd24iLCJjbGlja0xlbmdlbmQiLCJzcmMiLCJyZXF1aXJlIiwiY29uY2F0IiwiYWx0IiwiX3RvRGlzcGxheVN0cmluZyIsIl9ob2lzdGVkXzciLCJ1dGlsTmFtZSIsImlzTW9kZSIsImNhbnZhc0Rvd24iLCJvbk1vdXNldXAiLCJjYW52YXNVcCIsIm9uTW91c2Vtb3ZlIiwiY2FudmFzTW92ZSIsIm9uQ2xpY2siLCJjbGlja0NhbnZhcyIsIl9ub3JtYWxpemVTdHlsZSIsImJhY2tncm91bmQiLCJjYW52YXNTdHlsZUluZm8iLCJfaG9pc3RlZF8xMCIsIl9ob2lzdGVkXzExIiwiX2hvaXN0ZWRfMTIiLCJfY29tcG9uZW50X2VsX2NvbG9yX3BpY2tlciIsImRpc2FibGVkIiwicm91dGUiLCJxdWVyeSIsInR5cGUiLCJfaG9pc3RlZF8xMyIsIl9ob2lzdGVkXzE0IiwiX2NvbXBvbmVudF9lbF9pbnB1dCIsImltYWdlTmFtZSIsInBsYWNlaG9sZGVyIiwiX2NvbXBvbmVudF9lbF9idXR0b24iLCJkb3duTG9hZCIsIl9jcmVhdGVDb21tZW50Vk5vZGUiLCJhY3RpdmVOb2RlSW5mbyIsIm5vZGVMaXN0IiwibGVuZ3RoIiwiX2hvaXN0ZWRfMTUiLCJfaG9pc3RlZF8xNiIsIm9uQWN0aXZlQ2hhbmdlIiwiY2hhbmdlTm9kZVRoZW1lQ29sb3IiLCJfaG9pc3RlZF8xNyIsIl9ob2lzdGVkXzE4IiwiY2hhbmdlTm9kZVRleHRDb2xvciIsIl9ob2lzdGVkXzE5IiwiX2hvaXN0ZWRfMjAiLCJvbklucHV0IiwiY2hhbmdlTm9kZVRleHRJbmZvIiwiX2hvaXN0ZWRfMjEiLCJkZWxldGVMaW5lIiwiX2hvaXN0ZWRfMjIiLCJkZWxldGVOb2RlIiwib25CbHVyIiwic2F2ZVRleHRhcmVhVmFsdWUiLCJ0ZXh0YXJlYUNsYXNzIiwidGV4dGFyZWFWYWx1ZSIsIm1heGxlbmd0aCIsInJvd3MiLCJ0ZXh0YXJlYVNob3ciLCJfY29tcG9uZW50X2VsX2Zvcm0iLCJyZWYiLCJtb2RlbCIsImZvcm1EYXRhIiwicnVsZXMiLCJ0ZW1wbGF0ZUxpc3QiLCJJdGVtIiwiSW5kZXgiLCJmb3JtTGlzdCIsIml0ZW0iLCJpbmRleCIsIl9jb21wb25lbnRfZWxfZm9ybV9pdGVtIiwibGFiZWwiLCJwcm9wIiwiY2xlYXJhYmxlIiwiZGlzYWJsZWRGdW4iLCJlZGl0RGlzYWJsZWQiLCJyZW1hcmsiLCJfY29tcG9uZW50X2VsX3Rvb2x0aXAiLCJlZmZlY3QiLCJjb250ZW50IiwicGxhY2VtZW50IiwiX2NvbXBvbmVudF9lbF9pY29uIiwic2l6ZSIsIl9jb21wb25lbnRfUXVlc3Rpb25GaWxsZWQiLCJfY29tcG9uZW50X2VsX3NlbGVjdCIsIm0iLCJuIiwiX2NvbXBvbmVudF9lbF9vcHRpb24iLCJ2YWx1ZSIsIl9jb21wb25lbnRfZWxfcmFkaW9fZ3JvdXAiLCJfY29tcG9uZW50X2VsX3JhZGlvIiwibXVsdGlwbGUiLCJfY29tcG9uZW50X2VsX3VwbG9hZCIsInJlcXVlc3RGaWxlIiwibGltaXQiLCJ0aXAiLCJfd2l0aEN0eCIsIl9jb21wb25lbnRfZWxfZGF0ZV9waWNrZXIiLCJzZXREaXNhYmxlRGF0ZSIsIm9wZW5GbG93Q2hhcnQiLCJfaG9pc3RlZF81IiwiX2NhY2hlIiwiYWRkIiwicnVsZUZvcm1SZWYiLCJlZGl0IiwianVtcFRvTGlzdCIsIl9ob2lzdGVkXzYiLCJfY29tcG9uZW50X2VsX2RpYWxvZyIsImZ1bGxzY3JlZW4iLCJkaWFsb2dGbG93Q2hhcnQiLCJoYW5kbGVDbG9zZSIsImZvb3RlciIsInNhdmVFbnRpcnlDYW52YXMiXSwic291cmNlUm9vdCI6IiJ9