"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_permission_index_vue"],{

/***/ 2845:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".contentBox[data-v-085a47d4] {\n  height: 100%;\n}\n[data-v-085a47d4] .el-tabs--border-card {\n  border-bottom: none !important;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/permission/index.vue","webpack://./index.vue"],"names":[],"mappings":"AACA;EACE,YAAA;ACAF;ADEA;EACE,8BAAA;ACAF","sourcesContent":["\n.contentBox {\n  height: 100%;\n}\n::v-deep(.el-tabs--border-card) {\n  border-bottom: none !important;\n}\n",".contentBox {\n  height: 100%;\n}\n::v-deep(.el-tabs--border-card) {\n  border-bottom: none !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 51105:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".roleBox[data-v-5cd168e2] {\n  position: relative;\n  padding-top: 30px;\n}\n.roleBox p[data-v-5cd168e2] {\n  color: #fd1030;\n  position: absolute;\n  top: 0px;\n  left: 10px;\n}\n.roleBox .saveBtn[data-v-5cd168e2] {\n  position: absolute;\n  right: 10px;\n  top: 0px;\n}\n.columnBox[data-v-5cd168e2] {\n  border: 1px solid #e6e8ec;\n  border-top: none;\n  padding: 10px;\n}\n.doneBox[data-v-5cd168e2] {\n  border: 1px solid #e6e8ec;\n  height: 40px;\n  line-height: 39px;\n}\n.doneTypeClass[data-v-5cd168e2] {\n  margin-right: 20px;\n  display: inline-block;\n}\n.vxe-header--column[data-v-5cd168e2] {\n  height: 50px !important;\n}\n[data-v-5cd168e2] .vxe-body--column {\n  padding: 0px !important;\n}\n[data-v-5cd168e2] .vxe-cell {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/permission/role.vue","webpack://./role.vue"],"names":[],"mappings":"AACA;EACE,kBAAA;EACA,iBAAA;ACAF;ADFA;EAII,cAAA;EACA,kBAAA;EACA,QAAA;EACA,UAAA;ACCJ;ADRA;EAUI,kBAAA;EACA,WAAA;EACA,QAAA;ACCJ;ADEA;EACE,yBAAA;EACA,gBAAA;EACA,aAAA;ACAF;ADEA;EACE,yBAAA;EACA,YAAA;EACA,iBAAA;ACAF;ADEA;EACE,kBAAA;EACA,qBAAA;ACAF;ADEA;EACE,uBAAA;ACAF;ADEA;EACE,uBAAA;ACAF;ADEA;EACE,4BAAA;EACA,6BAAA;ACAF","sourcesContent":["\n.roleBox {\n  position: relative;\n  padding-top: 30px;\n  p {\n    color: #fd1030;\n    position: absolute;\n    top: 0px;\n    left: 10px;\n  }\n  .saveBtn {\n    position: absolute;\n    right: 10px;\n    top: 0px;\n  }\n}\n.columnBox {\n  border: 1px solid #e6e8ec;\n  border-top: none;\n  padding: 10px;\n}\n.doneBox {\n  border: 1px solid #e6e8ec;\n  height: 40px;\n  line-height: 39px;\n}\n.doneTypeClass {\n  margin-right: 20px;\n  display: inline-block;\n}\n.vxe-header--column {\n  height: 50px !important;\n}\n::v-deep(.vxe-body--column) {\n  padding: 0px !important;\n}\n::v-deep(.vxe-cell) {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n}\n",".roleBox {\n  position: relative;\n  padding-top: 30px;\n}\n.roleBox p {\n  color: #fd1030;\n  position: absolute;\n  top: 0px;\n  left: 10px;\n}\n.roleBox .saveBtn {\n  position: absolute;\n  right: 10px;\n  top: 0px;\n}\n.columnBox {\n  border: 1px solid #e6e8ec;\n  border-top: none;\n  padding: 10px;\n}\n.doneBox {\n  border: 1px solid #e6e8ec;\n  height: 40px;\n  line-height: 39px;\n}\n.doneTypeClass {\n  margin-right: 20px;\n  display: inline-block;\n}\n.vxe-header--column {\n  height: 50px !important;\n}\n::v-deep(.vxe-body--column) {\n  padding: 0px !important;\n}\n::v-deep(.vxe-cell) {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 37684:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".mainBox .search[data-v-10a00ff5] {\n  display: flex;\n}\n.mainBox .search .searchItem[data-v-10a00ff5] {\n  margin-right: 10px;\n}\n.mainBox .search .searchItem .searchLable[data-v-10a00ff5] {\n  margin: 0 10px;\n}\n.mainBox .tableBox[data-v-10a00ff5] {\n  margin-top: 20px;\n  height: 560px;\n}\np[data-v-10a00ff5] {\n  text-align: center;\n}\np .modelItem[data-v-10a00ff5] {\n  width: 200px;\n  margin: 10px 20px;\n}\n.footer[data-v-10a00ff5] {\n  margin-top: 10px;\n  display: flex;\n  justify-content: flex-end;\n}\n.footer .btn[data-v-10a00ff5] {\n  width: 60px;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/permission/userList.vue","webpack://./userList.vue"],"names":[],"mappings":"AACA;EAEI,aAAA;ACDJ;ADDA;EAKM,kBAAA;ACDN;ADJA;EAQQ,cAAA;ACDR;ADPA;EAcI,gBAAA;EACA,aAAA;ACJJ;ADOA;EACE,kBAAA;ACLF;ADIA;EAGI,YAAA;EACA,iBAAA;ACJJ;ADOA;EACE,gBAAA;EACA,aAAA;EACA,yBAAA;ACLF;ADEA;EAKI,WAAA;ACJJ","sourcesContent":["\n.mainBox {\n  .search {\n    display: flex;\n\n    .searchItem {\n      margin-right: 10px;\n\n      .searchLable {\n        margin: 0 10px;\n      }\n    }\n  }\n\n  .tableBox {\n    margin-top: 20px;\n    height: 560px;\n  }\n}\np {\n  text-align: center;\n  .modelItem {\n    width: 200px;\n    margin: 10px 20px;\n  }\n}\n.footer {\n  margin-top: 10px;\n  display: flex;\n  justify-content: flex-end;\n  .btn {\n    width: 60px;\n  }\n}\n",".mainBox .search {\n  display: flex;\n}\n.mainBox .search .searchItem {\n  margin-right: 10px;\n}\n.mainBox .search .searchItem .searchLable {\n  margin: 0 10px;\n}\n.mainBox .tableBox {\n  margin-top: 20px;\n  height: 560px;\n}\np {\n  text-align: center;\n}\np .modelItem {\n  width: 200px;\n  margin: 10px 20px;\n}\n.footer {\n  margin-top: 10px;\n  display: flex;\n  justify-content: flex-end;\n}\n.footer .btn {\n  width: 60px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 66742:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/index.vue?vue&type=script&setup=true&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _userList_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./userList.vue */ 83874);
/* harmony import */ var _role_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./role.vue */ 57372);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'index',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var __returned__ = {
      UserList: _userList_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
      Role: _role_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 40594:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/role.vue?vue&type=script&setup=true&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'role',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var tableData = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    var changeCheck1 = function changeCheck1(val, row) {
      val.indeterminate = false;
      var index = row["doneName"].findIndex(function (item) {
        return item[0].parent === val.name;
      });
      row["doneName"][index].map(function (v) {
        return v.flag = val.flag;
      });
      //  changeList()
    };

    var changeCheck2 = function changeCheck2(val, row) {
      console.log(val, row, "???");
      var index = row["doneName"].findIndex(function (item) {
        return item[0].parent === val.parent;
      });
      var list = row["doneName"][index];
      var parentIndex = row.menuName.findIndex(function (item) {
        return item.name === val.parent;
      });
      var parentItem = row.menuName[parentIndex];
      if (list.every(function (item) {
        return item.flag === true;
      })) {
        parentItem.flag = true;
        parentItem.indeterminate = false;
      } else if (list.every(function (item) {
        return item.flag === false;
      })) {
        parentItem.flag = false;
        parentItem.indeterminate = false;
      } else if (list.some(function (item) {
        return item.flag === true;
      })) {
        parentItem.flag = false;
        parentItem.indeterminate = true;
      }
      // changeList()
    };

    var reqList = function reqList() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/userRole/roleList")).then(function (res) {
        if (res.code === 200) {
          tableData.value = res.data;
        }
      });
    };
    var changeList = function changeList() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/userRole/updateRole"), {
        data: tableData.value
      }).then(function (res) {
        if (res.code === 200) {
          (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
            reqList();
          });
        }
      });
    };
    reqList();
    (0,vue__WEBPACK_IMPORTED_MODULE_2__.onMounted)(function () {});
    (0,vue__WEBPACK_IMPORTED_MODULE_2__.onBeforeUnmount)(function () {
      // changeList()
    });
    var __returned__ = {
      tableData: tableData,
      changeCheck1: changeCheck1,
      changeCheck2: changeCheck2,
      reqList: reqList,
      changeList: changeList,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"];
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 10838:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/userList.vue?vue&type=script&setup=true&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);




//角色列表

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'userList',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var roleList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    var reqRoleList = function reqRoleList() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_0__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_1__.envname.apiUrl, "/app/userRole/roleList")).then(function (res) {
        if (res.code === 200) {
          roleList.value = res.data;
          roleList.value.unshift({
            name: "",
            cname: "全部"
          });
          reqList();
        }
      });
    };
    var getRoleValue = function getRoleValue(val) {
      var value = roleList.value.find(function (item) {
        return item.name === val;
      });
      if (value) {
        return value.cname;
      }
      //   return roleList.value.find(item=>item.name === val)['cname']
      return val;
    };
    reqRoleList();

    //查询列表
    var query = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({
      userName: "",
      name: "",
      role: ""
    });
    var pageInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({
      currentPage: 1,
      pageSize: 10
    });
    var total = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(8);
    var tableData = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    var reqList = function reqList() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_0__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_1__.envname.apiUrl, "/app/userRole/userlist"), {
        query: query,
        pageInfo: pageInfo
      }).then(function (res) {
        if (res.code === 200) {
          tableData.value = res.data.list;
          total.value = res.data.total;
        }
      });
    };
    var rowInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({});
    var visiable = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false);
    var openDia = function openDia(row) {
      rowInfo.value = row;
      visiable.value = true;
    };
    var saveRole = function saveRole() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_0__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_1__.envname.apiUrl, "/app/userRole/updateUserRole"), {
        data: rowInfo.value
      }).then(function (res) {
        if (res.code === 200) {
          visiable.value = false;
          (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
            reqList();
          });
        }
      });
    };
    var __returned__ = {
      roleList: roleList,
      reqRoleList: reqRoleList,
      getRoleValue: getRoleValue,
      query: query,
      pageInfo: pageInfo,
      total: total,
      tableData: tableData,
      reqList: reqList,
      rowInfo: rowInfo,
      visiable: visiable,
      openDia: openDia,
      saveRole: saveRole,
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_0__["default"];
      },
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_1__.envname;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 89428:
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/index.vue?vue&type=template&id=085a47d4&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-085a47d4"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "contentBox"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_tab_pane = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-tab-pane");
  var _component_el_tabs = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-tabs");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tabs, {
    type: "border-card"
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tab_pane, {
        label: "用户列表"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["UserList"])];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tab_pane, {
        label: "角色管理"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["Role"])];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  })]);
}

/***/ }),

/***/ 13467:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/role.vue?vue&type=template&id=5cd168e2&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-5cd168e2"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "roleBox"
};
var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, "*超级管理员拥有全部的权限,并且不可更改", -1 /* HOISTED */);
});

function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_vxe_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-button");
  var _component_vxe_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-column");
  var _component_vxe_checkbox = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-checkbox");
  var _component_vxe_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-table");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [_hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_button, {
    type: "text",
    status: "primary",
    content: "保存",
    onClick: $setup.changeList,
    "class": "saveBtn"
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_table, {
    align: 'center',
    data: $setup.tableData
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        field: "cname",
        title: "角色名称",
        width: "300"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (_ref) {
          var row = _ref.row;
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(row.cname), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        field: "menuName",
        title: "菜单名称",
        width: "300"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (_ref2) {
          var row = _ref2.row;
          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(row.menuName, function (item, index) {
            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
              "class": "doneBox",
              key: index
            }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_checkbox, {
              modelValue: item.flag,
              "onUpdate:modelValue": function onUpdateModelValue($event) {
                return item.flag = $event;
              },
              content: item.label,
              indeterminate: item.indeterminate,
              onChange: function onChange($event) {
                return $setup.changeCheck1(item, row);
              },
              disabled: item.disabled
            }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "content", "indeterminate", "onChange", "disabled"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <el-checkbox v-model=\"item.flag\" :label=\"item.label\" size=\"large\" /> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" {{ item.label }} ")]);
          }), 128 /* KEYED_FRAGMENT */))];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        field: "doneName",
        title: "操作名称"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (_ref3) {
          var row = _ref3.row;
          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(row.doneName, function (item, index) {
            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
              key: index,
              "class": "doneBox"
            }, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item, function (val, ind) {
              return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
                key: ind,
                "class": "doneTypeClass"
              }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_checkbox, {
                modelValue: val.flag,
                "onUpdate:modelValue": function onUpdateModelValue($event) {
                  return val.flag = $event;
                },
                content: val.label,
                size: "large",
                onChange: function onChange($event) {
                  return $setup.changeCheck2(val, row);
                },
                disabled: val.disabled
              }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue", "content", "onChange", "disabled"])]);
            }), 128 /* KEYED_FRAGMENT */))]);
          }), 128 /* KEYED_FRAGMENT */))];
        }),

        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"])]);
}

/***/ }),

/***/ 59353:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/permission/userList.vue?vue&type=template&id=10a00ff5&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-10a00ff5"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "mainBox"
};
var _hoisted_2 = {
  "class": "search"
};
var _hoisted_3 = {
  "class": "searchItem"
};
var _hoisted_4 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLable"
  }, "用户名:", -1 /* HOISTED */);
});
var _hoisted_5 = {
  "class": "searchItem"
};
var _hoisted_6 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLable"
  }, "用户账号:", -1 /* HOISTED */);
});
var _hoisted_7 = {
  "class": "searchItem"
};
var _hoisted_8 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLable"
  }, "用户角色:", -1 /* HOISTED */);
});
var _hoisted_9 = {
  "class": "searchItem"
};
var _hoisted_10 = {
  "class": "tableBox"
};
var _hoisted_11 = {
  "class": "footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_vxe_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-input");
  var _component_vxe_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-option");
  var _component_vxe_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-select");
  var _component_vxe_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-button");
  var _component_vxe_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-column");
  var _component_vxe_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-table");
  var _component_vxe_pager = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-pager");
  var _component_vxe_modal = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("vxe-modal");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [_hoisted_4, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_input, {
    modelValue: $setup.query.userName,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return $setup.query.userName = $event;
    }),
    placeholder: "输入用户名",
    size: "small",
    type: "search",
    clearable: "",
    onClear: $setup.reqList,
    onSearchClick: $setup.reqList
  }, null, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [_hoisted_6, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_input, {
    modelValue: $setup.query.name,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
      return $setup.query.name = $event;
    }),
    placeholder: "输入用户账号",
    size: "small",
    type: "search",
    clearable: "",
    onClear: $setup.reqList,
    onSearchClick: $setup.reqList
  }, null, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_7, [_hoisted_8, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_select, {
    modelValue: $setup.query.role,
    "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
      return $setup.query.role = $event;
    }),
    placeholder: "选择用户角色",
    size: "small",
    onChange: $setup.reqList
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.roleList, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_vxe_option, {
          key: index,
          value: item.name,
          label: item.cname
        }, null, 8 /* PROPS */, ["value", "label"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_button, {
    status: "primary",
    content: "查询",
    size: "small",
    onClick: $setup.reqList
  })])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_10, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_table, {
    align: 'left',
    data: $setup.tableData
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        field: "userName",
        title: "用户中文名"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        field: "name",
        title: "用户账号"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        title: "用户角色"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (_ref) {
          var row = _ref.row;
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getRoleValue(row.role)), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_column, {
        title: "操作",
        width: "200",
        "show-overflow": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (_ref2) {
          var row = _ref2.row;
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_button, {
            type: "text",
            status: "primary",
            onClick: function onClick($event) {
              return $setup.openDia(row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("编辑")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_pager, {
    background: "",
    "current-page": $setup.pageInfo.currentPage,
    "onUpdate:currentPage": _cache[3] || (_cache[3] = function ($event) {
      return $setup.pageInfo.currentPage = $event;
    }),
    "page-size": $setup.pageInfo.pageSize,
    "onUpdate:pageSize": _cache[4] || (_cache[4] = function ($event) {
      return $setup.pageInfo.pageSize = $event;
    }),
    total: $setup.total,
    layouts: ['PrevJump', 'PrevPage', 'JumpNumber', 'NextPage', 'NextJump', 'Sizes', 'FullJump', 'Total']
  }, null, 8 /* PROPS */, ["current-page", "page-size", "total"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_modal, {
    modelValue: $setup.visiable,
    "onUpdate:modelValue": _cache[8] || (_cache[8] = function ($event) {
      return $setup.visiable = $event;
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 姓名: "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_input, {
        modelValue: $setup.rowInfo.userName,
        "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
          return $setup.rowInfo.userName = $event;
        }),
        disabled: "",
        size: "small",
        "class": "modelItem"
      }, null, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 角色: "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_select, {
        modelValue: $setup.rowInfo.role,
        "onUpdate:modelValue": _cache[6] || (_cache[6] = function ($event) {
          return $setup.rowInfo.role = $event;
        }),
        placeholder: "选择用户角色",
        size: "small",
        "class": "modelItem"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.roleList, function (item, index) {
            return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_vxe_option, {
              key: index,
              value: item.name,
              label: item.cname
            }, null, 8 /* PROPS */, ["value", "label"]);
          }), 128 /* KEYED_FRAGMENT */))];
        }),

        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_11, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_button, {
        size: "small",
        onClick: _cache[7] || (_cache[7] = function ($event) {
          return $setup.visiable = false;
        }),
        "class": "btn"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_vxe_button, {
        status: "primary",
        size: "small",
        onClick: $setup.saveRole,
        "class": "btn"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("确定")];
        }),
        _: 1 /* STABLE */
      })])])];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 49643:
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true */ 2845);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 48915:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less */ 51105);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 26749:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/permission/userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true */ 37684);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 99788:
/*!****************************************!*\
  !*** ./src/pages/permission/index.vue ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_085a47d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=085a47d4&scoped=true */ 56957);
/* harmony import */ var _index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&setup=true&lang=js */ 53837);
/* harmony import */ var _index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true */ 49055);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_index_vue_vue_type_template_id_085a47d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-085a47d4"],['__file',"src/pages/permission/index.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 57372:
/*!***************************************!*\
  !*** ./src/pages/permission/role.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _role_vue_vue_type_template_id_5cd168e2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./role.vue?vue&type=template&id=5cd168e2&scoped=true */ 73304);
/* harmony import */ var _role_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./role.vue?vue&type=script&setup=true&lang=js */ 11466);
/* harmony import */ var _role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less */ 44484);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_role_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_role_vue_vue_type_template_id_5cd168e2_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-5cd168e2"],['__file',"src/pages/permission/role.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 83874:
/*!*******************************************!*\
  !*** ./src/pages/permission/userList.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _userList_vue_vue_type_template_id_10a00ff5_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./userList.vue?vue&type=template&id=10a00ff5&scoped=true */ 73603);
/* harmony import */ var _userList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./userList.vue?vue&type=script&setup=true&lang=js */ 12544);
/* harmony import */ var _userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true */ 33798);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_userList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_userList_vue_vue_type_template_id_10a00ff5_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-10a00ff5"],['__file',"src/pages/permission/userList.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 53837:
/*!***************************************************************************!*\
  !*** ./src/pages/permission/index.vue?vue&type=script&setup=true&lang=js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=script&setup=true&lang=js */ 66742);
 

/***/ }),

/***/ 11466:
/*!**************************************************************************!*\
  !*** ./src/pages/permission/role.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_role_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_role_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./role.vue?vue&type=script&setup=true&lang=js */ 40594);
 

/***/ }),

/***/ 12544:
/*!******************************************************************************!*\
  !*** ./src/pages/permission/userList.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_userList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_userList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./userList.vue?vue&type=script&setup=true&lang=js */ 10838);
 

/***/ }),

/***/ 56957:
/*!**********************************************************************************!*\
  !*** ./src/pages/permission/index.vue?vue&type=template&id=085a47d4&scoped=true ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_085a47d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_085a47d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=template&id=085a47d4&scoped=true */ 89428);


/***/ }),

/***/ 73304:
/*!*********************************************************************************!*\
  !*** ./src/pages/permission/role.vue?vue&type=template&id=5cd168e2&scoped=true ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_role_vue_vue_type_template_id_5cd168e2_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_role_vue_vue_type_template_id_5cd168e2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./role.vue?vue&type=template&id=5cd168e2&scoped=true */ 13467);


/***/ }),

/***/ 73603:
/*!*************************************************************************************!*\
  !*** ./src/pages/permission/userList.vue?vue&type=template&id=10a00ff5&scoped=true ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_userList_vue_vue_type_template_id_10a00ff5_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_userList_vue_vue_type_template_id_10a00ff5_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./userList.vue?vue&type=template&id=10a00ff5&scoped=true */ 59353);


/***/ }),

/***/ 49055:
/*!*************************************************************************************************!*\
  !*** ./src/pages/permission/index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_085a47d4_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=085a47d4&lang=less&scoped=true */ 49643);


/***/ }),

/***/ 44484:
/*!************************************************************************************************!*\
  !*** ./src/pages/permission/role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_role_vue_vue_type_style_index_0_id_5cd168e2_scoped_true_lang_less__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./role.vue?vue&type=style&index=0&id=5cd168e2&scoped=true&lang=less */ 48915);


/***/ }),

/***/ 33798:
/*!****************************************************************************************************!*\
  !*** ./src/pages/permission/userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_userList_vue_vue_type_style_index_0_id_10a00ff5_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./userList.vue?vue&type=style&index=0&id=10a00ff5&lang=less&scoped=true */ 26749);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX3Blcm1pc3Npb25faW5kZXhfdnVlLmRjYTZmMTEzMWY5NTU0ZjhjY2I0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDZ0g7QUFDakI7QUFDL0YsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLHdFQUF3RSxpQkFBaUIsR0FBRywyQ0FBMkMsbUNBQW1DLEdBQUcsU0FBUyx5SEFBeUgsVUFBVSxLQUFLLEtBQUssV0FBVyx3Q0FBd0MsaUJBQWlCLEdBQUcsbUNBQW1DLG1DQUFtQyxHQUFHLGtCQUFrQixpQkFBaUIsR0FBRyxtQ0FBbUMsbUNBQW1DLEdBQUcscUJBQXFCO0FBQ3ZsQjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxxRUFBcUUsdUJBQXVCLHNCQUFzQixHQUFHLCtCQUErQixtQkFBbUIsdUJBQXVCLGFBQWEsZUFBZSxHQUFHLHNDQUFzQyx1QkFBdUIsZ0JBQWdCLGFBQWEsR0FBRywrQkFBK0IsOEJBQThCLHFCQUFxQixrQkFBa0IsR0FBRyw2QkFBNkIsOEJBQThCLGlCQUFpQixzQkFBc0IsR0FBRyxtQ0FBbUMsdUJBQXVCLDBCQUEwQixHQUFHLHdDQUF3Qyw0QkFBNEIsR0FBRyx1Q0FBdUMsNEJBQTRCLEdBQUcsK0JBQStCLGlDQUFpQyxrQ0FBa0MsR0FBRyxTQUFTLHVIQUF1SCxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsV0FBVyxVQUFVLFVBQVUsS0FBSyxLQUFLLFdBQVcsVUFBVSxVQUFVLEtBQUssS0FBSyxXQUFXLFdBQVcsVUFBVSxLQUFLLEtBQUssV0FBVyxVQUFVLFdBQVcsS0FBSyxLQUFLLFdBQVcsV0FBVyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssV0FBVyxXQUFXLHFDQUFxQyx1QkFBdUIsc0JBQXNCLE9BQU8scUJBQXFCLHlCQUF5QixlQUFlLGlCQUFpQixLQUFLLGNBQWMseUJBQXlCLGtCQUFrQixlQUFlLEtBQUssR0FBRyxjQUFjLDhCQUE4QixxQkFBcUIsa0JBQWtCLEdBQUcsWUFBWSw4QkFBOEIsaUJBQWlCLHNCQUFzQixHQUFHLGtCQUFrQix1QkFBdUIsMEJBQTBCLEdBQUcsdUJBQXVCLDRCQUE0QixHQUFHLCtCQUErQiw0QkFBNEIsR0FBRyx1QkFBdUIsaUNBQWlDLGtDQUFrQyxHQUFHLGVBQWUsdUJBQXVCLHNCQUFzQixHQUFHLGNBQWMsbUJBQW1CLHVCQUF1QixhQUFhLGVBQWUsR0FBRyxxQkFBcUIsdUJBQXVCLGdCQUFnQixhQUFhLEdBQUcsY0FBYyw4QkFBOEIscUJBQXFCLGtCQUFrQixHQUFHLFlBQVksOEJBQThCLGlCQUFpQixzQkFBc0IsR0FBRyxrQkFBa0IsdUJBQXVCLDBCQUEwQixHQUFHLHVCQUF1Qiw0QkFBNEIsR0FBRywrQkFBK0IsNEJBQTRCLEdBQUcsdUJBQXVCLGlDQUFpQyxrQ0FBa0MsR0FBRyxxQkFBcUI7QUFDcG5GO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQdkM7QUFDZ0g7QUFDakI7QUFDL0YsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLDZFQUE2RSxrQkFBa0IsR0FBRyxpREFBaUQsdUJBQXVCLEdBQUcsOERBQThELG1CQUFtQixHQUFHLHVDQUF1QyxxQkFBcUIsa0JBQWtCLEdBQUcsc0JBQXNCLHVCQUF1QixHQUFHLGlDQUFpQyxpQkFBaUIsc0JBQXNCLEdBQUcsNEJBQTRCLHFCQUFxQixrQkFBa0IsOEJBQThCLEdBQUcsaUNBQWlDLGdCQUFnQixHQUFHLFNBQVMsK0hBQStILFVBQVUsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsVUFBVSxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssVUFBVSxXQUFXLEtBQUssS0FBSyxXQUFXLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxxQ0FBcUMsYUFBYSxvQkFBb0IscUJBQXFCLDJCQUEyQix3QkFBd0IseUJBQXlCLFNBQVMsT0FBTyxLQUFLLGlCQUFpQix1QkFBdUIsb0JBQW9CLEtBQUssR0FBRyxLQUFLLHVCQUF1QixnQkFBZ0IsbUJBQW1CLHdCQUF3QixLQUFLLEdBQUcsV0FBVyxxQkFBcUIsa0JBQWtCLDhCQUE4QixVQUFVLGtCQUFrQixLQUFLLEdBQUcsdUJBQXVCLGtCQUFrQixHQUFHLGdDQUFnQyx1QkFBdUIsR0FBRyw2Q0FBNkMsbUJBQW1CLEdBQUcsc0JBQXNCLHFCQUFxQixrQkFBa0IsR0FBRyxLQUFLLHVCQUF1QixHQUFHLGdCQUFnQixpQkFBaUIsc0JBQXNCLEdBQUcsV0FBVyxxQkFBcUIsa0JBQWtCLDhCQUE4QixHQUFHLGdCQUFnQixnQkFBZ0IsR0FBRyxxQkFBcUI7QUFDajFEO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTUQ7QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZGlCO0FBQ0o7OztBQUMzQyxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHdDQUFHO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLCtEQUFXLFdBQVcsK0RBQWM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLFVBQVUsNkNBQVE7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4Q0FBUztBQUNiLElBQUksb0RBQWU7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3REFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSwyREFBTztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRjBDO0FBQ0k7OztBQUMvQztBQUNBO0FBQ0EsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQix3Q0FBRztBQUN0QjtBQUNBLE1BQU0sK0RBQVcsV0FBVywrREFBYztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZDQUFRO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLDZDQUFRO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix3Q0FBRztBQUNuQixvQkFBb0Isd0NBQUc7QUFDdkI7QUFDQSxNQUFNLGdFQUFZLFdBQVcsK0RBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHdDQUFHO0FBQ3JCLG1CQUFtQix3Q0FBRztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxnRUFBWSxXQUFXLCtEQUFjO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSw2Q0FBUTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsMkRBQU87QUFDdEI7QUFDQTtBQUNBLGVBQWUsd0RBQU87QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VGcEdNLFNBQU07QUFBWTs7OzsyREFBdkJFLHVEQUFBLENBU00sT0FUTkMsVUFTTSxHQVJKQyxnREFBQSxDQU9VQyxrQkFBQTtJQVBEQyxJQUFJLEVBQUM7RUFBYTs0REFDekI7TUFBQSxPQUVjLENBRmRGLGdEQUFBLENBRWNHLHNCQUFBO1FBRkRDLEtBQUssRUFBQztNQUFNO2dFQUN2QjtVQUFBLE9BQXFCLENBQXJCSixnREFBQSxDQUFxQkssTUFBQTs7O1VBRXZCTCxnREFBQSxDQUVjRyxzQkFBQTtRQUZEQyxLQUFLLEVBQUM7TUFBTTtnRUFDdkI7VUFBQSxPQUFhLENBQWJKLGdEQUFBLENBQWFLLE1BQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUdOZCxTQUFNO0FBQVM7O3NCQUNsQkMsdURBQUEsQ0FBMkIsV0FBeEIsc0JBQW9CO0FBQUE7Ozs7Ozs7MkRBRHpCUix1REFBQSxDQXNETSxPQXRETkMsVUFzRE0sR0FyREpRLFVBQTJCLEVBQzNCUCxnREFBQSxDQU1jUSxxQkFBQTtJQUxaTixJQUFJLEVBQUMsTUFBTTtJQUNYTyxNQUFNLEVBQUMsU0FBUztJQUNoQkMsT0FBTyxFQUFDLElBQUk7SUFDWEMsT0FBSyxFQUFFTixNQUFBLENBQUFPLFVBQVU7SUFDbEIsU0FBTTtNQUVSWixnREFBQSxDQTRDWWEsb0JBQUE7SUE1Q0FDLEtBQUssRUFBRSxRQUFRO0lBQUdDLElBQUksRUFBRVYsTUFBQSxDQUFBVzs7NERBQ2xDO01BQUEsT0FJYSxDQUpiaEIsZ0RBQUEsQ0FJYWlCLHFCQUFBO1FBSkRDLEtBQUssRUFBQyxPQUFPO1FBQUNDLEtBQUssRUFBQyxNQUFNO1FBQUNDLEtBQUssRUFBQzs7UUFDaEMsV0FBT0MsNENBQUEsQ0FDaEIsVUFBQUMsSUFBQTtVQUFBLElBRG9CQyxHQUFHLEdBQUFELElBQUEsQ0FBSEMsR0FBRztVQUFBLFFBQ3ZCakIsdURBQUEsQ0FBNEIsY0FBQWtCLG9EQUFBLENBQW5CRCxHQUFHLENBQUNFLEtBQUs7Ozs7VUFHdEJ6QixnREFBQSxDQWtCYWlCLHFCQUFBO1FBbEJEQyxLQUFLLEVBQUMsVUFBVTtRQUFDQyxLQUFLLEVBQUMsTUFBTTtRQUFDQyxLQUFLLEVBQUM7O1FBQ25DLFdBQU9DLDRDQUFBLENBR2QsVUFBQUssS0FBQTtVQUFBLElBSGtCSCxHQUFHLEdBQUFHLEtBQUEsQ0FBSEgsR0FBRztVQUFBLCtEQUN2QnpCLHVEQUFBLENBY002Qix5Q0FBQSxRQUFBQywrQ0FBQSxDQVpvQkwsR0FBRyxDQUFDTSxRQUFRLFlBQTVCQyxJQUFJLEVBQUVDLEtBQUs7cUVBRnJCakMsdURBQUEsQ0FjTTtjQWJKLFNBQU0sU0FBUztjQUVka0MsR0FBRyxFQUFFRDtnQkFFTi9CLGdEQUFBLENBTWdCaUMsdUJBQUE7MEJBTExILElBQUksQ0FBQ0ksSUFBSTs7dUJBQVRKLElBQUksQ0FBQ0ksSUFBSSxHQUFBQyxNQUFBO2NBQUE7Y0FDakJ6QixPQUFPLEVBQUVvQixJQUFJLENBQUMxQixLQUFLO2NBQ25CZ0MsYUFBYSxFQUFFTixJQUFJLENBQUNNLGFBQWE7Y0FDakNDLFFBQU0sV0FBQUEsU0FBQUYsTUFBQTtnQkFBQSxPQUFFOUIsTUFBQSxDQUFBaUMsWUFBWSxDQUFDUixJQUFJLEVBQUVQLEdBQUc7Y0FBQTtjQUM5QmdCLFFBQVEsRUFBRVQsSUFBSSxDQUFDUztnSUFFbEJDLHVEQUFBLGdGQUE2RSxFQUM3RUEsdURBQUEsc0JBQXlCOzs7OztVQUkvQnhDLGdEQUFBLENBa0JhaUIscUJBQUE7UUFsQkRDLEtBQUssRUFBQyxVQUFVO1FBQUNDLEtBQUssRUFBQzs7UUFDdEIsV0FBT0UsNENBQUEsQ0FFZCxVQUFBb0IsS0FBQTtVQUFBLElBRmtCbEIsR0FBRyxHQUFBa0IsS0FBQSxDQUFIbEIsR0FBRztVQUFBLCtEQUN2QnpCLHVEQUFBLENBY002Qix5Q0FBQSxRQUFBQywrQ0FBQSxDQWJvQkwsR0FBRyxDQUFDbUIsUUFBUSxZQUE1QlosSUFBSSxFQUFFQyxLQUFLO3FFQURyQmpDLHVEQUFBLENBY007Y0FaSGtDLEdBQUcsRUFBRUQsS0FBSztjQUNYLFNBQU07dUVBRU5qQyx1REFBQSxDQVFNNkIseUNBQUEsUUFBQUMsK0NBQUEsQ0FSb0JFLElBQUksWUFBakJhLEdBQUcsRUFBRUMsR0FBRzt1RUFBckI5Qyx1REFBQSxDQVFNO2dCQVIyQmtDLEdBQUcsRUFBRVksR0FBRztnQkFBRSxTQUFNO2tCQUMvQzVDLGdEQUFBLENBTUVpQyx1QkFBQTs0QkFMU1UsR0FBRyxDQUFDVCxJQUFJOzt5QkFBUlMsR0FBRyxDQUFDVCxJQUFJLEdBQUFDLE1BQUE7Z0JBQUE7Z0JBQ2hCekIsT0FBTyxFQUFFaUMsR0FBRyxDQUFDdkMsS0FBSztnQkFDbkJ5QyxJQUFJLEVBQUMsT0FBTztnQkFDWFIsUUFBTSxXQUFBQSxTQUFBRixNQUFBO2tCQUFBLE9BQUU5QixNQUFBLENBQUF5QyxZQUFZLENBQUNILEdBQUcsRUFBRXBCLEdBQUc7Z0JBQUE7Z0JBQzdCZ0IsUUFBUSxFQUFFSSxHQUFHLENBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQy9DeEIsU0FBTTtBQUFTOztFQUNiLFNBQU07QUFBUTs7RUFDWixTQUFNO0FBQVk7O3NCQUNyQmpDLHVEQUFBLENBQ0M7SUFESyxTQUFNO0VBQWEsR0FBQyxNQUFJO0FBQUE7O0VBVzNCLFNBQU07QUFBWTs7c0JBQ3JCQSx1REFBQSxDQUFzQztJQUFoQyxTQUFNO0VBQWEsR0FBQyxPQUFLO0FBQUE7O0VBVzVCLFNBQU07QUFBWTs7c0JBQ3JCQSx1REFBQSxDQUFzQztJQUFoQyxTQUFNO0VBQWEsR0FBQyxPQUFLO0FBQUE7O0VBZTVCLFNBQU07QUFBWTs7RUFTcEIsU0FBTTtBQUFVOztFQWlFZCxTQUFNO0FBQVE7Ozs7Ozs7Ozs7cUtBcEh2QkEsdURBQUEsQ0F3Rk0sT0F4Rk5QLFVBd0ZNLEdBdkZKTyx1REFBQSxDQWlETSxPQWpETkMsVUFpRE0sR0FoREpELHVEQUFBLENBV00sT0FYTnlDLFVBV00sR0FWSkMsVUFDQyxFQUFBaEQsZ0RBQUEsQ0FRWWlELG9CQUFBO2dCQVBGNUMsTUFBQSxDQUFBNkMsS0FBSyxDQUFDQyxRQUFROzthQUFkOUMsTUFBQSxDQUFBNkMsS0FBSyxDQUFDQyxRQUFRLEdBQUFoQixNQUFBO0lBQUE7SUFDdkJpQixXQUFXLEVBQUMsT0FBTztJQUNuQlAsSUFBSSxFQUFDLE9BQU87SUFDWjNDLElBQUksRUFBQyxRQUFRO0lBQ2JtRCxTQUFTLEVBQVQsRUFBUztJQUNSQyxPQUFLLEVBQUVqRCxNQUFBLENBQUFrRCxPQUFPO0lBQ2RDLGFBQVksRUFBRW5ELE1BQUEsQ0FBQWtEOzZDQUduQmpELHVEQUFBLENBV00sT0FYTm1ELFVBV00sR0FWSkMsVUFBc0MsRUFDdEMxRCxnREFBQSxDQVFhaUQsb0JBQUE7Z0JBUEY1QyxNQUFBLENBQUE2QyxLQUFLLENBQUNTLElBQUk7O2FBQVZ0RCxNQUFBLENBQUE2QyxLQUFLLENBQUNTLElBQUksR0FBQXhCLE1BQUE7SUFBQTtJQUNuQmlCLFdBQVcsRUFBQyxRQUFRO0lBQ3BCUCxJQUFJLEVBQUMsT0FBTztJQUNaM0MsSUFBSSxFQUFDLFFBQVE7SUFDYm1ELFNBQVMsRUFBVCxFQUFTO0lBQ1JDLE9BQUssRUFBRWpELE1BQUEsQ0FBQWtELE9BQU87SUFDZEMsYUFBWSxFQUFFbkQsTUFBQSxDQUFBa0Q7NkNBR25CakQsdURBQUEsQ0FlTSxPQWZOc0QsVUFlTSxHQWRKQyxVQUFzQyxFQUN0QzdELGdEQUFBLENBWWE4RCxxQkFBQTtnQkFYRnpELE1BQUEsQ0FBQTZDLEtBQUssQ0FBQ2EsSUFBSTs7YUFBVjFELE1BQUEsQ0FBQTZDLEtBQUssQ0FBQ2EsSUFBSSxHQUFBNUIsTUFBQTtJQUFBO0lBQ25CaUIsV0FBVyxFQUFDLFFBQVE7SUFDcEJQLElBQUksRUFBQyxPQUFPO0lBQ1hSLFFBQU0sRUFBRWhDLE1BQUEsQ0FBQWtEOzs0REFHUDtNQUFBLE9BQWlDLHdEQURuQ3pELHVEQUFBLENBS2M2Qix5Q0FBQSxRQUFBQywrQ0FBQSxDQUpZdkIsTUFBQSxDQUFBMkQsUUFBUSxZQUF4QmxDLElBQUksRUFBRUMsS0FBSztpRUFEckJrQyxnREFBQSxDQUtjQyxxQkFBQTtVQUhYbEMsR0FBRyxFQUFFRCxLQUFLO1VBQ1ZvQyxLQUFLLEVBQUVyQyxJQUFJLENBQUM2QixJQUFJO1VBQ2hCdkQsS0FBSyxFQUFFMEIsSUFBSSxDQUFDTDs7Ozs7O3VDQUluQm5CLHVEQUFBLENBT00sT0FQTjhELFVBT00sR0FOSnBFLGdEQUFBLENBS2NRLHFCQUFBO0lBSlpDLE1BQU0sRUFBQyxTQUFTO0lBQ2hCQyxPQUFPLEVBQUMsSUFBSTtJQUNabUMsSUFBSSxFQUFDLE9BQU87SUFDWGxDLE9BQUssRUFBRU4sTUFBQSxDQUFBa0Q7VUFJZGpELHVEQUFBLENBbUJNLE9BbkJOK0QsV0FtQk0sR0FsQkpyRSxnREFBQSxDQWlCWWEsb0JBQUE7SUFqQkFDLEtBQUssRUFBRSxNQUFNO0lBQUdDLElBQUksRUFBRVYsTUFBQSxDQUFBVzs7NERBQ2hDO01BQUEsT0FBd0QsQ0FBeERoQixnREFBQSxDQUF3RGlCLHFCQUFBO1FBQTVDQyxLQUFLLEVBQUMsVUFBVTtRQUFDQyxLQUFLLEVBQUM7VUFDbkNuQixnREFBQSxDQUFtRGlCLHFCQUFBO1FBQXZDQyxLQUFLLEVBQUMsTUFBTTtRQUFDQyxLQUFLLEVBQUM7VUFDL0JuQixnREFBQSxDQU1haUIscUJBQUE7UUFOREUsS0FBSyxFQUFDO01BQU07UUFDWCxXQUFPRSw0Q0FBQSxDQUNoQixVQUFBQyxJQUFBO1VBQUEsSUFEb0JDLEdBQUcsR0FBQUQsSUFBQSxDQUFIQyxHQUFHO1VBQUEsUUFDdkJqQix1REFBQSxDQUVPLGNBQUFrQixvREFBQSxDQURGbkIsTUFBQSxDQUFBaUUsWUFBWSxDQUFDL0MsR0FBRyxDQUFDd0MsSUFBSTs7OztVQUk5Qi9ELGdEQUFBLENBTWFpQixxQkFBQTtRQU5ERSxLQUFLLEVBQUMsSUFBSTtRQUFDQyxLQUFLLEVBQUMsS0FBSztRQUFDLGVBQWEsRUFBYjs7UUFDdEIsV0FBT0MsNENBQUEsQ0FDaEIsVUFBQUssS0FBQTtVQUFBLElBRG9CSCxHQUFHLEdBQUFHLEtBQUEsQ0FBSEgsR0FBRztVQUFBLFFBQ3ZCdkIsZ0RBQUEsQ0FFQ1EscUJBQUE7WUFGV04sSUFBSSxFQUFDLE1BQU07WUFBQ08sTUFBTSxFQUFDLFNBQVM7WUFBRUUsT0FBSyxXQUFBQSxRQUFBd0IsTUFBQTtjQUFBLE9BQUU5QixNQUFBLENBQUFrRSxPQUFPLENBQUNoRCxHQUFHO1lBQUE7O29FQUN6RDtjQUFBLE9BQUUsc0RBQUYsSUFBRTs7Ozs7Ozs7OztpQ0FNYnZCLGdEQUFBLENBZ0JZd0Usb0JBQUE7SUFmVkMsVUFBVSxFQUFWLEVBQVU7SUFDRixjQUFZLEVBQUVwRSxNQUFBLENBQUFxRSxRQUFRLENBQUNDLFdBQVc7O2FBQXBCdEUsTUFBQSxDQUFBcUUsUUFBUSxDQUFDQyxXQUFXLEdBQUF4QyxNQUFBO0lBQUE7SUFDbEMsV0FBUyxFQUFFOUIsTUFBQSxDQUFBcUUsUUFBUSxDQUFDRSxRQUFROzthQUFqQnZFLE1BQUEsQ0FBQXFFLFFBQVEsQ0FBQ0UsUUFBUSxHQUFBekMsTUFBQTtJQUFBO0lBQ25DMEMsS0FBSyxFQUFFeEUsTUFBQSxDQUFBd0UsS0FBSztJQUNaQyxPQUFPLEVBQUU7cUVBYWQ5RSxnREFBQSxDQW9DWStFLG9CQUFBO2dCQXBDUTFFLE1BQUEsQ0FBQTJFLFFBQVE7O2FBQVIzRSxNQUFBLENBQUEyRSxRQUFRLEdBQUE3QyxNQUFBO0lBQUE7OzREQUMxQjtNQUFBLE9Ba0NNLENBbENON0IsdURBQUEsQ0FrQ00sY0FqQ0pBLHVEQUFBLENBUUksaUVBUkQsT0FFRCxHQUFBTixnREFBQSxDQUthaUQsb0JBQUE7b0JBSkY1QyxNQUFBLENBQUE0RSxPQUFPLENBQUM5QixRQUFROztpQkFBaEI5QyxNQUFBLENBQUE0RSxPQUFPLENBQUM5QixRQUFRLEdBQUFoQixNQUFBO1FBQUE7UUFDekJJLFFBQVEsRUFBUixFQUFRO1FBQ1JNLElBQUksRUFBQyxPQUFPO1FBQ1osU0FBTTtpREFHVnZDLHVEQUFBLENBZUksaUVBZkQsT0FFRCxHQUFBTixnREFBQSxDQVlhOEQscUJBQUE7b0JBWEZ6RCxNQUFBLENBQUE0RSxPQUFPLENBQUNsQixJQUFJOztpQkFBWjFELE1BQUEsQ0FBQTRFLE9BQU8sQ0FBQ2xCLElBQUksR0FBQTVCLE1BQUE7UUFBQTtRQUNyQmlCLFdBQVcsRUFBQyxRQUFRO1FBQ3BCUCxJQUFJLEVBQUMsT0FBTztRQUNaLFNBQU07O2dFQUdKO1VBQUEsT0FBaUMsd0RBRG5DL0MsdURBQUEsQ0FLYzZCLHlDQUFBLFFBQUFDLCtDQUFBLENBSll2QixNQUFBLENBQUEyRCxRQUFRLFlBQXhCbEMsSUFBSSxFQUFFQyxLQUFLO3FFQURyQmtDLGdEQUFBLENBS2NDLHFCQUFBO2NBSFhsQyxHQUFHLEVBQUVELEtBQUs7Y0FDVm9DLEtBQUssRUFBRXJDLElBQUksQ0FBQzZCLElBQUk7Y0FDaEJ2RCxLQUFLLEVBQUUwQixJQUFJLENBQUNMOzs7Ozs7MkNBSW5CbkIsdURBQUEsQ0FPTSxPQVBONEUsV0FPTSxHQU5KbEYsZ0RBQUEsQ0FFQ1EscUJBQUE7UUFGV3FDLElBQUksRUFBQyxPQUFPO1FBQUVsQyxPQUFLLEVBQUF3RSxNQUFBLFFBQUFBLE1BQUEsZ0JBQUFoRCxNQUFBO1VBQUEsT0FBRTlCLE1BQUEsQ0FBQTJFLFFBQVE7UUFBQTtRQUFVLFNBQU07O2dFQUN0RDtVQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1VBRUxoRixnREFBQSxDQUVDUSxxQkFBQTtRQUZXQyxNQUFNLEVBQUMsU0FBUztRQUFDb0MsSUFBSSxFQUFDLE9BQU87UUFBRWxDLE9BQUssRUFBRU4sTUFBQSxDQUFBK0UsUUFBUTtRQUFFLFNBQU07O2dFQUMvRDtVQUFBLE9BQUUsc0RBQUYsSUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekhiLE1BQXFHO0FBQ3JHLE1BQTJGO0FBQzNGLE1BQWtHO0FBQ2xHLE1BQXFIO0FBQ3JILE1BQThHO0FBQzlHLE1BQThHO0FBQzlHLE1BQXFWO0FBQ3JWO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHFHQUFtQjtBQUMvQyx3QkFBd0Isa0hBQWE7O0FBRXJDLHVCQUF1Qix1R0FBYTtBQUNwQztBQUNBLGlCQUFpQiwrRkFBTTtBQUN2Qiw2QkFBNkIsc0dBQWtCOztBQUUvQyxhQUFhLDBHQUFHLENBQUMsbVNBQU87Ozs7QUFJK1I7QUFDdlQsT0FBTyxpRUFBZSxtU0FBTyxJQUFJLDBTQUFjLEdBQUcsMFNBQWMsWUFBWSxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBb1Y7QUFDcFY7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyxrU0FBTzs7OztBQUk4UjtBQUN0VCxPQUFPLGlFQUFlLGtTQUFPLElBQUkseVNBQWMsR0FBRyx5U0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUF3VjtBQUN4VjtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLHNTQUFPOzs7O0FBSWtTO0FBQzFULE9BQU8saUVBQWUsc1NBQU8sSUFBSSw2U0FBYyxHQUFHLDZTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCQztBQUNYO0FBQ0w7O0FBRTlELENBQTZFOztBQUVxQztBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyxxRkFBTSxhQUFhLHdGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCOEQ7QUFDWDtBQUNMOztBQUU3RCxDQUE0RTs7QUFFc0M7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsb0ZBQU0sYUFBYSx1RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QmtFO0FBQ1g7QUFDTDs7QUFFakUsQ0FBZ0Y7O0FBRWtDO0FBQ2xILGlDQUFpQyxrSEFBZSxDQUFDLHdGQUFNLGFBQWEsMkZBQU07QUFDMUU7QUFDQSxJQUFJLEtBQVUsRUFBRSxFQVlmOzs7QUFHRCxpRUFBZTs7Ozs7Ozs7Ozs7Ozs7O0FDeEJxVzs7Ozs7Ozs7Ozs7Ozs7O0FDQUQ7Ozs7Ozs7Ozs7Ozs7OztBQ0FJIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9pbmRleC52dWU/YzE3ZiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlPzg0NjIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi91c2VyTGlzdC52dWU/OTkzZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL2luZGV4LnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlPzlkZTIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi91c2VyTGlzdC52dWU/ZWYzYyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vdXNlckxpc3QudnVlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vaW5kZXgudnVlPzgwZWMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9yb2xlLnZ1ZT8xOTA4Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vdXNlckxpc3QudnVlPzljNjAiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9pbmRleC52dWU/YzEzMCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlPzVjZTIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi91c2VyTGlzdC52dWU/ZGIwYSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL2luZGV4LnZ1ZT9lNmI3Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vcm9sZS52dWU/NzFjZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3VzZXJMaXN0LnZ1ZT9kM2MxIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vaW5kZXgudnVlPzQxMmUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9yb2xlLnZ1ZT9mNWJlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vdXNlckxpc3QudnVlP2YwMDMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9pbmRleC52dWU/YWYwZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlPzEzMGMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcGVybWlzc2lvbi91c2VyTGlzdC52dWU/YTY4YSJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5jb250ZW50Qm94W2RhdGEtdi0wODVhNDdkNF0ge1xcbiAgaGVpZ2h0OiAxMDAlO1xcbn1cXG5bZGF0YS12LTA4NWE0N2Q0XSAuZWwtdGFicy0tYm9yZGVyLWNhcmQge1xcbiAgYm9yZGVyLWJvdHRvbTogbm9uZSAhaW1wb3J0YW50O1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvcGFnZXMvcGVybWlzc2lvbi9pbmRleC52dWVcIixcIndlYnBhY2s6Ly8uL2luZGV4LnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLFlBQUE7QUNBRjtBREVBO0VBQ0UsOEJBQUE7QUNBRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4uY29udGVudEJveCB7XFxuICBoZWlnaHQ6IDEwMCU7XFxufVxcbjo6di1kZWVwKC5lbC10YWJzLS1ib3JkZXItY2FyZCkge1xcbiAgYm9yZGVyLWJvdHRvbTogbm9uZSAhaW1wb3J0YW50O1xcbn1cXG5cIixcIi5jb250ZW50Qm94IHtcXG4gIGhlaWdodDogMTAwJTtcXG59XFxuOjp2LWRlZXAoLmVsLXRhYnMtLWJvcmRlci1jYXJkKSB7XFxuICBib3JkZXItYm90dG9tOiBub25lICFpbXBvcnRhbnQ7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5yb2xlQm94W2RhdGEtdi01Y2QxNjhlMl0ge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgcGFkZGluZy10b3A6IDMwcHg7XFxufVxcbi5yb2xlQm94IHBbZGF0YS12LTVjZDE2OGUyXSB7XFxuICBjb2xvcjogI2ZkMTAzMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMHB4O1xcbiAgbGVmdDogMTBweDtcXG59XFxuLnJvbGVCb3ggLnNhdmVCdG5bZGF0YS12LTVjZDE2OGUyXSB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogMTBweDtcXG4gIHRvcDogMHB4O1xcbn1cXG4uY29sdW1uQm94W2RhdGEtdi01Y2QxNjhlMl0ge1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2U2ZThlYztcXG4gIGJvcmRlci10b3A6IG5vbmU7XFxuICBwYWRkaW5nOiAxMHB4O1xcbn1cXG4uZG9uZUJveFtkYXRhLXYtNWNkMTY4ZTJdIHtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICNlNmU4ZWM7XFxuICBoZWlnaHQ6IDQwcHg7XFxuICBsaW5lLWhlaWdodDogMzlweDtcXG59XFxuLmRvbmVUeXBlQ2xhc3NbZGF0YS12LTVjZDE2OGUyXSB7XFxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxufVxcbi52eGUtaGVhZGVyLS1jb2x1bW5bZGF0YS12LTVjZDE2OGUyXSB7XFxuICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcXG59XFxuW2RhdGEtdi01Y2QxNjhlMl0gLnZ4ZS1ib2R5LS1jb2x1bW4ge1xcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XFxufVxcbltkYXRhLXYtNWNkMTY4ZTJdIC52eGUtY2VsbCB7XFxuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xcbiAgcGFkZGluZy1yaWdodDogMHB4ICFpbXBvcnRhbnQ7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9wZXJtaXNzaW9uL3JvbGUudnVlXCIsXCJ3ZWJwYWNrOi8vLi9yb2xlLnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7QUNBRjtBREZBO0VBSUksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7QUNDSjtBRFJBO0VBVUksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtBQ0NKO0FERUE7RUFDRSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQ0FGO0FERUE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0FGO0FERUE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0FDQUY7QURFQTtFQUNFLHVCQUFBO0FDQUY7QURFQTtFQUNFLHVCQUFBO0FDQUY7QURFQTtFQUNFLDRCQUFBO0VBQ0EsNkJBQUE7QUNBRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4ucm9sZUJveCB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBwYWRkaW5nLXRvcDogMzBweDtcXG4gIHAge1xcbiAgICBjb2xvcjogI2ZkMTAzMDtcXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICB0b3A6IDBweDtcXG4gICAgbGVmdDogMTBweDtcXG4gIH1cXG4gIC5zYXZlQnRuIHtcXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICByaWdodDogMTBweDtcXG4gICAgdG9wOiAwcHg7XFxuICB9XFxufVxcbi5jb2x1bW5Cb3gge1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2U2ZThlYztcXG4gIGJvcmRlci10b3A6IG5vbmU7XFxuICBwYWRkaW5nOiAxMHB4O1xcbn1cXG4uZG9uZUJveCB7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZTZlOGVjO1xcbiAgaGVpZ2h0OiA0MHB4O1xcbiAgbGluZS1oZWlnaHQ6IDM5cHg7XFxufVxcbi5kb25lVHlwZUNsYXNzIHtcXG4gIG1hcmdpbi1yaWdodDogMjBweDtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG59XFxuLnZ4ZS1oZWFkZXItLWNvbHVtbiB7XFxuICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcXG59XFxuOjp2LWRlZXAoLnZ4ZS1ib2R5LS1jb2x1bW4pIHtcXG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xcbn1cXG46OnYtZGVlcCgudnhlLWNlbGwpIHtcXG4gIHBhZGRpbmctbGVmdDogMHB4ICFpbXBvcnRhbnQ7XFxuICBwYWRkaW5nLXJpZ2h0OiAwcHggIWltcG9ydGFudDtcXG59XFxuXCIsXCIucm9sZUJveCB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBwYWRkaW5nLXRvcDogMzBweDtcXG59XFxuLnJvbGVCb3ggcCB7XFxuICBjb2xvcjogI2ZkMTAzMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMHB4O1xcbiAgbGVmdDogMTBweDtcXG59XFxuLnJvbGVCb3ggLnNhdmVCdG4ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgcmlnaHQ6IDEwcHg7XFxuICB0b3A6IDBweDtcXG59XFxuLmNvbHVtbkJveCB7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZTZlOGVjO1xcbiAgYm9yZGVyLXRvcDogbm9uZTtcXG4gIHBhZGRpbmc6IDEwcHg7XFxufVxcbi5kb25lQm94IHtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICNlNmU4ZWM7XFxuICBoZWlnaHQ6IDQwcHg7XFxuICBsaW5lLWhlaWdodDogMzlweDtcXG59XFxuLmRvbmVUeXBlQ2xhc3Mge1xcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbn1cXG4udnhlLWhlYWRlci0tY29sdW1uIHtcXG4gIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xcbn1cXG46OnYtZGVlcCgudnhlLWJvZHktLWNvbHVtbikge1xcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XFxufVxcbjo6di1kZWVwKC52eGUtY2VsbCkge1xcbiAgcGFkZGluZy1sZWZ0OiAwcHggIWltcG9ydGFudDtcXG4gIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xcbn1cXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIubWFpbkJveCAuc2VhcmNoW2RhdGEtdi0xMGEwMGZmNV0ge1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLm1haW5Cb3ggLnNlYXJjaCAuc2VhcmNoSXRlbVtkYXRhLXYtMTBhMDBmZjVdIHtcXG4gIG1hcmdpbi1yaWdodDogMTBweDtcXG59XFxuLm1haW5Cb3ggLnNlYXJjaCAuc2VhcmNoSXRlbSAuc2VhcmNoTGFibGVbZGF0YS12LTEwYTAwZmY1XSB7XFxuICBtYXJnaW46IDAgMTBweDtcXG59XFxuLm1haW5Cb3ggLnRhYmxlQm94W2RhdGEtdi0xMGEwMGZmNV0ge1xcbiAgbWFyZ2luLXRvcDogMjBweDtcXG4gIGhlaWdodDogNTYwcHg7XFxufVxcbnBbZGF0YS12LTEwYTAwZmY1XSB7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcbnAgLm1vZGVsSXRlbVtkYXRhLXYtMTBhMDBmZjVdIHtcXG4gIHdpZHRoOiAyMDBweDtcXG4gIG1hcmdpbjogMTBweCAyMHB4O1xcbn1cXG4uZm9vdGVyW2RhdGEtdi0xMGEwMGZmNV0ge1xcbiAgbWFyZ2luLXRvcDogMTBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbn1cXG4uZm9vdGVyIC5idG5bZGF0YS12LTEwYTAwZmY1XSB7XFxuICB3aWR0aDogNjBweDtcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL3BhZ2VzL3Blcm1pc3Npb24vdXNlckxpc3QudnVlXCIsXCJ3ZWJwYWNrOi8vLi91c2VyTGlzdC52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFFSSxhQUFBO0FDREo7QUREQTtFQUtNLGtCQUFBO0FDRE47QURKQTtFQVFRLGNBQUE7QUNEUjtBRFBBO0VBY0ksZ0JBQUE7RUFDQSxhQUFBO0FDSko7QURPQTtFQUNFLGtCQUFBO0FDTEY7QURJQTtFQUdJLFlBQUE7RUFDQSxpQkFBQTtBQ0pKO0FET0E7RUFDRSxnQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtBQ0xGO0FERUE7RUFLSSxXQUFBO0FDSkpcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxuLm1haW5Cb3gge1xcbiAgLnNlYXJjaCB7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuXFxuICAgIC5zZWFyY2hJdGVtIHtcXG4gICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XFxuXFxuICAgICAgLnNlYXJjaExhYmxlIHtcXG4gICAgICAgIG1hcmdpbjogMCAxMHB4O1xcbiAgICAgIH1cXG4gICAgfVxcbiAgfVxcblxcbiAgLnRhYmxlQm94IHtcXG4gICAgbWFyZ2luLXRvcDogMjBweDtcXG4gICAgaGVpZ2h0OiA1NjBweDtcXG4gIH1cXG59XFxucCB7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICAubW9kZWxJdGVtIHtcXG4gICAgd2lkdGg6IDIwMHB4O1xcbiAgICBtYXJnaW46IDEwcHggMjBweDtcXG4gIH1cXG59XFxuLmZvb3RlciB7XFxuICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxuICAuYnRuIHtcXG4gICAgd2lkdGg6IDYwcHg7XFxuICB9XFxufVxcblwiLFwiLm1haW5Cb3ggLnNlYXJjaCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbn1cXG4ubWFpbkJveCAuc2VhcmNoIC5zZWFyY2hJdGVtIHtcXG4gIG1hcmdpbi1yaWdodDogMTBweDtcXG59XFxuLm1haW5Cb3ggLnNlYXJjaCAuc2VhcmNoSXRlbSAuc2VhcmNoTGFibGUge1xcbiAgbWFyZ2luOiAwIDEwcHg7XFxufVxcbi5tYWluQm94IC50YWJsZUJveCB7XFxuICBtYXJnaW4tdG9wOiAyMHB4O1xcbiAgaGVpZ2h0OiA1NjBweDtcXG59XFxucCB7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcbnAgLm1vZGVsSXRlbSB7XFxuICB3aWR0aDogMjAwcHg7XFxuICBtYXJnaW46IDEwcHggMjBweDtcXG59XFxuLmZvb3RlciB7XFxuICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxufVxcbi5mb290ZXIgLmJ0biB7XFxuICB3aWR0aDogNjBweDtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsIjx0ZW1wbGF0ZT5cclxuICA8ZGl2IGNsYXNzPVwiY29udGVudEJveFwiPlxyXG4gICAgPGVsLXRhYnMgdHlwZT1cImJvcmRlci1jYXJkXCI+XHJcbiAgICAgIDxlbC10YWItcGFuZSBsYWJlbD1cIueUqOaIt+WIl+ihqFwiPlxyXG4gICAgICAgIDxVc2VyTGlzdD48L1VzZXJMaXN0PlxyXG4gICAgICA8L2VsLXRhYi1wYW5lPlxyXG4gICAgICA8ZWwtdGFiLXBhbmUgbGFiZWw9XCLop5LoibLnrqHnkIZcIj5cclxuICAgICAgICA8Um9sZT48L1JvbGU+XHJcbiAgICAgIDwvZWwtdGFiLXBhbmU+XHJcbiAgICA8L2VsLXRhYnM+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCBVc2VyTGlzdCBmcm9tIFwiLi91c2VyTGlzdC52dWVcIjtcclxuaW1wb3J0IFJvbGUgZnJvbSBcIi4vcm9sZS52dWVcIjtcclxuPC9zY3JpcHQ+XHJcbjxzdHlsZSBsYW5nPVwibGVzc1wiIHNjb3BlZD5cclxuLmNvbnRlbnRCb3gge1xyXG4gIGhlaWdodDogMTAwJTtcclxufVxyXG46OnYtZGVlcCguZWwtdGFicy0tYm9yZGVyLWNhcmQpIHtcclxuICBib3JkZXItYm90dG9tOiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuPC9zdHlsZT4iLCJpbXBvcnQgeyBlbnZuYW1lIH0gZnJvbSBcIkAvamF2YXNjcmlwdC9lbnZuYW1lXCI7XG5pbXBvcnQgcmVxdWVzdCBmcm9tIFwiQC91dGlscy9yZXF1ZXN0VXRpbHNcIjtcbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAncm9sZScsXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlO1xuICAgIGV4cG9zZSgpO1xuICAgIHZhciB0YWJsZURhdGEgPSByZWYoW10pO1xuICAgIHZhciBjaGFuZ2VDaGVjazEgPSBmdW5jdGlvbiBjaGFuZ2VDaGVjazEodmFsLCByb3cpIHtcbiAgICAgIHZhbC5pbmRldGVybWluYXRlID0gZmFsc2U7XG4gICAgICB2YXIgaW5kZXggPSByb3dbXCJkb25lTmFtZVwiXS5maW5kSW5kZXgoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW1bMF0ucGFyZW50ID09PSB2YWwubmFtZTtcbiAgICAgIH0pO1xuICAgICAgcm93W1wiZG9uZU5hbWVcIl1baW5kZXhdLm1hcChmdW5jdGlvbiAodikge1xuICAgICAgICByZXR1cm4gdi5mbGFnID0gdmFsLmZsYWc7XG4gICAgICB9KTtcbiAgICAgIC8vICBjaGFuZ2VMaXN0KClcbiAgICB9O1xuXG4gICAgdmFyIGNoYW5nZUNoZWNrMiA9IGZ1bmN0aW9uIGNoYW5nZUNoZWNrMih2YWwsIHJvdykge1xuICAgICAgY29uc29sZS5sb2codmFsLCByb3csIFwiPz8/XCIpO1xuICAgICAgdmFyIGluZGV4ID0gcm93W1wiZG9uZU5hbWVcIl0uZmluZEluZGV4KGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtWzBdLnBhcmVudCA9PT0gdmFsLnBhcmVudDtcbiAgICAgIH0pO1xuICAgICAgdmFyIGxpc3QgPSByb3dbXCJkb25lTmFtZVwiXVtpbmRleF07XG4gICAgICB2YXIgcGFyZW50SW5kZXggPSByb3cubWVudU5hbWUuZmluZEluZGV4KGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLm5hbWUgPT09IHZhbC5wYXJlbnQ7XG4gICAgICB9KTtcbiAgICAgIHZhciBwYXJlbnRJdGVtID0gcm93Lm1lbnVOYW1lW3BhcmVudEluZGV4XTtcbiAgICAgIGlmIChsaXN0LmV2ZXJ5KGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLmZsYWcgPT09IHRydWU7XG4gICAgICB9KSkge1xuICAgICAgICBwYXJlbnRJdGVtLmZsYWcgPSB0cnVlO1xuICAgICAgICBwYXJlbnRJdGVtLmluZGV0ZXJtaW5hdGUgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBpZiAobGlzdC5ldmVyeShmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICByZXR1cm4gaXRlbS5mbGFnID09PSBmYWxzZTtcbiAgICAgIH0pKSB7XG4gICAgICAgIHBhcmVudEl0ZW0uZmxhZyA9IGZhbHNlO1xuICAgICAgICBwYXJlbnRJdGVtLmluZGV0ZXJtaW5hdGUgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBpZiAobGlzdC5zb21lKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLmZsYWcgPT09IHRydWU7XG4gICAgICB9KSkge1xuICAgICAgICBwYXJlbnRJdGVtLmZsYWcgPSBmYWxzZTtcbiAgICAgICAgcGFyZW50SXRlbS5pbmRldGVybWluYXRlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIC8vIGNoYW5nZUxpc3QoKVxuICAgIH07XG5cbiAgICB2YXIgcmVxTGlzdCA9IGZ1bmN0aW9uIHJlcUxpc3QoKSB7XG4gICAgICByZXF1ZXN0LmdldChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3VzZXJSb2xlL3JvbGVMaXN0XCIpKS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICB0YWJsZURhdGEudmFsdWUgPSByZXMuZGF0YTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgY2hhbmdlTGlzdCA9IGZ1bmN0aW9uIGNoYW5nZUxpc3QoKSB7XG4gICAgICByZXF1ZXN0LnBvc3QoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcC91c2VyUm9sZS91cGRhdGVSb2xlXCIpLCB7XG4gICAgICAgIGRhdGE6IHRhYmxlRGF0YS52YWx1ZVxuICAgICAgfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgbmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmVxTGlzdCgpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHJlcUxpc3QoKTtcbiAgICBvbk1vdW50ZWQoZnVuY3Rpb24gKCkge30pO1xuICAgIG9uQmVmb3JlVW5tb3VudChmdW5jdGlvbiAoKSB7XG4gICAgICAvLyBjaGFuZ2VMaXN0KClcbiAgICB9KTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgdGFibGVEYXRhOiB0YWJsZURhdGEsXG4gICAgICBjaGFuZ2VDaGVjazE6IGNoYW5nZUNoZWNrMSxcbiAgICAgIGNoYW5nZUNoZWNrMjogY2hhbmdlQ2hlY2syLFxuICAgICAgcmVxTGlzdDogcmVxTGlzdCxcbiAgICAgIGNoYW5nZUxpc3Q6IGNoYW5nZUxpc3QsXG4gICAgICBnZXQgZW52bmFtZSgpIHtcbiAgICAgICAgcmV0dXJuIGVudm5hbWU7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0O1xuICAgICAgfVxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsImltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xuaW1wb3J0IHsgZW52bmFtZSB9IGZyb20gXCJAL2phdmFzY3JpcHQvZW52bmFtZVwiO1xuLy/op5LoibLliJfooahcblxuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICd1c2VyTGlzdCcsXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlO1xuICAgIGV4cG9zZSgpO1xuICAgIHZhciByb2xlTGlzdCA9IHJlZihbXSk7XG4gICAgdmFyIHJlcVJvbGVMaXN0ID0gZnVuY3Rpb24gcmVxUm9sZUxpc3QoKSB7XG4gICAgICByZXF1ZXN0LmdldChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3VzZXJSb2xlL3JvbGVMaXN0XCIpKS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICByb2xlTGlzdC52YWx1ZSA9IHJlcy5kYXRhO1xuICAgICAgICAgIHJvbGVMaXN0LnZhbHVlLnVuc2hpZnQoe1xuICAgICAgICAgICAgbmFtZTogXCJcIixcbiAgICAgICAgICAgIGNuYW1lOiBcIuWFqOmDqFwiXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmVxTGlzdCgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBnZXRSb2xlVmFsdWUgPSBmdW5jdGlvbiBnZXRSb2xlVmFsdWUodmFsKSB7XG4gICAgICB2YXIgdmFsdWUgPSByb2xlTGlzdC52YWx1ZS5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLm5hbWUgPT09IHZhbDtcbiAgICAgIH0pO1xuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5jbmFtZTtcbiAgICAgIH1cbiAgICAgIC8vICAgcmV0dXJuIHJvbGVMaXN0LnZhbHVlLmZpbmQoaXRlbT0+aXRlbS5uYW1lID09PSB2YWwpWydjbmFtZSddXG4gICAgICByZXR1cm4gdmFsO1xuICAgIH07XG4gICAgcmVxUm9sZUxpc3QoKTtcblxuICAgIC8v5p+l6K+i5YiX6KGoXG4gICAgdmFyIHF1ZXJ5ID0gcmVhY3RpdmUoe1xuICAgICAgdXNlck5hbWU6IFwiXCIsXG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgcm9sZTogXCJcIlxuICAgIH0pO1xuICAgIHZhciBwYWdlSW5mbyA9IHJlYWN0aXZlKHtcbiAgICAgIGN1cnJlbnRQYWdlOiAxLFxuICAgICAgcGFnZVNpemU6IDEwXG4gICAgfSk7XG4gICAgdmFyIHRvdGFsID0gcmVmKDgpO1xuICAgIHZhciB0YWJsZURhdGEgPSByZWYoW10pO1xuICAgIHZhciByZXFMaXN0ID0gZnVuY3Rpb24gcmVxTGlzdCgpIHtcbiAgICAgIHJlcXVlc3QucG9zdChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3VzZXJSb2xlL3VzZXJsaXN0XCIpLCB7XG4gICAgICAgIHF1ZXJ5OiBxdWVyeSxcbiAgICAgICAgcGFnZUluZm86IHBhZ2VJbmZvXG4gICAgICB9KS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcbiAgICAgICAgICB0YWJsZURhdGEudmFsdWUgPSByZXMuZGF0YS5saXN0O1xuICAgICAgICAgIHRvdGFsLnZhbHVlID0gcmVzLmRhdGEudG90YWw7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIHJvd0luZm8gPSByZWYoe30pO1xuICAgIHZhciB2aXNpYWJsZSA9IHJlZihmYWxzZSk7XG4gICAgdmFyIG9wZW5EaWEgPSBmdW5jdGlvbiBvcGVuRGlhKHJvdykge1xuICAgICAgcm93SW5mby52YWx1ZSA9IHJvdztcbiAgICAgIHZpc2lhYmxlLnZhbHVlID0gdHJ1ZTtcbiAgICB9O1xuICAgIHZhciBzYXZlUm9sZSA9IGZ1bmN0aW9uIHNhdmVSb2xlKCkge1xuICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvdXNlclJvbGUvdXBkYXRlVXNlclJvbGVcIiksIHtcbiAgICAgICAgZGF0YTogcm93SW5mby52YWx1ZVxuICAgICAgfSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XG4gICAgICAgICAgdmlzaWFibGUudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICBuZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXFMaXN0KCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIHJvbGVMaXN0OiByb2xlTGlzdCxcbiAgICAgIHJlcVJvbGVMaXN0OiByZXFSb2xlTGlzdCxcbiAgICAgIGdldFJvbGVWYWx1ZTogZ2V0Um9sZVZhbHVlLFxuICAgICAgcXVlcnk6IHF1ZXJ5LFxuICAgICAgcGFnZUluZm86IHBhZ2VJbmZvLFxuICAgICAgdG90YWw6IHRvdGFsLFxuICAgICAgdGFibGVEYXRhOiB0YWJsZURhdGEsXG4gICAgICByZXFMaXN0OiByZXFMaXN0LFxuICAgICAgcm93SW5mbzogcm93SW5mbyxcbiAgICAgIHZpc2lhYmxlOiB2aXNpYWJsZSxcbiAgICAgIG9wZW5EaWE6IG9wZW5EaWEsXG4gICAgICBzYXZlUm9sZTogc2F2ZVJvbGUsXG4gICAgICBnZXQgcmVxdWVzdCgpIHtcbiAgICAgICAgcmV0dXJuIHJlcXVlc3Q7XG4gICAgICB9LFxuICAgICAgZ2V0IGVudm5hbWUoKSB7XG4gICAgICAgIHJldHVybiBlbnZuYW1lO1xuICAgICAgfVxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsIjx0ZW1wbGF0ZT5cclxuICA8ZGl2IGNsYXNzPVwicm9sZUJveFwiPlxyXG4gICAgPHA+Kui2hee6p+euoeeQhuWRmOaLpeacieWFqOmDqOeahOadg+mZkCzlubbkuJTkuI3lj6/mm7TmlLk8L3A+XHJcbiAgICA8dnhlLWJ1dHRvblxyXG4gICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgIHN0YXR1cz1cInByaW1hcnlcIlxyXG4gICAgICBjb250ZW50PVwi5L+d5a2YXCJcclxuICAgICAgQGNsaWNrPVwiY2hhbmdlTGlzdFwiXHJcbiAgICAgIGNsYXNzPVwic2F2ZUJ0blwiXHJcbiAgICA+PC92eGUtYnV0dG9uPlxyXG4gICAgPHZ4ZS10YWJsZSA6YWxpZ249XCInY2VudGVyJ1wiIDpkYXRhPVwidGFibGVEYXRhXCI+XHJcbiAgICAgIDx2eGUtY29sdW1uIGZpZWxkPVwiY25hbWVcIiB0aXRsZT1cIuinkuiJsuWQjeensFwiIHdpZHRoPVwiMzAwXCI+XHJcbiAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwieyByb3cgfVwiPlxyXG4gICAgICAgICAgPHNwYW4+e3sgcm93LmNuYW1lIH19PC9zcGFuPlxyXG4gICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgIDwvdnhlLWNvbHVtbj5cclxuICAgICAgPHZ4ZS1jb2x1bW4gZmllbGQ9XCJtZW51TmFtZVwiIHRpdGxlPVwi6I+c5Y2V5ZCN56ewXCIgd2lkdGg9XCIzMDBcIj5cclxuICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJ7IHJvdyB9XCI+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzPVwiZG9uZUJveFwiXHJcbiAgICAgICAgICAgIHYtZm9yPVwiKGl0ZW0sIGluZGV4KSBpbiByb3cubWVudU5hbWVcIlxyXG4gICAgICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8dnhlLWNoZWNrYm94XHJcbiAgICAgICAgICAgICAgdi1tb2RlbD1cIml0ZW0uZmxhZ1wiXHJcbiAgICAgICAgICAgICAgOmNvbnRlbnQ9XCJpdGVtLmxhYmVsXCJcclxuICAgICAgICAgICAgICA6aW5kZXRlcm1pbmF0ZT1cIml0ZW0uaW5kZXRlcm1pbmF0ZVwiXHJcbiAgICAgICAgICAgICAgQGNoYW5nZT1cImNoYW5nZUNoZWNrMShpdGVtLCByb3cpXCJcclxuICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJpdGVtLmRpc2FibGVkXCJcclxuICAgICAgICAgICAgPjwvdnhlLWNoZWNrYm94PlxyXG4gICAgICAgICAgICA8IS0tIDxlbC1jaGVja2JveCB2LW1vZGVsPVwiaXRlbS5mbGFnXCIgOmxhYmVsPVwiaXRlbS5sYWJlbFwiIHNpemU9XCJsYXJnZVwiIC8+IC0tPlxyXG4gICAgICAgICAgICA8IS0tIHt7IGl0ZW0ubGFiZWwgfX0gLS0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICA8L3Z4ZS1jb2x1bW4+XHJcbiAgICAgIDx2eGUtY29sdW1uIGZpZWxkPVwiZG9uZU5hbWVcIiB0aXRsZT1cIuaTjeS9nOWQjeensFwiPlxyXG4gICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInsgcm93IH1cIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHJvdy5kb25lTmFtZVwiXHJcbiAgICAgICAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwiZG9uZUJveFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgdi1mb3I9XCIodmFsLCBpbmQpIGluIGl0ZW1cIiA6a2V5PVwiaW5kXCIgY2xhc3M9XCJkb25lVHlwZUNsYXNzXCI+XHJcbiAgICAgICAgICAgICAgPHZ4ZS1jaGVja2JveFxyXG4gICAgICAgICAgICAgICAgdi1tb2RlbD1cInZhbC5mbGFnXCJcclxuICAgICAgICAgICAgICAgIDpjb250ZW50PVwidmFsLmxhYmVsXCJcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBAY2hhbmdlPVwiY2hhbmdlQ2hlY2syKHZhbCwgcm93KVwiXHJcbiAgICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJ2YWwuZGlzYWJsZWRcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgPC92eGUtY29sdW1uPlxyXG4gICAgPC92eGUtdGFibGU+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcbiAgPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHsgZW52bmFtZSB9IGZyb20gXCJAL2phdmFzY3JpcHQvZW52bmFtZVwiO1xyXG5pbXBvcnQgcmVxdWVzdCBmcm9tIFwiQC91dGlscy9yZXF1ZXN0VXRpbHNcIjtcclxuY29uc3QgdGFibGVEYXRhID0gcmVmKFtdKTtcclxuY29uc3QgY2hhbmdlQ2hlY2sxID0gKHZhbCwgcm93KSA9PiB7XHJcbiAgdmFsLmluZGV0ZXJtaW5hdGUgPSBmYWxzZTtcclxuICBsZXQgaW5kZXggPSByb3dbXCJkb25lTmFtZVwiXS5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW1bMF0ucGFyZW50ID09PSB2YWwubmFtZSk7XHJcbiAgcm93W1wiZG9uZU5hbWVcIl1baW5kZXhdLm1hcCgodikgPT4gKHYuZmxhZyA9IHZhbC5mbGFnKSk7XHJcbiAgLy8gIGNoYW5nZUxpc3QoKVxyXG59O1xyXG5jb25zdCBjaGFuZ2VDaGVjazIgPSAodmFsLCByb3cpID0+IHtcclxuICBjb25zb2xlLmxvZyh2YWwsIHJvdywgXCI/Pz9cIik7XHJcbiAgbGV0IGluZGV4ID0gcm93W1wiZG9uZU5hbWVcIl0uZmluZEluZGV4KFxyXG4gICAgKGl0ZW0pID0+IGl0ZW1bMF0ucGFyZW50ID09PSB2YWwucGFyZW50XHJcbiAgKTtcclxuICBsZXQgbGlzdCA9IHJvd1tcImRvbmVOYW1lXCJdW2luZGV4XTtcclxuICBsZXQgcGFyZW50SW5kZXggPSByb3cubWVudU5hbWUuZmluZEluZGV4KChpdGVtKSA9PiBpdGVtLm5hbWUgPT09IHZhbC5wYXJlbnQpO1xyXG4gIGxldCBwYXJlbnRJdGVtID0gcm93Lm1lbnVOYW1lW3BhcmVudEluZGV4XTtcclxuICBpZiAobGlzdC5ldmVyeSgoaXRlbSkgPT4gaXRlbS5mbGFnID09PSB0cnVlKSkge1xyXG4gICAgcGFyZW50SXRlbS5mbGFnID0gdHJ1ZTtcclxuICAgIHBhcmVudEl0ZW0uaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xyXG4gIH0gZWxzZSBpZiAobGlzdC5ldmVyeSgoaXRlbSkgPT4gaXRlbS5mbGFnID09PSBmYWxzZSkpIHtcclxuICAgIHBhcmVudEl0ZW0uZmxhZyA9IGZhbHNlO1xyXG4gICAgcGFyZW50SXRlbS5pbmRldGVybWluYXRlID0gZmFsc2U7XHJcbiAgfSBlbHNlIGlmIChsaXN0LnNvbWUoKGl0ZW0pID0+IGl0ZW0uZmxhZyA9PT0gdHJ1ZSkpIHtcclxuICAgIHBhcmVudEl0ZW0uZmxhZyA9IGZhbHNlO1xyXG4gICAgcGFyZW50SXRlbS5pbmRldGVybWluYXRlID0gdHJ1ZTtcclxuICB9XHJcbiAgLy8gY2hhbmdlTGlzdCgpXHJcbn07XHJcbmNvbnN0IHJlcUxpc3QgPSAoKSA9PiB7XHJcbiAgcmVxdWVzdC5nZXQoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC91c2VyUm9sZS9yb2xlTGlzdGApLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgdGFibGVEYXRhLnZhbHVlID0gcmVzLmRhdGE7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn07XHJcbmNvbnN0IGNoYW5nZUxpc3QgPSAoKSA9PiB7XHJcbiAgcmVxdWVzdFxyXG4gICAgLnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC91c2VyUm9sZS91cGRhdGVSb2xlYCwge1xyXG4gICAgICBkYXRhOiB0YWJsZURhdGEudmFsdWUsXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgIG5leHRUaWNrKCgpID0+IHtcclxuICAgICAgICAgIHJlcUxpc3QoKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbn07XHJcbnJlcUxpc3QoKTtcclxub25Nb3VudGVkKCgpID0+IHt9KTtcclxub25CZWZvcmVVbm1vdW50KCgpID0+IHtcclxuICAvLyBjaGFuZ2VMaXN0KClcclxufSk7XHJcbjwvc2NyaXB0PlxyXG4gIDxzdHlsZSBzY29wZWQgbGFuZz1cImxlc3NcIj5cclxuLnJvbGVCb3gge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBwYWRkaW5nLXRvcDogMzBweDtcclxuICBwIHtcclxuICAgIGNvbG9yOiAjZmQxMDMwO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwcHg7XHJcbiAgICBsZWZ0OiAxMHB4O1xyXG4gIH1cclxuICAuc2F2ZUJ0biB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogMTBweDtcclxuICAgIHRvcDogMHB4O1xyXG4gIH1cclxufVxyXG4uY29sdW1uQm94IHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZTZlOGVjO1xyXG4gIGJvcmRlci10b3A6IG5vbmU7XHJcbiAgcGFkZGluZzogMTBweDtcclxufVxyXG4uZG9uZUJveCB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2U2ZThlYztcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDM5cHg7XHJcbn1cclxuLmRvbmVUeXBlQ2xhc3Mge1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLnZ4ZS1oZWFkZXItLWNvbHVtbiB7XHJcbiAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuOjp2LWRlZXAoLnZ4ZS1ib2R5LS1jb2x1bW4pIHtcclxuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxufVxyXG46OnYtZGVlcCgudnhlLWNlbGwpIHtcclxuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcbjwvc3R5bGU+IiwiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJtYWluQm94XCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2VhcmNoXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJzZWFyY2hMYWJsZVwiPueUqOaIt+WQjTo8L3NwYW5cclxuICAgICAgICA+PHZ4ZS1pbnB1dFxyXG4gICAgICAgICAgdi1tb2RlbD1cInF1ZXJ5LnVzZXJOYW1lXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6L6T5YWl55So5oi35ZCNXCJcclxuICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgQGNsZWFyPVwicmVxTGlzdFwiXHJcbiAgICAgICAgICBAc2VhcmNoLWNsaWNrPVwicmVxTGlzdFwiXHJcbiAgICAgICAgPjwvdnhlLWlucHV0PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaEl0ZW1cIj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cInNlYXJjaExhYmxlXCI+55So5oi36LSm5Y+3Ojwvc3Bhbj5cclxuICAgICAgICA8dnhlLWlucHV0XHJcbiAgICAgICAgICB2LW1vZGVsPVwicXVlcnkubmFtZVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIui+k+WFpeeUqOaIt+i0puWPt1wiXHJcbiAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgdHlwZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgIEBjbGVhcj1cInJlcUxpc3RcIlxyXG4gICAgICAgICAgQHNlYXJjaC1jbGljaz1cInJlcUxpc3RcIlxyXG4gICAgICAgID48L3Z4ZS1pbnB1dD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJzZWFyY2hMYWJsZVwiPueUqOaIt+inkuiJsjo8L3NwYW4+XHJcbiAgICAgICAgPHZ4ZS1zZWxlY3RcclxuICAgICAgICAgIHYtbW9kZWw9XCJxdWVyeS5yb2xlXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6YCJ5oup55So5oi36KeS6ImyXCJcclxuICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICBAY2hhbmdlPVwicmVxTGlzdFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHZ4ZS1vcHRpb25cclxuICAgICAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHJvbGVMaXN0XCJcclxuICAgICAgICAgICAgOmtleT1cImluZGV4XCJcclxuICAgICAgICAgICAgOnZhbHVlPVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5jbmFtZVwiXHJcbiAgICAgICAgICA+PC92eGUtb3B0aW9uPlxyXG4gICAgICAgIDwvdnhlLXNlbGVjdD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHZ4ZS1idXR0b25cclxuICAgICAgICAgIHN0YXR1cz1cInByaW1hcnlcIlxyXG4gICAgICAgICAgY29udGVudD1cIuafpeivolwiXHJcbiAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgQGNsaWNrPVwicmVxTGlzdFwiXHJcbiAgICAgICAgPjwvdnhlLWJ1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJ0YWJsZUJveFwiPlxyXG4gICAgICA8dnhlLXRhYmxlIDphbGlnbj1cIidsZWZ0J1wiIDpkYXRhPVwidGFibGVEYXRhXCI+XHJcbiAgICAgICAgPHZ4ZS1jb2x1bW4gZmllbGQ9XCJ1c2VyTmFtZVwiIHRpdGxlPVwi55So5oi35Lit5paH5ZCNXCI+PC92eGUtY29sdW1uPlxyXG4gICAgICAgIDx2eGUtY29sdW1uIGZpZWxkPVwibmFtZVwiIHRpdGxlPVwi55So5oi36LSm5Y+3XCI+PC92eGUtY29sdW1uPlxyXG4gICAgICAgIDx2eGUtY29sdW1uIHRpdGxlPVwi55So5oi36KeS6ImyXCI+XHJcbiAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJ7IHJvdyB9XCI+XHJcbiAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgIHt7IGdldFJvbGVWYWx1ZShyb3cucm9sZSkgfX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICA8L3Z4ZS1jb2x1bW4+XHJcbiAgICAgICAgPHZ4ZS1jb2x1bW4gdGl0bGU9XCLmk43kvZxcIiB3aWR0aD1cIjIwMFwiIHNob3ctb3ZlcmZsb3c+XHJcbiAgICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJ7IHJvdyB9XCI+XHJcbiAgICAgICAgICAgIDx2eGUtYnV0dG9uIHR5cGU9XCJ0ZXh0XCIgc3RhdHVzPVwicHJpbWFyeVwiIEBjbGljaz1cIm9wZW5EaWEocm93KVwiXHJcbiAgICAgICAgICAgICAgPue8lui+kTwvdnhlLWJ1dHRvblxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICA8L3RlbXBsYXRlPlxyXG4gICAgICAgIDwvdnhlLWNvbHVtbj5cclxuICAgICAgPC92eGUtdGFibGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIDx2eGUtcGFnZXJcclxuICAgICAgYmFja2dyb3VuZFxyXG4gICAgICB2LW1vZGVsOmN1cnJlbnQtcGFnZT1cInBhZ2VJbmZvLmN1cnJlbnRQYWdlXCJcclxuICAgICAgdi1tb2RlbDpwYWdlLXNpemU9XCJwYWdlSW5mby5wYWdlU2l6ZVwiXHJcbiAgICAgIDp0b3RhbD1cInRvdGFsXCJcclxuICAgICAgOmxheW91dHM9XCJbXHJcbiAgICAgICAgJ1ByZXZKdW1wJyxcclxuICAgICAgICAnUHJldlBhZ2UnLFxyXG4gICAgICAgICdKdW1wTnVtYmVyJyxcclxuICAgICAgICAnTmV4dFBhZ2UnLFxyXG4gICAgICAgICdOZXh0SnVtcCcsXHJcbiAgICAgICAgJ1NpemVzJyxcclxuICAgICAgICAnRnVsbEp1bXAnLFxyXG4gICAgICAgICdUb3RhbCcsXHJcbiAgICAgIF1cIlxyXG4gICAgPlxyXG4gICAgPC92eGUtcGFnZXI+XHJcbiAgPC9kaXY+XHJcbiAgPHZ4ZS1tb2RhbCB2LW1vZGVsPVwidmlzaWFibGVcIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwPlxyXG4gICAgICAgIOWnk+WQjTpcclxuICAgICAgICA8dnhlLWlucHV0XHJcbiAgICAgICAgICB2LW1vZGVsPVwicm93SW5mby51c2VyTmFtZVwiXHJcbiAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgIGNsYXNzPVwibW9kZWxJdGVtXCJcclxuICAgICAgICA+PC92eGUtaW5wdXQ+XHJcbiAgICAgIDwvcD5cclxuICAgICAgPHA+XHJcbiAgICAgICAg6KeS6ImyOlxyXG4gICAgICAgIDx2eGUtc2VsZWN0XHJcbiAgICAgICAgICB2LW1vZGVsPVwicm93SW5mby5yb2xlXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6YCJ5oup55So5oi36KeS6ImyXCJcclxuICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICBjbGFzcz1cIm1vZGVsSXRlbVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHZ4ZS1vcHRpb25cclxuICAgICAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHJvbGVMaXN0XCJcclxuICAgICAgICAgICAgOmtleT1cImluZGV4XCJcclxuICAgICAgICAgICAgOnZhbHVlPVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5jbmFtZVwiXHJcbiAgICAgICAgICA+PC92eGUtb3B0aW9uPlxyXG4gICAgICAgIDwvdnhlLXNlbGVjdD5cclxuICAgICAgPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyXCI+XHJcbiAgICAgICAgPHZ4ZS1idXR0b24gc2l6ZT1cInNtYWxsXCIgQGNsaWNrPVwidmlzaWFibGUgPSBmYWxzZVwiIGNsYXNzPVwiYnRuXCJcclxuICAgICAgICAgID7lj5bmtog8L3Z4ZS1idXR0b25cclxuICAgICAgICA+XHJcbiAgICAgICAgPHZ4ZS1idXR0b24gc3RhdHVzPVwicHJpbWFyeVwiIHNpemU9XCJzbWFsbFwiIEBjbGljaz1cInNhdmVSb2xlXCIgY2xhc3M9XCJidG5cIlxyXG4gICAgICAgICAgPuehruWumjwvdnhlLWJ1dHRvblxyXG4gICAgICAgID5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICA8L3Z4ZS1tb2RhbD5cclxuPC90ZW1wbGF0ZT5cclxuPHNjcmlwdCBzZXR1cD5cclxuaW1wb3J0IHJlcXVlc3QgZnJvbSBcIkAvdXRpbHMvcmVxdWVzdFV0aWxzXCI7XHJcbmltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcclxuLy/op5LoibLliJfooahcclxuY29uc3Qgcm9sZUxpc3QgPSByZWYoW10pO1xyXG5jb25zdCByZXFSb2xlTGlzdCA9ICgpID0+IHtcclxuICByZXF1ZXN0LmdldChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3VzZXJSb2xlL3JvbGVMaXN0YCkudGhlbigocmVzKSA9PiB7XHJcbiAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICByb2xlTGlzdC52YWx1ZSA9IHJlcy5kYXRhO1xyXG4gICAgICByb2xlTGlzdC52YWx1ZS51bnNoaWZ0KHtcclxuICAgICAgICBuYW1lOiBcIlwiLFxyXG4gICAgICAgIGNuYW1lOiBcIuWFqOmDqFwiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmVxTGlzdCgpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBnZXRSb2xlVmFsdWUgPSAodmFsKSA9PiB7XHJcbiAgbGV0IHZhbHVlID0gcm9sZUxpc3QudmFsdWUuZmluZCgoaXRlbSkgPT4gaXRlbS5uYW1lID09PSB2YWwpO1xyXG4gIGlmICh2YWx1ZSkge1xyXG4gICAgcmV0dXJuIHZhbHVlLmNuYW1lO1xyXG4gIH1cclxuICAvLyAgIHJldHVybiByb2xlTGlzdC52YWx1ZS5maW5kKGl0ZW09Pml0ZW0ubmFtZSA9PT0gdmFsKVsnY25hbWUnXVxyXG4gIHJldHVybiB2YWw7XHJcbn07XHJcbnJlcVJvbGVMaXN0KCk7XHJcblxyXG4vL+afpeivouWIl+ihqFxyXG5jb25zdCBxdWVyeSA9IHJlYWN0aXZlKHtcclxuICB1c2VyTmFtZTogXCJcIixcclxuICBuYW1lOiBcIlwiLFxyXG4gIHJvbGU6IFwiXCIsXHJcbn0pO1xyXG5jb25zdCBwYWdlSW5mbyA9IHJlYWN0aXZlKHtcclxuICBjdXJyZW50UGFnZTogMSxcclxuICBwYWdlU2l6ZTogMTAsXHJcbn0pO1xyXG5jb25zdCB0b3RhbCA9IHJlZig4KTtcclxuY29uc3QgdGFibGVEYXRhID0gcmVmKFtdKTtcclxuY29uc3QgcmVxTGlzdCA9ICgpID0+IHtcclxuICByZXF1ZXN0XHJcbiAgICAucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3VzZXJSb2xlL3VzZXJsaXN0YCwgeyBxdWVyeSwgcGFnZUluZm8gfSlcclxuICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgICB0YWJsZURhdGEudmFsdWUgPSByZXMuZGF0YS5saXN0O1xyXG4gICAgICAgIHRvdGFsLnZhbHVlID0gcmVzLmRhdGEudG90YWw7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG59O1xyXG5cclxuY29uc3Qgcm93SW5mbyA9IHJlZih7fSk7XHJcbmNvbnN0IHZpc2lhYmxlID0gcmVmKGZhbHNlKTtcclxuY29uc3Qgb3BlbkRpYSA9IChyb3cpID0+IHtcclxuICByb3dJbmZvLnZhbHVlID0gcm93O1xyXG4gIHZpc2lhYmxlLnZhbHVlID0gdHJ1ZTtcclxufTtcclxuY29uc3Qgc2F2ZVJvbGUgPSAoKSA9PiB7XHJcbiAgcmVxdWVzdFxyXG4gICAgLnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC91c2VyUm9sZS91cGRhdGVVc2VyUm9sZWAsIHtcclxuICAgICAgZGF0YTogcm93SW5mby52YWx1ZSxcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgIGlmIChyZXMuY29kZSA9PT0gMjAwKSB7XHJcbiAgICAgICAgdmlzaWFibGUudmFsdWUgPSBmYWxzZTtcclxuICAgICAgICBuZXh0VGljaygoKSA9PiB7XHJcbiAgICAgICAgICByZXFMaXN0KCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG59O1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4ubWFpbkJveCB7XHJcbiAgLnNlYXJjaCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgIC5zZWFyY2hJdGVtIHtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5cclxuICAgICAgLnNlYXJjaExhYmxlIHtcclxuICAgICAgICBtYXJnaW46IDAgMTBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLnRhYmxlQm94IHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDU2MHB4O1xyXG4gIH1cclxufVxyXG5wIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgLm1vZGVsSXRlbSB7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBtYXJnaW46IDEwcHggMjBweDtcclxuICB9XHJcbn1cclxuLmZvb3RlciB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgLmJ0biB7XHJcbiAgICB3aWR0aDogNjBweDtcclxuICB9XHJcbn1cclxuPC9zdHlsZT4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0wODVhNDdkNCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MDg1YTQ3ZDQmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vcm9sZS52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD01Y2QxNjhlMiZzY29wZWQ9dHJ1ZSZsYW5nPWxlc3NcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vcm9sZS52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD01Y2QxNjhlMiZzY29wZWQ9dHJ1ZSZsYW5nPWxlc3NcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi91c2VyTGlzdC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0xMGEwMGZmNSZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MTBhMDBmZjUmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTA4NWE0N2Q0JnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTA4NWE0N2Q0Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LTA4NWE0N2Q0XCJdLFsnX19maWxlJyxcInNyYy9wYWdlcy9wZXJtaXNzaW9uL2luZGV4LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIwODVhNDdkNFwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzA4NWE0N2Q0JywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMDg1YTQ3ZDQnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wODVhNDdkNCZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCcwODVhNDdkNCcsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vcm9sZS52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NWNkMTY4ZTImc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9yb2xlLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL3JvbGUudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL3JvbGUudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NWNkMTY4ZTImc2NvcGVkPXRydWUmbGFuZz1sZXNzXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtNWNkMTY4ZTJcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL3Blcm1pc3Npb24vcm9sZS52dWVcIl1dKVxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgX19leHBvcnRzX18uX19obXJJZCA9IFwiNWNkMTY4ZTJcIlxuICBjb25zdCBhcGkgPSBfX1ZVRV9ITVJfUlVOVElNRV9fXG4gIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgaWYgKCFhcGkuY3JlYXRlUmVjb3JkKCc1Y2QxNjhlMicsIF9fZXhwb3J0c19fKSkge1xuICAgIGFwaS5yZWxvYWQoJzVjZDE2OGUyJywgX19leHBvcnRzX18pXG4gIH1cbiAgXG4gIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9yb2xlLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD01Y2QxNjhlMiZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCc1Y2QxNjhlMicsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTEwYTAwZmY1JnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL3VzZXJMaXN0LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTEwYTAwZmY1Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LTEwYTAwZmY1XCJdLFsnX19maWxlJyxcInNyYy9wYWdlcy9wZXJtaXNzaW9uL3VzZXJMaXN0LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIxMGEwMGZmNVwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzEwYTAwZmY1JywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMTBhMDBmZjUnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL3VzZXJMaXN0LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0xMGEwMGZmNSZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCcxMGEwMGZmNScsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9pbmRleC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vcm9sZS52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3JvbGUudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3VzZXJMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3RlbXBsYXRlTG9hZGVyLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzRdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9pbmRleC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MDg1YTQ3ZDQmc2NvcGVkPXRydWVcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3RlbXBsYXRlTG9hZGVyLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzRdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9yb2xlLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD01Y2QxNjhlMiZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3VzZXJMaXN0LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0xMGEwMGZmNSZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MDg1YTQ3ZDQmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9yb2xlLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTVjZDE2OGUyJnNjb3BlZD10cnVlJmxhbmc9bGVzc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vdXNlckxpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MTBhMDBmZjUmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiXSwibmFtZXMiOlsiVXNlckxpc3QiLCJSb2xlIiwiX2NyZWF0ZUVsZW1lbnRCbG9jayIsIl9ob2lzdGVkXzEiLCJfY3JlYXRlVk5vZGUiLCJfY29tcG9uZW50X2VsX3RhYnMiLCJ0eXBlIiwiX2NvbXBvbmVudF9lbF90YWJfcGFuZSIsImxhYmVsIiwiJHNldHVwIiwiX2NyZWF0ZUVsZW1lbnRWTm9kZSIsIl9ob2lzdGVkXzIiLCJfY29tcG9uZW50X3Z4ZV9idXR0b24iLCJzdGF0dXMiLCJjb250ZW50Iiwib25DbGljayIsImNoYW5nZUxpc3QiLCJfY29tcG9uZW50X3Z4ZV90YWJsZSIsImFsaWduIiwiZGF0YSIsInRhYmxlRGF0YSIsIl9jb21wb25lbnRfdnhlX2NvbHVtbiIsImZpZWxkIiwidGl0bGUiLCJ3aWR0aCIsIl93aXRoQ3R4IiwiX3JlZiIsInJvdyIsIl90b0Rpc3BsYXlTdHJpbmciLCJjbmFtZSIsIl9yZWYyIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJtZW51TmFtZSIsIml0ZW0iLCJpbmRleCIsImtleSIsIl9jb21wb25lbnRfdnhlX2NoZWNrYm94IiwiZmxhZyIsIiRldmVudCIsImluZGV0ZXJtaW5hdGUiLCJvbkNoYW5nZSIsImNoYW5nZUNoZWNrMSIsImRpc2FibGVkIiwiX2NyZWF0ZUNvbW1lbnRWTm9kZSIsIl9yZWYzIiwiZG9uZU5hbWUiLCJ2YWwiLCJpbmQiLCJzaXplIiwiY2hhbmdlQ2hlY2syIiwiX2hvaXN0ZWRfMyIsIl9ob2lzdGVkXzQiLCJfY29tcG9uZW50X3Z4ZV9pbnB1dCIsInF1ZXJ5IiwidXNlck5hbWUiLCJwbGFjZWhvbGRlciIsImNsZWFyYWJsZSIsIm9uQ2xlYXIiLCJyZXFMaXN0Iiwib25TZWFyY2hDbGljayIsIl9ob2lzdGVkXzUiLCJfaG9pc3RlZF82IiwibmFtZSIsIl9ob2lzdGVkXzciLCJfaG9pc3RlZF84IiwiX2NvbXBvbmVudF92eGVfc2VsZWN0Iiwicm9sZSIsInJvbGVMaXN0IiwiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF92eGVfb3B0aW9uIiwidmFsdWUiLCJfaG9pc3RlZF85IiwiX2hvaXN0ZWRfMTAiLCJnZXRSb2xlVmFsdWUiLCJvcGVuRGlhIiwiX2NvbXBvbmVudF92eGVfcGFnZXIiLCJiYWNrZ3JvdW5kIiwicGFnZUluZm8iLCJjdXJyZW50UGFnZSIsInBhZ2VTaXplIiwidG90YWwiLCJsYXlvdXRzIiwiX2NvbXBvbmVudF92eGVfbW9kYWwiLCJ2aXNpYWJsZSIsInJvd0luZm8iLCJfaG9pc3RlZF8xMSIsIl9jYWNoZSIsInNhdmVSb2xlIl0sInNvdXJjZVJvb3QiOiIifQ==