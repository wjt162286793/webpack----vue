"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_business_components_newBusiness_vue"],{

/***/ 65637:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "h4[data-v-0e4bf362] {\n  font-size: 18px;\n  font-weight: 500;\n  margin-bottom: 20px;\n}\n.formBox[data-v-0e4bf362] {\n  padding: 20px;\n  position: relative;\n  overflow: auto;\n  height: 100%;\n  padding-bottom: 40px;\n}\n.formBox .formItem[data-v-0e4bf362] {\n  width: 300px;\n}\n.formBox .btnList[data-v-0e4bf362] {\n  margin-bottom: 20px;\n}\n.formBox .footer[data-v-0e4bf362] {\n  padding-top: 10px;\n  height: 40px;\n  width: 100%;\n  position: absolute;\n  bottom: 30px;\n  left: 0px;\n  display: flex;\n  padding-right: 20px;\n  justify-content: flex-end;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/business/components/newBusiness.vue","webpack://./newBusiness.vue"],"names":[],"mappings":"AACA;EACE,eAAA;EACA,gBAAA;EACA,mBAAA;ACAF;ADGA;EACE,aAAA;EACA,kBAAA;EACA,cAAA;EACA,YAAA;EACA,oBAAA;ACDF;ADJA;EAQI,YAAA;ACDJ;ADPA;EAYI,mBAAA;ACFJ;ADVA;EAgBI,iBAAA;EACA,YAAA;EACA,WAAA;EACA,kBAAA;EACA,YAAA;EACA,SAAA;EACA,aAAA;EACA,mBAAA;EACA,yBAAA;ACHJ","sourcesContent":["\nh4 {\n  font-size: 18px;\n  font-weight: 500;\n  margin-bottom: 20px;\n}\n\n.formBox {\n  padding: 20px;\n  position: relative;\n  overflow: auto;\n  height: 100%;\n  padding-bottom: 40px;\n\n  .formItem {\n    width: 300px;\n  }\n\n  .btnList {\n    margin-bottom: 20px;\n  }\n\n  .footer {\n    padding-top: 10px;\n    height: 40px;\n    width: 100%;\n    position: absolute;\n    bottom: 30px;\n    left: 0px;\n    display: flex;\n    padding-right: 20px;\n    justify-content: flex-end;\n  }\n}\n","h4 {\n  font-size: 18px;\n  font-weight: 500;\n  margin-bottom: 20px;\n}\n.formBox {\n  padding: 20px;\n  position: relative;\n  overflow: auto;\n  height: 100%;\n  padding-bottom: 40px;\n}\n.formBox .formItem {\n  width: 300px;\n}\n.formBox .btnList {\n  margin-bottom: 20px;\n}\n.formBox .footer {\n  padding-top: 10px;\n  height: 40px;\n  width: 100%;\n  position: absolute;\n  bottom: 30px;\n  left: 0px;\n  display: flex;\n  padding-right: 20px;\n  justify-content: flex-end;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 20389:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/newBusiness.vue?vue&type=script&setup=true&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var _visual_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./visual.vue */ 27742);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! uuid */ 98170);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var _data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../data.json */ 45990);
/* harmony import */ var _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/dictionaries/business.json */ 56789);












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'newBusiness',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var ruleForm = (0,vue__WEBPACK_IMPORTED_MODULE_3__.reactive)({
      name: "",
      cname: "",
      user: "",
      region: null,
      entiry: null,
      dcs: "",
      type: null,
      status: 1,
      modelList: [],
      mode: "business"
    });
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRoute)();
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    var ruleFormRef = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(null);
    var VisualCom = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(null);
    var drawerTitle = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)("新建模型方案");
    var openFlag = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)("new");
    var attr = (0,vue__WEBPACK_IMPORTED_MODULE_3__.useAttrs)();
    var drawer = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(false);
    var rowIndex = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)(0);
    var typeOptions = _data_json__WEBPACK_IMPORTED_MODULE_4__.type;
    var userList = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)([]);
    var entiryList = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)([]);
    var rules = (0,vue__WEBPACK_IMPORTED_MODULE_3__.reactive)({
      name: [{
        required: true,
        message: "请输入业务领域英文名称",
        trigger: "blur"
      }, {
        min: 3,
        max: 20,
        message: "Length should be 3 to 5",
        trigger: "blur"
      }],
      cname: [{
        required: true,
        message: "请输入业务领域中文名称",
        trigger: "blur"
      }, {
        min: 3,
        max: 10,
        message: "Length should be 3 to 5",
        trigger: "blur"
      }],
      user: [{
        required: true,
        message: "请选择资产负责人",
        trigger: "change"
      }],
      type: [{
        required: true,
        message: "请选择资产类型",
        trigger: "change"
      }]
    });
    var handleSelectionChange = function handleSelectionChange(val) {
      multipleSelection.value = val;
    };
    var multipleSelection = (0,vue__WEBPACK_IMPORTED_MODULE_3__.ref)([]);
    var submitForm = function submitForm(formEl) {
      if (!formEl) return;
      formEl.validate(function (valid, fields) {
        if (valid) {
          // console.log(ruleForm, "结果");
          _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/business/new"), ruleForm).then(function (res) {
            if (res.code === 200) {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
                message: "新建成功",
                type: "success"
              });
              goBack();
            } else if (res.code === 201) {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
                message: res.message,
                type: "warning"
              });
            }
          });
        } else {
          console.log("error submit!", fields);
        }
      });
    };
    var filterModeType = function filterModeType(scope) {
      console.log(_dictionaries_business_json__WEBPACK_IMPORTED_MODULE_5__.typeOptions, scope.row.modeType, "???什么");
      return _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_5__.typeOptions.find(function (item) {
        return item.value === scope.row.modeType;
      })["label"];
    };
    var getLists = function getLists() {
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/user/userAllList")).then(function (res) {
        if (res.code == 200) {
          userList.value = res.data;
        }
      });
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/publicApi/all"), {
        mode: "entiry"
      }).then(function (res) {
        if (res.code == 200) {
          res.data.forEach(function (item) {
            entiryList.value.push({
              label: item.entiryCnName,
              value: item.uuid
            });
          });
        }
      });
    };
    var resetForm = function resetForm(formEl) {
      if (!formEl) return;
      formEl.resetFields();
    };
    var goBack = function goBack() {
      router.push({
        name: "businessList"
      });
    };
    var options = Array.from({
      length: 10000
    }).map(function (_, idx) {
      return {
        value: "".concat(idx + 1),
        label: "".concat(idx + 1)
      };
    });
    var openDrawer = function openDrawer(flag) {
      openFlag.value = flag;
      drawer.value = true;
      (0,vue__WEBPACK_IMPORTED_MODULE_3__.nextTick)(function () {
        if (flag === "new") {
          VisualCom.value.doneType("new");
          drawerTitle.value = "新建模型方案";
          if (ruleForm.modelList.length >= 3) {
            (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
              type: "warning",
              message: "最多可有三套模型方案"
            });
            drawer.value = false;
          }
        } else {
          console.log(flag, "什么???");
          rowIndex.value = flag.$index;
          VisualCom.value.doneType("change", flag.row);
          drawerTitle.value = flag.row.scenarioName;
        }
      });
    };
    var deleteRow = function deleteRow(flag) {
      ruleForm.modelList.splice(flag.$index, 1);
    };
    var cancelClick = function cancelClick() {
      drawer.value = false;
    };
    var confirmClick = function confirmClick() {
      console.log(VisualCom.value.info, "属性???");
      console.log(VisualCom.value.scenario_name, VisualCom.value.mode_type, "上面");
      if (VisualCom.value.scenario_name === "") {
        (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
          type: "warning",
          message: "请输入模型名称"
        });
        return;
      }
      if (VisualCom.value.mode_type === "") {
        (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
          type: "warning",
          message: "请选择模型规范"
        });
        return;
      }
      var modelParam = {
        flowInfo: VisualCom.value.info,
        scenarioName: VisualCom.value.scenario_name,
        modeType: VisualCom.value.mode_type
      };
      if (openFlag.value === "new") {
        modelParam.id = (0,uuid__WEBPACK_IMPORTED_MODULE_8__["default"])();
        ruleForm.modelList.push(modelParam);
      } else {
        console.log(ruleForm.modelList, rowIndex.value, modelParam, "插入");
        ruleForm.modelList[rowIndex.value] = modelParam;
      }
      cancelClick();
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_3__.onMounted)(function () {
      getLists();
    });
    var __returned__ = {
      ruleForm: ruleForm,
      route: route,
      router: router,
      ruleFormRef: ruleFormRef,
      get VisualCom() {
        return VisualCom;
      },
      set VisualCom(v) {
        VisualCom = v;
      },
      get drawerTitle() {
        return drawerTitle;
      },
      set drawerTitle(v) {
        drawerTitle = v;
      },
      openFlag: openFlag,
      get attr() {
        return attr;
      },
      set attr(v) {
        attr = v;
      },
      get drawer() {
        return drawer;
      },
      set drawer(v) {
        drawer = v;
      },
      get rowIndex() {
        return rowIndex;
      },
      set rowIndex(v) {
        rowIndex = v;
      },
      get typeOptions() {
        return typeOptions;
      },
      set typeOptions(v) {
        typeOptions = v;
      },
      get userList() {
        return userList;
      },
      set userList(v) {
        userList = v;
      },
      get entiryList() {
        return entiryList;
      },
      set entiryList(v) {
        entiryList = v;
      },
      rules: rules,
      handleSelectionChange: handleSelectionChange,
      multipleSelection: multipleSelection,
      submitForm: submitForm,
      filterModeType: filterModeType,
      getLists: getLists,
      resetForm: resetForm,
      goBack: goBack,
      options: options,
      openDrawer: openDrawer,
      deleteRow: deleteRow,
      cancelClick: cancelClick,
      confirmClick: confirmClick,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_6__.useRouter;
      },
      get useRoute() {
        return vue_router__WEBPACK_IMPORTED_MODULE_6__.useRoute;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage;
      },
      Visual: _visual_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
      get uuidv4() {
        return uuid__WEBPACK_IMPORTED_MODULE_8__["default"];
      },
      get Delete() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__.Delete;
      },
      get Edit() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_9__.Edit;
      },
      nextTick: vue__WEBPACK_IMPORTED_MODULE_3__.nextTick,
      onMounted: vue__WEBPACK_IMPORTED_MODULE_3__.onMounted,
      get datas() {
        return _data_json__WEBPACK_IMPORTED_MODULE_4__;
      },
      get word() {
        return _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_5__;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 81350:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/newBusiness.vue?vue&type=template&id=0e4bf362&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-0e4bf362"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "formBox"
};
var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "基本信息", -1 /* HOISTED */);
});
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "模型图", -1 /* HOISTED */);
});
var _hoisted_4 = {
  "class": "btnList"
};
var _hoisted_5 = {
  "class": "footer"
};
var _hoisted_6 = {
  style: {
    "margin-bottom": "0px"
  }
};
var _hoisted_7 = {
  style: {
    "flex": "auto"
  }
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_form_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form-item");
  var _component_el_col = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-col");
  var _component_el_row = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-row");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_table_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table-column");
  var _component_el_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table");
  var _component_el_drawer = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-drawer");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [_hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
    ref: "ruleFormRef",
    model: $setup.ruleForm,
    rules: $setup.rules,
    "label-width": "120px",
    "class": "demo-ruleForm",
    "status-icon": ""
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "英文名称",
                prop: "name"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                    modelValue: $setup.ruleForm.name,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
                      return $setup.ruleForm.name = $event;
                    }),
                    "class": "formItem",
                    placeholder: "请输入业务领域英文名称",
                    clearable: ""
                  }, null, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "中文名称",
                prop: "cname"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                    modelValue: $setup.ruleForm.cname,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
                      return $setup.ruleForm.cname = $event;
                    }),
                    "class": "formItem",
                    placeholder: "请输入业务领域中文名",
                    clearable: ""
                  }, null, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "指定负责人",
                prop: "user"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                    modelValue: $setup.ruleForm.user,
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
                      return $setup.ruleForm.user = $event;
                    }),
                    placeholder: "请选择资产负责人",
                    "class": "formItem",
                    clearable: ""
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_option, {
                        label: "王惊涛",
                        value: "王惊涛"
                      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_option, {
                        label: "马师",
                        value: "马师"
                      })];
                    }),
                    _: 1 /* STABLE */
                  }, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "资产类型",
                prop: "type"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                    modelValue: $setup.ruleForm.type,
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
                      return $setup.ruleForm.type = $event;
                    }),
                    placeholder: "请选择资产类型",
                    "class": "formItem",
                    clearable: ""
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.typeOptions, function (item, index) {
                        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                          key: index,
                          label: item.label,
                          value: item.value
                        }, null, 8 /* PROPS */, ["label", "value"]);
                      }), 128 /* KEYED_FRAGMENT */))];
                    }),

                    _: 1 /* STABLE */
                  }, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "关联实体",
                prop: "entiry"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                    modelValue: $setup.ruleForm.entiry,
                    "onUpdate:modelValue": _cache[4] || (_cache[4] = function ($event) {
                      return $setup.ruleForm.entiry = $event;
                    }),
                    placeholder: "请选择关联实体",
                    "class": "formItem",
                    clearable: ""
                  }, {
                    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.entiryList, function (item, index) {
                        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                          key: index,
                          label: item.label,
                          value: item.value
                        }, null, 8 /* PROPS */, ["label", "value"]);
                      }), 128 /* KEYED_FRAGMENT */))];
                    }),

                    _: 1 /* STABLE */
                  }, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 12
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
                label: "资产描述",
                prop: "dsc"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                    modelValue: $setup.ruleForm.dsc,
                    "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
                      return $setup.ruleForm.dsc = $event;
                    }),
                    rows: 4,
                    type: "textarea",
                    placeholder: "请输入资产描述",
                    "class": "formItem",
                    clearable: ""
                  }, null, 8 /* PROPS */, ["modelValue"])];
                }),
                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["model", "rules"]), _hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: _cache[6] || (_cache[6] = function ($event) {
      return $setup.openDrawer('new');
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("创建模型图方案")];
    }),
    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table, {
    ref: "multipleTableRef",
    data: $setup.ruleForm.modelList,
    style: {
      "width": "100%"
    }
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "scenarioName",
        label: "模型图名称",
        width: "240"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "modeType",
        label: "模型规范",
        width: "240",
        "show-overflow-tooltip": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.filterModeType(scope)), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "id",
        label: "id",
        width: "width"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "操作",
        width: "240"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            icon: $setup.Edit,
            circle: "",
            onClick: function onClick($event) {
              return $setup.openDrawer(scope);
            }
          }, null, 8 /* PROPS */, ["icon", "onClick"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "danger",
            icon: $setup.Delete,
            circle: "",
            onClick: function onClick($event) {
              return $setup.deleteRow(scope);
            }
          }, null, 8 /* PROPS */, ["icon", "onClick"])];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: _cache[7] || (_cache[7] = function ($event) {
      return $setup.submitForm($setup.ruleFormRef);
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 创建 ")];
    }),
    _: 1 /* STABLE */
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    onClick: $setup.goBack
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("返回")];
    }),
    _: 1 /* STABLE */
  })])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_drawer, {
    modelValue: $setup.drawer,
    "onUpdate:modelValue": _cache[8] || (_cache[8] = function ($event) {
      return $setup.drawer = $event;
    }),
    direction: "rtl",
    size: "85%",
    "destroy-on-close": ""
  }, {
    header: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", _hoisted_6, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.drawerTitle), 1 /* TEXT */)];
    }),

    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["Visual"], {
        ref: "VisualCom"
      }, null, 512 /* NEED_PATCH */)];
    }),

    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_7, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: $setup.cancelClick
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        type: "primary",
        onClick: $setup.confirmClick
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("保存")];
        }),
        _: 1 /* STABLE */
      })])];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 94115:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true */ 65637);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 48347:
/*!*******************************************************!*\
  !*** ./src/pages/business/components/newBusiness.vue ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _newBusiness_vue_vue_type_template_id_0e4bf362_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./newBusiness.vue?vue&type=template&id=0e4bf362&scoped=true */ 99832);
/* harmony import */ var _newBusiness_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./newBusiness.vue?vue&type=script&setup=true&lang=js */ 72627);
/* harmony import */ var _newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true */ 97258);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_newBusiness_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_newBusiness_vue_vue_type_template_id_0e4bf362_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-0e4bf362"],['__file',"src/pages/business/components/newBusiness.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 72627:
/*!******************************************************************************************!*\
  !*** ./src/pages/business/components/newBusiness.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_newBusiness_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_newBusiness_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./newBusiness.vue?vue&type=script&setup=true&lang=js */ 20389);
 

/***/ }),

/***/ 99832:
/*!*************************************************************************************************!*\
  !*** ./src/pages/business/components/newBusiness.vue?vue&type=template&id=0e4bf362&scoped=true ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_newBusiness_vue_vue_type_template_id_0e4bf362_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_newBusiness_vue_vue_type_template_id_0e4bf362_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./newBusiness.vue?vue&type=template&id=0e4bf362&scoped=true */ 81350);


/***/ }),

/***/ 97258:
/*!****************************************************************************************************************!*\
  !*** ./src/pages/business/components/newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_newBusiness_vue_vue_type_style_index_0_id_0e4bf362_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./newBusiness.vue?vue&type=style&index=0&id=0e4bf362&lang=less&scoped=true */ 94115);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2J1c2luZXNzX2NvbXBvbmVudHNfbmV3QnVzaW5lc3NfdnVlLjkwMDU4NzQwNWFlYmI1NzA0NmQxLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDbUg7QUFDakI7QUFDbEcsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLCtEQUErRCxvQkFBb0IscUJBQXFCLHdCQUF3QixHQUFHLDZCQUE2QixrQkFBa0IsdUJBQXVCLG1CQUFtQixpQkFBaUIseUJBQXlCLEdBQUcsdUNBQXVDLGlCQUFpQixHQUFHLHNDQUFzQyx3QkFBd0IsR0FBRyxxQ0FBcUMsc0JBQXNCLGlCQUFpQixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLGtCQUFrQix3QkFBd0IsOEJBQThCLEdBQUcsU0FBUyw4SUFBOEksVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsV0FBVyxVQUFVLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssWUFBWSxVQUFVLFVBQVUsV0FBVyxVQUFVLFVBQVUsVUFBVSxXQUFXLFdBQVcsK0JBQStCLG9CQUFvQixxQkFBcUIsd0JBQXdCLEdBQUcsY0FBYyxrQkFBa0IsdUJBQXVCLG1CQUFtQixpQkFBaUIseUJBQXlCLGlCQUFpQixtQkFBbUIsS0FBSyxnQkFBZ0IsMEJBQTBCLEtBQUssZUFBZSx3QkFBd0IsbUJBQW1CLGtCQUFrQix5QkFBeUIsbUJBQW1CLGdCQUFnQixvQkFBb0IsMEJBQTBCLGdDQUFnQyxLQUFLLEdBQUcsU0FBUyxvQkFBb0IscUJBQXFCLHdCQUF3QixHQUFHLFlBQVksa0JBQWtCLHVCQUF1QixtQkFBbUIsaUJBQWlCLHlCQUF5QixHQUFHLHNCQUFzQixpQkFBaUIsR0FBRyxxQkFBcUIsd0JBQXdCLEdBQUcsb0JBQW9CLHNCQUFzQixpQkFBaUIsZ0JBQWdCLHVCQUF1QixpQkFBaUIsY0FBYyxrQkFBa0Isd0JBQXdCLDhCQUE4QixHQUFHLHFCQUFxQjtBQUNuL0Q7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BRO0FBQ0U7QUFDTjtBQUNGO0FBQ1A7QUFDRTtBQUNtQjtBQUNiO0FBQ1Q7QUFDZTs7O0FBQ2hELGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsNkNBQVE7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixvREFBUTtBQUN4QixpQkFBaUIscURBQVM7QUFDMUIsc0JBQXNCLHdDQUFHO0FBQ3pCLG9CQUFvQix3Q0FBRztBQUN2QixzQkFBc0Isd0NBQUc7QUFDekIsbUJBQW1CLHdDQUFHO0FBQ3RCLGVBQWUsNkNBQVE7QUFDdkIsaUJBQWlCLHdDQUFHO0FBQ3BCLG1CQUFtQix3Q0FBRztBQUN0QixzQkFBc0IsNENBQVU7QUFDaEMsbUJBQW1CLHdDQUFHO0FBQ3RCLHFCQUFxQix3Q0FBRztBQUN4QixnQkFBZ0IsNkNBQVE7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsd0NBQUc7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsZ0VBQVksV0FBVywrREFBYztBQUMvQztBQUNBLGNBQWMsdURBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsdURBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixvRUFBZ0I7QUFDbEMsYUFBYSx5RUFBcUI7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLCtEQUFXLFdBQVcsK0RBQWM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLGdFQUFZLFdBQVcsK0RBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sNkNBQVE7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksdURBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsdURBQVM7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSx1REFBUztBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdEQUFNO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4Q0FBUztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3REFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSxpREFBUztBQUN4QjtBQUNBO0FBQ0EsZUFBZSxnREFBUTtBQUN2QjtBQUNBO0FBQ0EsZUFBZSwyREFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSxtREFBUztBQUN4QjtBQUNBLGNBQWMsbURBQU07QUFDcEI7QUFDQSxlQUFlLDRDQUFNO0FBQ3JCO0FBQ0E7QUFDQSxlQUFlLDJEQUFNO0FBQ3JCO0FBQ0E7QUFDQSxlQUFlLHlEQUFJO0FBQ25CO0FBQ0EsZ0JBQWdCLHlDQUFRO0FBQ3hCLGlCQUFpQiwwQ0FBUztBQUMxQjtBQUNBLGVBQWUsdUNBQUs7QUFDcEI7QUFDQTtBQUNBLGVBQWUsd0RBQUk7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VDclRNLFNBQU07QUFBUzs7c0JBQ2xCQSx1REFBQSxDQUFhLFlBQVQsTUFBSTtBQUFBOztzQkF1RlJBLHVEQUFBLENBQVksWUFBUixLQUFHO0FBQUE7O0VBQ0YsU0FBTTtBQUFTOztFQXVDZixTQUFNO0FBQVE7O0VBU2JDLEtBQTBCLEVBQTFCO0lBQUE7RUFBQTtBQUEwQjs7RUFNekJBLEtBQWtCLEVBQWxCO0lBQUE7RUFBQTtBQUFrQjs7Ozs7Ozs7Ozs7OztxS0EvSTNCRCx1REFBQSxDQXNJTSxPQXRJTkUsVUFzSU0sR0FySUpDLFVBQWEsRUFDYkMsZ0RBQUEsQ0FxRlVDLGtCQUFBO0lBcEZSQyxHQUFHLEVBQUMsYUFBYTtJQUNoQkMsS0FBSyxFQUFFQyxNQUFBLENBQUFDLFFBQVE7SUFDZkMsS0FBSyxFQUFFRixNQUFBLENBQUFFLEtBQUs7SUFDYixhQUFXLEVBQUMsT0FBTztJQUNuQixTQUFNLGVBQWU7SUFDckIsYUFBVyxFQUFYOzs0REFFQTtNQUFBLE9BbUJTLENBbkJUTixnREFBQSxDQW1CU08saUJBQUE7Z0VBbEJQO1VBQUEsT0FRVSxDQVJWUCxnREFBQSxDQVFVUSxpQkFBQTtZQVJEQyxJQUFJLEVBQUU7VUFBRTtvRUFDZjtjQUFBLE9BT0QsQ0FQQ1QsZ0RBQUEsQ0FPRFUsdUJBQUE7Z0JBUGVDLEtBQUssRUFBQyxNQUFNO2dCQUFDQyxJQUFJLEVBQUM7O3dFQUM5QjtrQkFBQSxPQUtFLENBTEZaLGdEQUFBLENBS0VhLG1CQUFBO2dDQUpTVCxNQUFBLENBQUFDLFFBQVEsQ0FBQ1MsSUFBSTs7NkJBQWJWLE1BQUEsQ0FBQUMsUUFBUSxDQUFDUyxJQUFJLEdBQUFDLE1BQUE7b0JBQUE7b0JBQ3RCLFNBQU0sVUFBVTtvQkFDaEJDLFdBQVcsRUFBQyxhQUFhO29CQUN6QkMsU0FBUyxFQUFUOzs7Ozs7OztjQUdOakIsZ0RBQUEsQ0FRVVEsaUJBQUE7WUFSREMsSUFBSSxFQUFFO1VBQUU7b0VBQ2Y7Y0FBQSxPQU9ELENBUENULGdEQUFBLENBT0RVLHVCQUFBO2dCQVBlQyxLQUFLLEVBQUMsTUFBTTtnQkFBQ0MsSUFBSSxFQUFDOzt3RUFDOUI7a0JBQUEsT0FLRSxDQUxGWixnREFBQSxDQUtFYSxtQkFBQTtnQ0FKU1QsTUFBQSxDQUFBQyxRQUFRLENBQUNhLEtBQUs7OzZCQUFkZCxNQUFBLENBQUFDLFFBQVEsQ0FBQ2EsS0FBSyxHQUFBSCxNQUFBO29CQUFBO29CQUN2QixTQUFNLFVBQVU7b0JBQ2hCQyxXQUFXLEVBQUMsWUFBWTtvQkFDeEJDLFNBQVMsRUFBVDs7Ozs7Ozs7Ozs7O1VBSVJqQixnREFBQSxDQTRCU08saUJBQUE7Z0VBM0JQO1VBQUEsT0FXVSxDQVhWUCxnREFBQSxDQVdVUSxpQkFBQTtZQVhEQyxJQUFJLEVBQUU7VUFBRTtvRUFDZjtjQUFBLE9BVUQsQ0FWQ1QsZ0RBQUEsQ0FVRFUsdUJBQUE7Z0JBVmVDLEtBQUssRUFBQyxPQUFPO2dCQUFDQyxJQUFJLEVBQUM7O3dFQUMvQjtrQkFBQSxPQVFZLENBUlpaLGdEQUFBLENBUVltQixvQkFBQTtnQ0FQRGYsTUFBQSxDQUFBQyxRQUFRLENBQUNlLElBQUk7OzZCQUFiaEIsTUFBQSxDQUFBQyxRQUFRLENBQUNlLElBQUksR0FBQUwsTUFBQTtvQkFBQTtvQkFDdEJDLFdBQVcsRUFBQyxVQUFVO29CQUN0QixTQUFNLFVBQVU7b0JBQ2hCQyxTQUFTLEVBQVQ7OzRFQUVBO3NCQUFBLE9BQXFDLENBQXJDakIsZ0RBQUEsQ0FBcUNxQixvQkFBQTt3QkFBMUJWLEtBQUssRUFBQyxLQUFLO3dCQUFDVyxLQUFLLEVBQUM7MEJBQzdCdEIsZ0RBQUEsQ0FBbUNxQixvQkFBQTt3QkFBeEJWLEtBQUssRUFBQyxJQUFJO3dCQUFDVyxLQUFLLEVBQUM7Ozs7Ozs7Ozs7O2NBR2xDdEIsZ0RBQUEsQ0FjVVEsaUJBQUE7WUFkREMsSUFBSSxFQUFFO1VBQUU7b0VBQ2Y7Y0FBQSxPQWFELENBYkNULGdEQUFBLENBYURVLHVCQUFBO2dCQWJlQyxLQUFLLEVBQUMsTUFBTTtnQkFBQ0MsSUFBSSxFQUFDOzt3RUFDOUI7a0JBQUEsT0FXNEIsQ0FYNUJaLGdEQUFBLENBVzRCbUIsb0JBQUE7Z0NBVmpCZixNQUFBLENBQUFDLFFBQVEsQ0FBQ2tCLElBQUk7OzZCQUFibkIsTUFBQSxDQUFBQyxRQUFRLENBQUNrQixJQUFJLEdBQUFSLE1BQUE7b0JBQUE7b0JBQ3RCQyxXQUFXLEVBQUMsU0FBUztvQkFDckIsU0FBTSxVQUFVO29CQUNoQkMsU0FBUyxFQUFUOzs0RUFHRTtzQkFBQSxPQUFvQyx3REFEdENPLHVEQUFBLENBS2FDLHlDQUFBLFFBQUFDLCtDQUFBLENBSmF0QixNQUFBLENBQUF1QixXQUFXLFlBQTNCQyxJQUFJLEVBQUVDLEtBQUs7aUZBRHJCQyxnREFBQSxDQUthVCxvQkFBQTswQkFIVlUsR0FBRyxFQUFFRixLQUFLOzBCQUNWbEIsS0FBSyxFQUFFaUIsSUFBSSxDQUFDakIsS0FBSzswQkFDakJXLEtBQUssRUFBRU0sSUFBSSxDQUFDTjs7Ozs7Ozs7Ozs7Ozs7Ozs7VUFJdkJ0QixnREFBQSxDQTJCU08saUJBQUE7Z0VBMUJQO1VBQUEsT0FjVSxDQWRWUCxnREFBQSxDQWNVUSxpQkFBQTtZQWREQyxJQUFJLEVBQUU7VUFBRTtvRUFDZjtjQUFBLE9BYUQsQ0FiQ1QsZ0RBQUEsQ0FhRFUsdUJBQUE7Z0JBYmVDLEtBQUssRUFBQyxNQUFNO2dCQUFDQyxJQUFJLEVBQUM7O3dFQUM5QjtrQkFBQSxPQVdpQixDQVhqQlosZ0RBQUEsQ0FXaUJtQixvQkFBQTtnQ0FWTmYsTUFBQSxDQUFBQyxRQUFRLENBQUMyQixNQUFNOzs2QkFBZjVCLE1BQUEsQ0FBQUMsUUFBUSxDQUFDMkIsTUFBTSxHQUFBakIsTUFBQTtvQkFBQTtvQkFDeEJDLFdBQVcsRUFBQyxTQUFTO29CQUNyQixTQUFNLFVBQVU7b0JBQ2hCQyxTQUFTLEVBQVQ7OzRFQUdFO3NCQUFBLE9BQW1DLHdEQURyQ08sdURBQUEsQ0FLRUMseUNBQUEsUUFBQUMsK0NBQUEsQ0FKd0J0QixNQUFBLENBQUE2QixVQUFVLFlBQTFCTCxJQUFJLEVBQUVDLEtBQUs7aUZBRHJCQyxnREFBQSxDQUtFVCxvQkFBQTswQkFIQ1UsR0FBRyxFQUFFRixLQUFLOzBCQUNWbEIsS0FBSyxFQUFFaUIsSUFBSSxDQUFDakIsS0FBSzswQkFDakJXLEtBQUssRUFBRU0sSUFBSSxDQUFDTjs7Ozs7Ozs7Ozs7OztjQUdyQnRCLGdEQUFBLENBVVVRLGlCQUFBO1lBVkRDLElBQUksRUFBRTtVQUFFO29FQUNmO2NBQUEsT0FTRCxDQVRDVCxnREFBQSxDQVNEVSx1QkFBQTtnQkFUZUMsS0FBSyxFQUFDLE1BQU07Z0JBQUNDLElBQUksRUFBQzs7d0VBQzlCO2tCQUFBLE9BT0UsQ0FQRlosZ0RBQUEsQ0FPRWEsbUJBQUE7Z0NBTlNULE1BQUEsQ0FBQUMsUUFBUSxDQUFDNkIsR0FBRzs7NkJBQVo5QixNQUFBLENBQUFDLFFBQVEsQ0FBQzZCLEdBQUcsR0FBQW5CLE1BQUE7b0JBQUE7b0JBQ3BCb0IsSUFBSSxFQUFFLENBQUM7b0JBQ1JaLElBQUksRUFBQyxVQUFVO29CQUNmUCxXQUFXLEVBQUMsU0FBUztvQkFDckIsU0FBTSxVQUFVO29CQUNoQkMsU0FBUyxFQUFUOzs7Ozs7Ozs7Ozs7Ozs7O3lDQUtWbUIsVUFBWSxFQUNaeEMsdURBQUEsQ0FJTSxPQUpOeUMsVUFJTSxHQUhKckMsZ0RBQUEsQ0FFQ3NDLG9CQUFBO0lBRlVmLElBQUksRUFBQyxTQUFTO0lBQUVnQixPQUFLLEVBQUFDLE1BQUEsUUFBQUEsTUFBQSxnQkFBQXpCLE1BQUE7TUFBQSxPQUFFWCxNQUFBLENBQUFxQyxVQUFVO0lBQUE7OzREQUN6QztNQUFBLE9BQU8sc0RBQVAsU0FBTzs7O1FBR1p6QyxnREFBQSxDQWlDVzBDLG1CQUFBO0lBaENUeEMsR0FBRyxFQUFDLGtCQUFrQjtJQUNyQnlDLElBQUksRUFBRXZDLE1BQUEsQ0FBQUMsUUFBUSxDQUFDdUMsU0FBUztJQUN6Qi9DLEtBQW1CLEVBQW5CO01BQUE7SUFBQTs7NERBRUE7TUFBQSxPQUFxRSxDQUFyRUcsZ0RBQUEsQ0FBcUU2QywwQkFBQTtRQUFwREMsUUFBUSxFQUFDLGNBQWM7UUFBQ25DLEtBQUssRUFBQyxPQUFPO1FBQUNvQyxLQUFLLEVBQUM7VUFDN0QvQyxnREFBQSxDQVNrQjZDLDBCQUFBO1FBUmhCQyxRQUFRLEVBQUMsVUFBVTtRQUNuQm5DLEtBQUssRUFBQyxNQUFNO1FBQ1pvQyxLQUFLLEVBQUMsS0FBSztRQUNYLHVCQUFxQixFQUFyQjs7UUFFVyxXQUFPQyw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztVQUFBLFFBQ3ZCckQsdURBQUEsQ0FBd0MsY0FBQXNELG9EQUFBLENBQS9COUMsTUFBQSxDQUFBK0MsY0FBYyxDQUFDRixLQUFLOzs7O1VBR2pDakQsZ0RBQUEsQ0FBMEQ2QywwQkFBQTtRQUF6Q0MsUUFBUSxFQUFDLElBQUk7UUFBQ25DLEtBQUssRUFBQyxJQUFJO1FBQUNvQyxLQUFLLEVBQUM7VUFDaEQvQyxnREFBQSxDQWVrQjZDLDBCQUFBO1FBZkRsQyxLQUFLLEVBQUMsSUFBSTtRQUFDb0MsS0FBSyxFQUFDOztRQUNyQixXQUFPQyw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztVQUFBLFFBQ3ZCakQsZ0RBQUEsQ0FLRXNDLG9CQUFBO1lBSkFmLElBQUksRUFBQyxTQUFTO1lBQ2I2QixJQUFJLEVBQUVoRCxNQUFBLENBQUFpRCxJQUFJO1lBQ1hDLE1BQU0sRUFBTixFQUFNO1lBQ0xmLE9BQUssV0FBQUEsUUFBQXhCLE1BQUE7Y0FBQSxPQUFFWCxNQUFBLENBQUFxQyxVQUFVLENBQUNRLEtBQUs7WUFBQTt3REFFMUJqRCxnREFBQSxDQUtFc0Msb0JBQUE7WUFKQWYsSUFBSSxFQUFDLFFBQVE7WUFDWjZCLElBQUksRUFBRWhELE1BQUEsQ0FBQW1ELE1BQU07WUFDYkQsTUFBTSxFQUFOLEVBQU07WUFDTGYsT0FBSyxXQUFBQSxRQUFBeEIsTUFBQTtjQUFBLE9BQUVYLE1BQUEsQ0FBQW9ELFNBQVMsQ0FBQ1AsS0FBSztZQUFBOzs7Ozs7OzsrQkFLL0JyRCx1REFBQSxDQUtNLE9BTE42RCxVQUtNLEdBSkp6RCxnREFBQSxDQUVZc0Msb0JBQUE7SUFGRGYsSUFBSSxFQUFDLFNBQVM7SUFBRWdCLE9BQUssRUFBQUMsTUFBQSxRQUFBQSxNQUFBLGdCQUFBekIsTUFBQTtNQUFBLE9BQUVYLE1BQUEsQ0FBQXNELFVBQVUsQ0FBQ3RELE1BQUEsQ0FBQXVELFdBQVc7SUFBQTs7NERBQUc7TUFBQSxPQUUzRCxzREFGMkQsTUFFM0Q7OztNQUNBM0QsZ0RBQUEsQ0FBeUNzQyxvQkFBQTtJQUE3QkMsT0FBSyxFQUFFbkMsTUFBQSxDQUFBd0Q7RUFBTTs0REFBRTtNQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1VBR2pDNUQsZ0RBQUEsQ0FhWTZELG9CQUFBO2dCQWJRekQsTUFBQSxDQUFBMEQsTUFBTTs7YUFBTjFELE1BQUEsQ0FBQTBELE1BQU0sR0FBQS9DLE1BQUE7SUFBQTtJQUFFZ0QsU0FBUyxFQUFDLEtBQUs7SUFBQ0MsSUFBSSxFQUFDLEtBQUs7SUFBQyxrQkFBZ0IsRUFBaEI7O0lBQzFDQyxNQUFNLEVBQUFqQiw0Q0FBQSxDQUNmO01BQUEsT0FBcUQsQ0FBckRwRCx1REFBQSxDQUFxRCxNQUFyRHNFLFVBQXFELEVBQUFoQixvREFBQSxDQUFuQjlDLE1BQUEsQ0FBQStELFdBQVc7OztJQUVwQyxXQUFPbkIsNENBQUEsQ0FDaEI7TUFBQSxPQUFpQyxDQUFqQ2hELGdEQUFBLENBQWlDSSxNQUFBO1FBQXpCRixHQUFHLEVBQUM7TUFBVzs7O0lBRWRrRSxNQUFNLEVBQUFwQiw0Q0FBQSxDQUNmO01BQUEsT0FHTSxDQUhOcEQsdURBQUEsQ0FHTSxPQUhOeUUsVUFHTSxHQUZKckUsZ0RBQUEsQ0FBOENzQyxvQkFBQTtRQUFsQ0MsT0FBSyxFQUFFbkMsTUFBQSxDQUFBa0U7TUFBVztnRUFBRTtVQUFBLE9BQUUsc0RBQUYsSUFBRTs7O1VBQ2xDdEUsZ0RBQUEsQ0FBOERzQyxvQkFBQTtRQUFuRGYsSUFBSSxFQUFDLFNBQVM7UUFBRWdCLE9BQUssRUFBRW5DLE1BQUEsQ0FBQW1FOztnRUFBYztVQUFBLE9BQUUsc0RBQUYsSUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakoxRCxNQUF3RztBQUN4RyxNQUE4RjtBQUM5RixNQUFxRztBQUNyRyxNQUF3SDtBQUN4SCxNQUFpSDtBQUNqSCxNQUFpSDtBQUNqSCxNQUF1VztBQUN2VztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLHlTQUFPOzs7O0FBSWlUO0FBQ3pVLE9BQU8saUVBQWUseVNBQU8sSUFBSSxnVEFBYyxHQUFHLGdUQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCTztBQUNYO0FBQ0w7O0FBRXBFLENBQW1GOztBQUUrQjtBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQywyRkFBTSxhQUFhLDhGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7OztBQ3hCdVgiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL25ld0J1c2luZXNzLnZ1ZT8xMzM2Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvbmV3QnVzaW5lc3MudnVlPzM3ZTEiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9uZXdCdXNpbmVzcy52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9uZXdCdXNpbmVzcy52dWU/MTFkZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL25ld0J1c2luZXNzLnZ1ZT82MTA0Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvbmV3QnVzaW5lc3MudnVlPzc0NmMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9uZXdCdXNpbmVzcy52dWU/YmI2NyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL25ld0J1c2luZXNzLnZ1ZT9lMDNhIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiaDRbZGF0YS12LTBlNGJmMzYyXSB7XFxuICBmb250LXNpemU6IDE4cHg7XFxuICBmb250LXdlaWdodDogNTAwO1xcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcXG59XFxuLmZvcm1Cb3hbZGF0YS12LTBlNGJmMzYyXSB7XFxuICBwYWRkaW5nOiAyMHB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBwYWRkaW5nLWJvdHRvbTogNDBweDtcXG59XFxuLmZvcm1Cb3ggLmZvcm1JdGVtW2RhdGEtdi0wZTRiZjM2Ml0ge1xcbiAgd2lkdGg6IDMwMHB4O1xcbn1cXG4uZm9ybUJveCAuYnRuTGlzdFtkYXRhLXYtMGU0YmYzNjJdIHtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5mb3JtQm94IC5mb290ZXJbZGF0YS12LTBlNGJmMzYyXSB7XFxuICBwYWRkaW5nLXRvcDogMTBweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgYm90dG9tOiAzMHB4O1xcbiAgbGVmdDogMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9uZXdCdXNpbmVzcy52dWVcIixcIndlYnBhY2s6Ly8uL25ld0J1c2luZXNzLnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDQUY7QURHQTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUNERjtBREpBO0VBUUksWUFBQTtBQ0RKO0FEUEE7RUFZSSxtQkFBQTtBQ0ZKO0FEVkE7RUFnQkksaUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQ0hKXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcbmg0IHtcXG4gIGZvbnQtc2l6ZTogMThweDtcXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XFxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xcbn1cXG5cXG4uZm9ybUJveCB7XFxuICBwYWRkaW5nOiAyMHB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBwYWRkaW5nLWJvdHRvbTogNDBweDtcXG5cXG4gIC5mb3JtSXRlbSB7XFxuICAgIHdpZHRoOiAzMDBweDtcXG4gIH1cXG5cXG4gIC5idG5MaXN0IHtcXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcXG4gIH1cXG5cXG4gIC5mb290ZXIge1xcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcXG4gICAgaGVpZ2h0OiA0MHB4O1xcbiAgICB3aWR0aDogMTAwJTtcXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICBib3R0b206IDMwcHg7XFxuICAgIGxlZnQ6IDBweDtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAgcGFkZGluZy1yaWdodDogMjBweDtcXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcXG4gIH1cXG59XFxuXCIsXCJoNCB7XFxuICBmb250LXNpemU6IDE4cHg7XFxuICBmb250LXdlaWdodDogNTAwO1xcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcXG59XFxuLmZvcm1Cb3gge1xcbiAgcGFkZGluZzogMjBweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgcGFkZGluZy1ib3R0b206IDQwcHg7XFxufVxcbi5mb3JtQm94IC5mb3JtSXRlbSB7XFxuICB3aWR0aDogMzAwcHg7XFxufVxcbi5mb3JtQm94IC5idG5MaXN0IHtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5mb3JtQm94IC5mb290ZXIge1xcbiAgcGFkZGluZy10b3A6IDEwcHg7XFxuICBoZWlnaHQ6IDQwcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGJvdHRvbTogMzBweDtcXG4gIGxlZnQ6IDBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsImltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcbmltcG9ydCB7IHVzZVJvdXRlciwgdXNlUm91dGUgfSBmcm9tIFwidnVlLXJvdXRlclwiO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSBcIkAvdXRpbHMvcmVxdWVzdFV0aWxzXCI7XG5pbXBvcnQgeyBFbE1lc3NhZ2UgfSBmcm9tIFwiZWxlbWVudC1wbHVzXCI7XG5pbXBvcnQgVmlzdWFsIGZyb20gXCIuL3Zpc3VhbC52dWVcIjtcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XG5pbXBvcnQgeyBEZWxldGUsIEVkaXQgfSBmcm9tIFwiQGVsZW1lbnQtcGx1cy9pY29ucy12dWVcIjtcbmltcG9ydCB7IG5leHRUaWNrLCBvbk1vdW50ZWQgfSBmcm9tIFwidnVlXCI7XG5pbXBvcnQgZGF0YXMgZnJvbSBcIi4uL2RhdGEuanNvblwiO1xuaW1wb3J0IHdvcmQgZnJvbSBcIkAvZGljdGlvbmFyaWVzL2J1c2luZXNzLmpzb25cIjtcbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAnbmV3QnVzaW5lc3MnLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICBleHBvc2UoKTtcbiAgICB2YXIgcnVsZUZvcm0gPSByZWFjdGl2ZSh7XG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgY25hbWU6IFwiXCIsXG4gICAgICB1c2VyOiBcIlwiLFxuICAgICAgcmVnaW9uOiBudWxsLFxuICAgICAgZW50aXJ5OiBudWxsLFxuICAgICAgZGNzOiBcIlwiLFxuICAgICAgdHlwZTogbnVsbCxcbiAgICAgIHN0YXR1czogMSxcbiAgICAgIG1vZGVsTGlzdDogW10sXG4gICAgICBtb2RlOiBcImJ1c2luZXNzXCJcbiAgICB9KTtcbiAgICB2YXIgcm91dGUgPSB1c2VSb3V0ZSgpO1xuICAgIHZhciByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgICB2YXIgcnVsZUZvcm1SZWYgPSByZWYobnVsbCk7XG4gICAgdmFyIFZpc3VhbENvbSA9IHJlZihudWxsKTtcbiAgICB2YXIgZHJhd2VyVGl0bGUgPSByZWYoXCLmlrDlu7rmqKHlnovmlrnmoYhcIik7XG4gICAgdmFyIG9wZW5GbGFnID0gcmVmKFwibmV3XCIpO1xuICAgIHZhciBhdHRyID0gdXNlQXR0cnMoKTtcbiAgICB2YXIgZHJhd2VyID0gcmVmKGZhbHNlKTtcbiAgICB2YXIgcm93SW5kZXggPSByZWYoMCk7XG4gICAgdmFyIHR5cGVPcHRpb25zID0gZGF0YXMudHlwZTtcbiAgICB2YXIgdXNlckxpc3QgPSByZWYoW10pO1xuICAgIHZhciBlbnRpcnlMaXN0ID0gcmVmKFtdKTtcbiAgICB2YXIgcnVsZXMgPSByZWFjdGl2ZSh7XG4gICAgICBuYW1lOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXkuJrliqHpoobln5/oi7HmloflkI3np7BcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH0sIHtcbiAgICAgICAgbWluOiAzLFxuICAgICAgICBtYXg6IDIwLFxuICAgICAgICBtZXNzYWdlOiBcIkxlbmd0aCBzaG91bGQgYmUgMyB0byA1XCIsXG4gICAgICAgIHRyaWdnZXI6IFwiYmx1clwiXG4gICAgICB9XSxcbiAgICAgIGNuYW1lOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXkuJrliqHpoobln5/kuK3mloflkI3np7BcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH0sIHtcbiAgICAgICAgbWluOiAzLFxuICAgICAgICBtYXg6IDEwLFxuICAgICAgICBtZXNzYWdlOiBcIkxlbmd0aCBzaG91bGQgYmUgMyB0byA1XCIsXG4gICAgICAgIHRyaWdnZXI6IFwiYmx1clwiXG4gICAgICB9XSxcbiAgICAgIHVzZXI6IFt7XG4gICAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIuivt+mAieaLqei1hOS6p+i0n+i0o+S6ulwiLFxuICAgICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiXG4gICAgICB9XSxcbiAgICAgIHR5cGU6IFt7XG4gICAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIuivt+mAieaLqei1hOS6p+exu+Wei1wiLFxuICAgICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiXG4gICAgICB9XVxuICAgIH0pO1xuICAgIHZhciBoYW5kbGVTZWxlY3Rpb25DaGFuZ2UgPSBmdW5jdGlvbiBoYW5kbGVTZWxlY3Rpb25DaGFuZ2UodmFsKSB7XG4gICAgICBtdWx0aXBsZVNlbGVjdGlvbi52YWx1ZSA9IHZhbDtcbiAgICB9O1xuICAgIHZhciBtdWx0aXBsZVNlbGVjdGlvbiA9IHJlZihbXSk7XG4gICAgdmFyIHN1Ym1pdEZvcm0gPSBmdW5jdGlvbiBzdWJtaXRGb3JtKGZvcm1FbCkge1xuICAgICAgaWYgKCFmb3JtRWwpIHJldHVybjtcbiAgICAgIGZvcm1FbC52YWxpZGF0ZShmdW5jdGlvbiAodmFsaWQsIGZpZWxkcykge1xuICAgICAgICBpZiAodmFsaWQpIHtcbiAgICAgICAgICAvLyBjb25zb2xlLmxvZyhydWxlRm9ybSwgXCLnu5PmnpxcIik7XG4gICAgICAgICAgcmVxdWVzdC5wb3N0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvYnVzaW5lc3MvbmV3XCIpLCBydWxlRm9ybSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xuICAgICAgICAgICAgICBFbE1lc3NhZ2Uoe1xuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwi5paw5bu65oiQ5YqfXCIsXG4gICAgICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCJcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIGdvQmFjaygpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuY29kZSA9PT0gMjAxKSB7XG4gICAgICAgICAgICAgIEVsTWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgbWVzc2FnZTogcmVzLm1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCJcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBzdWJtaXQhXCIsIGZpZWxkcyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIGZpbHRlck1vZGVUeXBlID0gZnVuY3Rpb24gZmlsdGVyTW9kZVR5cGUoc2NvcGUpIHtcbiAgICAgIGNvbnNvbGUubG9nKHdvcmQudHlwZU9wdGlvbnMsIHNjb3BlLnJvdy5tb2RlVHlwZSwgXCI/Pz/ku4DkuYhcIik7XG4gICAgICByZXR1cm4gd29yZC50eXBlT3B0aW9ucy5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLnZhbHVlID09PSBzY29wZS5yb3cubW9kZVR5cGU7XG4gICAgICB9KVtcImxhYmVsXCJdO1xuICAgIH07XG4gICAgdmFyIGdldExpc3RzID0gZnVuY3Rpb24gZ2V0TGlzdHMoKSB7XG4gICAgICByZXF1ZXN0LmdldChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3VzZXIvdXNlckFsbExpc3RcIikpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBpZiAocmVzLmNvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgdXNlckxpc3QudmFsdWUgPSByZXMuZGF0YTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXF1ZXN0LnBvc3QoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcC9wdWJsaWNBcGkvYWxsXCIpLCB7XG4gICAgICAgIG1vZGU6IFwiZW50aXJ5XCJcbiAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBpZiAocmVzLmNvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgcmVzLmRhdGEuZm9yRWFjaChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgZW50aXJ5TGlzdC52YWx1ZS5wdXNoKHtcbiAgICAgICAgICAgICAgbGFiZWw6IGl0ZW0uZW50aXJ5Q25OYW1lLFxuICAgICAgICAgICAgICB2YWx1ZTogaXRlbS51dWlkXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgcmVzZXRGb3JtID0gZnVuY3Rpb24gcmVzZXRGb3JtKGZvcm1FbCkge1xuICAgICAgaWYgKCFmb3JtRWwpIHJldHVybjtcbiAgICAgIGZvcm1FbC5yZXNldEZpZWxkcygpO1xuICAgIH07XG4gICAgdmFyIGdvQmFjayA9IGZ1bmN0aW9uIGdvQmFjaygpIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgbmFtZTogXCJidXNpbmVzc0xpc3RcIlxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgb3B0aW9ucyA9IEFycmF5LmZyb20oe1xuICAgICAgbGVuZ3RoOiAxMDAwMFxuICAgIH0pLm1hcChmdW5jdGlvbiAoXywgaWR4KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcIi5jb25jYXQoaWR4ICsgMSksXG4gICAgICAgIGxhYmVsOiBcIlwiLmNvbmNhdChpZHggKyAxKVxuICAgICAgfTtcbiAgICB9KTtcbiAgICB2YXIgb3BlbkRyYXdlciA9IGZ1bmN0aW9uIG9wZW5EcmF3ZXIoZmxhZykge1xuICAgICAgb3BlbkZsYWcudmFsdWUgPSBmbGFnO1xuICAgICAgZHJhd2VyLnZhbHVlID0gdHJ1ZTtcbiAgICAgIG5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKGZsYWcgPT09IFwibmV3XCIpIHtcbiAgICAgICAgICBWaXN1YWxDb20udmFsdWUuZG9uZVR5cGUoXCJuZXdcIik7XG4gICAgICAgICAgZHJhd2VyVGl0bGUudmFsdWUgPSBcIuaWsOW7uuaooeWei+aWueahiFwiO1xuICAgICAgICAgIGlmIChydWxlRm9ybS5tb2RlbExpc3QubGVuZ3RoID49IDMpIHtcbiAgICAgICAgICAgIEVsTWVzc2FnZSh7XG4gICAgICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxuICAgICAgICAgICAgICBtZXNzYWdlOiBcIuacgOWkmuWPr+acieS4ieWll+aooeWei+aWueahiFwiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGRyYXdlci52YWx1ZSA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhmbGFnLCBcIuS7gOS5iD8/P1wiKTtcbiAgICAgICAgICByb3dJbmRleC52YWx1ZSA9IGZsYWcuJGluZGV4O1xuICAgICAgICAgIFZpc3VhbENvbS52YWx1ZS5kb25lVHlwZShcImNoYW5nZVwiLCBmbGFnLnJvdyk7XG4gICAgICAgICAgZHJhd2VyVGl0bGUudmFsdWUgPSBmbGFnLnJvdy5zY2VuYXJpb05hbWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgdmFyIGRlbGV0ZVJvdyA9IGZ1bmN0aW9uIGRlbGV0ZVJvdyhmbGFnKSB7XG4gICAgICBydWxlRm9ybS5tb2RlbExpc3Quc3BsaWNlKGZsYWcuJGluZGV4LCAxKTtcbiAgICB9O1xuICAgIHZhciBjYW5jZWxDbGljayA9IGZ1bmN0aW9uIGNhbmNlbENsaWNrKCkge1xuICAgICAgZHJhd2VyLnZhbHVlID0gZmFsc2U7XG4gICAgfTtcbiAgICB2YXIgY29uZmlybUNsaWNrID0gZnVuY3Rpb24gY29uZmlybUNsaWNrKCkge1xuICAgICAgY29uc29sZS5sb2coVmlzdWFsQ29tLnZhbHVlLmluZm8sIFwi5bGe5oCnPz8/XCIpO1xuICAgICAgY29uc29sZS5sb2coVmlzdWFsQ29tLnZhbHVlLnNjZW5hcmlvX25hbWUsIFZpc3VhbENvbS52YWx1ZS5tb2RlX3R5cGUsIFwi5LiK6Z2iXCIpO1xuICAgICAgaWYgKFZpc3VhbENvbS52YWx1ZS5zY2VuYXJpb19uYW1lID09PSBcIlwiKSB7XG4gICAgICAgIEVsTWVzc2FnZSh7XG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXG4gICAgICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXmqKHlnovlkI3np7BcIlxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKFZpc3VhbENvbS52YWx1ZS5tb2RlX3R5cGUgPT09IFwiXCIpIHtcbiAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcbiAgICAgICAgICBtZXNzYWdlOiBcIuivt+mAieaLqeaooeWei+inhOiMg1wiXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgbW9kZWxQYXJhbSA9IHtcbiAgICAgICAgZmxvd0luZm86IFZpc3VhbENvbS52YWx1ZS5pbmZvLFxuICAgICAgICBzY2VuYXJpb05hbWU6IFZpc3VhbENvbS52YWx1ZS5zY2VuYXJpb19uYW1lLFxuICAgICAgICBtb2RlVHlwZTogVmlzdWFsQ29tLnZhbHVlLm1vZGVfdHlwZVxuICAgICAgfTtcbiAgICAgIGlmIChvcGVuRmxhZy52YWx1ZSA9PT0gXCJuZXdcIikge1xuICAgICAgICBtb2RlbFBhcmFtLmlkID0gdXVpZHY0KCk7XG4gICAgICAgIHJ1bGVGb3JtLm1vZGVsTGlzdC5wdXNoKG1vZGVsUGFyYW0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2cocnVsZUZvcm0ubW9kZWxMaXN0LCByb3dJbmRleC52YWx1ZSwgbW9kZWxQYXJhbSwgXCLmj5LlhaVcIik7XG4gICAgICAgIHJ1bGVGb3JtLm1vZGVsTGlzdFtyb3dJbmRleC52YWx1ZV0gPSBtb2RlbFBhcmFtO1xuICAgICAgfVxuICAgICAgY2FuY2VsQ2xpY2soKTtcbiAgICB9O1xuICAgIG9uTW91bnRlZChmdW5jdGlvbiAoKSB7XG4gICAgICBnZXRMaXN0cygpO1xuICAgIH0pO1xuICAgIHZhciBfX3JldHVybmVkX18gPSB7XG4gICAgICBydWxlRm9ybTogcnVsZUZvcm0sXG4gICAgICByb3V0ZTogcm91dGUsXG4gICAgICByb3V0ZXI6IHJvdXRlcixcbiAgICAgIHJ1bGVGb3JtUmVmOiBydWxlRm9ybVJlZixcbiAgICAgIGdldCBWaXN1YWxDb20oKSB7XG4gICAgICAgIHJldHVybiBWaXN1YWxDb207XG4gICAgICB9LFxuICAgICAgc2V0IFZpc3VhbENvbSh2KSB7XG4gICAgICAgIFZpc3VhbENvbSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGRyYXdlclRpdGxlKCkge1xuICAgICAgICByZXR1cm4gZHJhd2VyVGl0bGU7XG4gICAgICB9LFxuICAgICAgc2V0IGRyYXdlclRpdGxlKHYpIHtcbiAgICAgICAgZHJhd2VyVGl0bGUgPSB2O1xuICAgICAgfSxcbiAgICAgIG9wZW5GbGFnOiBvcGVuRmxhZyxcbiAgICAgIGdldCBhdHRyKCkge1xuICAgICAgICByZXR1cm4gYXR0cjtcbiAgICAgIH0sXG4gICAgICBzZXQgYXR0cih2KSB7XG4gICAgICAgIGF0dHIgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBkcmF3ZXIoKSB7XG4gICAgICAgIHJldHVybiBkcmF3ZXI7XG4gICAgICB9LFxuICAgICAgc2V0IGRyYXdlcih2KSB7XG4gICAgICAgIGRyYXdlciA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJvd0luZGV4KCkge1xuICAgICAgICByZXR1cm4gcm93SW5kZXg7XG4gICAgICB9LFxuICAgICAgc2V0IHJvd0luZGV4KHYpIHtcbiAgICAgICAgcm93SW5kZXggPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCB0eXBlT3B0aW9ucygpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVPcHRpb25zO1xuICAgICAgfSxcbiAgICAgIHNldCB0eXBlT3B0aW9ucyh2KSB7XG4gICAgICAgIHR5cGVPcHRpb25zID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgdXNlckxpc3QoKSB7XG4gICAgICAgIHJldHVybiB1c2VyTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgdXNlckxpc3Qodikge1xuICAgICAgICB1c2VyTGlzdCA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGVudGlyeUxpc3QoKSB7XG4gICAgICAgIHJldHVybiBlbnRpcnlMaXN0O1xuICAgICAgfSxcbiAgICAgIHNldCBlbnRpcnlMaXN0KHYpIHtcbiAgICAgICAgZW50aXJ5TGlzdCA9IHY7XG4gICAgICB9LFxuICAgICAgcnVsZXM6IHJ1bGVzLFxuICAgICAgaGFuZGxlU2VsZWN0aW9uQ2hhbmdlOiBoYW5kbGVTZWxlY3Rpb25DaGFuZ2UsXG4gICAgICBtdWx0aXBsZVNlbGVjdGlvbjogbXVsdGlwbGVTZWxlY3Rpb24sXG4gICAgICBzdWJtaXRGb3JtOiBzdWJtaXRGb3JtLFxuICAgICAgZmlsdGVyTW9kZVR5cGU6IGZpbHRlck1vZGVUeXBlLFxuICAgICAgZ2V0TGlzdHM6IGdldExpc3RzLFxuICAgICAgcmVzZXRGb3JtOiByZXNldEZvcm0sXG4gICAgICBnb0JhY2s6IGdvQmFjayxcbiAgICAgIG9wdGlvbnM6IG9wdGlvbnMsXG4gICAgICBvcGVuRHJhd2VyOiBvcGVuRHJhd2VyLFxuICAgICAgZGVsZXRlUm93OiBkZWxldGVSb3csXG4gICAgICBjYW5jZWxDbGljazogY2FuY2VsQ2xpY2ssXG4gICAgICBjb25maXJtQ2xpY2s6IGNvbmZpcm1DbGljayxcbiAgICAgIGdldCBlbnZuYW1lKCkge1xuICAgICAgICByZXR1cm4gZW52bmFtZTtcbiAgICAgIH0sXG4gICAgICBnZXQgdXNlUm91dGVyKCkge1xuICAgICAgICByZXR1cm4gdXNlUm91dGVyO1xuICAgICAgfSxcbiAgICAgIGdldCB1c2VSb3V0ZSgpIHtcbiAgICAgICAgcmV0dXJuIHVzZVJvdXRlO1xuICAgICAgfSxcbiAgICAgIGdldCByZXF1ZXN0KCkge1xuICAgICAgICByZXR1cm4gcmVxdWVzdDtcbiAgICAgIH0sXG4gICAgICBnZXQgRWxNZXNzYWdlKCkge1xuICAgICAgICByZXR1cm4gRWxNZXNzYWdlO1xuICAgICAgfSxcbiAgICAgIFZpc3VhbDogVmlzdWFsLFxuICAgICAgZ2V0IHV1aWR2NCgpIHtcbiAgICAgICAgcmV0dXJuIHV1aWR2NDtcbiAgICAgIH0sXG4gICAgICBnZXQgRGVsZXRlKCkge1xuICAgICAgICByZXR1cm4gRGVsZXRlO1xuICAgICAgfSxcbiAgICAgIGdldCBFZGl0KCkge1xuICAgICAgICByZXR1cm4gRWRpdDtcbiAgICAgIH0sXG4gICAgICBuZXh0VGljazogbmV4dFRpY2ssXG4gICAgICBvbk1vdW50ZWQ6IG9uTW91bnRlZCxcbiAgICAgIGdldCBkYXRhcygpIHtcbiAgICAgICAgcmV0dXJuIGRhdGFzO1xuICAgICAgfSxcbiAgICAgIGdldCB3b3JkKCkge1xuICAgICAgICByZXR1cm4gd29yZDtcbiAgICAgIH1cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImZvcm1Cb3hcIj5cclxuICAgIDxoND7ln7rmnKzkv6Hmga88L2g0PlxyXG4gICAgPGVsLWZvcm1cclxuICAgICAgcmVmPVwicnVsZUZvcm1SZWZcIlxyXG4gICAgICA6bW9kZWw9XCJydWxlRm9ybVwiXHJcbiAgICAgIDpydWxlcz1cInJ1bGVzXCJcclxuICAgICAgbGFiZWwtd2lkdGg9XCIxMjBweFwiXHJcbiAgICAgIGNsYXNzPVwiZGVtby1ydWxlRm9ybVwiXHJcbiAgICAgIHN0YXR1cy1pY29uXHJcbiAgICA+XHJcbiAgICAgIDxlbC1yb3c+XHJcbiAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEyXCI+XHJcbiAgICAgICAgICA8ZWwtZm9ybS1pdGVtIGxhYmVsPVwi6Iux5paH5ZCN56ewXCIgcHJvcD1cIm5hbWVcIj5cclxuICAgICAgICAgICAgPGVsLWlucHV0XHJcbiAgICAgICAgICAgICAgdi1tb2RlbD1cInJ1bGVGb3JtLm5hbWVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiZm9ybUl0ZW1cIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6K+36L6T5YWl5Lia5Yqh6aKG5Z+f6Iux5paH5ZCN56ewXCJcclxuICAgICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgLz4gPC9lbC1mb3JtLWl0ZW1cclxuICAgICAgICA+PC9lbC1jb2w+XHJcbiAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEyXCI+XHJcbiAgICAgICAgICA8ZWwtZm9ybS1pdGVtIGxhYmVsPVwi5Lit5paH5ZCN56ewXCIgcHJvcD1cImNuYW1lXCI+XHJcbiAgICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybS5jbmFtZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLor7fovpPlhaXkuJrliqHpoobln5/kuK3mloflkI1cIlxyXG4gICAgICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgICAvPiA8L2VsLWZvcm0taXRlbVxyXG4gICAgICAgID48L2VsLWNvbD5cclxuICAgICAgPC9lbC1yb3c+XHJcbiAgICAgIDxlbC1yb3c+XHJcbiAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEyXCI+XHJcbiAgICAgICAgICA8ZWwtZm9ybS1pdGVtIGxhYmVsPVwi5oyH5a6a6LSf6LSj5Lq6XCIgcHJvcD1cInVzZXJcIj5cclxuICAgICAgICAgICAgPGVsLXNlbGVjdFxyXG4gICAgICAgICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybS51c2VyXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+mAieaLqei1hOS6p+i0n+i0o+S6ulwiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZWwtb3B0aW9uIGxhYmVsPVwi546L5oOK5rabXCIgdmFsdWU9XCLnjovmg4rmtptcIiAvPlxyXG4gICAgICAgICAgICAgIDxlbC1vcHRpb24gbGFiZWw9XCLpqazluIhcIiB2YWx1ZT1cIumprOW4iFwiIC8+XHJcbiAgICAgICAgICAgIDwvZWwtc2VsZWN0PiA8L2VsLWZvcm0taXRlbVxyXG4gICAgICAgID48L2VsLWNvbD5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTJcIj5cclxuICAgICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLotYTkuqfnsbvlnotcIiBwcm9wPVwidHlwZVwiPlxyXG4gICAgICAgICAgICA8ZWwtc2VsZWN0XHJcbiAgICAgICAgICAgICAgdi1tb2RlbD1cInJ1bGVGb3JtLnR5cGVcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6K+36YCJ5oup6LWE5Lqn57G75Z6LXCJcclxuICAgICAgICAgICAgICBjbGFzcz1cImZvcm1JdGVtXCJcclxuICAgICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxlbC1vcHRpb25cclxuICAgICAgICAgICAgICAgIHYtZm9yPVwiKGl0ZW0sIGluZGV4KSBpbiB0eXBlT3B0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICA6dmFsdWU9XCJpdGVtLnZhbHVlXCJcclxuICAgICAgICAgICAgICA+PC9lbC1vcHRpb24+IDwvZWwtc2VsZWN0PjwvZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgPjwvZWwtY29sPlxyXG4gICAgICA8L2VsLXJvdz5cclxuICAgICAgPGVsLXJvdz5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTJcIj5cclxuICAgICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLlhbPogZTlrp7kvZNcIiBwcm9wPVwiZW50aXJ5XCI+XHJcbiAgICAgICAgICAgIDxlbC1zZWxlY3RcclxuICAgICAgICAgICAgICB2LW1vZGVsPVwicnVsZUZvcm0uZW50aXJ5XCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+mAieaLqeWFs+iBlOWunuS9k1wiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZWwtb3B0aW9uXHJcbiAgICAgICAgICAgICAgICB2LWZvcj1cIihpdGVtLCBpbmRleCkgaW4gZW50aXJ5TGlzdFwiXHJcbiAgICAgICAgICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICA6dmFsdWU9XCJpdGVtLnZhbHVlXCJcclxuICAgICAgICAgICAgICAvPiA8L2VsLXNlbGVjdD48L2VsLWZvcm0taXRlbVxyXG4gICAgICAgID48L2VsLWNvbD5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTJcIj5cclxuICAgICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLotYTkuqfmj4/ov7BcIiBwcm9wPVwiZHNjXCI+XHJcbiAgICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybS5kc2NcIlxyXG4gICAgICAgICAgICAgIDpyb3dzPVwiNFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRhcmVhXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpei1hOS6p+aPj+i/sFwiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtSXRlbVwiXHJcbiAgICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAgIC8+IDwvZWwtZm9ybS1pdGVtXHJcbiAgICAgICAgPjwvZWwtY29sPlxyXG4gICAgICA8L2VsLXJvdz5cclxuICAgIDwvZWwtZm9ybT5cclxuICAgIDxoND7mqKHlnovlm748L2g0PlxyXG4gICAgPGRpdiBjbGFzcz1cImJ0bkxpc3RcIj5cclxuICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cIm9wZW5EcmF3ZXIoJ25ldycpXCJcclxuICAgICAgICA+5Yib5bu65qih5Z6L5Zu+5pa55qGIPC9lbC1idXR0b25cclxuICAgICAgPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZWwtdGFibGVcclxuICAgICAgcmVmPVwibXVsdGlwbGVUYWJsZVJlZlwiXHJcbiAgICAgIDpkYXRhPVwicnVsZUZvcm0ubW9kZWxMaXN0XCJcclxuICAgICAgc3R5bGU9XCJ3aWR0aDogMTAwJVwiXHJcbiAgICA+XHJcbiAgICAgIDxlbC10YWJsZS1jb2x1bW4gcHJvcGVydHk9XCJzY2VuYXJpb05hbWVcIiBsYWJlbD1cIuaooeWei+WbvuWQjeensFwiIHdpZHRoPVwiMjQwXCIgLz5cclxuICAgICAgPGVsLXRhYmxlLWNvbHVtblxyXG4gICAgICAgIHByb3BlcnR5PVwibW9kZVR5cGVcIlxyXG4gICAgICAgIGxhYmVsPVwi5qih5Z6L6KeE6IyDXCJcclxuICAgICAgICB3aWR0aD1cIjI0MFwiXHJcbiAgICAgICAgc2hvdy1vdmVyZmxvdy10b29sdGlwXHJcbiAgICAgID5cclxuICAgICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ9XCJzY29wZVwiPlxyXG4gICAgICAgICAgPHNwYW4+e3sgZmlsdGVyTW9kZVR5cGUoc2NvcGUpIH19PC9zcGFuPlxyXG4gICAgICAgIDwvdGVtcGxhdGU+XHJcbiAgICAgIDwvZWwtdGFibGUtY29sdW1uPlxyXG4gICAgICA8ZWwtdGFibGUtY29sdW1uIHByb3BlcnR5PVwiaWRcIiBsYWJlbD1cImlkXCIgd2lkdGg9XCJ3aWR0aFwiIC8+XHJcbiAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLmk43kvZxcIiB3aWR0aD1cIjI0MFwiPlxyXG4gICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICA8ZWwtYnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgOmljb249XCJFZGl0XCJcclxuICAgICAgICAgICAgY2lyY2xlXHJcbiAgICAgICAgICAgIEBjbGljaz1cIm9wZW5EcmF3ZXIoc2NvcGUpXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZWwtYnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJkYW5nZXJcIlxyXG4gICAgICAgICAgICA6aWNvbj1cIkRlbGV0ZVwiXHJcbiAgICAgICAgICAgIGNpcmNsZVxyXG4gICAgICAgICAgICBAY2xpY2s9XCJkZWxldGVSb3coc2NvcGUpXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgPC9lbC10YWJsZS1jb2x1bW4+XHJcbiAgICA8L2VsLXRhYmxlPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxyXG4gICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgQGNsaWNrPVwic3VibWl0Rm9ybShydWxlRm9ybVJlZilcIj5cclxuICAgICAgICDliJvlu7pcclxuICAgICAgPC9lbC1idXR0b24+XHJcbiAgICAgIDxlbC1idXR0b24gQGNsaWNrPVwiZ29CYWNrXCI+6L+U5ZuePC9lbC1idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8ZWwtZHJhd2VyIHYtbW9kZWw9XCJkcmF3ZXJcIiBkaXJlY3Rpb249XCJydGxcIiBzaXplPVwiODUlXCIgZGVzdHJveS1vbi1jbG9zZT5cclxuICAgIDx0ZW1wbGF0ZSAjaGVhZGVyPlxyXG4gICAgICA8aDQgc3R5bGU9XCJtYXJnaW4tYm90dG9tOiAwcHhcIj57eyBkcmF3ZXJUaXRsZSB9fTwvaDQ+XHJcbiAgICA8L3RlbXBsYXRlPlxyXG4gICAgPHRlbXBsYXRlICNkZWZhdWx0PlxyXG4gICAgICA8VmlzdWFsIHJlZj1cIlZpc3VhbENvbVwiPjwvVmlzdWFsPlxyXG4gICAgPC90ZW1wbGF0ZT5cclxuICAgIDx0ZW1wbGF0ZSAjZm9vdGVyPlxyXG4gICAgICA8ZGl2IHN0eWxlPVwiZmxleDogYXV0b1wiPlxyXG4gICAgICAgIDxlbC1idXR0b24gQGNsaWNrPVwiY2FuY2VsQ2xpY2tcIj7lj5bmtog8L2VsLWJ1dHRvbj5cclxuICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgQGNsaWNrPVwiY29uZmlybUNsaWNrXCI+5L+d5a2YPC9lbC1idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC90ZW1wbGF0ZT5cclxuICA8L2VsLWRyYXdlcj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyLCB1c2VSb3V0ZSB9IGZyb20gXCJ2dWUtcm91dGVyXCI7XHJcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xyXG5pbXBvcnQgeyBFbE1lc3NhZ2UgfSBmcm9tIFwiZWxlbWVudC1wbHVzXCI7XHJcbmltcG9ydCBWaXN1YWwgZnJvbSBcIi4vdmlzdWFsLnZ1ZVwiO1xyXG5pbXBvcnQgeyB2NCBhcyB1dWlkdjQgfSBmcm9tIFwidXVpZFwiO1xyXG5pbXBvcnQgeyBEZWxldGUsIEVkaXQgfSBmcm9tIFwiQGVsZW1lbnQtcGx1cy9pY29ucy12dWVcIjtcclxuaW1wb3J0IHsgbmV4dFRpY2ssIG9uTW91bnRlZCB9IGZyb20gXCJ2dWVcIjtcclxuaW1wb3J0IGRhdGFzIGZyb20gXCIuLi9kYXRhLmpzb25cIjtcclxuaW1wb3J0IHdvcmQgZnJvbSBcIkAvZGljdGlvbmFyaWVzL2J1c2luZXNzLmpzb25cIjtcclxuY29uc3QgcnVsZUZvcm0gPSByZWFjdGl2ZSh7XHJcbiAgbmFtZTogXCJcIixcclxuICBjbmFtZTogXCJcIixcclxuICB1c2VyOiBcIlwiLFxyXG4gIHJlZ2lvbjogbnVsbCxcclxuICBlbnRpcnk6IG51bGwsXHJcbiAgZGNzOiBcIlwiLFxyXG4gIHR5cGU6IG51bGwsXHJcbiAgc3RhdHVzOiAxLFxyXG4gIG1vZGVsTGlzdDogW10sXHJcbiAgbW9kZTogXCJidXNpbmVzc1wiLFxyXG59KTtcclxuY29uc3Qgcm91dGUgPSB1c2VSb3V0ZSgpO1xyXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuY29uc3QgcnVsZUZvcm1SZWYgPSByZWYobnVsbCk7XHJcbmxldCBWaXN1YWxDb20gPSByZWYobnVsbCk7XHJcbmxldCBkcmF3ZXJUaXRsZSA9IHJlZihcIuaWsOW7uuaooeWei+aWueahiFwiKTtcclxuY29uc3Qgb3BlbkZsYWcgPSByZWYoXCJuZXdcIik7XHJcbmxldCBhdHRyID0gdXNlQXR0cnMoKTtcclxubGV0IGRyYXdlciA9IHJlZihmYWxzZSk7XHJcbmxldCByb3dJbmRleCA9IHJlZigwKTtcclxubGV0IHR5cGVPcHRpb25zID0gZGF0YXMudHlwZTtcclxubGV0IHVzZXJMaXN0ID0gcmVmKFtdKTtcclxubGV0IGVudGlyeUxpc3QgPSByZWYoW10pO1xyXG5cclxuY29uc3QgcnVsZXMgPSByZWFjdGl2ZSh7XHJcbiAgbmFtZTogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXkuJrliqHpoobln5/oi7HmloflkI3np7BcIixcclxuICAgICAgdHJpZ2dlcjogXCJibHVyXCIsXHJcbiAgICB9LFxyXG4gICAgeyBtaW46IDMsIG1heDogMjAsIG1lc3NhZ2U6IFwiTGVuZ3RoIHNob3VsZCBiZSAzIHRvIDVcIiwgdHJpZ2dlcjogXCJibHVyXCIgfSxcclxuICBdLFxyXG4gIGNuYW1lOiBbXHJcbiAgICB7XHJcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICBtZXNzYWdlOiBcIuivt+i+k+WFpeS4muWKoemihuWfn+S4reaWh+WQjeensFwiLFxyXG4gICAgICB0cmlnZ2VyOiBcImJsdXJcIixcclxuICAgIH0sXHJcbiAgICB7IG1pbjogMywgbWF4OiAxMCwgbWVzc2FnZTogXCJMZW5ndGggc2hvdWxkIGJlIDMgdG8gNVwiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gIF0sXHJcbiAgdXNlcjogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLor7fpgInmi6notYTkuqfotJ/otKPkurpcIixcclxuICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIixcclxuICAgIH0sXHJcbiAgXSxcclxuICB0eXBlOiBbXHJcbiAgICB7XHJcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICBtZXNzYWdlOiBcIuivt+mAieaLqei1hOS6p+exu+Wei1wiLFxyXG4gICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiLFxyXG4gICAgfSxcclxuICBdLFxyXG59KTtcclxuXHJcbmNvbnN0IGhhbmRsZVNlbGVjdGlvbkNoYW5nZSA9ICh2YWwpID0+IHtcclxuICBtdWx0aXBsZVNlbGVjdGlvbi52YWx1ZSA9IHZhbDtcclxufTtcclxuY29uc3QgbXVsdGlwbGVTZWxlY3Rpb24gPSByZWYoW10pO1xyXG5cclxuY29uc3Qgc3VibWl0Rm9ybSA9IChmb3JtRWwpID0+IHtcclxuICBpZiAoIWZvcm1FbCkgcmV0dXJuO1xyXG4gIGZvcm1FbC52YWxpZGF0ZSgodmFsaWQsIGZpZWxkcykgPT4ge1xyXG4gICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHJ1bGVGb3JtLCBcIue7k+aenFwiKTtcclxuICAgICAgcmVxdWVzdFxyXG4gICAgICAgIC5wb3N0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvYnVzaW5lc3MvbmV3YCwgcnVsZUZvcm0pXHJcbiAgICAgICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiBcIuaWsOW7uuaIkOWKn1wiLFxyXG4gICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgZ29CYWNrKCk7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jb2RlID09PSAyMDEpIHtcclxuICAgICAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiByZXMubWVzc2FnZSxcclxuICAgICAgICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZyhcImVycm9yIHN1Ym1pdCFcIiwgZmllbGRzKTtcclxuICAgIH1cclxuICB9KTtcclxufTtcclxuY29uc3QgZmlsdGVyTW9kZVR5cGUgPSAoc2NvcGUpID0+IHtcclxuICBjb25zb2xlLmxvZyh3b3JkLnR5cGVPcHRpb25zLCBzY29wZS5yb3cubW9kZVR5cGUsIFwiPz8/5LuA5LmIXCIpO1xyXG4gIHJldHVybiB3b3JkLnR5cGVPcHRpb25zLmZpbmQoKGl0ZW0pID0+IGl0ZW0udmFsdWUgPT09IHNjb3BlLnJvdy5tb2RlVHlwZSlbXHJcbiAgICBcImxhYmVsXCJcclxuICBdO1xyXG59O1xyXG5jb25zdCBnZXRMaXN0cyA9ICgpID0+IHtcclxuICByZXF1ZXN0LmdldChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3VzZXIvdXNlckFsbExpc3RgKS50aGVuKChyZXMpID0+IHtcclxuICAgIGlmIChyZXMuY29kZSA9PSAyMDApIHtcclxuICAgICAgdXNlckxpc3QudmFsdWUgPSByZXMuZGF0YTtcclxuICAgIH1cclxuICB9KTtcclxuICByZXF1ZXN0XHJcbiAgICAucG9zdChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3B1YmxpY0FwaS9hbGxgLCB7IG1vZGU6IFwiZW50aXJ5XCIgfSlcclxuICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgaWYgKHJlcy5jb2RlID09IDIwMCkge1xyXG4gICAgICAgIHJlcy5kYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGVudGlyeUxpc3QudmFsdWUucHVzaCh7XHJcbiAgICAgICAgICAgIGxhYmVsOiBpdGVtLmVudGlyeUNuTmFtZSxcclxuICAgICAgICAgICAgdmFsdWU6IGl0ZW0udXVpZCxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxufTtcclxuY29uc3QgcmVzZXRGb3JtID0gKGZvcm1FbCkgPT4ge1xyXG4gIGlmICghZm9ybUVsKSByZXR1cm47XHJcbiAgZm9ybUVsLnJlc2V0RmllbGRzKCk7XHJcbn07XHJcblxyXG5jb25zdCBnb0JhY2sgPSAoKSA9PiB7XHJcbiAgcm91dGVyLnB1c2goe1xyXG4gICAgbmFtZTogXCJidXNpbmVzc0xpc3RcIixcclxuICB9KTtcclxufTtcclxuXHJcbmNvbnN0IG9wdGlvbnMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiAxMDAwMCB9KS5tYXAoKF8sIGlkeCkgPT4gKHtcclxuICB2YWx1ZTogYCR7aWR4ICsgMX1gLFxyXG4gIGxhYmVsOiBgJHtpZHggKyAxfWAsXHJcbn0pKTtcclxuY29uc3Qgb3BlbkRyYXdlciA9IChmbGFnKSA9PiB7XHJcbiAgb3BlbkZsYWcudmFsdWUgPSBmbGFnO1xyXG4gIGRyYXdlci52YWx1ZSA9IHRydWU7XHJcbiAgbmV4dFRpY2soKCkgPT4ge1xyXG4gICAgaWYgKGZsYWcgPT09IFwibmV3XCIpIHtcclxuICAgICAgVmlzdWFsQ29tLnZhbHVlLmRvbmVUeXBlKFwibmV3XCIpO1xyXG4gICAgICBkcmF3ZXJUaXRsZS52YWx1ZSA9IFwi5paw5bu65qih5Z6L5pa55qGIXCI7XHJcbiAgICAgIGlmIChydWxlRm9ybS5tb2RlbExpc3QubGVuZ3RoID49IDMpIHtcclxuICAgICAgICBFbE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIuacgOWkmuWPr+acieS4ieWll+aooeWei+aWueahiFwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGRyYXdlci52YWx1ZSA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZyhmbGFnLCBcIuS7gOS5iD8/P1wiKTtcclxuICAgICAgcm93SW5kZXgudmFsdWUgPSBmbGFnLiRpbmRleDtcclxuICAgICAgVmlzdWFsQ29tLnZhbHVlLmRvbmVUeXBlKFwiY2hhbmdlXCIsIGZsYWcucm93KTtcclxuICAgICAgZHJhd2VyVGl0bGUudmFsdWUgPSBmbGFnLnJvdy5zY2VuYXJpb05hbWU7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn07XHJcbmNvbnN0IGRlbGV0ZVJvdyA9IChmbGFnKSA9PiB7XHJcbiAgcnVsZUZvcm0ubW9kZWxMaXN0LnNwbGljZShmbGFnLiRpbmRleCwgMSk7XHJcbn07XHJcbmNvbnN0IGNhbmNlbENsaWNrID0gKCkgPT4ge1xyXG4gIGRyYXdlci52YWx1ZSA9IGZhbHNlO1xyXG59O1xyXG5jb25zdCBjb25maXJtQ2xpY2sgPSAoKSA9PiB7XHJcbiAgY29uc29sZS5sb2coVmlzdWFsQ29tLnZhbHVlLmluZm8sIFwi5bGe5oCnPz8/XCIpO1xyXG4gIGNvbnNvbGUubG9nKFZpc3VhbENvbS52YWx1ZS5zY2VuYXJpb19uYW1lLCBWaXN1YWxDb20udmFsdWUubW9kZV90eXBlLCBcIuS4iumdolwiKTtcclxuICBpZiAoVmlzdWFsQ29tLnZhbHVlLnNjZW5hcmlvX25hbWUgPT09IFwiXCIpIHtcclxuICAgIEVsTWVzc2FnZSh7XHJcbiAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICBtZXNzYWdlOiBcIuivt+i+k+WFpeaooeWei+WQjeensFwiLFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChWaXN1YWxDb20udmFsdWUubW9kZV90eXBlID09PSBcIlwiKSB7XHJcbiAgICBFbE1lc3NhZ2Uoe1xyXG4gICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgbWVzc2FnZTogXCLor7fpgInmi6nmqKHlnovop4TojINcIixcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgbGV0IG1vZGVsUGFyYW0gPSB7XHJcbiAgICBmbG93SW5mbzogVmlzdWFsQ29tLnZhbHVlLmluZm8sXHJcbiAgICBzY2VuYXJpb05hbWU6IFZpc3VhbENvbS52YWx1ZS5zY2VuYXJpb19uYW1lLFxyXG4gICAgbW9kZVR5cGU6IFZpc3VhbENvbS52YWx1ZS5tb2RlX3R5cGUsXHJcbiAgfTtcclxuICBpZiAob3BlbkZsYWcudmFsdWUgPT09IFwibmV3XCIpIHtcclxuICAgIG1vZGVsUGFyYW0uaWQgPSB1dWlkdjQoKTtcclxuICAgIHJ1bGVGb3JtLm1vZGVsTGlzdC5wdXNoKG1vZGVsUGFyYW0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjb25zb2xlLmxvZyhydWxlRm9ybS5tb2RlbExpc3QsIHJvd0luZGV4LnZhbHVlLCBtb2RlbFBhcmFtLCBcIuaPkuWFpVwiKTtcclxuICAgIHJ1bGVGb3JtLm1vZGVsTGlzdFtyb3dJbmRleC52YWx1ZV0gPSBtb2RlbFBhcmFtO1xyXG4gIH1cclxuICBjYW5jZWxDbGljaygpO1xyXG59O1xyXG5vbk1vdW50ZWQoKCkgPT4ge1xyXG4gIGdldExpc3RzKCk7XHJcbn0pO1xyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZSBsYW5nPVwibGVzc1wiIHNjb3BlZD5cclxuaDQge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuXHJcbi5mb3JtQm94IHtcclxuICBwYWRkaW5nOiAyMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBvdmVyZmxvdzogYXV0bztcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgcGFkZGluZy1ib3R0b206IDQwcHg7XHJcblxyXG4gIC5mb3JtSXRlbSB7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbiAgfVxyXG5cclxuICAuYnRuTGlzdCB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgLmZvb3RlciB7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAzMHB4O1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDIwcHg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG4gIH1cclxufVxyXG48L3N0eWxlPlxyXG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9uZXdCdXNpbmVzcy52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0wZTRiZjM2MiZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MGU0YmYzNjImbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTBlNGJmMzYyJnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL25ld0J1c2luZXNzLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTBlNGJmMzYyJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LTBlNGJmMzYyXCJdLFsnX19maWxlJyxcInNyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL25ld0J1c2luZXNzLnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIwZTRiZjM2MlwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzBlNGJmMzYyJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMGU0YmYzNjInLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL25ld0J1c2luZXNzLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wZTRiZjM2MiZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCcwZTRiZjM2MicsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9uZXdCdXNpbmVzcy52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL25ld0J1c2luZXNzLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wZTRiZjM2MiZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vbmV3QnVzaW5lc3MudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MGU0YmYzNjImbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiXSwibmFtZXMiOlsiX2NyZWF0ZUVsZW1lbnRWTm9kZSIsInN0eWxlIiwiX2hvaXN0ZWRfMSIsIl9ob2lzdGVkXzIiLCJfY3JlYXRlVk5vZGUiLCJfY29tcG9uZW50X2VsX2Zvcm0iLCJyZWYiLCJtb2RlbCIsIiRzZXR1cCIsInJ1bGVGb3JtIiwicnVsZXMiLCJfY29tcG9uZW50X2VsX3JvdyIsIl9jb21wb25lbnRfZWxfY29sIiwic3BhbiIsIl9jb21wb25lbnRfZWxfZm9ybV9pdGVtIiwibGFiZWwiLCJwcm9wIiwiX2NvbXBvbmVudF9lbF9pbnB1dCIsIm5hbWUiLCIkZXZlbnQiLCJwbGFjZWhvbGRlciIsImNsZWFyYWJsZSIsImNuYW1lIiwiX2NvbXBvbmVudF9lbF9zZWxlY3QiLCJ1c2VyIiwiX2NvbXBvbmVudF9lbF9vcHRpb24iLCJ2YWx1ZSIsInR5cGUiLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJ0eXBlT3B0aW9ucyIsIml0ZW0iLCJpbmRleCIsIl9jcmVhdGVCbG9jayIsImtleSIsImVudGlyeSIsImVudGlyeUxpc3QiLCJkc2MiLCJyb3dzIiwiX2hvaXN0ZWRfMyIsIl9ob2lzdGVkXzQiLCJfY29tcG9uZW50X2VsX2J1dHRvbiIsIm9uQ2xpY2siLCJfY2FjaGUiLCJvcGVuRHJhd2VyIiwiX2NvbXBvbmVudF9lbF90YWJsZSIsImRhdGEiLCJtb2RlbExpc3QiLCJfY29tcG9uZW50X2VsX3RhYmxlX2NvbHVtbiIsInByb3BlcnR5Iiwid2lkdGgiLCJfd2l0aEN0eCIsInNjb3BlIiwiX3RvRGlzcGxheVN0cmluZyIsImZpbHRlck1vZGVUeXBlIiwiaWNvbiIsIkVkaXQiLCJjaXJjbGUiLCJEZWxldGUiLCJkZWxldGVSb3ciLCJfaG9pc3RlZF81Iiwic3VibWl0Rm9ybSIsInJ1bGVGb3JtUmVmIiwiZ29CYWNrIiwiX2NvbXBvbmVudF9lbF9kcmF3ZXIiLCJkcmF3ZXIiLCJkaXJlY3Rpb24iLCJzaXplIiwiaGVhZGVyIiwiX2hvaXN0ZWRfNiIsImRyYXdlclRpdGxlIiwiZm9vdGVyIiwiX2hvaXN0ZWRfNyIsImNhbmNlbENsaWNrIiwiY29uZmlybUNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==