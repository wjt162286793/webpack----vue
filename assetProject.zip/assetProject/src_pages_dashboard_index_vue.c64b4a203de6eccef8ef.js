(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_dashboard_index_vue"],{

/***/ 15398:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/dashboard/index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".layout[data-v-363a5543] {\n  display: flex;\n  flex-direction: column;\n  height: 100vh;\n  position: relative;\n}\n.layout .layoutHeader[data-v-363a5543] {\n  color: var(--text-color1);\n  background: var(--background-color1);\n  box-sizing: border-box;\n  border-bottom: var(--border-color2) 1px solid;\n  height: 100px;\n  display: flex;\n}\n.layout .layoutHeader h1[data-v-363a5543] {\n  width: 200px;\n  height: 100px;\n  line-height: 100px;\n  text-align: center;\n  color: var(--text-color3);\n  background: var(--backround-color5);\n}\n.layout .layoutHeader .headerMenu[data-v-363a5543] {\n  flex: 1;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n  position: relative;\n}\n.layout .layoutHeader .headerMenu .headerImg[data-v-363a5543] {\n  margin: 0px 15px;\n  width: 30px;\n  height: 30px;\n  cursor: pointer;\n}\n.layout .layoutBody[data-v-363a5543] {\n  display: flex;\n  flex-grow: 1;\n  overflow: auto;\n}\n.layout .layoutBody .content[data-v-363a5543] {\n  overflow: auto;\n  flex-grow: 1;\n  /* 右侧内容区自适应宽度 */\n  display: flex;\n  padding: 20px;\n  padding-top: 60px;\n  position: relative;\n  background: var(--background-color3);\n}\n.layout .layoutBody .content .breadCrumb[data-v-363a5543] {\n  position: absolute;\n  top: 20px;\n  left: 20px;\n}\n.layout .layoutBody .content .breadCrumb span[data-v-363a5543] {\n  cursor: pointer;\n}\n.el-menu-vertical-demo[data-v-363a5543]:not(.el-menu--collapse) {\n  min-width: 200px;\n  width: 200px !important;\n  min-height: 400px;\n}\n[data-v-363a5543] .el-menu {\n  border-right: none !important;\n}\n.menuIcon[data-v-363a5543] {\n  position: absolute;\n  left: 25px;\n  bottom: 20px;\n  cursor: pointer;\n}\n.leftMenuImg[data-v-363a5543] {\n  width: 20px;\n  height: 20px;\n  cursor: pointer;\n  margin-right: 20px;\n}\n.rowList[data-v-363a5543] {\n  padding: 16px;\n}\n.rowList .row[data-v-363a5543] {\n  margin-bottom: 40px;\n}\n.rowList .row h4[data-v-363a5543] {\n  font-weight: 600;\n  font-size: 16px;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/dashboard/index.vue","webpack://./index.vue"],"names":[],"mappings":"AACA;EACE,aAAA;EACA,sBAAA;EACA,aAAA;EACA,kBAAA;ACAF;ADJA;EAMI,yBAAA;EACA,oCAAA;EACA,sBAAA;EACA,6CAAA;EACA,aAAA;EACA,aAAA;ACCJ;ADZA;EAcM,YAAA;EACA,aAAA;EACA,kBAAA;EACA,kBAAA;EACA,yBAAA;EACA,mCAAA;ACCN;ADpBA;EAsBM,OAAA;EACA,aAAA;EACA,yBAAA;EACA,mBAAA;EACA,kBAAA;ACCN;AD3BA;EA4BQ,gBAAA;EACA,WAAA;EACA,YAAA;EACA,eAAA;ACER;ADjCA;EAoCI,aAAA;EACA,YAAA;EACA,cAAA;ACAJ;ADtCA;EAmDM,cAAA;EACA,YAAA;ECVJ,eAAe;EDWX,aAAA;EACA,aAAA;EACA,iBAAA;EACA,kBAAA;EACA,oCAAA;ACTN;ADhDA;EA2DQ,kBAAA;EACA,SAAA;EACA,UAAA;ACRR;ADrDA;EA+DU,eAAA;ACPV;ADsBA;EACE,gBAAA;EACA,uBAAA;EACA,iBAAA;ACpBF;ADsBA;EACE,6BAAA;ACpBF;ADsBA;EACE,kBAAA;EACA,UAAA;EACA,YAAA;EACA,eAAA;ACpBF;ADsBA;EACE,WAAA;EACA,YAAA;EACA,eAAA;EACA,kBAAA;ACpBF;ADsBA;EACE,aAAA;ACpBF;ADmBA;EAGI,mBAAA;ACnBJ;ADgBA;EAKI,gBAAA;EACA,eAAA;AClBJ","sourcesContent":["\n.layout {\n  display: flex;\n  flex-direction: column;\n  height: 100vh;\n  position: relative;\n  .layoutHeader {\n    color: var(--text-color1);\n    background: var(--background-color1);\n    box-sizing: border-box;\n    border-bottom: var(--border-color2) 1px solid;\n    height: 100px;\n    display: flex;\n    // background: chartreuse;\n    h1 {\n      width: 200px;\n      height: 100px;\n      line-height: 100px;\n      text-align: center;\n      color: var(--text-color3);\n      background: var(--backround-color5);\n    }\n    .headerMenu {\n      flex: 1;\n      display: flex;\n      justify-content: flex-end;\n      align-items: center;\n      position: relative;\n      .headerImg {\n        margin: 0px 15px;\n        width: 30px;\n        height: 30px;\n        cursor: pointer;\n      }\n    }\n  }\n  .layoutBody {\n    display: flex;\n    flex-grow: 1;\n    overflow: auto;\n    // .leftMenu {\n    //   // width: 200px; /* 设置左侧边栏宽度 */\n    //   transition: width 0.2s;\n    //   background-color: var(--backround-color6);\n    //   position: relative;\n    //   .LeftBtn {\n    //     position: absolute;\n    //     bottom: 10px;\n    //     right: 10px;\n    //   }\n    // }\n    .content {\n      overflow: auto;\n      flex-grow: 1; /* 右侧内容区自适应宽度 */\n      display: flex;\n      padding: 20px;\n      padding-top: 60px;\n      position: relative;\n      background: var(--background-color3);\n      .breadCrumb {\n        position: absolute;\n        top: 20px;\n        left: 20px;\n        span {\n          cursor: pointer;\n        }\n        // ::v-deep() .el-breadcrumb__inner {\n        //   color: #fff !important;\n        // }\n        // ::v-deep() .el-breadcrumb__separator {\n        //   color: #fff !important;\n        // }\n      }\n    }\n  }\n}\n// .el-menu {\n//   position: relative;\n// }\n.el-menu-vertical-demo:not(.el-menu--collapse) {\n  min-width: 200px;\n  width: 200px !important;\n  min-height: 400px;\n}\n::v-deep(.el-menu)  {\n  border-right: none !important;\n}\n.menuIcon {\n  position: absolute;\n  left: 25px;\n  bottom: 20px;\n  cursor: pointer;\n}\n.leftMenuImg {\n  width: 20px;\n  height: 20px;\n  cursor: pointer;\n  margin-right: 20px;\n}\n.rowList{\n  padding: 16px;\n  .row{\n    margin-bottom: 40px;\n    h4{\n    font-weight: 600;\n    font-size: 16px;\n  }\n  }\n\n}\n",".layout {\n  display: flex;\n  flex-direction: column;\n  height: 100vh;\n  position: relative;\n}\n.layout .layoutHeader {\n  color: var(--text-color1);\n  background: var(--background-color1);\n  box-sizing: border-box;\n  border-bottom: var(--border-color2) 1px solid;\n  height: 100px;\n  display: flex;\n}\n.layout .layoutHeader h1 {\n  width: 200px;\n  height: 100px;\n  line-height: 100px;\n  text-align: center;\n  color: var(--text-color3);\n  background: var(--backround-color5);\n}\n.layout .layoutHeader .headerMenu {\n  flex: 1;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n  position: relative;\n}\n.layout .layoutHeader .headerMenu .headerImg {\n  margin: 0px 15px;\n  width: 30px;\n  height: 30px;\n  cursor: pointer;\n}\n.layout .layoutBody {\n  display: flex;\n  flex-grow: 1;\n  overflow: auto;\n}\n.layout .layoutBody .content {\n  overflow: auto;\n  flex-grow: 1;\n  /* 右侧内容区自适应宽度 */\n  display: flex;\n  padding: 20px;\n  padding-top: 60px;\n  position: relative;\n  background: var(--background-color3);\n}\n.layout .layoutBody .content .breadCrumb {\n  position: absolute;\n  top: 20px;\n  left: 20px;\n}\n.layout .layoutBody .content .breadCrumb span {\n  cursor: pointer;\n}\n.el-menu-vertical-demo:not(.el-menu--collapse) {\n  min-width: 200px;\n  width: 200px !important;\n  min-height: 400px;\n}\n::v-deep(.el-menu) {\n  border-right: none !important;\n}\n.menuIcon {\n  position: absolute;\n  left: 25px;\n  bottom: 20px;\n  cursor: pointer;\n}\n.leftMenuImg {\n  width: 20px;\n  height: 20px;\n  cursor: pointer;\n  margin-right: 20px;\n}\n.rowList {\n  padding: 16px;\n}\n.rowList .row {\n  margin-bottom: 40px;\n}\n.rowList .row h4 {\n  font-weight: 600;\n  font-size: 16px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 14997:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/dashboard/index.vue?vue&type=script&setup=true&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var screenfull__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! screenfull */ 22641);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store */ 28360);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'index',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var interInstance = (0,vue__WEBPACK_IMPORTED_MODULE_2__.getCurrentInstance)();
    var dialogUserInfoVisible = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false);
    var userInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(null);
    var theme = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(null);
    theme.value = document.body.dataset.theme;
    var menuActive = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)("dashboard");
    //全量路由
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    //当前路由
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_3__.useRoute)();
    //面包屑列表
    var breadList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)([{
      cname: "主页",
      name: "dashboard"
    }]);
    //计算面包屑列表
    var getBreadList = function getBreadList(routePath, allRouters) {
      breadList.splice(0, breadList.length);
      var pathList = routePath.split("/");
      pathList.shift();
      pathList.forEach(function (item, index) {
        if (item === "dashboard") {
          breadList.push({
            cname: "主页",
            name: "dashboard"
          });
        } else {
          var val = allRouters.find(function (v) {
            return v.name === item;
          });
          if (val) {
            breadList.push({
              cname: val.meta.name,
              name: val.name
            });
            if (val.children) {
              var m = val.children.find(function (v) {
                return v.name === pathList[index + 1];
              });
              if (m) {
                breadList.push({
                  cname: m.meta.name,
                  name: m.name
                });
              }
            }
          }
        }
      });
      if (breadList.length > 1) {
        menuActive.value = breadList[1].name;
      }
    };
    console.log(router.getRoutes(), '路由信息----');
    console.log(router, '路由');
    var leftMenuList = router.getRoutes().find(function (item) {
      return item.name === "dashboard";
    }).children;
    //左侧菜单伸展
    var isCollapse = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(false);
    //顶部菜单
    var headerMenuList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)([{
      name: "全屏",
      value: "full"
    }, {
      name: "github",
      value: "github"
    }, {
      name: "用户",
      value: "user"
    }, {
      name: "退出",
      value: "out"
    }]);
    var handleOpen = function handleOpen(key, keyPath) {
      // console.log(key, keyPath);
    };
    var handleClose = function handleClose(key, keyPath) {
      // console.log(key, keyPath);
    };
    var unfold = function unfold() {
      isCollapse.value = !isCollapse.value;
    };
    var jump = function jump(val) {
      router.push({
        name: val
      });
      // getBreadList(route.path, router.options.routes[3].children);
    };

    var outLogin = function outLogin(val) {
      localStorage.removeItem("token");
      router.push({
        path: "/login"
      });
      _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('changeAsyncRouteFinish', false);
      console.log(_store__WEBPACK_IMPORTED_MODULE_1__["default"].state.role, '????退出后的操作');
    };
    var Iconto = function Iconto(val) {
      switch (val) {
        case "github":
          window.open("https://github.com/wjt162286793/webpack----vue");
          break;
        case "out":
          outLogin();
          break;
        case "full":
          screenfull__WEBPACK_IMPORTED_MODULE_0__["default"].toggle();
          break;
        case "user":
          dialogUserInfoVisible.value = true;
          userInfo.value = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.user.userInfo;
          break;
      }
    };
    var breadJump = function breadJump(breadName) {
      if (breadName === "dashboard") {
        return;
      }
      if (breadName === route.name) {
        return;
      } else {
        router.push({
          name: breadName
        });
      }
    };
    var handleMenuSelect = function handleMenuSelect(menuVal) {
      menuActive.value = menuVal;
    };
    var jumpMode = function jumpMode(name) {
      router.push({
        name: name
      });
    };
    var themeList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([{
      color: '#409eff',
      theme: 'blue'
    }, {
      color: '#ba7de4',
      theme: 'purple'
    }, {
      color: '#72a15a',
      theme: 'green'
    }, {
      color: '#a72513',
      theme: 'red'
    }, {
      color: '#534668',
      theme: 'deepPurple'
    }, {
      color: '#13088a',
      theme: 'deepBlue'
    }]);
    var changeTheme = function changeTheme(item) {
      document.body.dataset.theme = item.theme;
      theme.value = item.theme;
      localStorage.setItem('theme', item.theme);
    };
    var getLiStyle = function getLiStyle(item) {
      return {
        background: item.color,
        width: item.theme === theme.value ? '40px' : '30px',
        height: item.theme === theme.value ? '40px' : '30px',
        margin: '10px',
        cursor: 'pointer'
      };
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_2__.onMounted)(function () {
      console.log(route, '进入了');
      if (route.path === "/dashboard") {
        var defaultRoute = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.role.filterAsyncRoutes.find(function (item) {
          return item.name === 'dashboard';
        }).children[0].path;
        console.log(defaultRoute, '自动匹配子路由');
        router.push({
          path: defaultRoute
        });
        menuActive.value = "business";
      } else {
        menuActive.value = route.name;
      }
      getBreadList(route.path, router.getRoutes().find(function (item) {
        return item.name === "dashboard";
      }).children);
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.watch)(function () {
        return route.path;
      }, function (newVal, oldVal) {
        getBreadList(newVal, router.getRoutes().find(function (item) {
          return item.name === 'dashboard';
        }).children);
        if (newVal === "/dashboard") {
          var _defaultRoute = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.role.filterAsyncRoutes.find(function (item) {
            return item.name === 'dashboard';
          }).children[0].path;
          console.log(_defaultRoute, '自动匹配子路由');
          router.push({
            path: _defaultRoute
          });
          menuActive.value = "business";
        }
      });
    });
    var __returned__ = {
      interInstance: interInstance,
      dialogUserInfoVisible: dialogUserInfoVisible,
      userInfo: userInfo,
      get theme() {
        return theme;
      },
      set theme(v) {
        theme = v;
      },
      get menuActive() {
        return menuActive;
      },
      set menuActive(v) {
        menuActive = v;
      },
      get router() {
        return router;
      },
      set router(v) {
        router = v;
      },
      get route() {
        return route;
      },
      set route(v) {
        route = v;
      },
      get breadList() {
        return breadList;
      },
      set breadList(v) {
        breadList = v;
      },
      getBreadList: getBreadList,
      leftMenuList: leftMenuList,
      isCollapse: isCollapse,
      headerMenuList: headerMenuList,
      handleOpen: handleOpen,
      handleClose: handleClose,
      unfold: unfold,
      jump: jump,
      outLogin: outLogin,
      Iconto: Iconto,
      breadJump: breadJump,
      handleMenuSelect: handleMenuSelect,
      jumpMode: jumpMode,
      get themeList() {
        return themeList;
      },
      set themeList(v) {
        themeList = v;
      },
      changeTheme: changeTheme,
      getLiStyle: getLiStyle,
      get useRouter() {
        return vue_router__WEBPACK_IMPORTED_MODULE_3__.useRouter;
      },
      get useRoute() {
        return vue_router__WEBPACK_IMPORTED_MODULE_3__.useRoute;
      },
      get screenfull() {
        return screenfull__WEBPACK_IMPORTED_MODULE_0__["default"];
      },
      get Document() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_4__.Document;
      },
      get IconMenu() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_4__.Menu;
      },
      get Location() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_4__.Location;
      },
      get Setting() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_4__.Setting;
      },
      get store() {
        return _store__WEBPACK_IMPORTED_MODULE_1__["default"];
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 58062:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/dashboard/index.vue?vue&type=template&id=363a5543&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var _assets_svg_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/svg/菜单.svg */ 57633);


var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-363a5543"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "layout"
};
var _hoisted_2 = {
  "class": "layoutHeader"
};
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h1", null, "资产管理系统", -1 /* HOISTED */);
});
var _hoisted_4 = {
  "class": "headerMenu"
};
var _hoisted_5 = ["src", "alt", "onClick"];
var _hoisted_6 = {
  "class": "layoutBody"
};
var _hoisted_7 = ["src"];
var _hoisted_8 = {
  "class": "content"
};
var _hoisted_9 = {
  "class": "modeBox"
};
var _hoisted_10 = {
  "class": "rowList"
};
var _hoisted_11 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "用户名", -1 /* HOISTED */);
});
var _hoisted_12 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "账号", -1 /* HOISTED */);
});
var _hoisted_13 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "用户权限", -1 /* HOISTED */);
});
var _hoisted_14 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", {
    style: {
      "line-height": "60px"
    }
  }, "主题色设置", -1 /* HOISTED */);
});
var _hoisted_15 = {
  style: {
    "display": "flex"
  }
};
var _hoisted_16 = ["onClick"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_menu_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-menu-item");
  var _component_el_menu = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-menu");
  var _component_el_breadcrumb_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-breadcrumb-item");
  var _component_el_breadcrumb = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-breadcrumb");
  var _component_router_view = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("router-view");
  var _component_el_col = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-col");
  var _component_el_row = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-row");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <el-button type=\"primary\" @click=\"createVueFile\">创建vue文件</el-button> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [_hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.headerMenuList, function (item, index) {
    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("img", {
      src: __webpack_require__(92498)("./".concat(item.name, ".svg")),
      alt: item.name,
      key: index,
      "class": "headerImg",
      onClick: function onClick($event) {
        return $setup.Iconto(item.value);
      }
    }, null, 8 /* PROPS */, _hoisted_5);
  }), 128 /* KEYED_FRAGMENT */))])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_menu, {
    "default-active": $setup.menuActive,
    collapse: $setup.isCollapse,
    "active-text-color": "#ffd04b",
    "background-color": "#545c64",
    "class": "el-menu-vertical-demo",
    "text-color": "#fff",
    onOpen: $setup.handleOpen,
    onClose: $setup.handleClose,
    onSelect: $setup.handleMenuSelect,
    router: true
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.leftMenuList, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_menu_item, {
          key: index,
          index: item.name,
          onClick: function onClick($event) {
            return $setup.jumpMode(item.name);
          }
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)(" <el-icon></el-icon> "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
              src: __webpack_require__(92498)("./".concat(item.meta.name, ".svg")),
              alt: "",
              "class": "leftMenuImg"
            }, null, 8 /* PROPS */, _hoisted_7), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.meta.name), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["index", "onClick"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["default-active", "collapse"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_8, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_breadcrumb, {
    separator: "/",
    "class": "breadCrumb"
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.breadList, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
          key: index
        }, [item.name !== 'dashboard' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_breadcrumb_item, {
          key: 0,
          onClick: function onClick($event) {
            return $setup.breadJump(item.name);
          }
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.cname), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])) : ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_breadcrumb_item, {
          key: 1,
          onClick: function onClick($event) {
            return $setup.breadJump(item.name);
          }
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.cname), 1 /* TEXT */)];
          }),

          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"]))], 64 /* STABLE_FRAGMENT */);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_router_view)])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_svg_svg__WEBPACK_IMPORTED_MODULE_1__,
    alt: "",
    onClick: $setup.unfold,
    "class": "menuIcon"
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_dialog, {
    modelValue: $setup.dialogUserInfoVisible,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return $setup.dialogUserInfoVisible = $event;
    }),
    title: "用户信息",
    width: "600px"
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_10, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, {
        "class": "row"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 8
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_11];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 16
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.userInfo.userName), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, {
        "class": "row"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 8
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_12];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 16
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.userInfo.name), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, {
        "class": "row"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 8
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_13];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 16
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.userInfo.role), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, {
        "class": "row"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 8
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_14];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 16
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ul", _hoisted_15, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.themeList, function (item, index) {
                return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("li", {
                  style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)($setup.getLiStyle(item)),
                  onClick: function onClick($event) {
                    return $setup.changeTheme(item);
                  }
                }, null, 12 /* STYLE, PROPS */, _hoisted_16);
              }), 256 /* UNKEYED_FRAGMENT */))])];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      })])];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 7002:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/dashboard/index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true */ 15398);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 23053:
/*!***************************************!*\
  !*** ./src/pages/dashboard/index.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_363a5543_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=363a5543&scoped=true */ 21676);
/* harmony import */ var _index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&setup=true&lang=js */ 43918);
/* harmony import */ var _index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true */ 34968);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_index_vue_vue_type_template_id_363a5543_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-363a5543"],['__file',"src/pages/dashboard/index.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 43918:
/*!**************************************************************************!*\
  !*** ./src/pages/dashboard/index.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=script&setup=true&lang=js */ 14997);
 

/***/ }),

/***/ 21676:
/*!*********************************************************************************!*\
  !*** ./src/pages/dashboard/index.vue?vue&type=template&id=363a5543&scoped=true ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_363a5543_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_363a5543_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=template&id=363a5543&scoped=true */ 58062);


/***/ }),

/***/ 34968:
/*!************************************************************************************************!*\
  !*** ./src/pages/dashboard/index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_363a5543_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=363a5543&lang=less&scoped=true */ 7002);


/***/ }),

/***/ 92498:
/*!********************************************!*\
  !*** ./src/assets/svg/ sync ^\.\/.*\.svg$ ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./github.svg": 20002,
	"./业务领域.svg": 46578,
	"./主题色.svg": 13823,
	"./价值流.svg": 99390,
	"./任务管理.svg": 56069,
	"./全屏.svg": 68631,
	"./实体.svg": 81785,
	"./文本编辑.svg": 18266,
	"./权限管理.svg": 44761,
	"./流程图.svg": 4073,
	"./用户.svg": 82227,
	"./统计图表.svg": 11447,
	"./菜单.svg": 57633,
	"./资产统计.svg": 71066,
	"./退出.svg": 10520,
	"./邮件.svg": 43318,
	"./风险管理.svg": 65031
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 92498;

/***/ }),

/***/ 20002:
/*!***********************************!*\
  !*** ./src/assets/svg/github.svg ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "0415635715a43eaf1005.svg";

/***/ }),

/***/ 46578:
/*!*********************************!*\
  !*** ./src/assets/svg/业务领域.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "3ef99a5febab3c11636f.svg";

/***/ }),

/***/ 13823:
/*!********************************!*\
  !*** ./src/assets/svg/主题色.svg ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "2c3f768464445ad3807e.svg";

/***/ }),

/***/ 99390:
/*!********************************!*\
  !*** ./src/assets/svg/价值流.svg ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "0702572136ae79ad77a1.svg";

/***/ }),

/***/ 56069:
/*!*********************************!*\
  !*** ./src/assets/svg/任务管理.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "e349f342c028fa1e70a3.svg";

/***/ }),

/***/ 68631:
/*!*******************************!*\
  !*** ./src/assets/svg/全屏.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "6109bddb53d21463ab6f.svg";

/***/ }),

/***/ 81785:
/*!*******************************!*\
  !*** ./src/assets/svg/实体.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "e0600deb2b1c64ebaab8.svg";

/***/ }),

/***/ 18266:
/*!*********************************!*\
  !*** ./src/assets/svg/文本编辑.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "049d0dc6ac7b81672adc.svg";

/***/ }),

/***/ 44761:
/*!*********************************!*\
  !*** ./src/assets/svg/权限管理.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "2ff93e085a34e03894f0.svg";

/***/ }),

/***/ 4073:
/*!********************************!*\
  !*** ./src/assets/svg/流程图.svg ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "6d0521782201c1f10938.svg";

/***/ }),

/***/ 82227:
/*!*******************************!*\
  !*** ./src/assets/svg/用户.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "7ec15eaf3bbb35968213.svg";

/***/ }),

/***/ 11447:
/*!*********************************!*\
  !*** ./src/assets/svg/统计图表.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "33a2e7b296af0e7e8893.svg";

/***/ }),

/***/ 57633:
/*!*******************************!*\
  !*** ./src/assets/svg/菜单.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "73ef803ec9b1b225f9a0.svg";

/***/ }),

/***/ 71066:
/*!*********************************!*\
  !*** ./src/assets/svg/资产统计.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "4802b867de9818612892.svg";

/***/ }),

/***/ 10520:
/*!*******************************!*\
  !*** ./src/assets/svg/退出.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "0277cd5fe22aebc04665.svg";

/***/ }),

/***/ 43318:
/*!*******************************!*\
  !*** ./src/assets/svg/邮件.svg ***!
  \*******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "2720f30826bf98d48313.svg";

/***/ }),

/***/ 65031:
/*!*********************************!*\
  !*** ./src/assets/svg/风险管理.svg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "e942b5ffe7f100e888b7.svg";

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2Rhc2hib2FyZF9pbmRleF92dWUuYzY0YjRhMjAzZGU2ZWNjZWY4ZWYuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNnSDtBQUNqQjtBQUMvRiw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0Esb0VBQW9FLGtCQUFrQiwyQkFBMkIsa0JBQWtCLHVCQUF1QixHQUFHLDBDQUEwQyw4QkFBOEIseUNBQXlDLDJCQUEyQixrREFBa0Qsa0JBQWtCLGtCQUFrQixHQUFHLDZDQUE2QyxpQkFBaUIsa0JBQWtCLHVCQUF1Qix1QkFBdUIsOEJBQThCLHdDQUF3QyxHQUFHLHNEQUFzRCxZQUFZLGtCQUFrQiw4QkFBOEIsd0JBQXdCLHVCQUF1QixHQUFHLGlFQUFpRSxxQkFBcUIsZ0JBQWdCLGlCQUFpQixvQkFBb0IsR0FBRyx3Q0FBd0Msa0JBQWtCLGlCQUFpQixtQkFBbUIsR0FBRyxpREFBaUQsbUJBQW1CLGlCQUFpQixzQ0FBc0Msa0JBQWtCLHNCQUFzQix1QkFBdUIseUNBQXlDLEdBQUcsNkRBQTZELHVCQUF1QixjQUFjLGVBQWUsR0FBRyxrRUFBa0Usb0JBQW9CLEdBQUcsbUVBQW1FLHFCQUFxQiw0QkFBNEIsc0JBQXNCLEdBQUcsOEJBQThCLGtDQUFrQyxHQUFHLDhCQUE4Qix1QkFBdUIsZUFBZSxpQkFBaUIsb0JBQW9CLEdBQUcsaUNBQWlDLGdCQUFnQixpQkFBaUIsb0JBQW9CLHVCQUF1QixHQUFHLDZCQUE2QixrQkFBa0IsR0FBRyxrQ0FBa0Msd0JBQXdCLEdBQUcscUNBQXFDLHFCQUFxQixvQkFBb0IsR0FBRyxTQUFTLHdIQUF3SCxVQUFVLFdBQVcsVUFBVSxXQUFXLEtBQUssS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsVUFBVSxLQUFLLEtBQUssVUFBVSxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsS0FBSyxNQUFNLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxLQUFLLE1BQU0sWUFBWSxVQUFVLFVBQVUsVUFBVSxLQUFLLE1BQU0sV0FBVyxVQUFVLFVBQVUsS0FBSyxNQUFNLFdBQVcsVUFBVSxVQUFVLFVBQVUsVUFBVSxXQUFXLFdBQVcsV0FBVyxLQUFLLE1BQU0sWUFBWSxVQUFVLFVBQVUsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLE1BQU0sTUFBTSxXQUFXLFVBQVUsVUFBVSxVQUFVLE1BQU0sTUFBTSxVQUFVLFVBQVUsVUFBVSxXQUFXLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxXQUFXLE1BQU0sTUFBTSxXQUFXLFVBQVUscUNBQXFDLGtCQUFrQiwyQkFBMkIsa0JBQWtCLHVCQUF1QixtQkFBbUIsZ0NBQWdDLDJDQUEyQyw2QkFBNkIsb0RBQW9ELG9CQUFvQixvQkFBb0IsZ0NBQWdDLFVBQVUscUJBQXFCLHNCQUFzQiwyQkFBMkIsMkJBQTJCLGtDQUFrQyw0Q0FBNEMsT0FBTyxtQkFBbUIsZ0JBQWdCLHNCQUFzQixrQ0FBa0MsNEJBQTRCLDJCQUEyQixvQkFBb0IsMkJBQTJCLHNCQUFzQix1QkFBdUIsMEJBQTBCLFNBQVMsT0FBTyxLQUFLLGlCQUFpQixvQkFBb0IsbUJBQW1CLHFCQUFxQixvQkFBb0IsNEJBQTRCLGdEQUFnRCxxREFBcUQsOEJBQThCLHFCQUFxQixnQ0FBZ0MsMEJBQTBCLHlCQUF5QixZQUFZLFVBQVUsZ0JBQWdCLHVCQUF1QixzQkFBc0Isc0NBQXNDLHNCQUFzQiwwQkFBMEIsMkJBQTJCLDZDQUE2QyxxQkFBcUIsNkJBQTZCLG9CQUFvQixxQkFBcUIsZ0JBQWdCLDRCQUE0QixXQUFXLCtDQUErQyxzQ0FBc0MsY0FBYyxtREFBbUQsc0NBQXNDLGNBQWMsU0FBUyxPQUFPLEtBQUssR0FBRyxlQUFlLDBCQUEwQixNQUFNLGtEQUFrRCxxQkFBcUIsNEJBQTRCLHNCQUFzQixHQUFHLHVCQUF1QixrQ0FBa0MsR0FBRyxhQUFhLHVCQUF1QixlQUFlLGlCQUFpQixvQkFBb0IsR0FBRyxnQkFBZ0IsZ0JBQWdCLGlCQUFpQixvQkFBb0IsdUJBQXVCLEdBQUcsV0FBVyxrQkFBa0IsU0FBUywwQkFBMEIsU0FBUyx1QkFBdUIsc0JBQXNCLEtBQUssS0FBSyxLQUFLLGNBQWMsa0JBQWtCLDJCQUEyQixrQkFBa0IsdUJBQXVCLEdBQUcseUJBQXlCLDhCQUE4Qix5Q0FBeUMsMkJBQTJCLGtEQUFrRCxrQkFBa0Isa0JBQWtCLEdBQUcsNEJBQTRCLGlCQUFpQixrQkFBa0IsdUJBQXVCLHVCQUF1Qiw4QkFBOEIsd0NBQXdDLEdBQUcscUNBQXFDLFlBQVksa0JBQWtCLDhCQUE4Qix3QkFBd0IsdUJBQXVCLEdBQUcsZ0RBQWdELHFCQUFxQixnQkFBZ0IsaUJBQWlCLG9CQUFvQixHQUFHLHVCQUF1QixrQkFBa0IsaUJBQWlCLG1CQUFtQixHQUFHLGdDQUFnQyxtQkFBbUIsaUJBQWlCLHNDQUFzQyxrQkFBa0Isc0JBQXNCLHVCQUF1Qix5Q0FBeUMsR0FBRyw0Q0FBNEMsdUJBQXVCLGNBQWMsZUFBZSxHQUFHLGlEQUFpRCxvQkFBb0IsR0FBRyxrREFBa0QscUJBQXFCLDRCQUE0QixzQkFBc0IsR0FBRyxzQkFBc0Isa0NBQWtDLEdBQUcsYUFBYSx1QkFBdUIsZUFBZSxpQkFBaUIsb0JBQW9CLEdBQUcsZ0JBQWdCLGdCQUFnQixpQkFBaUIsb0JBQW9CLHVCQUF1QixHQUFHLFlBQVksa0JBQWtCLEdBQUcsaUJBQWlCLHdCQUF3QixHQUFHLG9CQUFvQixxQkFBcUIsb0JBQW9CLEdBQUcscUJBQXFCO0FBQzM1TjtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQVTtBQUNiO0FBQ29EO0FBQzVEOzs7QUFDNUIsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix1REFBa0I7QUFDMUMsZ0NBQWdDLHdDQUFHO0FBQ25DLG1CQUFtQix3Q0FBRztBQUN0QixnQkFBZ0Isd0NBQUc7QUFDbkI7QUFDQSxxQkFBcUIsd0NBQUc7QUFDeEI7QUFDQSxpQkFBaUIscURBQVM7QUFDMUI7QUFDQSxnQkFBZ0Isb0RBQVE7QUFDeEI7QUFDQSxvQkFBb0IsNkNBQVE7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQix3Q0FBRztBQUN4QjtBQUNBLHlCQUF5Qiw2Q0FBUTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLHVEQUFjO0FBQ3BCLGtCQUFrQix5REFBZ0I7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLHlEQUFpQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsa0VBQXlCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksOENBQVM7QUFDYjtBQUNBO0FBQ0EsMkJBQTJCLGdGQUF1QztBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sMENBQUs7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsZ0ZBQXVDO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsaURBQVM7QUFDeEI7QUFDQTtBQUNBLGVBQWUsZ0RBQVE7QUFDdkI7QUFDQTtBQUNBLGVBQWUsa0RBQVU7QUFDekI7QUFDQTtBQUNBLGVBQWUsNkRBQVE7QUFDdkI7QUFDQTtBQUNBLGVBQWUseURBQVE7QUFDdkI7QUFDQTtBQUNBLGVBQWUsNkRBQVE7QUFDdkI7QUFDQTtBQUNBLGVBQWUsNERBQU87QUFDdEI7QUFDQTtBQUNBLGVBQWUsOENBQUs7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVPaUM7Ozs7O0VBN0QzQixTQUFNO0FBQVE7O0VBRVosU0FBTTtBQUFjOztzQkFDdkJDLHVEQUFBLENBQWUsWUFBWCxRQUFNO0FBQUE7O0VBQ0wsU0FBTTtBQUFZOzs7RUFXcEIsU0FBTTtBQUFZOzs7RUE0QmhCLFNBQU07QUFBUzs7RUFhYixTQUFNO0FBQVM7O0VBUW5CLFNBQU07QUFBUzs7c0JBRUdBLHVEQUFBLENBQVksWUFBUixLQUFHO0FBQUE7O3NCQUlQQSx1REFBQSxDQUFXLFlBQVAsSUFBRTtBQUFBOztzQkFJUEEsdURBQUEsQ0FBYSxZQUFULE1BQUk7QUFBQTs7c0JBSVJBLHVEQUFBLENBQXlDO0lBQXJDQyxLQUEwQixFQUExQjtNQUFBO0lBQUE7RUFBMEIsR0FBQyxPQUFLO0FBQUE7O0VBRS9DQSxLQUFzQixFQUF0QjtJQUFBO0VBQUE7QUFBc0I7Ozs7Ozs7Ozs7O3FLQWhGbkNELHVEQUFBLENBOERNLE9BOURORSxVQThETSxHQTdESkMsdURBQUEsOEVBQTZFLEVBQzdFSCx1REFBQSxDQVlNLE9BWk5JLFVBWU0sR0FYSkMsVUFBZSxFQUNmTCx1REFBQSxDQVNNLE9BVE5NLFVBU00sMERBUkpDLHVEQUFBLENBT0VDLHlDQUFBLFFBQUFDLCtDQUFBLENBSndCQyxNQUFBLENBQUFDLGNBQWMsWUFBOUJDLElBQUksRUFBRUMsS0FBSzs2REFIckJOLHVEQUFBLENBT0U7TUFOQ08sR0FBRyxFQUFFQywyQkFBUSxLQUFEQyxNQUFBLENBQWlCSixJQUFJLENBQUNLLElBQUk7TUFDdENDLEdBQUcsRUFBRU4sSUFBSSxDQUFDSyxJQUFJO01BRWRFLEdBQUcsRUFBRU4sS0FBSztNQUNYLFNBQU0sV0FBVztNQUNoQk8sT0FBSyxXQUFBQSxRQUFBQyxNQUFBO1FBQUEsT0FBRVgsTUFBQSxDQUFBWSxNQUFNLENBQUNWLElBQUksQ0FBQ1csS0FBSztNQUFBOztzQ0FJL0J2Qix1REFBQSxDQTZDTSxPQTdDTndCLFVBNkNNLEdBNUNKQyxnREFBQSxDQTBCVUMsa0JBQUE7SUF6QlAsZ0JBQWMsRUFBRWhCLE1BQUEsQ0FBQWlCLFVBQVU7SUFDMUJDLFFBQVEsRUFBRWxCLE1BQUEsQ0FBQW1CLFVBQVU7SUFDckIsbUJBQWlCLEVBQUMsU0FBUztJQUMzQixrQkFBZ0IsRUFBQyxTQUFTO0lBQzFCLFNBQU0sdUJBQXVCO0lBQzdCLFlBQVUsRUFBQyxNQUFNO0lBQ2hCQyxNQUFJLEVBQUVwQixNQUFBLENBQUFxQixVQUFVO0lBQ2hCQyxPQUFLLEVBQUV0QixNQUFBLENBQUF1QixXQUFXO0lBQ2xCQyxRQUFNLEVBQUV4QixNQUFBLENBQUF5QixnQkFBZ0I7SUFDeEJDLE1BQU0sRUFBRTs7NERBR1A7TUFBQSxPQUFxQyx3REFEdkM3Qix1REFBQSxDQWFlQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQVpXQyxNQUFBLENBQUEyQixZQUFZLFlBQTVCekIsSUFBSSxFQUFFQyxLQUFLO2lFQURyQnlCLGdEQUFBLENBYWVDLHVCQUFBO1VBWFpwQixHQUFHLEVBQUVOLEtBQUs7VUFDVkEsS0FBSyxFQUFFRCxJQUFJLENBQUNLLElBQUk7VUFDaEJHLE9BQUssV0FBQUEsUUFBQUMsTUFBQTtZQUFBLE9BQUVYLE1BQUEsQ0FBQThCLFFBQVEsQ0FBQzVCLElBQUksQ0FBQ0ssSUFBSTtVQUFBOztrRUFFMUI7WUFBQSxPQUE0QixDQUE1QmQsdURBQUEseUJBQTRCLEVBQzVCSCx1REFBQSxDQUlFO2NBSENjLEdBQUcsRUFBRUMsMkJBQVEsS0FBREMsTUFBQSxDQUFpQkosSUFBSSxDQUFDNkIsSUFBSSxDQUFDeEIsSUFBSTtjQUM1Q0MsR0FBRyxFQUFDLEVBQUU7Y0FDTixTQUFNO2lEQUVSbEIsdURBQUEsQ0FBaUMsY0FBQTBDLG9EQUFBLENBQXhCOUIsSUFBSSxDQUFDNkIsSUFBSSxDQUFDeEIsSUFBSTs7Ozs7Ozs7O3FEQUczQmpCLHVEQUFBLENBZ0JNLE9BaEJOMkMsVUFnQk0sR0FmSmxCLGdEQUFBLENBV2dCbUIsd0JBQUE7SUFYREMsU0FBUyxFQUFDLEdBQUc7SUFBQyxTQUFNOzs0REFDdkI7TUFBQSxPQUFrQyx3REFBNUN0Qyx1REFBQSxDQVNXQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQVR1QkMsTUFBQSxDQUFBb0MsU0FBUyxZQUF6QmxDLElBQUksRUFBRUMsS0FBSzs7ZUFBc0JBO1FBQUssSUFHOUNELElBQUksQ0FBQ0ssSUFBSSxzRUFGakJxQixnREFBQSxDQUlDUyw2QkFBQTs7VUFIRTNCLE9BQUssV0FBQUEsUUFBQUMsTUFBQTtZQUFBLE9BQUVYLE1BQUEsQ0FBQXNDLFNBQVMsQ0FBQ3BDLElBQUksQ0FBQ0ssSUFBSTtVQUFBOztrRUFFMUI7WUFBQSxPQUE2QixDQUE3QmpCLHVEQUFBLENBQTZCLGNBQUEwQyxvREFBQSxDQUFwQjlCLElBQUksQ0FBQ3FDLEtBQUs7Ozs7K0dBRXRCWCxnREFBQSxDQUVDUyw2QkFBQTs7VUFGb0IzQixPQUFLLFdBQUFBLFFBQUFDLE1BQUE7WUFBQSxPQUFFWCxNQUFBLENBQUFzQyxTQUFTLENBQUNwQyxJQUFJLENBQUNLLElBQUk7VUFBQTs7a0VBQzVDO1lBQUEsT0FBNkIsQ0FBN0JqQix1REFBQSxDQUE2QixjQUFBMEMsb0RBQUEsQ0FBcEI5QixJQUFJLENBQUNxQyxLQUFLOzs7Ozs7Ozs7TUFJMUJqRCx1REFBQSxDQUVNLE9BRk5rRCxVQUVNLEdBREp6QixnREFBQSxDQUEyQjBCLHNCQUFBLFNBSWpDbkQsdURBQUEsQ0FBeUU7SUFBcEVjLEdBQXlCLEVBQXpCZiw0Q0FBeUI7SUFBQ21CLEdBQUcsRUFBQyxFQUFFO0lBQUVFLE9BQUssRUFBRVYsTUFBQSxDQUFBMEMsTUFBTTtJQUFFLFNBQU07UUFFOUQzQixnREFBQSxDQXVCWTRCLG9CQUFBO2dCQXZCUTNDLE1BQUEsQ0FBQTRDLHFCQUFxQjs7YUFBckI1QyxNQUFBLENBQUE0QyxxQkFBcUIsR0FBQWpDLE1BQUE7SUFBQTtJQUFFa0MsS0FBSyxFQUFDLE1BQU07SUFBQ0MsS0FBSyxFQUFDOzs0REFDNUQ7TUFBQSxPQXFCTSxDQXJCTnhELHVEQUFBLENBcUJNLE9BckJOeUQsV0FxQk0sR0FwQkpoQyxnREFBQSxDQUdTaUMsaUJBQUE7UUFIRCxTQUFNO01BQUs7Z0VBQ2pCO1VBQUEsT0FBeUMsQ0FBekNqQyxnREFBQSxDQUF5Q2tDLGlCQUFBO1lBQWhDQyxJQUFJLEVBQUU7VUFBQztvRUFBRztjQUFBLE9BQVksQ0FBWkMsV0FBWTs7O2NBQy9CcEMsZ0RBQUEsQ0FBbURrQyxpQkFBQTtZQUExQ0MsSUFBSSxFQUFFO1VBQUU7b0VBQUU7Y0FBQSxPQUF1QiwyR0FBcEJsRCxNQUFBLENBQUFvRCxRQUFRLENBQUNDLFFBQVE7Ozs7Ozs7O1VBRXpDdEMsZ0RBQUEsQ0FHU2lDLGlCQUFBO1FBSEQsU0FBTTtNQUFLO2dFQUNqQjtVQUFBLE9BQXVDLENBQXZDakMsZ0RBQUEsQ0FBdUNrQyxpQkFBQTtZQUE5QkMsSUFBSSxFQUFFO1VBQUM7b0VBQUc7Y0FBQSxPQUFXLENBQVhJLFdBQVc7OztjQUM5QnZDLGdEQUFBLENBQStDa0MsaUJBQUE7WUFBdENDLElBQUksRUFBRTtVQUFFO29FQUFFO2NBQUEsT0FBbUIsMkdBQWhCbEQsTUFBQSxDQUFBb0QsUUFBUSxDQUFDN0MsSUFBSTs7Ozs7Ozs7VUFFckNRLGdEQUFBLENBR1NpQyxpQkFBQTtRQUhELFNBQU07TUFBSztnRUFDakI7VUFBQSxPQUF3QyxDQUF4Q2pDLGdEQUFBLENBQXdDa0MsaUJBQUE7WUFBL0JDLElBQUksRUFBRTtVQUFDO29FQUFFO2NBQUEsT0FBYSxDQUFiSyxXQUFhOzs7Y0FDL0J4QyxnREFBQSxDQUErQ2tDLGlCQUFBO1lBQXRDQyxJQUFJLEVBQUU7VUFBRTtvRUFBRTtjQUFBLE9BQW1CLDJHQUFoQmxELE1BQUEsQ0FBQW9ELFFBQVEsQ0FBQ0ksSUFBSTs7Ozs7Ozs7VUFFckN6QyxnREFBQSxDQU9TaUMsaUJBQUE7UUFQRCxTQUFNO01BQUs7Z0VBQ2pCO1VBQUEsT0FBb0UsQ0FBcEVqQyxnREFBQSxDQUFvRWtDLGlCQUFBO1lBQTNEQyxJQUFJLEVBQUU7VUFBQztvRUFBRTtjQUFBLE9BQXlDLENBQXpDTyxXQUF5Qzs7O2NBQzNEMUMsZ0RBQUEsQ0FJU2tDLGlCQUFBO1lBSkFDLElBQUksRUFBRTtVQUFFO29FQUNkO2NBQUEsT0FFSyxDQUZMNUQsdURBQUEsQ0FFSyxNQUZMb0UsV0FFSywwREFESjdELHVEQUFBLENBQWdHQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUFyRUMsTUFBQSxDQUFBMkQsU0FBUyxZQUF4QnpELElBQUksRUFBQ0MsS0FBSzt5RUFBdEJOLHVEQUFBLENBQWdHO2tCQUF6RE4sS0FBSyxFQUFBcUUsbURBQUEsQ0FBRTVELE1BQUEsQ0FBQTZELFVBQVUsQ0FBQzNELElBQUk7a0JBQUlRLE9BQUssV0FBQUEsUUFBQUMsTUFBQTtvQkFBQSxPQUFFWCxNQUFBLENBQUE4RCxXQUFXLENBQUM1RCxJQUFJO2tCQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pGcEcsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBcVY7QUFDclY7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyxtU0FBTzs7OztBQUkrUjtBQUN2VCxPQUFPLGlFQUFlLG1TQUFPLElBQUksMFNBQWMsR0FBRywwU0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUJDO0FBQ1g7QUFDTDs7QUFFOUQsQ0FBNkU7O0FBRXFDO0FBQ2xILGlDQUFpQyxrSEFBZSxDQUFDLHFGQUFNLGFBQWEsd0ZBQU07QUFDMUU7QUFDQSxJQUFJLEtBQVUsRUFBRSxFQVlmOzs7QUFHRCxpRUFBZTs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCcVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBR0FwWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZGFzaGJvYXJkL2luZGV4LnZ1ZT80YjNmIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2Rhc2hib2FyZC9pbmRleC52dWU/NGJkYiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9kYXNoYm9hcmQvaW5kZXgudnVlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2Rhc2hib2FyZC9pbmRleC52dWU/NTViZiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9kYXNoYm9hcmQvaW5kZXgudnVlP2NjN2MiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZGFzaGJvYXJkL2luZGV4LnZ1ZT81ZDRkIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2Rhc2hib2FyZC9pbmRleC52dWU/MjVjZCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9kYXNoYm9hcmQvaW5kZXgudnVlPzk0ZTkiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvYXNzZXRzL3N2Zy8gc3luYyBeXFwuXFwvLipcXC5zdmckIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydHNcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiLmxheW91dFtkYXRhLXYtMzYzYTU1NDNdIHtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbiAgaGVpZ2h0OiAxMDB2aDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmxheW91dCAubGF5b3V0SGVhZGVyW2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IxKTtcXG4gIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBib3JkZXItYm90dG9tOiB2YXIoLS1ib3JkZXItY29sb3IyKSAxcHggc29saWQ7XFxuICBoZWlnaHQ6IDEwMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmxheW91dCAubGF5b3V0SGVhZGVyIGgxW2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgd2lkdGg6IDIwMHB4O1xcbiAgaGVpZ2h0OiAxMDBweDtcXG4gIGxpbmUtaGVpZ2h0OiAxMDBweDtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMyk7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrcm91bmQtY29sb3I1KTtcXG59XFxuLmxheW91dCAubGF5b3V0SGVhZGVyIC5oZWFkZXJNZW51W2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgZmxleDogMTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmxheW91dCAubGF5b3V0SGVhZGVyIC5oZWFkZXJNZW51IC5oZWFkZXJJbWdbZGF0YS12LTM2M2E1NTQzXSB7XFxuICBtYXJnaW46IDBweCAxNXB4O1xcbiAgd2lkdGg6IDMwcHg7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5sYXlvdXQgLmxheW91dEJvZHlbZGF0YS12LTM2M2E1NTQzXSB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC1ncm93OiAxO1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxufVxcbi5sYXlvdXQgLmxheW91dEJvZHkgLmNvbnRlbnRbZGF0YS12LTM2M2E1NTQzXSB7XFxuICBvdmVyZmxvdzogYXV0bztcXG4gIGZsZXgtZ3JvdzogMTtcXG4gIC8qIOWPs+S+p+WGheWuueWMuuiHqumAguW6lOWuveW6piAqL1xcbiAgZGlzcGxheTogZmxleDtcXG4gIHBhZGRpbmc6IDIwcHg7XFxuICBwYWRkaW5nLXRvcDogNjBweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IzKTtcXG59XFxuLmxheW91dCAubGF5b3V0Qm9keSAuY29udGVudCAuYnJlYWRDcnVtYltkYXRhLXYtMzYzYTU1NDNdIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMjBweDtcXG4gIGxlZnQ6IDIwcHg7XFxufVxcbi5sYXlvdXQgLmxheW91dEJvZHkgLmNvbnRlbnQgLmJyZWFkQ3J1bWIgc3BhbltkYXRhLXYtMzYzYTU1NDNdIHtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmVsLW1lbnUtdmVydGljYWwtZGVtb1tkYXRhLXYtMzYzYTU1NDNdOm5vdCguZWwtbWVudS0tY29sbGFwc2UpIHtcXG4gIG1pbi13aWR0aDogMjAwcHg7XFxuICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcXG4gIG1pbi1oZWlnaHQ6IDQwMHB4O1xcbn1cXG5bZGF0YS12LTM2M2E1NTQzXSAuZWwtbWVudSB7XFxuICBib3JkZXItcmlnaHQ6IG5vbmUgIWltcG9ydGFudDtcXG59XFxuLm1lbnVJY29uW2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgbGVmdDogMjVweDtcXG4gIGJvdHRvbTogMjBweDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmxlZnRNZW51SW1nW2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgd2lkdGg6IDIwcHg7XFxuICBoZWlnaHQ6IDIwcHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XFxufVxcbi5yb3dMaXN0W2RhdGEtdi0zNjNhNTU0M10ge1xcbiAgcGFkZGluZzogMTZweDtcXG59XFxuLnJvd0xpc3QgLnJvd1tkYXRhLXYtMzYzYTU1NDNdIHtcXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XFxufVxcbi5yb3dMaXN0IC5yb3cgaDRbZGF0YS12LTM2M2E1NTQzXSB7XFxuICBmb250LXdlaWdodDogNjAwO1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvcGFnZXMvZGFzaGJvYXJkL2luZGV4LnZ1ZVwiLFwid2VicGFjazovLy4vaW5kZXgudnVlXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUNBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FDQUY7QURKQTtFQU1JLHlCQUFBO0VBQ0Esb0NBQUE7RUFDQSxzQkFBQTtFQUNBLDZDQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7QUNDSjtBRFpBO0VBY00sWUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQ0FBQTtBQ0NOO0FEcEJBO0VBc0JNLE9BQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDQ047QUQzQkE7RUE0QlEsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNFUjtBRGpDQTtFQW9DSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUNBSjtBRHRDQTtFQW1ETSxjQUFBO0VBQ0EsWUFBQTtFQ1ZKLGVBQWU7RURXWCxhQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQ0FBQTtBQ1ROO0FEaERBO0VBMkRRLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUNSUjtBRHJEQTtFQStEVSxlQUFBO0FDUFY7QURzQkE7RUFDRSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUNwQkY7QURzQkE7RUFDRSw2QkFBQTtBQ3BCRjtBRHNCQTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FDcEJGO0FEc0JBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNwQkY7QURzQkE7RUFDRSxhQUFBO0FDcEJGO0FEbUJBO0VBR0ksbUJBQUE7QUNuQko7QURnQkE7RUFLSSxnQkFBQTtFQUNBLGVBQUE7QUNsQkpcIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxuLmxheW91dCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcXG4gIGhlaWdodDogMTAwdmg7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAubGF5b3V0SGVhZGVyIHtcXG4gICAgY29sb3I6IHZhcigtLXRleHQtY29sb3IxKTtcXG4gICAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjEpO1xcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICBib3JkZXItYm90dG9tOiB2YXIoLS1ib3JkZXItY29sb3IyKSAxcHggc29saWQ7XFxuICAgIGhlaWdodDogMTAwcHg7XFxuICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgIC8vIGJhY2tncm91bmQ6IGNoYXJ0cmV1c2U7XFxuICAgIGgxIHtcXG4gICAgICB3aWR0aDogMjAwcHg7XFxuICAgICAgaGVpZ2h0OiAxMDBweDtcXG4gICAgICBsaW5lLWhlaWdodDogMTAwcHg7XFxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMyk7XFxuICAgICAgYmFja2dyb3VuZDogdmFyKC0tYmFja3JvdW5kLWNvbG9yNSk7XFxuICAgIH1cXG4gICAgLmhlYWRlck1lbnUge1xcbiAgICAgIGZsZXg6IDE7XFxuICAgICAgZGlzcGxheTogZmxleDtcXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgICAgIC5oZWFkZXJJbWcge1xcbiAgICAgICAgbWFyZ2luOiAwcHggMTVweDtcXG4gICAgICAgIHdpZHRoOiAzMHB4O1xcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xcbiAgICAgIH1cXG4gICAgfVxcbiAgfVxcbiAgLmxheW91dEJvZHkge1xcbiAgICBkaXNwbGF5OiBmbGV4O1xcbiAgICBmbGV4LWdyb3c6IDE7XFxuICAgIG92ZXJmbG93OiBhdXRvO1xcbiAgICAvLyAubGVmdE1lbnUge1xcbiAgICAvLyAgIC8vIHdpZHRoOiAyMDBweDsgLyog6K6+572u5bem5L6n6L655qCP5a695bqmICovXFxuICAgIC8vICAgdHJhbnNpdGlvbjogd2lkdGggMC4ycztcXG4gICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1iYWNrcm91bmQtY29sb3I2KTtcXG4gICAgLy8gICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAgIC8vICAgLkxlZnRCdG4ge1xcbiAgICAvLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICAvLyAgICAgYm90dG9tOiAxMHB4O1xcbiAgICAvLyAgICAgcmlnaHQ6IDEwcHg7XFxuICAgIC8vICAgfVxcbiAgICAvLyB9XFxuICAgIC5jb250ZW50IHtcXG4gICAgICBvdmVyZmxvdzogYXV0bztcXG4gICAgICBmbGV4LWdyb3c6IDE7IC8qIOWPs+S+p+WGheWuueWMuuiHqumAguW6lOWuveW6piAqL1xcbiAgICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgICAgcGFkZGluZzogMjBweDtcXG4gICAgICBwYWRkaW5nLXRvcDogNjBweDtcXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAgICAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjMpO1xcbiAgICAgIC5icmVhZENydW1iIHtcXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgICAgIHRvcDogMjBweDtcXG4gICAgICAgIGxlZnQ6IDIwcHg7XFxuICAgICAgICBzcGFuIHtcXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xcbiAgICAgICAgfVxcbiAgICAgICAgLy8gOjp2LWRlZXAoKSAuZWwtYnJlYWRjcnVtYl9faW5uZXIge1xcbiAgICAgICAgLy8gICBjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xcbiAgICAgICAgLy8gfVxcbiAgICAgICAgLy8gOjp2LWRlZXAoKSAuZWwtYnJlYWRjcnVtYl9fc2VwYXJhdG9yIHtcXG4gICAgICAgIC8vICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcXG4gICAgICAgIC8vIH1cXG4gICAgICB9XFxuICAgIH1cXG4gIH1cXG59XFxuLy8gLmVsLW1lbnUge1xcbi8vICAgcG9zaXRpb246IHJlbGF0aXZlO1xcbi8vIH1cXG4uZWwtbWVudS12ZXJ0aWNhbC1kZW1vOm5vdCguZWwtbWVudS0tY29sbGFwc2UpIHtcXG4gIG1pbi13aWR0aDogMjAwcHg7XFxuICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcXG4gIG1pbi1oZWlnaHQ6IDQwMHB4O1xcbn1cXG46OnYtZGVlcCguZWwtbWVudSkgIHtcXG4gIGJvcmRlci1yaWdodDogbm9uZSAhaW1wb3J0YW50O1xcbn1cXG4ubWVudUljb24ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgbGVmdDogMjVweDtcXG4gIGJvdHRvbTogMjBweDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmxlZnRNZW51SW1nIHtcXG4gIHdpZHRoOiAyMHB4O1xcbiAgaGVpZ2h0OiAyMHB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xcbn1cXG4ucm93TGlzdHtcXG4gIHBhZGRpbmc6IDE2cHg7XFxuICAucm93e1xcbiAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xcbiAgICBoNHtcXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcXG4gICAgZm9udC1zaXplOiAxNnB4O1xcbiAgfVxcbiAgfVxcblxcbn1cXG5cIixcIi5sYXlvdXQge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XFxuICBoZWlnaHQ6IDEwMHZoO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4ubGF5b3V0IC5sYXlvdXRIZWFkZXIge1xcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IxKTtcXG4gIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBib3JkZXItYm90dG9tOiB2YXIoLS1ib3JkZXItY29sb3IyKSAxcHggc29saWQ7XFxuICBoZWlnaHQ6IDEwMHB4O1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmxheW91dCAubGF5b3V0SGVhZGVyIGgxIHtcXG4gIHdpZHRoOiAyMDBweDtcXG4gIGhlaWdodDogMTAwcHg7XFxuICBsaW5lLWhlaWdodDogMTAwcHg7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjMpO1xcbiAgYmFja2dyb3VuZDogdmFyKC0tYmFja3JvdW5kLWNvbG9yNSk7XFxufVxcbi5sYXlvdXQgLmxheW91dEhlYWRlciAuaGVhZGVyTWVudSB7XFxuICBmbGV4OiAxO1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxuICBhbGlnbi1pdGVtczogY2VudGVyO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4ubGF5b3V0IC5sYXlvdXRIZWFkZXIgLmhlYWRlck1lbnUgLmhlYWRlckltZyB7XFxuICBtYXJnaW46IDBweCAxNXB4O1xcbiAgd2lkdGg6IDMwcHg7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5sYXlvdXQgLmxheW91dEJvZHkge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZ3JvdzogMTtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbn1cXG4ubGF5b3V0IC5sYXlvdXRCb2R5IC5jb250ZW50IHtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgZmxleC1ncm93OiAxO1xcbiAgLyog5Y+z5L6n5YaF5a655Yy66Ieq6YCC5bqU5a695bqmICovXFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgcGFkZGluZzogMjBweDtcXG4gIHBhZGRpbmctdG9wOiA2MHB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjMpO1xcbn1cXG4ubGF5b3V0IC5sYXlvdXRCb2R5IC5jb250ZW50IC5icmVhZENydW1iIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMjBweDtcXG4gIGxlZnQ6IDIwcHg7XFxufVxcbi5sYXlvdXQgLmxheW91dEJvZHkgLmNvbnRlbnQgLmJyZWFkQ3J1bWIgc3BhbiB7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5lbC1tZW51LXZlcnRpY2FsLWRlbW86bm90KC5lbC1tZW51LS1jb2xsYXBzZSkge1xcbiAgbWluLXdpZHRoOiAyMDBweDtcXG4gIHdpZHRoOiAyMDBweCAhaW1wb3J0YW50O1xcbiAgbWluLWhlaWdodDogNDAwcHg7XFxufVxcbjo6di1kZWVwKC5lbC1tZW51KSB7XFxuICBib3JkZXItcmlnaHQ6IG5vbmUgIWltcG9ydGFudDtcXG59XFxuLm1lbnVJY29uIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGxlZnQ6IDI1cHg7XFxuICBib3R0b206IDIwcHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5sZWZ0TWVudUltZyB7XFxuICB3aWR0aDogMjBweDtcXG4gIGhlaWdodDogMjBweDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIG1hcmdpbi1yaWdodDogMjBweDtcXG59XFxuLnJvd0xpc3Qge1xcbiAgcGFkZGluZzogMTZweDtcXG59XFxuLnJvd0xpc3QgLnJvdyB7XFxuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xcbn1cXG4ucm93TGlzdCAucm93IGg0IHtcXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XFxuICBmb250LXNpemU6IDE2cHg7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJpbXBvcnQgeyB1c2VSb3V0ZXIsIHVzZVJvdXRlIH0gZnJvbSBcInZ1ZS1yb3V0ZXJcIjtcbmltcG9ydCBzY3JlZW5mdWxsIGZyb20gJ3NjcmVlbmZ1bGwnO1xuaW1wb3J0IHsgRG9jdW1lbnQsIE1lbnUgYXMgSWNvbk1lbnUsIExvY2F0aW9uLCBTZXR0aW5nIH0gZnJvbSBcIkBlbGVtZW50LXBsdXMvaWNvbnMtdnVlXCI7XG5pbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmVcIjtcbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAnaW5kZXgnLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICBleHBvc2UoKTtcbiAgICB2YXIgaW50ZXJJbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIHZhciBkaWFsb2dVc2VySW5mb1Zpc2libGUgPSByZWYoZmFsc2UpO1xuICAgIHZhciB1c2VySW5mbyA9IHJlZihudWxsKTtcbiAgICB2YXIgdGhlbWUgPSByZWYobnVsbCk7XG4gICAgdGhlbWUudmFsdWUgPSBkb2N1bWVudC5ib2R5LmRhdGFzZXQudGhlbWU7XG4gICAgdmFyIG1lbnVBY3RpdmUgPSByZWYoXCJkYXNoYm9hcmRcIik7XG4gICAgLy/lhajph4/ot6/nlLFcbiAgICB2YXIgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gICAgLy/lvZPliY3ot6/nlLFcbiAgICB2YXIgcm91dGUgPSB1c2VSb3V0ZSgpO1xuICAgIC8v6Z2i5YyF5bGR5YiX6KGoXG4gICAgdmFyIGJyZWFkTGlzdCA9IHJlYWN0aXZlKFt7XG4gICAgICBjbmFtZTogXCLkuLvpobVcIixcbiAgICAgIG5hbWU6IFwiZGFzaGJvYXJkXCJcbiAgICB9XSk7XG4gICAgLy/orqHnrpfpnaLljIXlsZHliJfooahcbiAgICB2YXIgZ2V0QnJlYWRMaXN0ID0gZnVuY3Rpb24gZ2V0QnJlYWRMaXN0KHJvdXRlUGF0aCwgYWxsUm91dGVycykge1xuICAgICAgYnJlYWRMaXN0LnNwbGljZSgwLCBicmVhZExpc3QubGVuZ3RoKTtcbiAgICAgIHZhciBwYXRoTGlzdCA9IHJvdXRlUGF0aC5zcGxpdChcIi9cIik7XG4gICAgICBwYXRoTGlzdC5zaGlmdCgpO1xuICAgICAgcGF0aExpc3QuZm9yRWFjaChmdW5jdGlvbiAoaXRlbSwgaW5kZXgpIHtcbiAgICAgICAgaWYgKGl0ZW0gPT09IFwiZGFzaGJvYXJkXCIpIHtcbiAgICAgICAgICBicmVhZExpc3QucHVzaCh7XG4gICAgICAgICAgICBjbmFtZTogXCLkuLvpobVcIixcbiAgICAgICAgICAgIG5hbWU6IFwiZGFzaGJvYXJkXCJcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YXIgdmFsID0gYWxsUm91dGVycy5maW5kKGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICByZXR1cm4gdi5uYW1lID09PSBpdGVtO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmICh2YWwpIHtcbiAgICAgICAgICAgIGJyZWFkTGlzdC5wdXNoKHtcbiAgICAgICAgICAgICAgY25hbWU6IHZhbC5tZXRhLm5hbWUsXG4gICAgICAgICAgICAgIG5hbWU6IHZhbC5uYW1lXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICh2YWwuY2hpbGRyZW4pIHtcbiAgICAgICAgICAgICAgdmFyIG0gPSB2YWwuY2hpbGRyZW4uZmluZChmdW5jdGlvbiAodikge1xuICAgICAgICAgICAgICAgIHJldHVybiB2Lm5hbWUgPT09IHBhdGhMaXN0W2luZGV4ICsgMV07XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBpZiAobSkge1xuICAgICAgICAgICAgICAgIGJyZWFkTGlzdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgIGNuYW1lOiBtLm1ldGEubmFtZSxcbiAgICAgICAgICAgICAgICAgIG5hbWU6IG0ubmFtZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlmIChicmVhZExpc3QubGVuZ3RoID4gMSkge1xuICAgICAgICBtZW51QWN0aXZlLnZhbHVlID0gYnJlYWRMaXN0WzFdLm5hbWU7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zb2xlLmxvZyhyb3V0ZXIuZ2V0Um91dGVzKCksICfot6/nlLHkv6Hmga8tLS0tJyk7XG4gICAgY29uc29sZS5sb2cocm91dGVyLCAn6Lev55SxJyk7XG4gICAgdmFyIGxlZnRNZW51TGlzdCA9IHJvdXRlci5nZXRSb3V0ZXMoKS5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICByZXR1cm4gaXRlbS5uYW1lID09PSBcImRhc2hib2FyZFwiO1xuICAgIH0pLmNoaWxkcmVuO1xuICAgIC8v5bem5L6n6I+c5Y2V5Ly45bGVXG4gICAgdmFyIGlzQ29sbGFwc2UgPSByZWYoZmFsc2UpO1xuICAgIC8v6aG26YOo6I+c5Y2VXG4gICAgdmFyIGhlYWRlck1lbnVMaXN0ID0gcmVhY3RpdmUoW3tcbiAgICAgIG5hbWU6IFwi5YWo5bGPXCIsXG4gICAgICB2YWx1ZTogXCJmdWxsXCJcbiAgICB9LCB7XG4gICAgICBuYW1lOiBcImdpdGh1YlwiLFxuICAgICAgdmFsdWU6IFwiZ2l0aHViXCJcbiAgICB9LCB7XG4gICAgICBuYW1lOiBcIueUqOaIt1wiLFxuICAgICAgdmFsdWU6IFwidXNlclwiXG4gICAgfSwge1xuICAgICAgbmFtZTogXCLpgIDlh7pcIixcbiAgICAgIHZhbHVlOiBcIm91dFwiXG4gICAgfV0pO1xuICAgIHZhciBoYW5kbGVPcGVuID0gZnVuY3Rpb24gaGFuZGxlT3BlbihrZXksIGtleVBhdGgpIHtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGtleSwga2V5UGF0aCk7XG4gICAgfTtcbiAgICB2YXIgaGFuZGxlQ2xvc2UgPSBmdW5jdGlvbiBoYW5kbGVDbG9zZShrZXksIGtleVBhdGgpIHtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGtleSwga2V5UGF0aCk7XG4gICAgfTtcbiAgICB2YXIgdW5mb2xkID0gZnVuY3Rpb24gdW5mb2xkKCkge1xuICAgICAgaXNDb2xsYXBzZS52YWx1ZSA9ICFpc0NvbGxhcHNlLnZhbHVlO1xuICAgIH07XG4gICAgdmFyIGp1bXAgPSBmdW5jdGlvbiBqdW1wKHZhbCkge1xuICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICBuYW1lOiB2YWxcbiAgICAgIH0pO1xuICAgICAgLy8gZ2V0QnJlYWRMaXN0KHJvdXRlLnBhdGgsIHJvdXRlci5vcHRpb25zLnJvdXRlc1szXS5jaGlsZHJlbik7XG4gICAgfTtcblxuICAgIHZhciBvdXRMb2dpbiA9IGZ1bmN0aW9uIG91dExvZ2luKHZhbCkge1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJ0b2tlblwiKTtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgcGF0aDogXCIvbG9naW5cIlxuICAgICAgfSk7XG4gICAgICBzdG9yZS5kaXNwYXRjaCgnY2hhbmdlQXN5bmNSb3V0ZUZpbmlzaCcsIGZhbHNlKTtcbiAgICAgIGNvbnNvbGUubG9nKHN0b3JlLnN0YXRlLnJvbGUsICc/Pz8/6YCA5Ye65ZCO55qE5pON5L2cJyk7XG4gICAgfTtcbiAgICB2YXIgSWNvbnRvID0gZnVuY3Rpb24gSWNvbnRvKHZhbCkge1xuICAgICAgc3dpdGNoICh2YWwpIHtcbiAgICAgICAgY2FzZSBcImdpdGh1YlwiOlxuICAgICAgICAgIHdpbmRvdy5vcGVuKFwiaHR0cHM6Ly9naXRodWIuY29tL3dqdDE2MjI4Njc5My93ZWJwYWNrLS0tLXZ1ZVwiKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIm91dFwiOlxuICAgICAgICAgIG91dExvZ2luKCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJmdWxsXCI6XG4gICAgICAgICAgc2NyZWVuZnVsbC50b2dnbGUoKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInVzZXJcIjpcbiAgICAgICAgICBkaWFsb2dVc2VySW5mb1Zpc2libGUudmFsdWUgPSB0cnVlO1xuICAgICAgICAgIHVzZXJJbmZvLnZhbHVlID0gc3RvcmUuc3RhdGUudXNlci51c2VySW5mbztcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9O1xuICAgIHZhciBicmVhZEp1bXAgPSBmdW5jdGlvbiBicmVhZEp1bXAoYnJlYWROYW1lKSB7XG4gICAgICBpZiAoYnJlYWROYW1lID09PSBcImRhc2hib2FyZFwiKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChicmVhZE5hbWUgPT09IHJvdXRlLm5hbWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICAgIG5hbWU6IGJyZWFkTmFtZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHZhciBoYW5kbGVNZW51U2VsZWN0ID0gZnVuY3Rpb24gaGFuZGxlTWVudVNlbGVjdChtZW51VmFsKSB7XG4gICAgICBtZW51QWN0aXZlLnZhbHVlID0gbWVudVZhbDtcbiAgICB9O1xuICAgIHZhciBqdW1wTW9kZSA9IGZ1bmN0aW9uIGp1bXBNb2RlKG5hbWUpIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgbmFtZTogbmFtZVxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgdGhlbWVMaXN0ID0gcmVmKFt7XG4gICAgICBjb2xvcjogJyM0MDllZmYnLFxuICAgICAgdGhlbWU6ICdibHVlJ1xuICAgIH0sIHtcbiAgICAgIGNvbG9yOiAnI2JhN2RlNCcsXG4gICAgICB0aGVtZTogJ3B1cnBsZSdcbiAgICB9LCB7XG4gICAgICBjb2xvcjogJyM3MmExNWEnLFxuICAgICAgdGhlbWU6ICdncmVlbidcbiAgICB9LCB7XG4gICAgICBjb2xvcjogJyNhNzI1MTMnLFxuICAgICAgdGhlbWU6ICdyZWQnXG4gICAgfSwge1xuICAgICAgY29sb3I6ICcjNTM0NjY4JyxcbiAgICAgIHRoZW1lOiAnZGVlcFB1cnBsZSdcbiAgICB9LCB7XG4gICAgICBjb2xvcjogJyMxMzA4OGEnLFxuICAgICAgdGhlbWU6ICdkZWVwQmx1ZSdcbiAgICB9XSk7XG4gICAgdmFyIGNoYW5nZVRoZW1lID0gZnVuY3Rpb24gY2hhbmdlVGhlbWUoaXRlbSkge1xuICAgICAgZG9jdW1lbnQuYm9keS5kYXRhc2V0LnRoZW1lID0gaXRlbS50aGVtZTtcbiAgICAgIHRoZW1lLnZhbHVlID0gaXRlbS50aGVtZTtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0aGVtZScsIGl0ZW0udGhlbWUpO1xuICAgIH07XG4gICAgdmFyIGdldExpU3R5bGUgPSBmdW5jdGlvbiBnZXRMaVN0eWxlKGl0ZW0pIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGJhY2tncm91bmQ6IGl0ZW0uY29sb3IsXG4gICAgICAgIHdpZHRoOiBpdGVtLnRoZW1lID09PSB0aGVtZS52YWx1ZSA/ICc0MHB4JyA6ICczMHB4JyxcbiAgICAgICAgaGVpZ2h0OiBpdGVtLnRoZW1lID09PSB0aGVtZS52YWx1ZSA/ICc0MHB4JyA6ICczMHB4JyxcbiAgICAgICAgbWFyZ2luOiAnMTBweCcsXG4gICAgICAgIGN1cnNvcjogJ3BvaW50ZXInXG4gICAgICB9O1xuICAgIH07XG4gICAgb25Nb3VudGVkKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbnNvbGUubG9nKHJvdXRlLCAn6L+b5YWl5LqGJyk7XG4gICAgICBpZiAocm91dGUucGF0aCA9PT0gXCIvZGFzaGJvYXJkXCIpIHtcbiAgICAgICAgdmFyIGRlZmF1bHRSb3V0ZSA9IHN0b3JlLnN0YXRlLnJvbGUuZmlsdGVyQXN5bmNSb3V0ZXMuZmluZChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgIHJldHVybiBpdGVtLm5hbWUgPT09ICdkYXNoYm9hcmQnO1xuICAgICAgICB9KS5jaGlsZHJlblswXS5wYXRoO1xuICAgICAgICBjb25zb2xlLmxvZyhkZWZhdWx0Um91dGUsICfoh6rliqjljLnphY3lrZDot6/nlLEnKTtcbiAgICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICAgIHBhdGg6IGRlZmF1bHRSb3V0ZVxuICAgICAgICB9KTtcbiAgICAgICAgbWVudUFjdGl2ZS52YWx1ZSA9IFwiYnVzaW5lc3NcIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1lbnVBY3RpdmUudmFsdWUgPSByb3V0ZS5uYW1lO1xuICAgICAgfVxuICAgICAgZ2V0QnJlYWRMaXN0KHJvdXRlLnBhdGgsIHJvdXRlci5nZXRSb3V0ZXMoKS5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLm5hbWUgPT09IFwiZGFzaGJvYXJkXCI7XG4gICAgICB9KS5jaGlsZHJlbik7XG4gICAgICB3YXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiByb3V0ZS5wYXRoO1xuICAgICAgfSwgZnVuY3Rpb24gKG5ld1ZhbCwgb2xkVmFsKSB7XG4gICAgICAgIGdldEJyZWFkTGlzdChuZXdWYWwsIHJvdXRlci5nZXRSb3V0ZXMoKS5maW5kKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgcmV0dXJuIGl0ZW0ubmFtZSA9PT0gJ2Rhc2hib2FyZCc7XG4gICAgICAgIH0pLmNoaWxkcmVuKTtcbiAgICAgICAgaWYgKG5ld1ZhbCA9PT0gXCIvZGFzaGJvYXJkXCIpIHtcbiAgICAgICAgICB2YXIgX2RlZmF1bHRSb3V0ZSA9IHN0b3JlLnN0YXRlLnJvbGUuZmlsdGVyQXN5bmNSb3V0ZXMuZmluZChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgcmV0dXJuIGl0ZW0ubmFtZSA9PT0gJ2Rhc2hib2FyZCc7XG4gICAgICAgICAgfSkuY2hpbGRyZW5bMF0ucGF0aDtcbiAgICAgICAgICBjb25zb2xlLmxvZyhfZGVmYXVsdFJvdXRlLCAn6Ieq5Yqo5Yy56YWN5a2Q6Lev55SxJyk7XG4gICAgICAgICAgcm91dGVyLnB1c2goe1xuICAgICAgICAgICAgcGF0aDogX2RlZmF1bHRSb3V0ZVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIG1lbnVBY3RpdmUudmFsdWUgPSBcImJ1c2luZXNzXCI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHZhciBfX3JldHVybmVkX18gPSB7XG4gICAgICBpbnRlckluc3RhbmNlOiBpbnRlckluc3RhbmNlLFxuICAgICAgZGlhbG9nVXNlckluZm9WaXNpYmxlOiBkaWFsb2dVc2VySW5mb1Zpc2libGUsXG4gICAgICB1c2VySW5mbzogdXNlckluZm8sXG4gICAgICBnZXQgdGhlbWUoKSB7XG4gICAgICAgIHJldHVybiB0aGVtZTtcbiAgICAgIH0sXG4gICAgICBzZXQgdGhlbWUodikge1xuICAgICAgICB0aGVtZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IG1lbnVBY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiBtZW51QWN0aXZlO1xuICAgICAgfSxcbiAgICAgIHNldCBtZW51QWN0aXZlKHYpIHtcbiAgICAgICAgbWVudUFjdGl2ZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJvdXRlcigpIHtcbiAgICAgICAgcmV0dXJuIHJvdXRlcjtcbiAgICAgIH0sXG4gICAgICBzZXQgcm91dGVyKHYpIHtcbiAgICAgICAgcm91dGVyID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgcm91dGUoKSB7XG4gICAgICAgIHJldHVybiByb3V0ZTtcbiAgICAgIH0sXG4gICAgICBzZXQgcm91dGUodikge1xuICAgICAgICByb3V0ZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGJyZWFkTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIGJyZWFkTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgYnJlYWRMaXN0KHYpIHtcbiAgICAgICAgYnJlYWRMaXN0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXRCcmVhZExpc3Q6IGdldEJyZWFkTGlzdCxcbiAgICAgIGxlZnRNZW51TGlzdDogbGVmdE1lbnVMaXN0LFxuICAgICAgaXNDb2xsYXBzZTogaXNDb2xsYXBzZSxcbiAgICAgIGhlYWRlck1lbnVMaXN0OiBoZWFkZXJNZW51TGlzdCxcbiAgICAgIGhhbmRsZU9wZW46IGhhbmRsZU9wZW4sXG4gICAgICBoYW5kbGVDbG9zZTogaGFuZGxlQ2xvc2UsXG4gICAgICB1bmZvbGQ6IHVuZm9sZCxcbiAgICAgIGp1bXA6IGp1bXAsXG4gICAgICBvdXRMb2dpbjogb3V0TG9naW4sXG4gICAgICBJY29udG86IEljb250byxcbiAgICAgIGJyZWFkSnVtcDogYnJlYWRKdW1wLFxuICAgICAgaGFuZGxlTWVudVNlbGVjdDogaGFuZGxlTWVudVNlbGVjdCxcbiAgICAgIGp1bXBNb2RlOiBqdW1wTW9kZSxcbiAgICAgIGdldCB0aGVtZUxpc3QoKSB7XG4gICAgICAgIHJldHVybiB0aGVtZUxpc3Q7XG4gICAgICB9LFxuICAgICAgc2V0IHRoZW1lTGlzdCh2KSB7XG4gICAgICAgIHRoZW1lTGlzdCA9IHY7XG4gICAgICB9LFxuICAgICAgY2hhbmdlVGhlbWU6IGNoYW5nZVRoZW1lLFxuICAgICAgZ2V0TGlTdHlsZTogZ2V0TGlTdHlsZSxcbiAgICAgIGdldCB1c2VSb3V0ZXIoKSB7XG4gICAgICAgIHJldHVybiB1c2VSb3V0ZXI7XG4gICAgICB9LFxuICAgICAgZ2V0IHVzZVJvdXRlKCkge1xuICAgICAgICByZXR1cm4gdXNlUm91dGU7XG4gICAgICB9LFxuICAgICAgZ2V0IHNjcmVlbmZ1bGwoKSB7XG4gICAgICAgIHJldHVybiBzY3JlZW5mdWxsO1xuICAgICAgfSxcbiAgICAgIGdldCBEb2N1bWVudCgpIHtcbiAgICAgICAgcmV0dXJuIERvY3VtZW50O1xuICAgICAgfSxcbiAgICAgIGdldCBJY29uTWVudSgpIHtcbiAgICAgICAgcmV0dXJuIEljb25NZW51O1xuICAgICAgfSxcbiAgICAgIGdldCBMb2NhdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIExvY2F0aW9uO1xuICAgICAgfSxcbiAgICAgIGdldCBTZXR0aW5nKCkge1xuICAgICAgICByZXR1cm4gU2V0dGluZztcbiAgICAgIH0sXG4gICAgICBnZXQgc3RvcmUoKSB7XG4gICAgICAgIHJldHVybiBzdG9yZTtcbiAgICAgIH1cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImxheW91dFwiPlxyXG4gICAgPCEtLSA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgQGNsaWNrPVwiY3JlYXRlVnVlRmlsZVwiPuWIm+W7unZ1ZeaWh+S7tjwvZWwtYnV0dG9uPiAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJsYXlvdXRIZWFkZXJcIj5cclxuICAgICAgPGgxPui1hOS6p+euoeeQhuezu+e7nzwvaDE+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXJNZW51XCI+XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgOnNyYz1cInJlcXVpcmUoYEAvYXNzZXRzL3N2Zy8ke2l0ZW0ubmFtZX0uc3ZnYClcIlxyXG4gICAgICAgICAgOmFsdD1cIml0ZW0ubmFtZVwiXHJcbiAgICAgICAgICB2LWZvcj1cIihpdGVtLCBpbmRleCkgaW4gaGVhZGVyTWVudUxpc3RcIlxyXG4gICAgICAgICAgOmtleT1cImluZGV4XCJcclxuICAgICAgICAgIGNsYXNzPVwiaGVhZGVySW1nXCJcclxuICAgICAgICAgIEBjbGljaz1cIkljb250byhpdGVtLnZhbHVlKVwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJsYXlvdXRCb2R5XCI+XHJcbiAgICAgIDxlbC1tZW51XHJcbiAgICAgICAgOmRlZmF1bHQtYWN0aXZlPVwibWVudUFjdGl2ZVwiXHJcbiAgICAgICAgOmNvbGxhcHNlPVwiaXNDb2xsYXBzZVwiXHJcbiAgICAgICAgYWN0aXZlLXRleHQtY29sb3I9XCIjZmZkMDRiXCJcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yPVwiIzU0NWM2NFwiXHJcbiAgICAgICAgY2xhc3M9XCJlbC1tZW51LXZlcnRpY2FsLWRlbW9cIlxyXG4gICAgICAgIHRleHQtY29sb3I9XCIjZmZmXCJcclxuICAgICAgICBAb3Blbj1cImhhbmRsZU9wZW5cIlxyXG4gICAgICAgIEBjbG9zZT1cImhhbmRsZUNsb3NlXCJcclxuICAgICAgICBAc2VsZWN0PVwiaGFuZGxlTWVudVNlbGVjdFwiXHJcbiAgICAgICAgOnJvdXRlcj1cInRydWVcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPGVsLW1lbnUtaXRlbVxyXG4gICAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIGxlZnRNZW51TGlzdFwiXHJcbiAgICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgICAgOmluZGV4PVwiaXRlbS5uYW1lXCJcclxuICAgICAgICAgIEBjbGljaz1cImp1bXBNb2RlKGl0ZW0ubmFtZSlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDwhLS0gPGVsLWljb24+PC9lbC1pY29uPiAtLT5cclxuICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgOnNyYz1cInJlcXVpcmUoYEAvYXNzZXRzL3N2Zy8ke2l0ZW0ubWV0YS5uYW1lfS5zdmdgKVwiXHJcbiAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwibGVmdE1lbnVJbWdcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxzcGFuPnt7IGl0ZW0ubWV0YS5uYW1lIH19PC9zcGFuPlxyXG4gICAgICAgIDwvZWwtbWVudS1pdGVtPlxyXG4gICAgICA8L2VsLW1lbnU+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XHJcbiAgICAgICAgPGVsLWJyZWFkY3J1bWIgc2VwYXJhdG9yPVwiL1wiIGNsYXNzPVwiYnJlYWRDcnVtYlwiPlxyXG4gICAgICAgICAgPHRlbXBsYXRlIHYtZm9yPVwiKGl0ZW0sIGluZGV4KSBpbiBicmVhZExpc3RcIiA6a2V5PVwiaW5kZXhcIj5cclxuICAgICAgICAgICAgPGVsLWJyZWFkY3J1bWItaXRlbVxyXG4gICAgICAgICAgICAgIEBjbGljaz1cImJyZWFkSnVtcChpdGVtLm5hbWUpXCJcclxuICAgICAgICAgICAgICB2LWlmPVwiaXRlbS5uYW1lICE9PSAnZGFzaGJvYXJkJ1wiXHJcbiAgICAgICAgICAgICAgPjxzcGFuPnt7IGl0ZW0uY25hbWUgfX08L3NwYW4+PC9lbC1icmVhZGNydW1iLWl0ZW1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZWwtYnJlYWRjcnVtYi1pdGVtIEBjbGljaz1cImJyZWFkSnVtcChpdGVtLm5hbWUpXCIgdi1lbHNlXHJcbiAgICAgICAgICAgICAgPjxzcGFuPnt7IGl0ZW0uY25hbWUgfX08L3NwYW4+PC9lbC1icmVhZGNydW1iLWl0ZW1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICA8L2VsLWJyZWFkY3J1bWI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGVCb3hcIj5cclxuICAgICAgICAgIDxyb3V0ZXItdmlldz48L3JvdXRlci12aWV3PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPGltZyBzcmM9XCJAL2Fzc2V0cy9zdmcv6I+c5Y2VLnN2Z1wiIGFsdD1cIlwiIEBjbGljaz1cInVuZm9sZFwiIGNsYXNzPVwibWVudUljb25cIiAvPlxyXG4gIDwvZGl2PlxyXG4gIDxlbC1kaWFsb2cgdi1tb2RlbD1cImRpYWxvZ1VzZXJJbmZvVmlzaWJsZVwiIHRpdGxlPVwi55So5oi35L+h5oGvXCIgd2lkdGg9XCI2MDBweFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cInJvd0xpc3RcIj5cclxuICAgICAgPGVsLXJvdyBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgIDxlbC1jb2wgOnNwYW49XCI4XCI+IDxoND7nlKjmiLflkI08L2g0PiA8L2VsLWNvbD5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTZcIj57eyB1c2VySW5mby51c2VyTmFtZSB9fTwvZWwtY29sPlxyXG4gICAgICA8L2VsLXJvdz5cclxuICAgICAgPGVsLXJvdyBjbGFzcz1cInJvd1wiPlxyXG4gICAgICAgIDxlbC1jb2wgOnNwYW49XCI4XCI+IDxoND7otKblj7c8L2g0PjwvZWwtY29sPlxyXG4gICAgICAgIDxlbC1jb2wgOnNwYW49XCIxNlwiPnt7IHVzZXJJbmZvLm5hbWUgfX08L2VsLWNvbD5cclxuICAgICAgPC9lbC1yb3c+XHJcbiAgICAgIDxlbC1yb3cgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiOFwiPjxoND7nlKjmiLfmnYPpmZA8L2g0PjwvZWwtY29sPlxyXG4gICAgICAgIDxlbC1jb2wgOnNwYW49XCIxNlwiPnt7IHVzZXJJbmZvLnJvbGUgfX08L2VsLWNvbD5cclxuICAgICAgPC9lbC1yb3c+XHJcbiAgICAgIDxlbC1yb3cgY2xhc3M9XCJyb3dcIj5cclxuICAgICAgICA8ZWwtY29sIDpzcGFuPVwiOFwiPjxoNCBzdHlsZT1cImxpbmUtaGVpZ2h0OiA2MHB4O1wiPuS4u+mimOiJsuiuvue9rjwvaDQ+PC9lbC1jb2w+XHJcbiAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjE2XCI+XHJcbiAgICAgICAgICAgPHVsIHN0eWxlPVwiZGlzcGxheTogZmxleDtcIj5cclxuICAgICAgICAgICAgPGxpIHYtZm9yPVwiKGl0ZW0saW5kZXgpIGluIHRoZW1lTGlzdFwiIDpzdHlsZT1cImdldExpU3R5bGUoaXRlbSlcIiBAY2xpY2s9XCJjaGFuZ2VUaGVtZShpdGVtKVwiPjwvbGk+XHJcbiAgICAgICAgICAgPC91bD5cclxuICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgPC9lbC1yb3c+XHJcbiAgICA8L2Rpdj5cclxuICA8L2VsLWRpYWxvZz5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IHVzZVJvdXRlciwgdXNlUm91dGUgfSBmcm9tIFwidnVlLXJvdXRlclwiO1xyXG5pbXBvcnQgc2NyZWVuZnVsbCBmcm9tICdzY3JlZW5mdWxsJ1xyXG5pbXBvcnQge1xyXG4gIERvY3VtZW50LFxyXG4gIE1lbnUgYXMgSWNvbk1lbnUsXHJcbiAgTG9jYXRpb24sXHJcbiAgU2V0dGluZyxcclxufSBmcm9tIFwiQGVsZW1lbnQtcGx1cy9pY29ucy12dWVcIjtcclxuaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlXCI7XHJcbmNvbnN0IGludGVySW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcclxuY29uc3QgZGlhbG9nVXNlckluZm9WaXNpYmxlID0gcmVmKGZhbHNlKVxyXG5jb25zdCB1c2VySW5mbyA9IHJlZihudWxsKVxyXG5sZXQgdGhlbWUgPSByZWYobnVsbClcclxudGhlbWUudmFsdWUgPSBkb2N1bWVudC5ib2R5LmRhdGFzZXQudGhlbWVcclxubGV0IG1lbnVBY3RpdmUgPSByZWYoXCJkYXNoYm9hcmRcIik7XHJcbi8v5YWo6YeP6Lev55SxXHJcbmxldCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuLy/lvZPliY3ot6/nlLFcclxubGV0IHJvdXRlID0gdXNlUm91dGUoKTtcclxuLy/pnaLljIXlsZHliJfooahcclxubGV0IGJyZWFkTGlzdCA9IHJlYWN0aXZlKFtcclxuICB7XHJcbiAgICBjbmFtZTogXCLkuLvpobVcIixcclxuICAgIG5hbWU6IFwiZGFzaGJvYXJkXCIsXHJcbiAgfSxcclxuXSk7XHJcbi8v6K6h566X6Z2i5YyF5bGR5YiX6KGoXHJcbmNvbnN0IGdldEJyZWFkTGlzdCA9IChyb3V0ZVBhdGgsIGFsbFJvdXRlcnMpID0+IHtcclxuICBicmVhZExpc3Quc3BsaWNlKDAsIGJyZWFkTGlzdC5sZW5ndGgpO1xyXG4gIGxldCBwYXRoTGlzdCA9IHJvdXRlUGF0aC5zcGxpdChcIi9cIik7XHJcbiAgcGF0aExpc3Quc2hpZnQoKTtcclxuICBwYXRoTGlzdC5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgaWYgKGl0ZW0gPT09IFwiZGFzaGJvYXJkXCIpIHtcclxuICAgICAgYnJlYWRMaXN0LnB1c2goeyBjbmFtZTogXCLkuLvpobVcIiwgbmFtZTogXCJkYXNoYm9hcmRcIiB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxldCB2YWwgPSBhbGxSb3V0ZXJzLmZpbmQoKHYpID0+IHYubmFtZSA9PT0gaXRlbSk7XHJcbiAgICAgIGlmICh2YWwpIHtcclxuICAgICAgICBicmVhZExpc3QucHVzaCh7XHJcbiAgICAgICAgICBjbmFtZTogdmFsLm1ldGEubmFtZSxcclxuICAgICAgICAgIG5hbWU6IHZhbC5uYW1lLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmICh2YWwuY2hpbGRyZW4pIHtcclxuICAgICAgICAgIGxldCBtID0gdmFsLmNoaWxkcmVuLmZpbmQoKHYpID0+IHYubmFtZSA9PT0gcGF0aExpc3RbaW5kZXggKyAxXSk7XHJcbiAgICAgICAgICBpZiAobSkge1xyXG4gICAgICAgICAgICBicmVhZExpc3QucHVzaCh7XHJcbiAgICAgICAgICAgICAgY25hbWU6IG0ubWV0YS5uYW1lLFxyXG4gICAgICAgICAgICAgIG5hbWU6IG0ubmFtZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcbiAgaWYoYnJlYWRMaXN0Lmxlbmd0aCA+IDEpe1xyXG4gICAgbWVudUFjdGl2ZS52YWx1ZSA9IGJyZWFkTGlzdFsxXS5uYW1lXHJcbiAgfVxyXG4gIFxyXG59O1xyXG5jb25zb2xlLmxvZyhyb3V0ZXIuZ2V0Um91dGVzKCksJ+i3r+eUseS/oeaBry0tLS0nKVxyXG5jb25zb2xlLmxvZyhyb3V0ZXIsJ+i3r+eUsScpXHJcbmNvbnN0IGxlZnRNZW51TGlzdCA9IHJvdXRlci5nZXRSb3V0ZXMoKS5maW5kKFxyXG4gIChpdGVtKSA9PiBpdGVtLm5hbWUgPT09IFwiZGFzaGJvYXJkXCJcclxuKS5jaGlsZHJlbjtcclxuLy/lt6bkvqfoj5zljZXkvLjlsZVcclxuY29uc3QgaXNDb2xsYXBzZSA9IHJlZihmYWxzZSk7XHJcbi8v6aG26YOo6I+c5Y2VXHJcbmNvbnN0IGhlYWRlck1lbnVMaXN0ID0gcmVhY3RpdmUoW1xyXG4gIHtcclxuICAgIG5hbWU6XCLlhajlsY9cIixcclxuICAgIHZhbHVlOlwiZnVsbFwiXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcImdpdGh1YlwiLFxyXG4gICAgdmFsdWU6IFwiZ2l0aHViXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIueUqOaIt1wiLFxyXG4gICAgdmFsdWU6IFwidXNlclwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbmFtZTogXCLpgIDlh7pcIixcclxuICAgIHZhbHVlOiBcIm91dFwiLFxyXG4gIH0sXHJcbl0pO1xyXG5jb25zdCBoYW5kbGVPcGVuID0gKGtleSwga2V5UGF0aCkgPT4ge1xyXG4gIC8vIGNvbnNvbGUubG9nKGtleSwga2V5UGF0aCk7XHJcbn07XHJcbmNvbnN0IGhhbmRsZUNsb3NlID0gKGtleSwga2V5UGF0aCkgPT4ge1xyXG4gIC8vIGNvbnNvbGUubG9nKGtleSwga2V5UGF0aCk7XHJcbn07XHJcbmNvbnN0IHVuZm9sZCA9ICgpID0+IHtcclxuICBpc0NvbGxhcHNlLnZhbHVlID0gIWlzQ29sbGFwc2UudmFsdWU7XHJcbn07XHJcbmNvbnN0IGp1bXAgPSAodmFsKSA9PiB7XHJcbiAgcm91dGVyLnB1c2goeyBuYW1lOiB2YWwgfSk7XHJcbiAgLy8gZ2V0QnJlYWRMaXN0KHJvdXRlLnBhdGgsIHJvdXRlci5vcHRpb25zLnJvdXRlc1szXS5jaGlsZHJlbik7XHJcbn07XHJcbmNvbnN0IG91dExvZ2luID0gKHZhbCkgPT4ge1xyXG4gIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidG9rZW5cIik7XHJcbiAgcm91dGVyLnB1c2goeyBwYXRoOiBcIi9sb2dpblwiIH0pO1xyXG4gIHN0b3JlLmRpc3BhdGNoKCdjaGFuZ2VBc3luY1JvdXRlRmluaXNoJyxmYWxzZSk7XHJcbiAgY29uc29sZS5sb2coc3RvcmUuc3RhdGUucm9sZSwnPz8/P+mAgOWHuuWQjueahOaTjeS9nCcpXHJcbn07XHJcbmNvbnN0IEljb250byA9ICh2YWwpID0+IHtcclxuICBzd2l0Y2ggKHZhbCkge1xyXG4gICAgY2FzZSBcImdpdGh1YlwiOlxyXG4gICAgICB3aW5kb3cub3BlbihcImh0dHBzOi8vZ2l0aHViLmNvbS93anQxNjIyODY3OTMvd2VicGFjay0tLS12dWVcIik7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcIm91dFwiOlxyXG4gICAgICBvdXRMb2dpbigpO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgXCJmdWxsXCI6XHJcbiAgICBzY3JlZW5mdWxsLnRvZ2dsZSgpXHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcInVzZXJcIjpcclxuICAgIGRpYWxvZ1VzZXJJbmZvVmlzaWJsZS52YWx1ZSA9IHRydWVcclxuICAgIHVzZXJJbmZvLnZhbHVlID0gc3RvcmUuc3RhdGUudXNlci51c2VySW5mb1xyXG4gICAgYnJlYWtcclxuICB9XHJcbn07XHJcbmNvbnN0IGJyZWFkSnVtcCA9IChicmVhZE5hbWUpID0+IHtcclxuICBpZiAoYnJlYWROYW1lID09PSBcImRhc2hib2FyZFwiKSB7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChicmVhZE5hbWUgPT09IHJvdXRlLm5hbWUpIHtcclxuICAgIHJldHVybjtcclxuICB9IGVsc2Uge1xyXG4gICAgcm91dGVyLnB1c2goeyBuYW1lOiBicmVhZE5hbWUgfSk7XHJcbiAgfVxyXG59O1xyXG5jb25zdCBoYW5kbGVNZW51U2VsZWN0ID0gKG1lbnVWYWwpID0+IHtcclxuICBtZW51QWN0aXZlLnZhbHVlID0gbWVudVZhbDtcclxufTtcclxuY29uc3QganVtcE1vZGUgPSAobmFtZSkgPT4ge1xyXG4gIHJvdXRlci5wdXNoKHsgbmFtZTogbmFtZSB9KTtcclxufTtcclxubGV0IHRoZW1lTGlzdCA9IHJlZihbXHJcbiAge1xyXG4gICAgY29sb3I6JyM0MDllZmYnLFxyXG4gICAgdGhlbWU6J2JsdWUnXHJcbiAgfSxcclxuICB7XHJcbiAgICBjb2xvcjonI2JhN2RlNCcsXHJcbiAgICB0aGVtZToncHVycGxlJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgY29sb3I6JyM3MmExNWEnLFxyXG4gICAgdGhlbWU6J2dyZWVuJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgY29sb3I6JyNhNzI1MTMnLFxyXG4gICAgdGhlbWU6J3JlZCdcclxuICB9LFxyXG4gIHtcclxuICAgIGNvbG9yOicjNTM0NjY4JyxcclxuICAgIHRoZW1lOidkZWVwUHVycGxlJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgY29sb3I6JyMxMzA4OGEnLFxyXG4gICAgdGhlbWU6J2RlZXBCbHVlJ1xyXG4gIH0sXHJcbl0pXHJcbmNvbnN0IGNoYW5nZVRoZW1lID0gKGl0ZW0pPT57XHJcbiAgZG9jdW1lbnQuYm9keS5kYXRhc2V0LnRoZW1lID0gaXRlbS50aGVtZVxyXG4gIHRoZW1lLnZhbHVlID0gaXRlbS50aGVtZVxyXG4gIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0aGVtZScsaXRlbS50aGVtZSlcclxufVxyXG5jb25zdCBnZXRMaVN0eWxlID0gKGl0ZW0pPT57XHJcbiAgcmV0dXJue1xyXG4gICAgYmFja2dyb3VuZDppdGVtLmNvbG9yLFxyXG4gICAgd2lkdGg6aXRlbS50aGVtZSA9PT0gdGhlbWUudmFsdWU/JzQwcHgnOiczMHB4JyxcclxuICAgIGhlaWdodDppdGVtLnRoZW1lID09PSB0aGVtZS52YWx1ZT8nNDBweCc6JzMwcHgnLFxyXG4gICAgbWFyZ2luOicxMHB4JyxjdXJzb3I6J3BvaW50ZXInfVxyXG59XHJcbm9uTW91bnRlZCgoKSA9PiB7XHJcbiAgY29uc29sZS5sb2cocm91dGUsJ+i/m+WFpeS6hicpXHJcbiAgaWYgKHJvdXRlLnBhdGggPT09IFwiL2Rhc2hib2FyZFwiKSB7XHJcbiAgICBsZXQgZGVmYXVsdFJvdXRlID0gIHN0b3JlLnN0YXRlLnJvbGUuZmlsdGVyQXN5bmNSb3V0ZXMuZmluZChpdGVtPT5pdGVtLm5hbWUgPT09ICdkYXNoYm9hcmQnKS5jaGlsZHJlblswXS5wYXRoXHJcbiAgICAgICBjb25zb2xlLmxvZyhkZWZhdWx0Um91dGUsJ+iHquWKqOWMuemFjeWtkOi3r+eUsScpXHJcbiAgICAgICAgcm91dGVyLnB1c2goeyBwYXRoOiBkZWZhdWx0Um91dGUgfSk7XHJcbiAgICAgICAgbWVudUFjdGl2ZS52YWx1ZSA9IFwiYnVzaW5lc3NcIjtcclxuICB9IGVsc2Uge1xyXG4gICAgbWVudUFjdGl2ZS52YWx1ZSA9IHJvdXRlLm5hbWU7XHJcbiAgfVxyXG4gIGdldEJyZWFkTGlzdChyb3V0ZS5wYXRoLCByb3V0ZXIuZ2V0Um91dGVzKCkuZmluZChcclxuICAoaXRlbSkgPT4gaXRlbS5uYW1lID09PSBcImRhc2hib2FyZFwiXHJcbikuY2hpbGRyZW4pO1xyXG4gIHdhdGNoKFxyXG4gICAgKCkgPT4gcm91dGUucGF0aCxcclxuICAgIChuZXdWYWwsIG9sZFZhbCkgPT4ge1xyXG4gICAgICBnZXRCcmVhZExpc3QobmV3VmFsLCByb3V0ZXIuZ2V0Um91dGVzKCkuZmluZChpdGVtPT5pdGVtLm5hbWUgPT09ICdkYXNoYm9hcmQnKS5jaGlsZHJlbik7XHJcbiAgICAgIGlmIChuZXdWYWwgPT09IFwiL2Rhc2hib2FyZFwiKSB7XHJcbiAgICAgICBsZXQgZGVmYXVsdFJvdXRlID0gIHN0b3JlLnN0YXRlLnJvbGUuZmlsdGVyQXN5bmNSb3V0ZXMuZmluZChpdGVtPT5pdGVtLm5hbWUgPT09ICdkYXNoYm9hcmQnKS5jaGlsZHJlblswXS5wYXRoXHJcbiAgICAgICBjb25zb2xlLmxvZyhkZWZhdWx0Um91dGUsJ+iHquWKqOWMuemFjeWtkOi3r+eUsScpXHJcbiAgICAgICAgcm91dGVyLnB1c2goeyBwYXRoOiBkZWZhdWx0Um91dGUgfSk7XHJcbiAgICAgICAgbWVudUFjdGl2ZS52YWx1ZSA9IFwiYnVzaW5lc3NcIjtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcbn0pO1xyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZSBsYW5nPVwibGVzc1wiIHNjb3BlZD5cclxuLmxheW91dCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGhlaWdodDogMTAwdmg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC5sYXlvdXRIZWFkZXIge1xyXG4gICAgY29sb3I6IHZhcigtLXRleHQtY29sb3IxKTtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBib3JkZXItYm90dG9tOiB2YXIoLS1ib3JkZXItY29sb3IyKSAxcHggc29saWQ7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIC8vIGJhY2tncm91bmQ6IGNoYXJ0cmV1c2U7XHJcbiAgICBoMSB7XHJcbiAgICAgIHdpZHRoOiAyMDBweDtcclxuICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDEwMHB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMyk7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLWJhY2tyb3VuZC1jb2xvcjUpO1xyXG4gICAgfVxyXG4gICAgLmhlYWRlck1lbnUge1xyXG4gICAgICBmbGV4OiAxO1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIC5oZWFkZXJJbWcge1xyXG4gICAgICAgIG1hcmdpbjogMHB4IDE1cHg7XHJcbiAgICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAubGF5b3V0Qm9keSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1ncm93OiAxO1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICAvLyAubGVmdE1lbnUge1xyXG4gICAgLy8gICAvLyB3aWR0aDogMjAwcHg7IC8qIOiuvue9ruW3puS+p+i+ueagj+WuveW6piAqL1xyXG4gICAgLy8gICB0cmFuc2l0aW9uOiB3aWR0aCAwLjJzO1xyXG4gICAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1iYWNrcm91bmQtY29sb3I2KTtcclxuICAgIC8vICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgLy8gICAuTGVmdEJ0biB7XHJcbiAgICAvLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgLy8gICAgIGJvdHRvbTogMTBweDtcclxuICAgIC8vICAgICByaWdodDogMTBweDtcclxuICAgIC8vICAgfVxyXG4gICAgLy8gfVxyXG4gICAgLmNvbnRlbnQge1xyXG4gICAgICBvdmVyZmxvdzogYXV0bztcclxuICAgICAgZmxleC1ncm93OiAxOyAvKiDlj7PkvqflhoXlrrnljLroh6rpgILlupTlrr3luqYgKi9cclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgcGFkZGluZzogMjBweDtcclxuICAgICAgcGFkZGluZy10b3A6IDYwcHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjMpO1xyXG4gICAgICAuYnJlYWRDcnVtYiB7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHRvcDogMjBweDtcclxuICAgICAgICBsZWZ0OiAyMHB4O1xyXG4gICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyA6OnYtZGVlcCgpIC5lbC1icmVhZGNydW1iX19pbm5lciB7XHJcbiAgICAgICAgLy8gICBjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyA6OnYtZGVlcCgpIC5lbC1icmVhZGNydW1iX19zZXBhcmF0b3Ige1xyXG4gICAgICAgIC8vICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcclxuICAgICAgICAvLyB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuLy8gLmVsLW1lbnUge1xyXG4vLyAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuLy8gfVxyXG4uZWwtbWVudS12ZXJ0aWNhbC1kZW1vOm5vdCguZWwtbWVudS0tY29sbGFwc2UpIHtcclxuICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gIHdpZHRoOiAyMDBweCAhaW1wb3J0YW50O1xyXG4gIG1pbi1oZWlnaHQ6IDQwMHB4O1xyXG59XHJcbjo6di1kZWVwKC5lbC1tZW51KSAge1xyXG4gIGJvcmRlci1yaWdodDogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcbi5tZW51SWNvbiB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGxlZnQ6IDI1cHg7XHJcbiAgYm90dG9tOiAyMHB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4ubGVmdE1lbnVJbWcge1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGhlaWdodDogMjBweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG59XHJcbi5yb3dMaXN0e1xyXG4gIHBhZGRpbmc6IDE2cHg7XHJcbiAgLnJvd3tcclxuICAgIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbiAgICBoNHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgfVxyXG4gIH1cclxuXHJcbn1cclxuPC9zdHlsZT5cclxuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MzYzYTU1NDMmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2luZGV4LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTM2M2E1NTQzJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsImltcG9ydCB7IHJlbmRlciB9IGZyb20gXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0zNjNhNTU0MyZzY29wZWQ9dHJ1ZVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcblxuaW1wb3J0IFwiLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0zNjNhNTU0MyZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCJEOlxcXFzpobnnm65cXFxcd2VicGFjay12dWVcXFxcd2VicGFjay0tLS12dWVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1sb2FkZXJcXFxcZGlzdFxcXFxleHBvcnRIZWxwZXIuanNcIlxuY29uc3QgX19leHBvcnRzX18gPSAvKiNfX1BVUkVfXyovZXhwb3J0Q29tcG9uZW50KHNjcmlwdCwgW1sncmVuZGVyJyxyZW5kZXJdLFsnX19zY29wZUlkJyxcImRhdGEtdi0zNjNhNTU0M1wiXSxbJ19fZmlsZScsXCJzcmMvcGFnZXMvZGFzaGJvYXJkL2luZGV4LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIzNjNhNTU0M1wiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzM2M2E1NTQzJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMzYzYTU1NDMnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0zNjNhNTU0MyZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCczNjNhNTU0MycsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9pbmRleC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbNF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0zNjNhNTU0MyZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MzYzYTU1NDMmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiLCJ2YXIgbWFwID0ge1xuXHRcIi4vZ2l0aHViLnN2Z1wiOiAyMDAwMixcblx0XCIuL+S4muWKoemihuWfny5zdmdcIjogNDY1NzgsXG5cdFwiLi/kuLvpopjoibIuc3ZnXCI6IDEzODIzLFxuXHRcIi4v5Lu35YC85rWBLnN2Z1wiOiA5OTM5MCxcblx0XCIuL+S7u+WKoeeuoeeQhi5zdmdcIjogNTYwNjksXG5cdFwiLi/lhajlsY8uc3ZnXCI6IDY4NjMxLFxuXHRcIi4v5a6e5L2TLnN2Z1wiOiA4MTc4NSxcblx0XCIuL+aWh+acrOe8lui+kS5zdmdcIjogMTgyNjYsXG5cdFwiLi/mnYPpmZDnrqHnkIYuc3ZnXCI6IDQ0NzYxLFxuXHRcIi4v5rWB56iL5Zu+LnN2Z1wiOiA0MDczLFxuXHRcIi4v55So5oi3LnN2Z1wiOiA4MjIyNyxcblx0XCIuL+e7n+iuoeWbvuihqC5zdmdcIjogMTE0NDcsXG5cdFwiLi/oj5zljZUuc3ZnXCI6IDU3NjMzLFxuXHRcIi4v6LWE5Lqn57uf6K6hLnN2Z1wiOiA3MTA2Nixcblx0XCIuL+mAgOWHui5zdmdcIjogMTA1MjAsXG5cdFwiLi/pgq7ku7Yuc3ZnXCI6IDQzMzE4LFxuXHRcIi4v6aOO6Zmp566h55CGLnN2Z1wiOiA2NTAzMVxufTtcblxuXG5mdW5jdGlvbiB3ZWJwYWNrQ29udGV4dChyZXEpIHtcblx0dmFyIGlkID0gd2VicGFja0NvbnRleHRSZXNvbHZlKHJlcSk7XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKGlkKTtcbn1cbmZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0UmVzb2x2ZShyZXEpIHtcblx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhtYXAsIHJlcSkpIHtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0cmV0dXJuIG1hcFtyZXFdO1xufVxud2VicGFja0NvbnRleHQua2V5cyA9IGZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0S2V5cygpIHtcblx0cmV0dXJuIE9iamVjdC5rZXlzKG1hcCk7XG59O1xud2VicGFja0NvbnRleHQucmVzb2x2ZSA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZTtcbm1vZHVsZS5leHBvcnRzID0gd2VicGFja0NvbnRleHQ7XG53ZWJwYWNrQ29udGV4dC5pZCA9IDkyNDk4OyJdLCJuYW1lcyI6WyJfaW1wb3J0c18wIiwiX2NyZWF0ZUVsZW1lbnRWTm9kZSIsInN0eWxlIiwiX2hvaXN0ZWRfMSIsIl9jcmVhdGVDb21tZW50Vk5vZGUiLCJfaG9pc3RlZF8yIiwiX2hvaXN0ZWRfMyIsIl9ob2lzdGVkXzQiLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCIkc2V0dXAiLCJoZWFkZXJNZW51TGlzdCIsIml0ZW0iLCJpbmRleCIsInNyYyIsInJlcXVpcmUiLCJjb25jYXQiLCJuYW1lIiwiYWx0Iiwia2V5Iiwib25DbGljayIsIiRldmVudCIsIkljb250byIsInZhbHVlIiwiX2hvaXN0ZWRfNiIsIl9jcmVhdGVWTm9kZSIsIl9jb21wb25lbnRfZWxfbWVudSIsIm1lbnVBY3RpdmUiLCJjb2xsYXBzZSIsImlzQ29sbGFwc2UiLCJvbk9wZW4iLCJoYW5kbGVPcGVuIiwib25DbG9zZSIsImhhbmRsZUNsb3NlIiwib25TZWxlY3QiLCJoYW5kbGVNZW51U2VsZWN0Iiwicm91dGVyIiwibGVmdE1lbnVMaXN0IiwiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF9lbF9tZW51X2l0ZW0iLCJqdW1wTW9kZSIsIm1ldGEiLCJfdG9EaXNwbGF5U3RyaW5nIiwiX2hvaXN0ZWRfOCIsIl9jb21wb25lbnRfZWxfYnJlYWRjcnVtYiIsInNlcGFyYXRvciIsImJyZWFkTGlzdCIsIl9jb21wb25lbnRfZWxfYnJlYWRjcnVtYl9pdGVtIiwiYnJlYWRKdW1wIiwiY25hbWUiLCJfaG9pc3RlZF85IiwiX2NvbXBvbmVudF9yb3V0ZXJfdmlldyIsInVuZm9sZCIsIl9jb21wb25lbnRfZWxfZGlhbG9nIiwiZGlhbG9nVXNlckluZm9WaXNpYmxlIiwidGl0bGUiLCJ3aWR0aCIsIl9ob2lzdGVkXzEwIiwiX2NvbXBvbmVudF9lbF9yb3ciLCJfY29tcG9uZW50X2VsX2NvbCIsInNwYW4iLCJfaG9pc3RlZF8xMSIsInVzZXJJbmZvIiwidXNlck5hbWUiLCJfaG9pc3RlZF8xMiIsIl9ob2lzdGVkXzEzIiwicm9sZSIsIl9ob2lzdGVkXzE0IiwiX2hvaXN0ZWRfMTUiLCJ0aGVtZUxpc3QiLCJfbm9ybWFsaXplU3R5bGUiLCJnZXRMaVN0eWxlIiwiY2hhbmdlVGhlbWUiXSwic291cmNlUm9vdCI6IiJ9