"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_login_index_vue"],{

/***/ 56580:
/*!************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/login/index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".box[data-v-247e7dd8] {\n  background-image: linear-gradient(#f1f0f0, #fff);\n  position: relative;\n}\n.box .content .img[data-v-247e7dd8] {\n  width: 100vw;\n  height: 100vh;\n}\n.box .content .title[data-v-247e7dd8] {\n  margin: 10px 0 40px;\n  text-align: center;\n  color: var(--text-color3);\n  font-size: 18px;\n}\n.box .content .loginForm[data-v-247e7dd8] {\n  position: absolute;\n  right: 30px;\n  top: 200px;\n  width: 400px;\n  height: 300px;\n  background: #fff;\n}\n.box[data-v-247e7dd8] .el-form-item__content {\n  margin-left: 40px !important;\n}\n.box[data-v-247e7dd8] .el-input {\n  width: 330px !important;\n}\n[data-v-247e7dd8] .el-form-item__label {\n  width: 100px !important;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/login/index.vue","webpack://./index.vue"],"names":[],"mappings":"AACA;EACE,gDAAA;EACA,kBAAA;ACAF;ADFA;EAKM,YAAA;EACA,aAAA;ACAN;ADNA;EASM,mBAAA;EACA,kBAAA;EACA,yBAAA;EACA,eAAA;ACAN;ADZA;EAeM,kBAAA;EACA,WAAA;EACA,UAAA;EACA,YAAA;EACA,aAAA;EACA,gBAAA;ACAN;ADpBA;EA6BI,4BAAA;ACNJ;ADvBA;EAgCI,uBAAA;ACNJ;ADSA;EACE,uBAAA;ACPF","sourcesContent":["\n.box {\n  background-image: linear-gradient(#f1f0f0, #fff);\n  position: relative;\n  .content {\n    .img {\n      width: 100vw;\n      height: 100vh;\n    }\n    .title {\n      margin: 10px 0 40px;\n      text-align: center;\n      color: var(--text-color3);\n      font-size: 18px;\n    }\n    .loginForm {\n      position: absolute;\n      right: 30px;\n      top: 200px;\n      width: 400px;\n      height: 300px;\n      background: #fff;\n      .footer {\n        // padding-left: 50px;\n        .btn {\n        }\n      }\n    }\n  }\n  ::v-deep(.el-form-item__content) {\n    margin-left: 40px !important;\n  }\n  ::v-deep(.el-input) {\n    width: 330px !important;\n  }\n}\n::v-deep(.el-form-item__label) {\n  width: 100px !important;\n}\n",".box {\n  background-image: linear-gradient(#f1f0f0, #fff);\n  position: relative;\n}\n.box .content .img {\n  width: 100vw;\n  height: 100vh;\n}\n.box .content .title {\n  margin: 10px 0 40px;\n  text-align: center;\n  color: var(--text-color3);\n  font-size: 18px;\n}\n.box .content .loginForm {\n  position: absolute;\n  right: 30px;\n  top: 200px;\n  width: 400px;\n  height: 300px;\n  background: #fff;\n}\n.box ::v-deep(.el-form-item__content) {\n  margin-left: 40px !important;\n}\n.box ::v-deep(.el-input) {\n  width: 330px !important;\n}\n::v-deep(.el-form-item__label) {\n  width: 100px !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 38924:
/*!*********************************************!*\
  !*** ./src/pages/login/disposePermisson.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getRolePermission": () => (/* binding */ getRolePermission),
/* harmony export */   "loginSuccessDone": () => (/* binding */ loginSuccessDone)
/* harmony export */ });
/* harmony import */ var _router_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/router/index */ 41671);
/* harmony import */ var _router_asyncRoutes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/router/asyncRoutes */ 2825);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/store/index */ 28360);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ 53059);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/javascript/envname */ 78353);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }






var flatFun = function flatFun(alllist) {
  var List = [];
  alllist.forEach(function (item, index) {
    var newObj = {};
    newObj.path = item.path;
    newObj.name = item.name;
    newObj.meta = item.meta;
    newObj.component = item.component;
    List.push(newObj);
    if (item.children && item.children.length > 0) {
      console.log(item.children, 'children===');
      List = List.concat(flatFun(item.children));
    }
  });
  return List;
};
var getRolePermission = function getRolePermission(menuPermissionList, asyncRouteList, next, to) {
  var allAsyncRoutesList = (0,lodash__WEBPACK_IMPORTED_MODULE_4__.cloneDeep)(asyncRouteList);
  console.log(menuPermissionList, '菜单权限');
  console.log(allAsyncRoutesList, '全部路由');
  var flatRouteList = flatFun(allAsyncRoutesList);
  console.log(flatRouteList, '扁平化后的路由');
  // flatRouteList.forEach(item=>{
  //     router.addRoute(item)
  // })
  var filterRoute = [];
  flatRouteList.forEach(function (Item) {
    if (menuPermissionList.findIndex(function (item) {
      return item.name === Item.name;
    }) !== -1) {
      filterRoute.push(Item);
    }
  });
  filterRoute.forEach(function (item) {
    _router_index__WEBPACK_IMPORTED_MODULE_0__["default"].addRoute(item);
  });
  console.log(_router_index__WEBPACK_IMPORTED_MODULE_0__["default"].getRoutes(), '得到的路由');
  _store_index__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch('changeAsyncRouteFinish', true);
  if (next && to) {
    next(_objectSpread(_objectSpread({}, to), {}, {
      replace: true
    }));
  }
};
var loginSuccessDone = function loginSuccessDone(userInfo, next, to) {
  localStorage.setItem("userInfo", JSON.stringify(userInfo));
  localStorage.setItem("token", userInfo.token);
  _store_index__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch("changeUserInfo", userInfo);
  //  getRolePermission()
  _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_5__.envname.apiUrl, "/app/userRole/roleList")).then(function (res) {
    if (res.code === 200) {
      var roleList = res.data;
      console.log(roleList, '权限数据');
      var userRole = roleList.find(function (item) {
        return item.name === userInfo.role;
      });
      var menuPermissionList = userRole['menuName'];
      _store_index__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch("changeRolePermission", userRole);
      _store_index__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch("changeMenuPermissionList", menuPermissionList);
      getRolePermission(menuPermissionList, _router_asyncRoutes__WEBPACK_IMPORTED_MODULE_1__.asyncRoutes, next, to);
    }
  });
  console.log(_store_index__WEBPACK_IMPORTED_MODULE_2__["default"], 'store的操作');
  _router_index__WEBPACK_IMPORTED_MODULE_0__["default"].push({
    path: "/dashboard"
  });
};

/***/ }),

/***/ 3219:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/login/index.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/store */ 28360);
/* harmony import */ var _disposePermisson__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./disposePermisson */ 38924);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: "login",
  data: function data() {
    return {
      formSize: "default",
      ruleForm: {
        name: "admin123",
        password: "admin123"
      },
      rules: {
        name: [{
          required: true,
          message: "请输入账号",
          trigger: "blur"
        }, {
          min: 6,
          message: "账号至少为6位数",
          trigger: "blur"
        }],
        password: [{
          required: true,
          message: "请输入密码",
          trigger: "blur"
        }, {
          min: 6,
          message: "密码至少为6位数",
          trigger: "blur"
        }]
      },
      dialogRules: {
        userName: [{
          required: true,
          message: "请输入账号",
          trigger: "blur"
        }, {
          pattern: /[\u4e00-\u9fa50-9]*$/,
          message: "只可以输入中文和数字",
          trigger: "blur"
        }],
        name: [{
          required: true,
          message: "请输入账号",
          trigger: "blur"
        }, {
          min: 6,
          message: "账号至少为6位数",
          trigger: "blur"
        }],
        password: [{
          required: true,
          message: "请输入密码",
          trigger: "blur"
        }, {
          min: 6,
          message: "密码至少为6位数",
          trigger: "blur"
        }],
        verifyPassword: [{
          required: true,
          message: "请再次输入密码",
          trigger: "blur"
        }, {
          min: 6,
          message: "密码至少为6位数",
          trigger: "blur"
        }]
      },
      dialogTitle: "注册用户",
      dialogFormVisible: false,
      formLabelWidth: "240px",
      firstPassword: "",
      secondPassword: "",
      doneFlag: "register",
      form: {
        userName: "",
        name: "",
        password: "",
        verifyPassword: ""
      },
      autoLogin: false
    };
  },
  created: function created() {
    if (localStorage.getItem("autoLogin")) {
      if (localStorage.getItem("autoLogin") == "true") {
        this.changeCheck(true);
      } else if (localStorage.getItem("autoLogin") == "false") {
        this.changeCheck(false);
      }
    } else {
      localStorage.setItem("autoLogin", this.autoLogin);
    }
  },
  methods: {
    //登录
    submitForm: function submitForm() {
      var _this = this;
      this.$refs.ruleFormRef.validate(function (valid, fields) {
        if (valid) {
          console.log(_this.ruleForm, "登录信息");
          _this.$axios.post("app/user/login", _this.ruleForm).then(function (res) {
            console.log(res, "登录返回结果");
            if (res.code === 200) {
              // loginSuccessDone(res.data)
              localStorage.setItem("userInfo", JSON.stringify(res.data));
              localStorage.setItem("token", res.data.token);
              _this.$store.dispatch("changeUserInfo", res.data);
              _this.$router.push({
                path: "/dashboard"
              });
            } else if (res.code === 201) {
              _this.$message.error(res.message);
            }
          });
        } else {
          console.log("error submit!", fields);
        }
      });
    },
    //注册 or 修改密码
    done: function done() {
      var _this2 = this;
      var url = "";
      if (this.doneFlag === "register") {
        url = "".concat(envname.apiUrl, "/app/register/query");
      } else if (this.doneFlag === "change") {
        url = "".concat(envname.apiUrl, "/app/user/updatePassword");
      }
      this.$refs.dialogForm.validate(function (valid, fields) {
        if (valid) {
          if (_this2.form.password !== _this2.form.verifyPassword) {
            _this2.$message.warning("密码和确认密码不一致,请重新输入");
            return;
          }
          var queryData = {
            userName: _this2.form.userName,
            name: _this2.form.name,
            password: _this2.form.password,
            role: "code"
          };
          _this2.$axios.post(url, queryData).then(function (res) {
            if (res.code === 200) {
              _this2.$message.success(res.message);
              _this2.closeDialog();
            } else if (res.code === 201) {
              _this2.$message.error(res.message);
            }
          });
        } else {
          console.log("error submit!", fields);
        }
      });
    },
    //关闭弹框
    closeDialog: function closeDialog() {
      this.dialogFormVisible = false;
      this.form = {
        userName: "",
        name: "",
        password: "",
        verifyPassword: ""
      };
    },
    //打开弹框
    dialogOpen: function dialogOpen(flag) {
      this.dialogFormVisible = true;
      this.doneFlag = flag;
      if (flag === "register") {
        this.dialogTitle = "注册用户";
        this.firstPassword = "密码";
        this.secondPassword = "确认密码";
      } else {
        this.dialogTitle = "修改密码";
        this.firstPassword = "新密码";
        this.secondPassword = "确认密码";
      }
    },
    //修改自动登录
    changeCheck: function changeCheck(val) {
      this.autoLogin = val;
      console.log(this.autoLogin, "自动登录标识");
      localStorage.setItem("autoLogin", this.autoLogin);
    }
  }
});

/***/ }),

/***/ 84037:
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/login/index.vue?vue&type=template&id=247e7dd8&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var _assets_loginBack_jpg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/loginBack.jpg */ 83118);


var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-247e7dd8"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "box"
};
var _hoisted_2 = {
  "class": "content"
};
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_loginBack_jpg__WEBPACK_IMPORTED_MODULE_1__,
    "class": "img",
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_4 = {
  "class": "loginForm"
};
var _hoisted_5 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
    "class": "title"
  }, "欢迎登录", -1 /* HOISTED */);
});
var _hoisted_6 = {
  "class": "footer"
};
var _hoisted_7 = {
  "class": "dialog-footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_form_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form-item");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [_hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [_hoisted_5, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
    ref: "ruleFormRef",
    model: $data.ruleForm,
    rules: $data.rules,
    "label-width": "120px",
    "class": "demo-ruleForm",
    size: $data.formSize,
    "status-icon": ""
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
        prop: "name"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
            modelValue: $data.ruleForm.name,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
              return $data.ruleForm.name = $event;
            }),
            placeholder: "请输入账号",
            clearable: ""
          }, null, 8 /* PROPS */, ["modelValue"])];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
        prop: "password"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
            modelValue: $data.ruleForm.password,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
              return $data.ruleForm.password = $event;
            }),
            placeholder: "请输入密码",
            type: "password",
            "show-password": "",
            clearable: ""
          }, null, 8 /* PROPS */, ["modelValue"])];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            onClick: _cache[2] || (_cache[2] = function ($event) {
              return $options.submitForm();
            }),
            "class": "btn"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 登录 ")];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            onClick: _cache[3] || (_cache[3] = function ($event) {
              return $options.dialogOpen('register');
            }),
            "class": "btn"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 注册 ")];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            onClick: _cache[4] || (_cache[4] = function ($event) {
              return $options.dialogOpen('change');
            }),
            "class": "btn"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 修改密码 ")];
            }),
            _: 1 /* STABLE */
          })])];
        }),

        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["model", "rules", "size"])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_dialog, {
    modelValue: $data.dialogFormVisible,
    "onUpdate:modelValue": _cache[9] || (_cache[9] = function ($event) {
      return $data.dialogFormVisible = $event;
    }),
    title: $data.dialogTitle,
    width: "550"
  }, {
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_7, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: $options.closeDialog
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["onClick"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        type: "primary",
        onClick: $options.done,
        style: {
          "margin-right": "40px"
        }
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 确定 ")];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["onClick"])])];
    }),
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
        model: $data.form,
        ref: "dialogForm",
        rules: $data.dialogRules
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "姓名",
            "label-width": $data.formLabelWidth,
            prop: "userName"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $data.form.userName,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
                  return $data.form.userName = $event;
                }),
                autocomplete: "off",
                clearable: ""
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["label-width"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "账号",
            "label-width": $data.formLabelWidth,
            prop: "name"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $data.form.name,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = function ($event) {
                  return $data.form.name = $event;
                }),
                autocomplete: "off",
                clearable: ""
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["label-width"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: $data.firstPassword,
            "label-width": $data.formLabelWidth,
            prop: "password"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $data.form.password,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = function ($event) {
                  return $data.form.password = $event;
                }),
                autocomplete: "off",
                type: "password",
                "show-password": "",
                clearable: ""
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["label", "label-width"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: $data.secondPassword,
            "label-width": $data.formLabelWidth,
            prop: "verifyPassword"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $data.form.verifyPassword,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = function ($event) {
                  return $data.form.verifyPassword = $event;
                }),
                autocomplete: "off",
                type: "password",
                "show-password": "",
                clearable: ""
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }, 8 /* PROPS */, ["label", "label-width"])];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["model", "rules"])];
    }),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue", "title"])]);
}

/***/ }),

/***/ 50871:
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/login/index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true */ 56580);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 35924:
/*!***********************************!*\
  !*** ./src/pages/login/index.vue ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_247e7dd8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=247e7dd8&scoped=true */ 36629);
/* harmony import */ var _index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&lang=js */ 17089);
/* harmony import */ var _index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true */ 35013);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_index_vue_vue_type_template_id_247e7dd8_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-247e7dd8"],['__file',"src/pages/login/index.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 17089:
/*!***********************************************************!*\
  !*** ./src/pages/login/index.vue?vue&type=script&lang=js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=script&lang=js */ 3219);
 

/***/ }),

/***/ 36629:
/*!*****************************************************************************!*\
  !*** ./src/pages/login/index.vue?vue&type=template&id=247e7dd8&scoped=true ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_247e7dd8_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_247e7dd8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=template&id=247e7dd8&scoped=true */ 84037);


/***/ }),

/***/ 35013:
/*!********************************************************************************************!*\
  !*** ./src/pages/login/index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_247e7dd8_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=247e7dd8&lang=less&scoped=true */ 50871);


/***/ }),

/***/ 83118:
/*!**********************************!*\
  !*** ./src/assets/loginBack.jpg ***!
  \**********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "b3f6c1d3fa8a28658d90.jpg";

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2xvZ2luX2luZGV4X3Z1ZS4yMGM4OWMzZjBhNTc5NzRlYjAxNy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxpRUFBaUUscURBQXFELHVCQUF1QixHQUFHLHVDQUF1QyxpQkFBaUIsa0JBQWtCLEdBQUcseUNBQXlDLHdCQUF3Qix1QkFBdUIsOEJBQThCLG9CQUFvQixHQUFHLDZDQUE2Qyx1QkFBdUIsZ0JBQWdCLGVBQWUsaUJBQWlCLGtCQUFrQixxQkFBcUIsR0FBRyxnREFBZ0QsaUNBQWlDLEdBQUcsbUNBQW1DLDRCQUE0QixHQUFHLDBDQUEwQyw0QkFBNEIsR0FBRyxTQUFTLG9IQUFvSCxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUssV0FBVyxXQUFXLFdBQVcsVUFBVSxLQUFLLEtBQUssV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsS0FBSyxNQUFNLFlBQVksS0FBSyxNQUFNLFlBQVksS0FBSyxLQUFLLFdBQVcsaUNBQWlDLHFEQUFxRCx1QkFBdUIsY0FBYyxZQUFZLHFCQUFxQixzQkFBc0IsT0FBTyxjQUFjLDRCQUE0QiwyQkFBMkIsa0NBQWtDLHdCQUF3QixPQUFPLGtCQUFrQiwyQkFBMkIsb0JBQW9CLG1CQUFtQixxQkFBcUIsc0JBQXNCLHlCQUF5QixpQkFBaUIsZ0NBQWdDLGdCQUFnQixXQUFXLFNBQVMsT0FBTyxLQUFLLHNDQUFzQyxtQ0FBbUMsS0FBSyx5QkFBeUIsOEJBQThCLEtBQUssR0FBRyxrQ0FBa0MsNEJBQTRCLEdBQUcsV0FBVyxxREFBcUQsdUJBQXVCLEdBQUcsc0JBQXNCLGlCQUFpQixrQkFBa0IsR0FBRyx3QkFBd0Isd0JBQXdCLHVCQUF1Qiw4QkFBOEIsb0JBQW9CLEdBQUcsNEJBQTRCLHVCQUF1QixnQkFBZ0IsZUFBZSxpQkFBaUIsa0JBQWtCLHFCQUFxQixHQUFHLHlDQUF5QyxpQ0FBaUMsR0FBRyw0QkFBNEIsNEJBQTRCLEdBQUcsa0NBQWtDLDRCQUE0QixHQUFHLHFCQUFxQjtBQUMzOUU7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQSjtBQUNnQjtBQUNsQjtBQUNVO0FBQ1I7QUFDWTtBQUMvQyxJQUFJTSxPQUFPLEdBQUcsU0FBVkEsT0FBT0EsQ0FBSUMsT0FBTyxFQUFLO0VBQ3pCLElBQUlDLElBQUksR0FBRyxFQUFFO0VBQ2JELE9BQU8sQ0FBQ0UsT0FBTyxDQUFDLFVBQUNDLElBQUksRUFBRUMsS0FBSyxFQUFLO0lBQy9CLElBQUlDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDZkEsTUFBTSxDQUFDQyxJQUFJLEdBQUdILElBQUksQ0FBQ0csSUFBSTtJQUN2QkQsTUFBTSxDQUFDRSxJQUFJLEdBQUdKLElBQUksQ0FBQ0ksSUFBSTtJQUN2QkYsTUFBTSxDQUFDRyxJQUFJLEdBQUdMLElBQUksQ0FBQ0ssSUFBSTtJQUN2QkgsTUFBTSxDQUFDSSxTQUFTLEdBQUdOLElBQUksQ0FBQ00sU0FBUztJQUNqQ1IsSUFBSSxDQUFDUyxJQUFJLENBQUNMLE1BQU0sQ0FBQztJQUNqQixJQUFJRixJQUFJLENBQUNRLFFBQVEsSUFBSVIsSUFBSSxDQUFDUSxRQUFRLENBQUNDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDN0NDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDWCxJQUFJLENBQUNRLFFBQVEsRUFBRSxhQUFhLENBQUM7TUFDekNWLElBQUksR0FBR0EsSUFBSSxDQUFDYyxNQUFNLENBQUNoQixPQUFPLENBQUNJLElBQUksQ0FBQ1EsUUFBUSxDQUFDLENBQUM7SUFDNUM7RUFDRixDQUFDLENBQUM7RUFDRixPQUFPVixJQUFJO0FBQ2IsQ0FBQztBQUVNLElBQUllLGlCQUFpQixHQUFHLFNBQXBCQSxpQkFBaUJBLENBQUlDLGtCQUFrQixFQUFFQyxjQUFjLEVBQUVDLElBQUksRUFBRUMsRUFBRSxFQUFLO0VBQy9FLElBQUlDLGtCQUFrQixHQUFHeEIsaURBQVMsQ0FBQ3FCLGNBQWMsQ0FBQztFQUNsREwsT0FBTyxDQUFDQyxHQUFHLENBQUNHLGtCQUFrQixFQUFFLE1BQU0sQ0FBQztFQUN2Q0osT0FBTyxDQUFDQyxHQUFHLENBQUNPLGtCQUFrQixFQUFFLE1BQU0sQ0FBQztFQUV2QyxJQUFJQyxhQUFhLEdBQUd2QixPQUFPLENBQUNzQixrQkFBa0IsQ0FBQztFQUMvQ1IsT0FBTyxDQUFDQyxHQUFHLENBQUNRLGFBQWEsRUFBRSxTQUFTLENBQUM7RUFDckM7RUFDQTtFQUNBO0VBQ0EsSUFBSUMsV0FBVyxHQUFHLEVBQUU7RUFDcEJELGFBQWEsQ0FBQ3BCLE9BQU8sQ0FBQyxVQUFBc0IsSUFBSSxFQUFJO0lBQzVCLElBQUlQLGtCQUFrQixDQUFDUSxTQUFTLENBQUMsVUFBQXRCLElBQUk7TUFBQSxPQUFJQSxJQUFJLENBQUNJLElBQUksS0FBS2lCLElBQUksQ0FBQ2pCLElBQUk7SUFBQSxFQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7TUFDeEVnQixXQUFXLENBQUNiLElBQUksQ0FBQ2MsSUFBSSxDQUFDO0lBQ3hCO0VBQ0YsQ0FBQyxDQUFDO0VBQ0ZELFdBQVcsQ0FBQ3JCLE9BQU8sQ0FBQyxVQUFBQyxJQUFJLEVBQUk7SUFDMUJWLDhEQUFlLENBQUNVLElBQUksQ0FBQztFQUN2QixDQUFDLENBQUM7RUFDRlUsT0FBTyxDQUFDQyxHQUFHLENBQUNyQiwrREFBZ0IsRUFBRSxFQUFFLE9BQU8sQ0FBQztFQUN4Q0UsNkRBQWMsQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUM7RUFDOUMsSUFBSXdCLElBQUksSUFBSUMsRUFBRSxFQUFFO0lBQ2RELElBQUksQ0FBQVUsYUFBQSxDQUFBQSxhQUFBLEtBQU1ULEVBQUU7TUFBRVUsT0FBTyxFQUFFO0lBQUksR0FBRztFQUNoQztBQUVGLENBQUM7QUFFTSxJQUFJQyxnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQWdCQSxDQUFJQyxRQUFRLEVBQUViLElBQUksRUFBRUMsRUFBRSxFQUFLO0VBQ3BEYSxZQUFZLENBQUNDLE9BQU8sQ0FBQyxVQUFVLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSixRQUFRLENBQUMsQ0FBQztFQUMxREMsWUFBWSxDQUFDQyxPQUFPLENBQUMsT0FBTyxFQUFFRixRQUFRLENBQUNLLEtBQUssQ0FBQztFQUM3QzFDLDZEQUFjLENBQUMsZ0JBQWdCLEVBQUVxQyxRQUFRLENBQUM7RUFDMUM7RUFDQXBDLCtEQUFXLElBQUFtQixNQUFBLENBQUlqQiwrREFBYyw0QkFBeUIsQ0FBQzBDLElBQUksQ0FBQyxVQUFBQyxHQUFHLEVBQUk7SUFDakUsSUFBSUEsR0FBRyxDQUFDQyxJQUFJLEtBQUssR0FBRyxFQUFFO01BQ3BCLElBQUlDLFFBQVEsR0FBR0YsR0FBRyxDQUFDRyxJQUFJO01BQ3ZCL0IsT0FBTyxDQUFDQyxHQUFHLENBQUM2QixRQUFRLEVBQUUsTUFBTSxDQUFDO01BQzdCLElBQUlFLFFBQVEsR0FBR0YsUUFBUSxDQUFDRyxJQUFJLENBQUMsVUFBQTNDLElBQUk7UUFBQSxPQUFJQSxJQUFJLENBQUNJLElBQUksS0FBS3lCLFFBQVEsQ0FBQ2UsSUFBSTtNQUFBLEVBQUM7TUFDakUsSUFBSTlCLGtCQUFrQixHQUFHNEIsUUFBUSxDQUFDLFVBQVUsQ0FBQztNQUM3Q2xELDZEQUFjLENBQUMsc0JBQXNCLEVBQUVrRCxRQUFRLENBQUM7TUFDaERsRCw2REFBYyxDQUFDLDBCQUEwQixFQUFFc0Isa0JBQWtCLENBQUM7TUFDOURELGlCQUFpQixDQUFDQyxrQkFBa0IsRUFBRXZCLDREQUFXLEVBQUV5QixJQUFJLEVBQUVDLEVBQUUsQ0FBQztJQUM5RDtFQUNGLENBQUMsQ0FBQztFQUNGUCxPQUFPLENBQUNDLEdBQUcsQ0FBQ25CLG9EQUFLLEVBQUUsVUFBVSxDQUFDO0VBQzlCRiwwREFBVyxDQUFDO0lBQ1ZhLElBQUksRUFBRTtFQUNSLENBQUMsQ0FBQztBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNpQzJCO0FBQzBCO0FBQ3RELGlFQUFlO0VBQ2JDLElBQUksRUFBRSxPQUFPO0VBQ2JxQyxJQUFJLFdBQUFBLEtBQUEsRUFBRztJQUNMLE9BQU87TUFDTEksUUFBUSxFQUFFLFNBQVM7TUFDbkJDLFFBQVEsRUFBRTtRQUNSMUMsSUFBSSxFQUFFLFVBQVU7UUFDaEIyQyxRQUFRLEVBQUU7TUFDWixDQUFDO01BQ0RDLEtBQUssRUFBRTtRQUNMNUMsSUFBSSxFQUFFLENBQ0o7VUFBRTZDLFFBQVEsRUFBRSxJQUFJO1VBQUVDLE9BQU8sRUFBRSxPQUFPO1VBQUVDLE9BQU8sRUFBRTtRQUFPLENBQUMsRUFDckQ7VUFBRUMsR0FBRyxFQUFFLENBQUM7VUFBRUYsT0FBTyxFQUFFLFVBQVU7VUFBRUMsT0FBTyxFQUFFO1FBQU8sQ0FBQyxDQUNqRDtRQUNESixRQUFRLEVBQUUsQ0FDUjtVQUFFRSxRQUFRLEVBQUUsSUFBSTtVQUFFQyxPQUFPLEVBQUUsT0FBTztVQUFFQyxPQUFPLEVBQUU7UUFBTyxDQUFDLEVBQ3JEO1VBQUVDLEdBQUcsRUFBRSxDQUFDO1VBQUVGLE9BQU8sRUFBRSxVQUFVO1VBQUVDLE9BQU8sRUFBRTtRQUFPLENBQUM7TUFFcEQsQ0FBQztNQUNERSxXQUFXLEVBQUU7UUFDWEMsUUFBUSxFQUFFLENBQ1I7VUFBRUwsUUFBUSxFQUFFLElBQUk7VUFBRUMsT0FBTyxFQUFFLE9BQU87VUFBRUMsT0FBTyxFQUFFO1FBQU8sQ0FBQyxFQUNyRDtVQUNFSSxPQUFPLEVBQUUsc0JBQXNCO1VBQy9CTCxPQUFPLEVBQUUsWUFBWTtVQUNyQkMsT0FBTyxFQUFFO1FBQ1gsQ0FBQyxDQUNGO1FBQ0QvQyxJQUFJLEVBQUUsQ0FDSjtVQUFFNkMsUUFBUSxFQUFFLElBQUk7VUFBRUMsT0FBTyxFQUFFLE9BQU87VUFBRUMsT0FBTyxFQUFFO1FBQU8sQ0FBQyxFQUNyRDtVQUFFQyxHQUFHLEVBQUUsQ0FBQztVQUFFRixPQUFPLEVBQUUsVUFBVTtVQUFFQyxPQUFPLEVBQUU7UUFBTyxDQUFDLENBQ2pEO1FBQ0RKLFFBQVEsRUFBRSxDQUNSO1VBQUVFLFFBQVEsRUFBRSxJQUFJO1VBQUVDLE9BQU8sRUFBRSxPQUFPO1VBQUVDLE9BQU8sRUFBRTtRQUFPLENBQUMsRUFDckQ7VUFBRUMsR0FBRyxFQUFFLENBQUM7VUFBRUYsT0FBTyxFQUFFLFVBQVU7VUFBRUMsT0FBTyxFQUFFO1FBQU8sQ0FBQyxDQUNqRDtRQUNESyxjQUFjLEVBQUUsQ0FDZDtVQUFFUCxRQUFRLEVBQUUsSUFBSTtVQUFFQyxPQUFPLEVBQUUsU0FBUztVQUFFQyxPQUFPLEVBQUU7UUFBTyxDQUFDLEVBQ3ZEO1VBQUVDLEdBQUcsRUFBRSxDQUFDO1VBQUVGLE9BQU8sRUFBRSxVQUFVO1VBQUVDLE9BQU8sRUFBRTtRQUFPLENBQUM7TUFFcEQsQ0FBQztNQUNETSxXQUFXLEVBQUUsTUFBTTtNQUNuQkMsaUJBQWlCLEVBQUUsS0FBSztNQUN4QkMsY0FBYyxFQUFFLE9BQU87TUFDdkJDLGFBQWEsRUFBRSxFQUFFO01BQ2pCQyxjQUFjLEVBQUUsRUFBRTtNQUNsQkMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLElBQUksRUFBRTtRQUNKVCxRQUFRLEVBQUUsRUFBRTtRQUNabEQsSUFBSSxFQUFFLEVBQUU7UUFDUjJDLFFBQVEsRUFBRSxFQUFFO1FBQ1pTLGNBQWMsRUFBRTtNQUNsQixDQUFDO01BQ0RRLFNBQVMsRUFBRTtJQUNiLENBQUM7RUFDSCxDQUFDO0VBQ0RDLE9BQU8sV0FBQUEsUUFBQSxFQUFHO0lBQ1IsSUFBSW5DLFlBQVksQ0FBQ29DLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtNQUNyQyxJQUFJcEMsWUFBWSxDQUFDb0MsT0FBTyxDQUFDLFdBQVcsS0FBSyxNQUFNLEVBQUU7UUFDL0MsSUFBSSxDQUFDQyxXQUFXLENBQUMsSUFBSSxDQUFDO01BQ3hCLE9BQU8sSUFBSXJDLFlBQVksQ0FBQ29DLE9BQU8sQ0FBQyxXQUFXLEtBQUssT0FBTyxFQUFFO1FBQ3ZELElBQUksQ0FBQ0MsV0FBVyxDQUFDLEtBQUssQ0FBQztNQUN6QjtJQUNGLE9BQU87TUFDTHJDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUNpQyxTQUFTLENBQUM7SUFDbkQ7RUFDRixDQUFDO0VBQ0RJLE9BQU8sRUFBRTtJQUNQO0lBQ0FDLFVBQVUsV0FBQUEsV0FBQSxFQUFHO01BQUEsSUFBQUMsS0FBQTtNQUNYLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxXQUFXLENBQUNDLFFBQVEsQ0FBQyxVQUFDQyxLQUFLLEVBQUVDLE1BQU0sRUFBSztRQUNqRCxJQUFJRCxLQUFLLEVBQUU7VUFDVGhFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDMkQsS0FBSSxDQUFDeEIsUUFBUSxFQUFFLE1BQU0sQ0FBQztVQUNsQ3dCLEtBQUksQ0FBQ00sTUFBTSxDQUFDQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUVQLEtBQUksQ0FBQ3hCLFFBQVEsQ0FBQyxDQUFDVCxJQUFJLENBQUMsVUFBQ0MsR0FBRyxFQUFLO1lBQzlENUIsT0FBTyxDQUFDQyxHQUFHLENBQUMyQixHQUFHLEVBQUUsUUFBUSxDQUFDO1lBQzFCLElBQUlBLEdBQUcsQ0FBQ0MsSUFBRyxLQUFNLEdBQUcsRUFBRTtjQUNwQjtjQUNBVCxZQUFZLENBQUNDLE9BQU8sQ0FBQyxVQUFVLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSyxHQUFHLENBQUNHLElBQUksQ0FBQyxDQUFDO2NBQzFEWCxZQUFZLENBQUNDLE9BQU8sQ0FBQyxPQUFPLEVBQUVPLEdBQUcsQ0FBQ0csSUFBSSxDQUFDUCxLQUFLLENBQUM7Y0FDN0NvQyxLQUFJLENBQUNRLE1BQU0sQ0FBQ3JELFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRWEsR0FBRyxDQUFDRyxJQUFJLENBQUM7Y0FFaEQ2QixLQUFJLENBQUNTLE9BQU8sQ0FBQ3hFLElBQUksQ0FBQztnQkFDaEJKLElBQUksRUFBRTtjQUNSLENBQUMsQ0FBQztZQUNKLE9BQU8sSUFBSW1DLEdBQUcsQ0FBQ0MsSUFBRyxLQUFNLEdBQUcsRUFBRTtjQUMzQitCLEtBQUksQ0FBQ1UsUUFBUSxDQUFDQyxLQUFLLENBQUMzQyxHQUFHLENBQUNZLE9BQU8sQ0FBQztZQUNsQztVQUNGLENBQUMsQ0FBQztRQUNKLE9BQU87VUFDTHhDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLGVBQWUsRUFBRWdFLE1BQU0sQ0FBQztRQUN0QztNQUNGLENBQUMsQ0FBQztJQUNKLENBQUM7SUFDRDtJQUNBTyxJQUFJLFdBQUFBLEtBQUEsRUFBRztNQUFBLElBQUFDLE1BQUE7TUFDTCxJQUFJQyxHQUFFLEdBQUksRUFBRTtNQUNaLElBQUksSUFBSSxDQUFDdEIsUUFBTyxLQUFNLFVBQVUsRUFBRTtRQUNoQ3NCLEdBQUUsTUFBQXhFLE1BQUEsQ0FBT2pCLE9BQU8sQ0FBQ3lDLE1BQU0sd0JBQXFCO01BQzlDLE9BQU8sSUFBSSxJQUFJLENBQUMwQixRQUFPLEtBQU0sUUFBUSxFQUFFO1FBQ3JDc0IsR0FBRSxNQUFBeEUsTUFBQSxDQUFPakIsT0FBTyxDQUFDeUMsTUFBTSw2QkFBMEI7TUFDbkQ7TUFDQSxJQUFJLENBQUNtQyxLQUFLLENBQUNjLFVBQVUsQ0FBQ1osUUFBUSxDQUFDLFVBQUNDLEtBQUssRUFBRUMsTUFBTSxFQUFLO1FBQ2hELElBQUlELEtBQUssRUFBRTtVQUNULElBQUlTLE1BQUksQ0FBQ3BCLElBQUksQ0FBQ2hCLFFBQU8sS0FBTW9DLE1BQUksQ0FBQ3BCLElBQUksQ0FBQ1AsY0FBYyxFQUFFO1lBQ25EMkIsTUFBSSxDQUFDSCxRQUFRLENBQUNNLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztZQUN6QztVQUNGO1VBQ0EsSUFBSUMsU0FBUSxHQUFJO1lBQ2RqQyxRQUFRLEVBQUU2QixNQUFJLENBQUNwQixJQUFJLENBQUNULFFBQVE7WUFDNUJsRCxJQUFJLEVBQUUrRSxNQUFJLENBQUNwQixJQUFJLENBQUMzRCxJQUFJO1lBQ3BCMkMsUUFBUSxFQUFFb0MsTUFBSSxDQUFDcEIsSUFBSSxDQUFDaEIsUUFBUTtZQUM1QkgsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEdUMsTUFBSSxDQUFDUCxNQUFNLENBQUNDLElBQUksQ0FBQ08sR0FBRyxFQUFFRyxTQUFTLENBQUMsQ0FBQ2xELElBQUksQ0FBQyxVQUFDQyxHQUFHLEVBQUs7WUFDN0MsSUFBSUEsR0FBRyxDQUFDQyxJQUFHLEtBQU0sR0FBRyxFQUFFO2NBQ3BCNEMsTUFBSSxDQUFDSCxRQUFRLENBQUNRLE9BQU8sQ0FBQ2xELEdBQUcsQ0FBQ1ksT0FBTyxDQUFDO2NBQ2xDaUMsTUFBSSxDQUFDTSxXQUFXLEVBQUU7WUFDcEIsT0FBTyxJQUFJbkQsR0FBRyxDQUFDQyxJQUFHLEtBQU0sR0FBRyxFQUFFO2NBQzNCNEMsTUFBSSxDQUFDSCxRQUFRLENBQUNDLEtBQUssQ0FBQzNDLEdBQUcsQ0FBQ1ksT0FBTyxDQUFDO1lBQ2xDO1VBQ0YsQ0FBQyxDQUFDO1FBQ0osT0FBTztVQUNMeEMsT0FBTyxDQUFDQyxHQUFHLENBQUMsZUFBZSxFQUFFZ0UsTUFBTSxDQUFDO1FBQ3RDO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUNEO0lBQ0FjLFdBQVcsV0FBQUEsWUFBQSxFQUFHO01BQ1osSUFBSSxDQUFDL0IsaUJBQWdCLEdBQUksS0FBSztNQUM5QixJQUFJLENBQUNLLElBQUcsR0FBSTtRQUFFVCxRQUFRLEVBQUUsRUFBRTtRQUFFbEQsSUFBSSxFQUFFLEVBQUU7UUFBRTJDLFFBQVEsRUFBRSxFQUFFO1FBQUVTLGNBQWMsRUFBRTtNQUFHLENBQUM7SUFDMUUsQ0FBQztJQUNEO0lBQ0FrQyxVQUFVLFdBQUFBLFdBQUNDLElBQUksRUFBRTtNQUNmLElBQUksQ0FBQ2pDLGlCQUFnQixHQUFJLElBQUk7TUFDN0IsSUFBSSxDQUFDSSxRQUFPLEdBQUk2QixJQUFJO01BQ3BCLElBQUlBLElBQUcsS0FBTSxVQUFVLEVBQUU7UUFDdkIsSUFBSSxDQUFDbEMsV0FBVSxHQUFJLE1BQU07UUFDekIsSUFBSSxDQUFDRyxhQUFZLEdBQUksSUFBSTtRQUN6QixJQUFJLENBQUNDLGNBQWEsR0FBSSxNQUFNO01BQzlCLE9BQU87UUFDTCxJQUFJLENBQUNKLFdBQVUsR0FBSSxNQUFNO1FBQ3pCLElBQUksQ0FBQ0csYUFBWSxHQUFJLEtBQUs7UUFDMUIsSUFBSSxDQUFDQyxjQUFhLEdBQUksTUFBTTtNQUM5QjtJQUNGLENBQUM7SUFDRDtJQUNBTSxXQUFXLFdBQUFBLFlBQUN5QixHQUFHLEVBQUU7TUFDZixJQUFJLENBQUM1QixTQUFRLEdBQUk0QixHQUFHO01BQ3BCbEYsT0FBTyxDQUFDQyxHQUFHLENBQUMsSUFBSSxDQUFDcUQsU0FBUyxFQUFFLFFBQVEsQ0FBQztNQUNyQ2xDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUNpQyxTQUFTLENBQUM7SUFDbkQ7RUFDRjtBQUNGLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBOVBzQzs7Ozs7RUFGaEMsU0FBTTtBQUFLOztFQUNULFNBQU07QUFBUzs7c0JBQ2xCOEIsdURBQUEsQ0FBdUQ7SUFBbERDLEdBQTRCLEVBQTVCRixrREFBNEI7SUFBQyxTQUFNLEtBQUs7SUFBQ0csR0FBRyxFQUFDOzs7O0VBQzdDLFNBQU07QUFBVzs7c0JBQ3BCRix1REFBQSxDQUF5QjtJQUF0QixTQUFNO0VBQU8sR0FBQyxNQUFJO0FBQUE7O0VBMkJaLFNBQU07QUFBUTs7RUEyRGpCLFNBQU07QUFBZTs7Ozs7OzsyREExRmpDRyx1REFBQSxDQWtHTSxPQWxHTkMsVUFrR00sR0FqR0pKLHVEQUFBLENBZ0RNLE9BaEROSyxVQWdETSxHQS9DSkMsVUFBdUQsRUFDdkROLHVEQUFBLENBNkNNLE9BN0NOTyxVQTZDTSxHQTVDSkMsVUFBeUIsRUFDekJDLGdEQUFBLENBMENVQyxrQkFBQTtJQXpDUkMsR0FBRyxFQUFDLGFBQWE7SUFDaEJDLEtBQUssRUFBRUMsS0FBQSxDQUFBN0QsUUFBUTtJQUNmRSxLQUFLLEVBQUUyRCxLQUFBLENBQUEzRCxLQUFLO0lBQ2IsYUFBVyxFQUFDLE9BQU87SUFDbkIsU0FBTSxlQUFlO0lBQ3BCNEQsSUFBSSxFQUFFRCxLQUFBLENBQUE5RCxRQUFRO0lBQ2YsYUFBVyxFQUFYOzs0REFFQTtNQUFBLE9BTWUsQ0FOZjBELGdEQUFBLENBTWVNLHVCQUFBO1FBTkRDLElBQUksRUFBQztNQUFNO2dFQUN2QjtVQUFBLE9BSUUsQ0FKRlAsZ0RBQUEsQ0FJRVEsbUJBQUE7d0JBSFNKLEtBQUEsQ0FBQTdELFFBQVEsQ0FBQzFDLElBQUk7O3FCQUFidUcsS0FBQSxDQUFBN0QsUUFBUSxDQUFDMUMsSUFBSSxHQUFBNEcsTUFBQTtZQUFBO1lBQ3RCQyxXQUFXLEVBQUMsT0FBTztZQUNuQkMsU0FBUyxFQUFUOzs7O1VBR0pYLGdEQUFBLENBUWVNLHVCQUFBO1FBUkRDLElBQUksRUFBQztNQUFVO2dFQUMzQjtVQUFBLE9BTUUsQ0FORlAsZ0RBQUEsQ0FNRVEsbUJBQUE7d0JBTFNKLEtBQUEsQ0FBQTdELFFBQVEsQ0FBQ0MsUUFBUTs7cUJBQWpCNEQsS0FBQSxDQUFBN0QsUUFBUSxDQUFDQyxRQUFRLEdBQUFpRSxNQUFBO1lBQUE7WUFDMUJDLFdBQVcsRUFBQyxPQUFPO1lBQ25CRSxJQUFJLEVBQUMsVUFBVTtZQUNmLGVBQWEsRUFBYixFQUFhO1lBQ2JELFNBQVMsRUFBVDs7OztVQUdKWCxnREFBQSxDQWdCZU0sdUJBQUE7Z0VBZmI7VUFBQSxPQWNNLENBZE5mLHVEQUFBLENBY00sT0FkTnNCLFVBY00sR0FiSmIsZ0RBQUEsQ0FFWWMsb0JBQUE7WUFGREYsSUFBSSxFQUFDLFNBQVM7WUFBRUcsT0FBSyxFQUFBQyxNQUFBLFFBQUFBLE1BQUEsZ0JBQUFQLE1BQUE7Y0FBQSxPQUFFUSxRQUFBLENBQUFuRCxVQUFVO1lBQUE7WUFBSSxTQUFNOztvRUFBTTtjQUFBLE9BRTVELHNEQUY0RCxNQUU1RDs7O2NBQ0FrQyxnREFBQSxDQU1ZYyxvQkFBQTtZQUxWRixJQUFJLEVBQUMsU0FBUztZQUNiRyxPQUFLLEVBQUFDLE1BQUEsUUFBQUEsTUFBQSxnQkFBQVAsTUFBQTtjQUFBLE9BQUVRLFFBQUEsQ0FBQTlCLFVBQVU7WUFBQTtZQUNsQixTQUFNOztvRUFDUDtjQUFBLE9BRUQsc0RBRkMsTUFFRDs7O2NBQ0FhLGdEQUFBLENBRVljLG9CQUFBO1lBRkFDLE9BQUssRUFBQUMsTUFBQSxRQUFBQSxNQUFBLGdCQUFBUCxNQUFBO2NBQUEsT0FBRVEsUUFBQSxDQUFBOUIsVUFBVTtZQUFBO1lBQVksU0FBTTs7b0VBQU07Y0FBQSxPQUVyRCxzREFGcUQsUUFFckQ7Ozs7Ozs7Ozs7O3FEQU1WYSxnREFBQSxDQStDWWtCLG9CQUFBO2dCQS9DUWQsS0FBQSxDQUFBakQsaUJBQWlCOzthQUFqQmlELEtBQUEsQ0FBQWpELGlCQUFpQixHQUFBc0QsTUFBQTtJQUFBO0lBQUdVLEtBQUssRUFBRWYsS0FBQSxDQUFBbEQsV0FBVztJQUFFa0UsS0FBSyxFQUFDOztJQXVDckRDLE1BQU0sRUFBQUMsNENBQUEsQ0FDZjtNQUFBLE9BS08sQ0FMUC9CLHVEQUFBLENBS08sUUFMUGdDLFVBS08sR0FKTHZCLGdEQUFBLENBQThDYyxvQkFBQTtRQUFsQ0MsT0FBSyxFQUFFRSxRQUFBLENBQUEvQjtNQUFXO2dFQUFFO1VBQUEsT0FBRSxzREFBRixJQUFFOzs7c0NBQ2xDYyxnREFBQSxDQUVZYyxvQkFBQTtRQUZERixJQUFJLEVBQUMsU0FBUztRQUFFRyxPQUFLLEVBQUVFLFFBQUEsQ0FBQXRDLElBQUk7UUFBRTZDLEtBQTBCLEVBQTFCO1VBQUE7UUFBQTs7Z0VBQTJCO1VBQUEsT0FFbkUsc0RBRm1FLE1BRW5FOzs7Ozs0REEzQ0o7TUFBQSxPQXFDVSxDQXJDVnhCLGdEQUFBLENBcUNVQyxrQkFBQTtRQXJDQUUsS0FBSyxFQUFFQyxLQUFBLENBQUE1QyxJQUFJO1FBQUUwQyxHQUFHLEVBQUMsWUFBWTtRQUFFekQsS0FBSyxFQUFFMkQsS0FBQSxDQUFBdEQ7O2dFQUM5QztVQUFBLE9BTWUsQ0FOZmtELGdEQUFBLENBTWVNLHVCQUFBO1lBTGJtQixLQUFLLEVBQUMsSUFBSTtZQUNULGFBQVcsRUFBRXJCLEtBQUEsQ0FBQWhELGNBQWM7WUFDNUJtRCxJQUFJLEVBQUM7O29FQUVMO2NBQUEsT0FBaUUsQ0FBakVQLGdEQUFBLENBQWlFUSxtQkFBQTs0QkFBOUNKLEtBQUEsQ0FBQTVDLElBQUksQ0FBQ1QsUUFBUTs7eUJBQWJxRCxLQUFBLENBQUE1QyxJQUFJLENBQUNULFFBQVEsR0FBQTBELE1BQUE7Z0JBQUE7Z0JBQUVpQixZQUFZLEVBQUMsS0FBSztnQkFBQ2YsU0FBUyxFQUFUOzs7OzhDQUV2RFgsZ0RBQUEsQ0FFZU0sdUJBQUE7WUFGRG1CLEtBQUssRUFBQyxJQUFJO1lBQUUsYUFBVyxFQUFFckIsS0FBQSxDQUFBaEQsY0FBYztZQUFFbUQsSUFBSSxFQUFDOztvRUFDMUQ7Y0FBQSxPQUE2RCxDQUE3RFAsZ0RBQUEsQ0FBNkRRLG1CQUFBOzRCQUExQ0osS0FBQSxDQUFBNUMsSUFBSSxDQUFDM0QsSUFBSTs7eUJBQVR1RyxLQUFBLENBQUE1QyxJQUFJLENBQUMzRCxJQUFJLEdBQUE0RyxNQUFBO2dCQUFBO2dCQUFFaUIsWUFBWSxFQUFDLEtBQUs7Z0JBQUNmLFNBQVMsRUFBVDs7Ozs4Q0FFbkRYLGdEQUFBLENBWWVNLHVCQUFBO1lBWFptQixLQUFLLEVBQUVyQixLQUFBLENBQUEvQyxhQUFhO1lBQ3BCLGFBQVcsRUFBRStDLEtBQUEsQ0FBQWhELGNBQWM7WUFDNUJtRCxJQUFJLEVBQUM7O29FQUVMO2NBQUEsT0FNRSxDQU5GUCxnREFBQSxDQU1FUSxtQkFBQTs0QkFMU0osS0FBQSxDQUFBNUMsSUFBSSxDQUFDaEIsUUFBUTs7eUJBQWI0RCxLQUFBLENBQUE1QyxJQUFJLENBQUNoQixRQUFRLEdBQUFpRSxNQUFBO2dCQUFBO2dCQUN0QmlCLFlBQVksRUFBQyxLQUFLO2dCQUNsQmQsSUFBSSxFQUFDLFVBQVU7Z0JBQ2YsZUFBYSxFQUFiLEVBQWE7Z0JBQ2JELFNBQVMsRUFBVDs7Ozt1REFHSlgsZ0RBQUEsQ0FZZU0sdUJBQUE7WUFYWm1CLEtBQUssRUFBRXJCLEtBQUEsQ0FBQTlDLGNBQWM7WUFDckIsYUFBVyxFQUFFOEMsS0FBQSxDQUFBaEQsY0FBYztZQUM1Qm1ELElBQUksRUFBQzs7b0VBRUw7Y0FBQSxPQU1FLENBTkZQLGdEQUFBLENBTUVRLG1CQUFBOzRCQUxTSixLQUFBLENBQUE1QyxJQUFJLENBQUNQLGNBQWM7O3lCQUFuQm1ELEtBQUEsQ0FBQTVDLElBQUksQ0FBQ1AsY0FBYyxHQUFBd0QsTUFBQTtnQkFBQTtnQkFDNUJpQixZQUFZLEVBQUMsS0FBSztnQkFDbEJkLElBQUksRUFBQyxVQUFVO2dCQUNmLGVBQWEsRUFBYixFQUFhO2dCQUNiRCxTQUFTLEVBQVQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JGWixNQUFxRztBQUNyRyxNQUEyRjtBQUMzRixNQUFrRztBQUNsRyxNQUFxSDtBQUNySCxNQUE4RztBQUM5RyxNQUE4RztBQUM5RyxNQUFxVjtBQUNyVjtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLG1TQUFPOzs7O0FBSStSO0FBQ3ZULE9BQU8saUVBQWUsbVNBQU8sSUFBSSwwU0FBYyxHQUFHLDBTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCQztBQUN0QjtBQUNMOztBQUVuRCxDQUE2RTs7QUFFcUM7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsMEVBQU0sYUFBYSx3RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7QUN4QjBWIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlPzU4YWYiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vZGlzcG9zZVBlcm1pc3Nvbi5qcyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9sb2dpbi9pbmRleC52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlPzZhNWMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlPzdkODIiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlP2I4N2QiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlPzFjZGUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvbG9naW4vaW5kZXgudnVlPzEwNTYiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIuYm94W2RhdGEtdi0yNDdlN2RkOF0ge1xcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KCNmMWYwZjAsICNmZmYpO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4uYm94IC5jb250ZW50IC5pbWdbZGF0YS12LTI0N2U3ZGQ4XSB7XFxuICB3aWR0aDogMTAwdnc7XFxuICBoZWlnaHQ6IDEwMHZoO1xcbn1cXG4uYm94IC5jb250ZW50IC50aXRsZVtkYXRhLXYtMjQ3ZTdkZDhdIHtcXG4gIG1hcmdpbjogMTBweCAwIDQwcHg7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjMpO1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5sb2dpbkZvcm1bZGF0YS12LTI0N2U3ZGQ4XSB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogMzBweDtcXG4gIHRvcDogMjAwcHg7XFxuICB3aWR0aDogNDAwcHg7XFxuICBoZWlnaHQ6IDMwMHB4O1xcbiAgYmFja2dyb3VuZDogI2ZmZjtcXG59XFxuLmJveFtkYXRhLXYtMjQ3ZTdkZDhdIC5lbC1mb3JtLWl0ZW1fX2NvbnRlbnQge1xcbiAgbWFyZ2luLWxlZnQ6IDQwcHggIWltcG9ydGFudDtcXG59XFxuLmJveFtkYXRhLXYtMjQ3ZTdkZDhdIC5lbC1pbnB1dCB7XFxuICB3aWR0aDogMzMwcHggIWltcG9ydGFudDtcXG59XFxuW2RhdGEtdi0yNDdlN2RkOF0gLmVsLWZvcm0taXRlbV9fbGFiZWwge1xcbiAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9sb2dpbi9pbmRleC52dWVcIixcIndlYnBhY2s6Ly8uL2luZGV4LnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGdEQUFBO0VBQ0Esa0JBQUE7QUNBRjtBREZBO0VBS00sWUFBQTtFQUNBLGFBQUE7QUNBTjtBRE5BO0VBU00sbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtBQ0FOO0FEWkE7RUFlTSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQ0FOO0FEcEJBO0VBNkJJLDRCQUFBO0FDTko7QUR2QkE7RUFnQ0ksdUJBQUE7QUNOSjtBRFNBO0VBQ0UsdUJBQUE7QUNQRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4uYm94IHtcXG4gIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgjZjFmMGYwLCAjZmZmKTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIC5jb250ZW50IHtcXG4gICAgLmltZyB7XFxuICAgICAgd2lkdGg6IDEwMHZ3O1xcbiAgICAgIGhlaWdodDogMTAwdmg7XFxuICAgIH1cXG4gICAgLnRpdGxlIHtcXG4gICAgICBtYXJnaW46IDEwcHggMCA0MHB4O1xcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gICAgICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjMpO1xcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcXG4gICAgfVxcbiAgICAubG9naW5Gb3JtIHtcXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICAgICAgcmlnaHQ6IDMwcHg7XFxuICAgICAgdG9wOiAyMDBweDtcXG4gICAgICB3aWR0aDogNDAwcHg7XFxuICAgICAgaGVpZ2h0OiAzMDBweDtcXG4gICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgICAgIC5mb290ZXIge1xcbiAgICAgICAgLy8gcGFkZGluZy1sZWZ0OiA1MHB4O1xcbiAgICAgICAgLmJ0biB7XFxuICAgICAgICB9XFxuICAgICAgfVxcbiAgICB9XFxuICB9XFxuICA6OnYtZGVlcCguZWwtZm9ybS1pdGVtX19jb250ZW50KSB7XFxuICAgIG1hcmdpbi1sZWZ0OiA0MHB4ICFpbXBvcnRhbnQ7XFxuICB9XFxuICA6OnYtZGVlcCguZWwtaW5wdXQpIHtcXG4gICAgd2lkdGg6IDMzMHB4ICFpbXBvcnRhbnQ7XFxuICB9XFxufVxcbjo6di1kZWVwKC5lbC1mb3JtLWl0ZW1fX2xhYmVsKSB7XFxuICB3aWR0aDogMTAwcHggIWltcG9ydGFudDtcXG59XFxuXCIsXCIuYm94IHtcXG4gIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgjZjFmMGYwLCAjZmZmKTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmJveCAuY29udGVudCAuaW1nIHtcXG4gIHdpZHRoOiAxMDB2dztcXG4gIGhlaWdodDogMTAwdmg7XFxufVxcbi5ib3ggLmNvbnRlbnQgLnRpdGxlIHtcXG4gIG1hcmdpbjogMTBweCAwIDQwcHg7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjMpO1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5sb2dpbkZvcm0ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgcmlnaHQ6IDMwcHg7XFxuICB0b3A6IDIwMHB4O1xcbiAgd2lkdGg6IDQwMHB4O1xcbiAgaGVpZ2h0OiAzMDBweDtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxufVxcbi5ib3ggOjp2LWRlZXAoLmVsLWZvcm0taXRlbV9fY29udGVudCkge1xcbiAgbWFyZ2luLWxlZnQ6IDQwcHggIWltcG9ydGFudDtcXG59XFxuLmJveCA6OnYtZGVlcCguZWwtaW5wdXQpIHtcXG4gIHdpZHRoOiAzMzBweCAhaW1wb3J0YW50O1xcbn1cXG46OnYtZGVlcCguZWwtZm9ybS1pdGVtX19sYWJlbCkge1xcbiAgd2lkdGg6IDEwMHB4ICFpbXBvcnRhbnQ7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJpbXBvcnQgcm91dGVyIGZyb20gJ0Avcm91dGVyL2luZGV4J1xyXG5pbXBvcnQgeyBhc3luY1JvdXRlcyB9IGZyb20gJ0Avcm91dGVyL2FzeW5jUm91dGVzJztcclxuaW1wb3J0IHN0b3JlIGZyb20gJ0Avc3RvcmUvaW5kZXgnXHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJ0AvdXRpbHMvcmVxdWVzdFV0aWxzJztcclxuaW1wb3J0IHsgY2xvbmVEZWVwIH0gZnJvbSAnbG9kYXNoJztcclxuaW1wb3J0IHsgZW52bmFtZSB9IGZyb20gXCJAL2phdmFzY3JpcHQvZW52bmFtZVwiO1xyXG5sZXQgZmxhdEZ1biA9IChhbGxsaXN0KSA9PiB7XHJcbiAgbGV0IExpc3QgPSBbXVxyXG4gIGFsbGxpc3QuZm9yRWFjaCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgIGxldCBuZXdPYmogPSB7fVxyXG4gICAgbmV3T2JqLnBhdGggPSBpdGVtLnBhdGhcclxuICAgIG5ld09iai5uYW1lID0gaXRlbS5uYW1lXHJcbiAgICBuZXdPYmoubWV0YSA9IGl0ZW0ubWV0YVxyXG4gICAgbmV3T2JqLmNvbXBvbmVudCA9IGl0ZW0uY29tcG9uZW50XHJcbiAgICBMaXN0LnB1c2gobmV3T2JqKVxyXG4gICAgaWYgKGl0ZW0uY2hpbGRyZW4gJiYgaXRlbS5jaGlsZHJlbi5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGl0ZW0uY2hpbGRyZW4sICdjaGlsZHJlbj09PScpXHJcbiAgICAgIExpc3QgPSBMaXN0LmNvbmNhdChmbGF0RnVuKGl0ZW0uY2hpbGRyZW4pKVxyXG4gICAgfVxyXG4gIH0pXHJcbiAgcmV0dXJuIExpc3RcclxufVxyXG5cclxuZXhwb3J0IGxldCBnZXRSb2xlUGVybWlzc2lvbiA9IChtZW51UGVybWlzc2lvbkxpc3QsIGFzeW5jUm91dGVMaXN0LCBuZXh0LCB0bykgPT4ge1xyXG4gIGxldCBhbGxBc3luY1JvdXRlc0xpc3QgPSBjbG9uZURlZXAoYXN5bmNSb3V0ZUxpc3QpXHJcbiAgY29uc29sZS5sb2cobWVudVBlcm1pc3Npb25MaXN0LCAn6I+c5Y2V5p2D6ZmQJylcclxuICBjb25zb2xlLmxvZyhhbGxBc3luY1JvdXRlc0xpc3QsICflhajpg6jot6/nlLEnKVxyXG5cclxuICBsZXQgZmxhdFJvdXRlTGlzdCA9IGZsYXRGdW4oYWxsQXN5bmNSb3V0ZXNMaXN0KVxyXG4gIGNvbnNvbGUubG9nKGZsYXRSb3V0ZUxpc3QsICfmiYHlubPljJblkI7nmoTot6/nlLEnKVxyXG4gIC8vIGZsYXRSb3V0ZUxpc3QuZm9yRWFjaChpdGVtPT57XHJcbiAgLy8gICAgIHJvdXRlci5hZGRSb3V0ZShpdGVtKVxyXG4gIC8vIH0pXHJcbiAgbGV0IGZpbHRlclJvdXRlID0gW11cclxuICBmbGF0Um91dGVMaXN0LmZvckVhY2goSXRlbSA9PiB7XHJcbiAgICBpZiAobWVudVBlcm1pc3Npb25MaXN0LmZpbmRJbmRleChpdGVtID0+IGl0ZW0ubmFtZSA9PT0gSXRlbS5uYW1lKSAhPT0gLTEpIHtcclxuICAgICAgZmlsdGVyUm91dGUucHVzaChJdGVtKVxyXG4gICAgfVxyXG4gIH0pXHJcbiAgZmlsdGVyUm91dGUuZm9yRWFjaChpdGVtID0+IHtcclxuICAgIHJvdXRlci5hZGRSb3V0ZShpdGVtKVxyXG4gIH0pXHJcbiAgY29uc29sZS5sb2cocm91dGVyLmdldFJvdXRlcygpLCAn5b6X5Yiw55qE6Lev55SxJylcclxuICBzdG9yZS5kaXNwYXRjaCgnY2hhbmdlQXN5bmNSb3V0ZUZpbmlzaCcsIHRydWUpXHJcbiAgaWYgKG5leHQgJiYgdG8pIHtcclxuICAgIG5leHQoeyAuLi50bywgcmVwbGFjZTogdHJ1ZSB9KVxyXG4gIH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBsZXQgbG9naW5TdWNjZXNzRG9uZSA9ICh1c2VySW5mbywgbmV4dCwgdG8pID0+IHtcclxuICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJJbmZvXCIsIEpTT04uc3RyaW5naWZ5KHVzZXJJbmZvKSk7XHJcbiAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ0b2tlblwiLCB1c2VySW5mby50b2tlbik7XHJcbiAgc3RvcmUuZGlzcGF0Y2goXCJjaGFuZ2VVc2VySW5mb1wiLCB1c2VySW5mbyk7XHJcbiAgLy8gIGdldFJvbGVQZXJtaXNzaW9uKClcclxuICByZXF1ZXN0LmdldChgJHtlbnZuYW1lLmFwaVVybH0vYXBwL3VzZXJSb2xlL3JvbGVMaXN0YCkudGhlbihyZXMgPT4ge1xyXG4gICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgbGV0IHJvbGVMaXN0ID0gcmVzLmRhdGFcclxuICAgICAgY29uc29sZS5sb2cocm9sZUxpc3QsICfmnYPpmZDmlbDmja4nKVxyXG4gICAgICBsZXQgdXNlclJvbGUgPSByb2xlTGlzdC5maW5kKGl0ZW0gPT4gaXRlbS5uYW1lID09PSB1c2VySW5mby5yb2xlKVxyXG4gICAgICBsZXQgbWVudVBlcm1pc3Npb25MaXN0ID0gdXNlclJvbGVbJ21lbnVOYW1lJ11cclxuICAgICAgc3RvcmUuZGlzcGF0Y2goXCJjaGFuZ2VSb2xlUGVybWlzc2lvblwiLCB1c2VyUm9sZSlcclxuICAgICAgc3RvcmUuZGlzcGF0Y2goXCJjaGFuZ2VNZW51UGVybWlzc2lvbkxpc3RcIiwgbWVudVBlcm1pc3Npb25MaXN0KVxyXG4gICAgICBnZXRSb2xlUGVybWlzc2lvbihtZW51UGVybWlzc2lvbkxpc3QsIGFzeW5jUm91dGVzLCBuZXh0LCB0bylcclxuICAgIH1cclxuICB9KVxyXG4gIGNvbnNvbGUubG9nKHN0b3JlLCAnc3RvcmXnmoTmk43kvZwnKVxyXG4gIHJvdXRlci5wdXNoKHtcclxuICAgIHBhdGg6IFwiL2Rhc2hib2FyZFwiLFxyXG4gIH0pO1xyXG59ICIsIjx0ZW1wbGF0ZT5cclxuICA8ZGl2IGNsYXNzPVwiYm94XCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxyXG4gICAgICA8aW1nIHNyYz1cIkAvYXNzZXRzL2xvZ2luQmFjay5qcGdcIiBjbGFzcz1cImltZ1wiIGFsdD1cIlwiIC8+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJsb2dpbkZvcm1cIj5cclxuICAgICAgICA8cCBjbGFzcz1cInRpdGxlXCI+5qyi6L+O55m75b2VPC9wPlxyXG4gICAgICAgIDxlbC1mb3JtXHJcbiAgICAgICAgICByZWY9XCJydWxlRm9ybVJlZlwiXHJcbiAgICAgICAgICA6bW9kZWw9XCJydWxlRm9ybVwiXHJcbiAgICAgICAgICA6cnVsZXM9XCJydWxlc1wiXHJcbiAgICAgICAgICBsYWJlbC13aWR0aD1cIjEyMHB4XCJcclxuICAgICAgICAgIGNsYXNzPVwiZGVtby1ydWxlRm9ybVwiXHJcbiAgICAgICAgICA6c2l6ZT1cImZvcm1TaXplXCJcclxuICAgICAgICAgIHN0YXR1cy1pY29uXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGVsLWZvcm0taXRlbSBwcm9wPVwibmFtZVwiPlxyXG4gICAgICAgICAgICA8ZWwtaW5wdXRcclxuICAgICAgICAgICAgICB2LW1vZGVsPVwicnVsZUZvcm0ubmFtZVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLor7fovpPlhaXotKblj7dcIlxyXG4gICAgICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgICA8ZWwtZm9ybS1pdGVtIHByb3A9XCJwYXNzd29yZFwiPlxyXG4gICAgICAgICAgICA8ZWwtaW5wdXRcclxuICAgICAgICAgICAgICB2LW1vZGVsPVwicnVsZUZvcm0ucGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6K+36L6T5YWl5a+G56CBXCJcclxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgIHNob3ctcGFzc3dvcmRcclxuICAgICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgICAgPGVsLWZvcm0taXRlbT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxyXG4gICAgICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiBAY2xpY2s9XCJzdWJtaXRGb3JtKClcIiBjbGFzcz1cImJ0blwiPlxyXG4gICAgICAgICAgICAgICAg55m75b2VXHJcbiAgICAgICAgICAgICAgPC9lbC1idXR0b24+XHJcbiAgICAgICAgICAgICAgPGVsLWJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgQGNsaWNrPVwiZGlhbG9nT3BlbigncmVnaXN0ZXInKVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJ0blwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAg5rOo5YaMXHJcbiAgICAgICAgICAgICAgPC9lbC1idXR0b24+XHJcbiAgICAgICAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJkaWFsb2dPcGVuKCdjaGFuZ2UnKVwiIGNsYXNzPVwiYnRuXCI+XHJcbiAgICAgICAgICAgICAgICDkv67mlLnlr4bnoIFcclxuICAgICAgICAgICAgICA8L2VsLWJ1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2VsLWZvcm0taXRlbT5cclxuICAgICAgICA8L2VsLWZvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZWwtZGlhbG9nIHYtbW9kZWw9XCJkaWFsb2dGb3JtVmlzaWJsZVwiIDp0aXRsZT1cImRpYWxvZ1RpdGxlXCIgd2lkdGg9XCI1NTBcIj5cclxuICAgICAgPGVsLWZvcm0gOm1vZGVsPVwiZm9ybVwiIHJlZj1cImRpYWxvZ0Zvcm1cIiA6cnVsZXM9XCJkaWFsb2dSdWxlc1wiPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW1cclxuICAgICAgICAgIGxhYmVsPVwi5aeT5ZCNXCJcclxuICAgICAgICAgIDpsYWJlbC13aWR0aD1cImZvcm1MYWJlbFdpZHRoXCJcclxuICAgICAgICAgIHByb3A9XCJ1c2VyTmFtZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGVsLWlucHV0IHYtbW9kZWw9XCJmb3JtLnVzZXJOYW1lXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgY2xlYXJhYmxlIC8+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbSBsYWJlbD1cIui0puWPt1wiIDpsYWJlbC13aWR0aD1cImZvcm1MYWJlbFdpZHRoXCIgcHJvcD1cIm5hbWVcIj5cclxuICAgICAgICAgIDxlbC1pbnB1dCB2LW1vZGVsPVwiZm9ybS5uYW1lXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgY2xlYXJhYmxlIC8+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbVxyXG4gICAgICAgICAgOmxhYmVsPVwiZmlyc3RQYXNzd29yZFwiXHJcbiAgICAgICAgICA6bGFiZWwtd2lkdGg9XCJmb3JtTGFiZWxXaWR0aFwiXHJcbiAgICAgICAgICBwcm9wPVwicGFzc3dvcmRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICB2LW1vZGVsPVwiZm9ybS5wYXNzd29yZFwiXHJcbiAgICAgICAgICAgIGF1dG9jb21wbGV0ZT1cIm9mZlwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIHNob3ctcGFzc3dvcmRcclxuICAgICAgICAgICAgY2xlYXJhYmxlXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW1cclxuICAgICAgICAgIDpsYWJlbD1cInNlY29uZFBhc3N3b3JkXCJcclxuICAgICAgICAgIDpsYWJlbC13aWR0aD1cImZvcm1MYWJlbFdpZHRoXCJcclxuICAgICAgICAgIHByb3A9XCJ2ZXJpZnlQYXNzd29yZFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGVsLWlucHV0XHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJmb3JtLnZlcmlmeVBhc3N3b3JkXCJcclxuICAgICAgICAgICAgYXV0b2NvbXBsZXRlPVwib2ZmXCJcclxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgc2hvdy1wYXNzd29yZFxyXG4gICAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgIDwvZWwtZm9ybT5cclxuICAgICAgPHRlbXBsYXRlICNmb290ZXI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJkaWFsb2ctZm9vdGVyXCI+XHJcbiAgICAgICAgICA8ZWwtYnV0dG9uIEBjbGljaz1cImNsb3NlRGlhbG9nXCI+5Y+W5raIPC9lbC1idXR0b24+XHJcbiAgICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgQGNsaWNrPVwiZG9uZVwiIHN0eWxlPVwibWFyZ2luLXJpZ2h0OiA0MHB4XCI+XHJcbiAgICAgICAgICAgIOehruWumlxyXG4gICAgICAgICAgPC9lbC1idXR0b24+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L3RlbXBsYXRlPlxyXG4gICAgPC9lbC1kaWFsb2c+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG5pbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmVcIjtcclxuaW1wb3J0IHsgbG9naW5TdWNjZXNzRG9uZSB9IGZyb20gXCIuL2Rpc3Bvc2VQZXJtaXNzb25cIjtcclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gIG5hbWU6IFwibG9naW5cIixcclxuICBkYXRhKCkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZm9ybVNpemU6IFwiZGVmYXVsdFwiLFxyXG4gICAgICBydWxlRm9ybToge1xyXG4gICAgICAgIG5hbWU6IFwiYWRtaW4xMjNcIixcclxuICAgICAgICBwYXNzd29yZDogXCJhZG1pbjEyM1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBydWxlczoge1xyXG4gICAgICAgIG5hbWU6IFtcclxuICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwi6K+36L6T5YWl6LSm5Y+3XCIsIHRyaWdnZXI6IFwiYmx1clwiIH0sXHJcbiAgICAgICAgICB7IG1pbjogNiwgbWVzc2FnZTogXCLotKblj7foh7PlsJHkuLo25L2N5pWwXCIsIHRyaWdnZXI6IFwiYmx1clwiIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXNzd29yZDogW1xyXG4gICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCLor7fovpPlhaXlr4bnoIFcIiwgdHJpZ2dlcjogXCJibHVyXCIgfSxcclxuICAgICAgICAgIHsgbWluOiA2LCBtZXNzYWdlOiBcIuWvhueggeiHs+WwkeS4ujbkvY3mlbBcIiwgdHJpZ2dlcjogXCJibHVyXCIgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgICBkaWFsb2dSdWxlczoge1xyXG4gICAgICAgIHVzZXJOYW1lOiBbXHJcbiAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIuivt+i+k+WFpei0puWPt1wiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwYXR0ZXJuOiAvW1xcdTRlMDAtXFx1OWZhNTAtOV0qJC8sXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwi5Y+q5Y+v5Lul6L6T5YWl5Lit5paH5ZKM5pWw5a2XXCIsXHJcbiAgICAgICAgICAgIHRyaWdnZXI6IFwiYmx1clwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIG5hbWU6IFtcclxuICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwi6K+36L6T5YWl6LSm5Y+3XCIsIHRyaWdnZXI6IFwiYmx1clwiIH0sXHJcbiAgICAgICAgICB7IG1pbjogNiwgbWVzc2FnZTogXCLotKblj7foh7PlsJHkuLo25L2N5pWwXCIsIHRyaWdnZXI6IFwiYmx1clwiIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXNzd29yZDogW1xyXG4gICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCLor7fovpPlhaXlr4bnoIFcIiwgdHJpZ2dlcjogXCJibHVyXCIgfSxcclxuICAgICAgICAgIHsgbWluOiA2LCBtZXNzYWdlOiBcIuWvhueggeiHs+WwkeS4ujbkvY3mlbBcIiwgdHJpZ2dlcjogXCJibHVyXCIgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIHZlcmlmeVBhc3N3b3JkOiBbXHJcbiAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIuivt+WGjeasoei+k+WFpeWvhueggVwiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gICAgICAgICAgeyBtaW46IDYsIG1lc3NhZ2U6IFwi5a+G56CB6Iez5bCR5Li6NuS9jeaVsFwiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICAgIGRpYWxvZ1RpdGxlOiBcIuazqOWGjOeUqOaIt1wiLFxyXG4gICAgICBkaWFsb2dGb3JtVmlzaWJsZTogZmFsc2UsXHJcbiAgICAgIGZvcm1MYWJlbFdpZHRoOiBcIjI0MHB4XCIsXHJcbiAgICAgIGZpcnN0UGFzc3dvcmQ6IFwiXCIsXHJcbiAgICAgIHNlY29uZFBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICBkb25lRmxhZzogXCJyZWdpc3RlclwiLFxyXG4gICAgICBmb3JtOiB7XHJcbiAgICAgICAgdXNlck5hbWU6IFwiXCIsXHJcbiAgICAgICAgbmFtZTogXCJcIixcclxuICAgICAgICBwYXNzd29yZDogXCJcIixcclxuICAgICAgICB2ZXJpZnlQYXNzd29yZDogXCJcIixcclxuICAgICAgfSxcclxuICAgICAgYXV0b0xvZ2luOiBmYWxzZSxcclxuICAgIH07XHJcbiAgfSxcclxuICBjcmVhdGVkKCkge1xyXG4gICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYXV0b0xvZ2luXCIpKSB7XHJcbiAgICAgIGlmIChsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImF1dG9Mb2dpblwiKSA9PSBcInRydWVcIikge1xyXG4gICAgICAgIHRoaXMuY2hhbmdlQ2hlY2sodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJhdXRvTG9naW5cIikgPT0gXCJmYWxzZVwiKSB7XHJcbiAgICAgICAgdGhpcy5jaGFuZ2VDaGVjayhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYXV0b0xvZ2luXCIsIHRoaXMuYXV0b0xvZ2luKTtcclxuICAgIH1cclxuICB9LFxyXG4gIG1ldGhvZHM6IHtcclxuICAgIC8v55m75b2VXHJcbiAgICBzdWJtaXRGb3JtKCkge1xyXG4gICAgICB0aGlzLiRyZWZzLnJ1bGVGb3JtUmVmLnZhbGlkYXRlKCh2YWxpZCwgZmllbGRzKSA9PiB7XHJcbiAgICAgICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLnJ1bGVGb3JtLCBcIueZu+W9leS/oeaBr1wiKTtcclxuICAgICAgICAgIHRoaXMuJGF4aW9zLnBvc3QoXCJhcHAvdXNlci9sb2dpblwiLCB0aGlzLnJ1bGVGb3JtKS50aGVuKChyZXMpID0+IHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLCBcIueZu+W9lei/lOWbnue7k+aenFwiKTtcclxuICAgICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgICAgICAgICAvLyBsb2dpblN1Y2Nlc3NEb25lKHJlcy5kYXRhKVxyXG4gICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlckluZm9cIiwgSlNPTi5zdHJpbmdpZnkocmVzLmRhdGEpKTtcclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInRva2VuXCIsIHJlcy5kYXRhLnRva2VuKTtcclxuICAgICAgICAgICAgICB0aGlzLiRzdG9yZS5kaXNwYXRjaChcImNoYW5nZVVzZXJJbmZvXCIsIHJlcy5kYXRhKTtcclxuXHJcbiAgICAgICAgICAgICAgdGhpcy4kcm91dGVyLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgcGF0aDogXCIvZGFzaGJvYXJkXCIsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAocmVzLmNvZGUgPT09IDIwMSkge1xyXG4gICAgICAgICAgICAgIHRoaXMuJG1lc3NhZ2UuZXJyb3IocmVzLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBzdWJtaXQhXCIsIGZpZWxkcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0sXHJcbiAgICAvL+azqOWGjCBvciDkv67mlLnlr4bnoIFcclxuICAgIGRvbmUoKSB7XHJcbiAgICAgIGxldCB1cmwgPSBcIlwiO1xyXG4gICAgICBpZiAodGhpcy5kb25lRmxhZyA9PT0gXCJyZWdpc3RlclwiKSB7XHJcbiAgICAgICAgdXJsID0gYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC9yZWdpc3Rlci9xdWVyeWA7XHJcbiAgICAgIH0gZWxzZSBpZiAodGhpcy5kb25lRmxhZyA9PT0gXCJjaGFuZ2VcIikge1xyXG4gICAgICAgIHVybCA9IGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvdXNlci91cGRhdGVQYXNzd29yZGA7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy4kcmVmcy5kaWFsb2dGb3JtLnZhbGlkYXRlKCh2YWxpZCwgZmllbGRzKSA9PiB7XHJcbiAgICAgICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgICAgICBpZiAodGhpcy5mb3JtLnBhc3N3b3JkICE9PSB0aGlzLmZvcm0udmVyaWZ5UGFzc3dvcmQpIHtcclxuICAgICAgICAgICAgdGhpcy4kbWVzc2FnZS53YXJuaW5nKFwi5a+G56CB5ZKM56Gu6K6k5a+G56CB5LiN5LiA6Ie0LOivt+mHjeaWsOi+k+WFpVwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgbGV0IHF1ZXJ5RGF0YSA9IHtcclxuICAgICAgICAgICAgdXNlck5hbWU6IHRoaXMuZm9ybS51c2VyTmFtZSxcclxuICAgICAgICAgICAgbmFtZTogdGhpcy5mb3JtLm5hbWUsXHJcbiAgICAgICAgICAgIHBhc3N3b3JkOiB0aGlzLmZvcm0ucGFzc3dvcmQsXHJcbiAgICAgICAgICAgIHJvbGU6IFwiY29kZVwiLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHRoaXMuJGF4aW9zLnBvc3QodXJsLCBxdWVyeURhdGEpLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xyXG4gICAgICAgICAgICAgIHRoaXMuJG1lc3NhZ2Uuc3VjY2VzcyhyZXMubWVzc2FnZSk7XHJcbiAgICAgICAgICAgICAgdGhpcy5jbG9zZURpYWxvZygpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jb2RlID09PSAyMDEpIHtcclxuICAgICAgICAgICAgICB0aGlzLiRtZXNzYWdlLmVycm9yKHJlcy5tZXNzYWdlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3Igc3VibWl0IVwiLCBmaWVsZHMpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9LFxyXG4gICAgLy/lhbPpl63lvLnmoYZcclxuICAgIGNsb3NlRGlhbG9nKCkge1xyXG4gICAgICB0aGlzLmRpYWxvZ0Zvcm1WaXNpYmxlID0gZmFsc2U7XHJcbiAgICAgIHRoaXMuZm9ybSA9IHsgdXNlck5hbWU6IFwiXCIsIG5hbWU6IFwiXCIsIHBhc3N3b3JkOiBcIlwiLCB2ZXJpZnlQYXNzd29yZDogXCJcIiB9O1xyXG4gICAgfSxcclxuICAgIC8v5omT5byA5by55qGGXHJcbiAgICBkaWFsb2dPcGVuKGZsYWcpIHtcclxuICAgICAgdGhpcy5kaWFsb2dGb3JtVmlzaWJsZSA9IHRydWU7XHJcbiAgICAgIHRoaXMuZG9uZUZsYWcgPSBmbGFnO1xyXG4gICAgICBpZiAoZmxhZyA9PT0gXCJyZWdpc3RlclwiKSB7XHJcbiAgICAgICAgdGhpcy5kaWFsb2dUaXRsZSA9IFwi5rOo5YaM55So5oi3XCI7XHJcbiAgICAgICAgdGhpcy5maXJzdFBhc3N3b3JkID0gXCLlr4bnoIFcIjtcclxuICAgICAgICB0aGlzLnNlY29uZFBhc3N3b3JkID0gXCLnoa7orqTlr4bnoIFcIjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmRpYWxvZ1RpdGxlID0gXCLkv67mlLnlr4bnoIFcIjtcclxuICAgICAgICB0aGlzLmZpcnN0UGFzc3dvcmQgPSBcIuaWsOWvhueggVwiO1xyXG4gICAgICAgIHRoaXMuc2Vjb25kUGFzc3dvcmQgPSBcIuehruiupOWvhueggVwiO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy/kv67mlLnoh6rliqjnmbvlvZVcclxuICAgIGNoYW5nZUNoZWNrKHZhbCkge1xyXG4gICAgICB0aGlzLmF1dG9Mb2dpbiA9IHZhbDtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5hdXRvTG9naW4sIFwi6Ieq5Yqo55m75b2V5qCH6K+GXCIpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImF1dG9Mb2dpblwiLCB0aGlzLmF1dG9Mb2dpbik7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn07XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4uYm94IHtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoI2YxZjBmMCwgI2ZmZik7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC5jb250ZW50IHtcclxuICAgIC5pbWcge1xyXG4gICAgICB3aWR0aDogMTAwdnc7XHJcbiAgICAgIGhlaWdodDogMTAwdmg7XHJcbiAgICB9XHJcbiAgICAudGl0bGUge1xyXG4gICAgICBtYXJnaW46IDEwcHggMCA0MHB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMyk7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIH1cclxuICAgIC5sb2dpbkZvcm0ge1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHJpZ2h0OiAzMHB4O1xyXG4gICAgICB0b3A6IDIwMHB4O1xyXG4gICAgICB3aWR0aDogNDAwcHg7XHJcbiAgICAgIGhlaWdodDogMzAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgIC5mb290ZXIge1xyXG4gICAgICAgIC8vIHBhZGRpbmctbGVmdDogNTBweDtcclxuICAgICAgICAuYnRuIHtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgOjp2LWRlZXAoLmVsLWZvcm0taXRlbV9fY29udGVudCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgOjp2LWRlZXAoLmVsLWlucHV0KSB7XHJcbiAgICB3aWR0aDogMzMwcHggIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuOjp2LWRlZXAoLmVsLWZvcm0taXRlbV9fbGFiZWwpIHtcclxuICB3aWR0aDogMTAwcHggIWltcG9ydGFudDtcclxufVxyXG48L3N0eWxlPlxyXG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yNDdlN2RkOCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MjQ3ZTdkZDgmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTI0N2U3ZGQ4JnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MjQ3ZTdkZDgmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtMjQ3ZTdkZDhcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL2xvZ2luL2luZGV4LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIyNDdlN2RkOFwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzI0N2U3ZGQ4JywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMjQ3ZTdkZDgnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yNDdlN2RkOCZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCcyNDdlN2RkOCcsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTI0N2U3ZGQ4JnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yNDdlN2RkOCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIiJdLCJuYW1lcyI6WyJyb3V0ZXIiLCJhc3luY1JvdXRlcyIsInN0b3JlIiwicmVxdWVzdCIsImNsb25lRGVlcCIsImVudm5hbWUiLCJmbGF0RnVuIiwiYWxsbGlzdCIsIkxpc3QiLCJmb3JFYWNoIiwiaXRlbSIsImluZGV4IiwibmV3T2JqIiwicGF0aCIsIm5hbWUiLCJtZXRhIiwiY29tcG9uZW50IiwicHVzaCIsImNoaWxkcmVuIiwibGVuZ3RoIiwiY29uc29sZSIsImxvZyIsImNvbmNhdCIsImdldFJvbGVQZXJtaXNzaW9uIiwibWVudVBlcm1pc3Npb25MaXN0IiwiYXN5bmNSb3V0ZUxpc3QiLCJuZXh0IiwidG8iLCJhbGxBc3luY1JvdXRlc0xpc3QiLCJmbGF0Um91dGVMaXN0IiwiZmlsdGVyUm91dGUiLCJJdGVtIiwiZmluZEluZGV4IiwiYWRkUm91dGUiLCJnZXRSb3V0ZXMiLCJkaXNwYXRjaCIsIl9vYmplY3RTcHJlYWQiLCJyZXBsYWNlIiwibG9naW5TdWNjZXNzRG9uZSIsInVzZXJJbmZvIiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0b2tlbiIsImdldCIsImFwaVVybCIsInRoZW4iLCJyZXMiLCJjb2RlIiwicm9sZUxpc3QiLCJkYXRhIiwidXNlclJvbGUiLCJmaW5kIiwicm9sZSIsImZvcm1TaXplIiwicnVsZUZvcm0iLCJwYXNzd29yZCIsInJ1bGVzIiwicmVxdWlyZWQiLCJtZXNzYWdlIiwidHJpZ2dlciIsIm1pbiIsImRpYWxvZ1J1bGVzIiwidXNlck5hbWUiLCJwYXR0ZXJuIiwidmVyaWZ5UGFzc3dvcmQiLCJkaWFsb2dUaXRsZSIsImRpYWxvZ0Zvcm1WaXNpYmxlIiwiZm9ybUxhYmVsV2lkdGgiLCJmaXJzdFBhc3N3b3JkIiwic2Vjb25kUGFzc3dvcmQiLCJkb25lRmxhZyIsImZvcm0iLCJhdXRvTG9naW4iLCJjcmVhdGVkIiwiZ2V0SXRlbSIsImNoYW5nZUNoZWNrIiwibWV0aG9kcyIsInN1Ym1pdEZvcm0iLCJfdGhpcyIsIiRyZWZzIiwicnVsZUZvcm1SZWYiLCJ2YWxpZGF0ZSIsInZhbGlkIiwiZmllbGRzIiwiJGF4aW9zIiwicG9zdCIsIiRzdG9yZSIsIiRyb3V0ZXIiLCIkbWVzc2FnZSIsImVycm9yIiwiZG9uZSIsIl90aGlzMiIsInVybCIsImRpYWxvZ0Zvcm0iLCJ3YXJuaW5nIiwicXVlcnlEYXRhIiwic3VjY2VzcyIsImNsb3NlRGlhbG9nIiwiZGlhbG9nT3BlbiIsImZsYWciLCJ2YWwiLCJfaW1wb3J0c18wIiwiX2NyZWF0ZUVsZW1lbnRWTm9kZSIsInNyYyIsImFsdCIsIl9jcmVhdGVFbGVtZW50QmxvY2siLCJfaG9pc3RlZF8xIiwiX2hvaXN0ZWRfMiIsIl9ob2lzdGVkXzMiLCJfaG9pc3RlZF80IiwiX2hvaXN0ZWRfNSIsIl9jcmVhdGVWTm9kZSIsIl9jb21wb25lbnRfZWxfZm9ybSIsInJlZiIsIm1vZGVsIiwiJGRhdGEiLCJzaXplIiwiX2NvbXBvbmVudF9lbF9mb3JtX2l0ZW0iLCJwcm9wIiwiX2NvbXBvbmVudF9lbF9pbnB1dCIsIiRldmVudCIsInBsYWNlaG9sZGVyIiwiY2xlYXJhYmxlIiwidHlwZSIsIl9ob2lzdGVkXzYiLCJfY29tcG9uZW50X2VsX2J1dHRvbiIsIm9uQ2xpY2siLCJfY2FjaGUiLCIkb3B0aW9ucyIsIl9jb21wb25lbnRfZWxfZGlhbG9nIiwidGl0bGUiLCJ3aWR0aCIsImZvb3RlciIsIl93aXRoQ3R4IiwiX2hvaXN0ZWRfNyIsInN0eWxlIiwibGFiZWwiLCJhdXRvY29tcGxldGUiXSwic291cmNlUm9vdCI6IiJ9