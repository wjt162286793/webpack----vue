"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_business_components_visual_vue-src_pages_business_data_json"],{

/***/ 24420:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "[data-v-0e622562] .el-form-item {\n  display: flex;\n  flex-direction: column !important;\n}\nh6[data-v-0e622562] {\n  font-size: 14px;\n  font-weight: 500;\n  margin: 5px;\n  overflow: hidden;\n}\np[data-v-0e622562] {\n  margin: 20px;\n  border-bottom: 1px solid #eee;\n  overflow: hidden;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/business/components/rightForm.vue","webpack://./rightForm.vue"],"names":[],"mappings":"AACA;EACE,aAAA;EACA,iCAAA;ACAF;ADEA;EACE,eAAA;EACA,gBAAA;EACA,WAAA;EACA,gBAAA;ACAF;ADEA;EACE,YAAA;EACA,6BAAA;EACA,gBAAA;ACAF","sourcesContent":["\n::v-deep(.el-form-item)  {\n  display: flex;\n  flex-direction: column !important;\n}\nh6 {\n  font-size: 14px;\n  font-weight: 500;\n  margin: 5px;\n  overflow: hidden;\n}\np {\n  margin: 20px;\n  border-bottom: 1px solid #eee;\n  overflow: hidden;\n}\n","::v-deep(.el-form-item) {\n  display: flex;\n  flex-direction: column !important;\n}\nh6 {\n  font-size: 14px;\n  font-weight: 500;\n  margin: 5px;\n  overflow: hidden;\n}\np {\n  margin: 20px;\n  border-bottom: 1px solid #eee;\n  overflow: hidden;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 90105:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".box[data-v-77713f64] {\n  width: 100%;\n  height: 100%;\n  display: flex;\n}\n.leftMenu[data-v-77713f64] {\n  width: 240px;\n  border-right: 1px solid #d3d3d3;\n  border-bottom: 1px solid #d3d3d3;\n}\n.leftMenu h3[data-v-77713f64] {\n  width: 100%;\n  height: 30px;\n  line-height: 30px;\n  background: #eee;\n  text-align: center;\n}\n.leftMenu .content[data-v-77713f64] {\n  width: 180px;\n  height: 40px;\n  border: dashed 1px #030303;\n  text-align: center;\n  line-height: 40px;\n  margin-bottom: 10px;\n  margin-right: 10px;\n  cursor: pointer;\n}\n.plumbBox[data-v-77713f64] {\n  overflow: scroll;\n  position: relative;\n  width: 100%;\n  border-right: 1px solid #d3d3d3;\n}\n.rightContent[data-v-77713f64] {\n  width: 240px;\n  border-bottom: 1px solid #d3d3d3;\n}\n.rightContent h3[data-v-77713f64] {\n  width: 200px;\n  height: 30px;\n  line-height: 30px;\n  text-align: center;\n}\n.plumbNode[data-v-77713f64] {\n  float: left;\n  line-height: 45px;\n}\n.activePlumbNode[data-v-77713f64] {\n  float: left;\n  line-height: 45px;\n  background: #0bcfe9;\n}\n.normalNode[data-v-77713f64] {\n  background-color: #fff;\n}\n.activeNode[data-v-77713f64] {\n  background-color: #80eaf8;\n}\n.nameContent[data-v-77713f64] {\n  padding-bottom: 14px;\n  border-bottom: 1px solid #eee;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/business/components/visual.vue","webpack://./visual.vue"],"names":[],"mappings":"AACA;EACE,WAAA;EACA,YAAA;EACA,aAAA;ACAF;ADGA;EACE,YAAA;EACA,+BAAA;EACA,gCAAA;ACDF;ADFA;EAKI,WAAA;EACA,YAAA;EACA,iBAAA;EACA,gBAAA;EACA,kBAAA;ACAJ;ADTA;EAYI,YAAA;EACA,YAAA;EACA,0BAAA;EACA,kBAAA;EACA,iBAAA;EACA,mBAAA;EACA,kBAAA;EACA,eAAA;ACAJ;ADIA;EACE,gBAAA;EACA,kBAAA;EAEA,WAAA;EACA,+BAAA;ACHF;ADMA;EACE,YAAA;EACA,gCAAA;ACJF;ADEA;EAII,YAAA;EACA,YAAA;EACA,iBAAA;EACA,kBAAA;ACHJ;ADOA;EACE,WAAA;EACA,iBAAA;ACLF;ADOA;EACE,WAAA;EACA,iBAAA;EACA,mBAAA;ACLF;ADOA;EACE,sBAAA;ACLF;ADOA;EACE,yBAAA;ACLF;ADOA;EACE,oBAAA;EACA,6BAAA;ACLF","sourcesContent":["\n.box {\n  width: 100%;\n  height: 100%;\n  display: flex;\n}\n\n.leftMenu {\n  width: 240px;\n  border-right: 1px solid #d3d3d3;\n  border-bottom: 1px solid #d3d3d3;\n  h3 {\n    width: 100%;\n    height: 30px;\n    line-height: 30px;\n    background: #eee;\n    text-align: center;\n  }\n  .content {\n    width: 180px;\n    height: 40px;\n    border: dashed 1px #030303;\n    text-align: center;\n    line-height: 40px;\n    margin-bottom: 10px;\n    margin-right: 10px;\n    cursor: pointer;\n  }\n}\n\n.plumbBox {\n  overflow: scroll;\n  position: relative;\n  // margin: 0 20px;\n  width: 100%;\n  border-right: 1px solid #d3d3d3;\n}\n\n.rightContent {\n  width: 240px;\n  border-bottom: 1px solid #d3d3d3;\n  h3 {\n    width: 200px;\n    height: 30px;\n    line-height: 30px;\n    text-align: center;\n  }\n}\n\n.plumbNode {\n  float: left;\n  line-height: 45px;\n}\n.activePlumbNode {\n  float: left;\n  line-height: 45px;\n  background: #0bcfe9;\n}\n.normalNode {\n  background-color: #fff;\n}\n.activeNode {\n  background-color: #80eaf8;\n}\n.nameContent {\n  padding-bottom: 14px;\n  border-bottom: 1px solid #eee;\n}\n",".box {\n  width: 100%;\n  height: 100%;\n  display: flex;\n}\n.leftMenu {\n  width: 240px;\n  border-right: 1px solid #d3d3d3;\n  border-bottom: 1px solid #d3d3d3;\n}\n.leftMenu h3 {\n  width: 100%;\n  height: 30px;\n  line-height: 30px;\n  background: #eee;\n  text-align: center;\n}\n.leftMenu .content {\n  width: 180px;\n  height: 40px;\n  border: dashed 1px #030303;\n  text-align: center;\n  line-height: 40px;\n  margin-bottom: 10px;\n  margin-right: 10px;\n  cursor: pointer;\n}\n.plumbBox {\n  overflow: scroll;\n  position: relative;\n  width: 100%;\n  border-right: 1px solid #d3d3d3;\n}\n.rightContent {\n  width: 240px;\n  border-bottom: 1px solid #d3d3d3;\n}\n.rightContent h3 {\n  width: 200px;\n  height: 30px;\n  line-height: 30px;\n  text-align: center;\n}\n.plumbNode {\n  float: left;\n  line-height: 45px;\n}\n.activePlumbNode {\n  float: left;\n  line-height: 45px;\n  background: #0bcfe9;\n}\n.normalNode {\n  background-color: #fff;\n}\n.activeNode {\n  background-color: #80eaf8;\n}\n.nameContent {\n  padding-bottom: 14px;\n  border-bottom: 1px solid #eee;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 30923:
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/rightForm.vue?vue&type=script&setup=true&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) keys.push(key); return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'rightForm',
  emits: ["changeActiveNodeInfo", "deleteLine", "deleteNode"],
  setup: function setup(__props, _ref) {
    var expose = _ref.expose,
      emit = _ref.emit;
    var formData = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)([]);
    var lineData = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)({});
    var formSize = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)("default");
    var ruleFormRef = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)();
    var listShow = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(false);
    var ruleForm = (0,vue__WEBPACK_IMPORTED_MODULE_0__.reactive)({});
    var infoType = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)("node");
    var rules = (0,vue__WEBPACK_IMPORTED_MODULE_0__.reactive)({
      label: [{
        required: true,
        message: "节点名称为必输项",
        trigger: "blur"
      }, {
        min: 4,
        max: 8,
        message: "请输入4至8之间的字符",
        trigger: "blur"
      }],
      affiliation: [{
        required: true,
        message: "请选择归属项",
        trigger: "change"
      }]
    });
    var submitForm = /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(formEl) {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              if (formEl) {
                _context.next = 2;
                break;
              }
              return _context.abrupt("return");
            case 2:
              _context.next = 4;
              return formEl.validate(function (valid, fields) {
                if (valid) {
                  console.log(valid, ruleForm);
                  formData.value.forEach(function (item) {
                    item.value = ruleForm[item.name];
                  });
                  emit("changeActiveNodeInfo", formData.value);
                } else {
                  console.log("error submit!", fields);
                }
              });
            case 4:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      return function submitForm(_x) {
        return _ref2.apply(this, arguments);
      };
    }();
    var resetForm = function resetForm(formEl) {
      if (!formEl) return;
      formEl.resetFields();
    };
    var options = Array.from({
      length: 10000
    }).map(function (_, idx) {
      return {
        value: "".concat(idx + 1),
        label: "".concat(idx + 1)
      };
    });
    var getFormData = function getFormData() {
      console.log(formData, "信息");
    };
    //父节点传递信息函数
    var changeFormData = function changeFormData(val) {
      infoType.value = "node";
      listShow.value = true;
      console.log(val);
      formData.value = val;
      formData.value.forEach(function (item) {
        console.log(item, "遍历");
        ruleForm[item.name] = item.value;
      });
      console.log(ruleForm, "???");
    };
    //父节点传递连线信息
    var getLineInfo = function getLineInfo(lineInfo) {
      listShow.value = true;
      console.log(lineInfo, "连线信息");
      infoType.value = "line";
      lineData.value = lineInfo;
    };
    //删除连线信息
    var deleteLineFun = function deleteLineFun() {
      emit("deleteLine", lineData.value);
      infoType.value = null;
    };
    //删除节点
    var delteNodeFun = function delteNodeFun() {
      emit("deleteNode");
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(function () {});
    expose({
      changeFormData: changeFormData,
      getLineInfo: getLineInfo,
      formData: formData
    });
    var __returned__ = {
      get formData() {
        return formData;
      },
      set formData(v) {
        formData = v;
      },
      get lineData() {
        return lineData;
      },
      set lineData(v) {
        lineData = v;
      },
      formSize: formSize,
      ruleFormRef: ruleFormRef,
      listShow: listShow,
      get ruleForm() {
        return ruleForm;
      },
      set ruleForm(v) {
        ruleForm = v;
      },
      infoType: infoType,
      emit: emit,
      rules: rules,
      submitForm: submitForm,
      resetForm: resetForm,
      options: options,
      getFormData: getFormData,
      changeFormData: changeFormData,
      getLineInfo: getLineInfo,
      deleteLineFun: deleteLineFun,
      delteNodeFun: delteNodeFun
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 25523:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/visual.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jsplumb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsplumb */ 69669);
/* harmony import */ var jsplumb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsplumb__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_draggable_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-draggable-next */ 70707);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 53059);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! uuid */ 98170);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/dictionaries/business.json */ 56789);
/* harmony import */ var _rightForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rightForm */ 63770);










//名称和规范

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'visual',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    //引入jsPlumb
    console.log(typeOptions, '下拉框类型');
    var typeOptions = _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__.typeOptions;
    var scenario_name = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)("");
    var mode_type = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)("");
    var doneFlag = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)("new");
    //拖拽组件实例
    var draggable = vue_draggable_next__WEBPACK_IMPORTED_MODULE_5__.VueDraggableNext;
    var plumbBox = null;
    var plumbBoxPositionInfo = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({});
    //鼠标和节点的内部差距,为了让节点更精准的判断区域
    var nodePositionDiff = (0,vue__WEBPACK_IMPORTED_MODULE_2__.reactive)({});
    //后面需要回传给父组件的值
    var plumbList = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    //绘制标识
    var renderFlag = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(undefined);
    //动态节点
    var activeNode = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)({});
    var rightForm = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)(null);
    /*
    ----------------------------------------------
    //连线基础配置
    let jsPlumbConnectOptions = {
            isSource: true,
            isTarget: true,
            // 动态锚点、提供了4个方向 Continuous、AutoDefault
            anchor: ["Continuous",{shape:"Circle"}],
            overlays: [['Arrow', { width: 8, length: 8, location: 1 }]] // overlay
          }
    //画布节点的拖拽连线配置
    const jsplumbSourceOptions = {
      filter:'.plumbNode',
      filterExclude:false,
      anchor:'Continuous',
      allowLoopback:true,
      maxConnections: -1,
      onMaxConnections:function (info,e){
        console.log(`超过了最大值连线:${info.maxConnections}`)
      }
    }
    ----------------------------------------------
    */
    //修改
    var doneType = function doneType(flag, row) {
      doneFlag.value = flag;
      if (row) {
        console.log("???", row);
        scenario_name.value = row.scenarioName;
        mode_type.value = row.modeType;
        info.value = row.flowInfo;
      }
    };
    //左侧菜单节点的拖拽配置
    var options = {
      preventOnFilter: false,
      sort: false,
      disabled: false,
      ghostClass: "tt",
      // 不使用H5原生的配置
      forceFallback: true
    };
    //默认配置
    var globalConfig = {
      Container: "plumbBox",
      anchor: ["Bottom", "Top", "Left", "Right"],
      connector: "Bezier",
      endpoint: "Blank",
      paintStyle: {
        stroke: "#364249",
        strokeWidth: 1,
        outlineStroke: "transparent",
        outlineWidth: 10
      },
      hoverPaintStyle: {
        stroke: "#000",
        strokeWidth: 1.3
      },
      overlays: [["Arrow", {
        width: 5,
        length: 5,
        location: 1
      }]],
      endpointStyle: {
        fill: "lightgray",
        outlineStroke: "darkgray",
        outlineWidth: 2
      }
    };
    //左侧
    var leftMenuData = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([{
      name: "起始列表",
      children: [{
        to: [],
        top: 0,
        left: 0,
        status: "loading",
        isSource: true,
        isTarget: false,
        config: [{
          label: "名称",
          name: "label",
          type: "text",
          value: "起始节点1",
          require: true
        }, {
          label: "描述",
          name: "description",
          type: "textarea",
          value: "",
          require: false
        }, {
          label: "归属",
          name: "affiliation",
          type: "select",
          value: "check",
          require: true,
          options: [{
            label: "审核信息",
            value: "check"
          }, {
            label: "生产经营",
            value: "manage"
          }, {
            label: "结算报销",
            value: "account"
          }]
        }]
      }, {
        to: [],
        top: 0,
        left: 0,
        status: "loading",
        isSource: true,
        isTarget: true,
        config: [{
          label: "名称",
          name: "label",
          type: "text",
          value: "起始节点2",
          require: true
        }, {
          label: "描述",
          name: "description",
          type: "textarea",
          value: "",
          require: false
        }, {
          label: "归属",
          name: "affiliation",
          type: "select",
          value: "check",
          require: true,
          options: [{
            label: "审核信息",
            value: "check"
          }, {
            label: "生产经营",
            value: "manage"
          }, {
            label: "结算报销",
            value: "account"
          }]
        }]
      }]
    }, {
      name: "完结列表",
      children: [{
        to: [],
        top: 0,
        left: 0,
        status: "loading",
        type: "target",
        isSource: false,
        isTarget: false,
        config: [{
          label: "名称",
          name: "label",
          type: "text",
          value: "完结节点1",
          require: true
        }, {
          label: "描述",
          name: "description",
          type: "textarea",
          value: "check",
          require: false
        }, {
          label: "归属",
          name: "affiliation",
          type: "select",
          value: "",
          require: true,
          options: [{
            label: "审核信息",
            value: "check"
          }, {
            label: "生产经营",
            value: "manage"
          }, {
            label: "结算报销",
            value: "account"
          }]
        }]
      }, {
        to: [],
        top: 0,
        left: 0,
        status: "loading",
        isSource: false,
        isTarget: false,
        config: [{
          label: "名称",
          name: "label",
          type: "text",
          value: "完结节点2",
          require: true
        }, {
          label: "描述",
          name: "description",
          type: "textarea",
          value: "",
          require: false
        }, {
          label: "归属",
          name: "affiliation",
          type: "select",
          value: "check",
          require: true,
          options: [{
            label: "审核信息",
            value: "check"
          }, {
            label: "生产经营",
            value: "manage"
          }, {
            label: "结算报销",
            value: "account"
          }]
        }]
      }]
    }]);
    //渲染节点信息(默认是后台传过来的)
    var info = (0,vue__WEBPACK_IMPORTED_MODULE_2__.ref)([]);
    //新增一个节点
    var addNode = function addNode(newInfo) {
      newInfo.id = (0,uuid__WEBPACK_IMPORTED_MODULE_6__["default"])();
      newInfo = Object.assign(newInfo, globalConfig);
      info.value.push(newInfo);
      console.log(newInfo, "???新增节点的信息");
      // makeFun(newInfo)
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
        renderFlag.value = "new";
        makeFun(newInfo);
      });
    };

    //新增一条连线
    var addLine = function addLine() {
      info.value[3].to = ["div6"];
      renderNode();
    };
    var mouseDownFun = function mouseDownFun(event) {
      //具体位置鼠标信息
      var mousedownPositionInfo = {
        x: event.clientX,
        y: event.clientY
      };
      //被拖拽节点初始的位置信息
      var moveBoxBeforePosition = {
        x: event.target.getBoundingClientRect().x,
        y: event.target.getBoundingClientRect().y
      };
      nodePositionDiff = {
        leftDiff: mousedownPositionInfo.x - moveBoxBeforePosition.x,
        topDiff: mousedownPositionInfo.y - moveBoxBeforePosition.y
      };
    };
    //开始拖动
    var moveStart = function moveStart(el) {
      console.log(el, "开始拖动");
    };
    //停止拖动
    var moveEnd = function moveEnd(el) {
      refreshPlumbPostionInfo();
      var dragNodeInfo = JSON.parse(el.item.attributes.divOption.nodeValue);
      judgePosition(dragNodeInfo, plumbBoxPositionInfo, el.originalEvent.x, el.originalEvent.y);
    };
    //判断拖动区域
    var judgePosition = function judgePosition(dragNodeInfo, plumbBoxPositionInfo, x, y) {
      //拖拽至画布外部
      if (x - nodePositionDiff.leftDiff < plumbBoxPositionInfo.left || x + 180 - nodePositionDiff.leftDiff > plumbBoxPositionInfo.right || y - nodePositionDiff.topDiff < plumbBoxPositionInfo.top || y + 40 - nodePositionDiff.topDiff > plumbBoxPositionInfo.bottom) {
        (0,element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage)({
          message: "节点不能拖拽至画布之外",
          type: "error"
        });
      } else {
        dragNodeInfo.left = x - plumbBoxPositionInfo.left - nodePositionDiff.leftDiff;
        dragNodeInfo.top = y - plumbBoxPositionInfo.top - nodePositionDiff.topDiff;
        addNode(dragNodeInfo);
      }
    };
    //刷新画布区域信息
    var refreshPlumbPostionInfo = function refreshPlumbPostionInfo() {
      plumbBox = document.querySelector(".plumbBox");
      if (plumbBox) {
        var positionInfo = plumbBox.getBoundingClientRect();
        plumbBoxPositionInfo = positionInfo;
        console.log(plumbBoxPositionInfo, '画布信息');
      }
    };
    //渲染节点
    var renderNode = function renderNode(flag) {
      //合并节点信息和配置
      info.value.map(function (item) {
        return item = Object.assign(item, globalConfig);
      });
      //这里需要等所依赖的DOM节点全部渲染完毕,才能进行图形渲染
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
        if (flag === "new") {
          renderFlag.value = "once";
        }
        //清除之前的内容
        plumbInit.deleteEveryConnection();
        plumbInit.deleteEveryEndpoint();
        refreshPlumbPostionInfo();
        //渲染画布中的信息节点
        var renderList = [];
        // if(info.value.length<1){return}
        info.value.forEach(function (item) {
          if (item.to.length > 0) {
            item.to.forEach(function (v) {
              renderList.push({
                source: item.id,
                target: v,
                anchor: item.anchor,
                connector: item.connector,
                endpoint: item.endpoint,
                overlays: item.overlays,
                paintStyle: item.paintStyle,
                hoverPaintStyle: item.hoverPaintStyle,
                endpointStyle: item.endpointStyle
              });
            });
          }
        });
        plumbList.value = renderList;
        //渲染函数
        plumbInit.ready(function () {
          renderList.forEach(function (item) {
            // plumbInit.connect(item,jsPlumbConnectOptions);
            console.log(item, '渲染参数===');
            plumbInit.connect(item);
          });
          info.value.forEach(function (item) {
            makeFun(item);
            plumbInit.draggable(item.id, {
              containment: "parent",
              stop: function stop(el) {
                item.left = el.pos[0];
                item.top = el.pos[1];
              }
            });
          });
        });
      });
    };
    //设置节点可连接属性
    var makeFun = function makeFun(item) {
      plumbInit.setSourceEnabled(item.id, item.isSource);
      plumbInit.setTargetEnabled(item.id, item.isTarget);
      plumbInit.setDraggable(item.id, true);
      plumbInit.makeSource(item.id, {
        filter: ".plumbNode",
        filterExclude: false,
        allowLoopback: false,
        maxConnections: -1,
        Container: "plumbBox",
        anchor: item.anchor,
        connector: item.connector,
        endpoint: item.endpoint,
        overlays: item.overlays,
        paintStyle: item.paintStyle,
        hoverPaintStyle: item.hoverPaintStyle,
        endpointStyle: item.endpointStyle
      });
      plumbInit.makeTarget(item.id, {
        filter: ".plumbNode",
        filterExclude: false,
        allowLoopback: false,
        maxConnections: 1,
        Container: "plumbBox",
        anchor: item.anchor,
        connector: item.connector,
        endpoint: item.endpoint,
        overlays: item.overlays,
        paintStyle: item.paintStyle,
        hoverPaintStyle: item.hoverPaintStyle,
        endpointStyle: item.endpointStyle
      });
      plumbInit.draggable(item.id, {
        containment: "parent",
        stop: function stop(el) {
          item.left = el.pos[0];
          item.top = el.pos[1];
        }
      });
    };

    // 给元素设置渲染样式
    var getStyle = function getStyle(item) {
      return {
        position: "absolute",
        left: item.left + "px",
        top: item.top + "px",
        // color:item.color,
        // border:'1px solid #',
        width: "180px",
        height: "36px",
        lineHeight: "36px",
        textAlign: "center",
        borderLeft: "5px solid blue",
        borderRadius: "4%",
        boxShadow: "#eee 3px 3px 3px 3px",
        cursor: "pointer"
      };
    };
    //初始化jsplumb实例
    var plumbInit = jsplumb__WEBPACK_IMPORTED_MODULE_0__.jsPlumb.getInstance();

    //点击连线事件
    plumbInit.bind("click", function (conn, originalEvent) {
      console.log(conn, "点击连线");
      var lineInfo = {};
      console.log(info.value, "整体信息");
      var sourceInfo = info.value.find(function (v) {
        return v.id === conn.sourceId;
      });
      var targetInfo = info.value.find(function (v) {
        return v.id === conn.targetId;
      });
      lineInfo = {
        sourceInfo: sourceInfo,
        targetInfo: targetInfo
      };
      rightForm.value.getLineInfo(lineInfo);
      // console.log("点击了", coon, originalEvent);
      // plumbInit.deleteConnection(conn);
    });
    //连线触发事件
    plumbInit.bind("connection", function (event) {
      console.log(event, "新的连线事件触发");
      // forceUpdate();
      var sourceNode = info.value.find(function (item) {
        return item.id === event.sourceId;
      });
      console.log(sourceNode.to, event.targetId, "???");
      if (sourceNode.to.findIndex(function (v) {
        return v === event.targetId;
      }) === -1) {
        sourceNode.to.push(event.targetId);
      }
      plumbInit.repaint();
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
        renderFlag.value = "new";
      });
      if (renderFlag.value === "new") {
        console.log("新的页面刷新");
        renderFlag.value = "once";
        renderNode("new");
      }
      // console.log(info.value,'所有节点')
      // renderNode()
    });

    //切换动态节点
    function sendActive(node) {
      activeNode.value = node;
      console.log(activeNode.value, "动态节点");
      rightForm.value.changeFormData(activeNode.value.config);
    }
    (0,vue__WEBPACK_IMPORTED_MODULE_2__.onMounted)(function () {
      setTimeout(function () {
        renderNode();
        (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
          console.log("页面初次渲染完毕");
          renderFlag.value = "render";
        });
      });
    });
    //右侧保存值
    var changeActiveNodeInfo = function changeActiveNodeInfo(info) {
      console.log(info, "保存后的新值");
      activeNode.value.config = info;
      (0,vue__WEBPACK_IMPORTED_MODULE_2__.nextTick)(function () {
        renderFlag.value = "new";
        makeFun(activeNode.value);
      });
    };
    //删除线
    var deleteLine = function deleteLine(deleteLineInfo) {
      console.log(deleteLineInfo, "要删除的连线信息");
      console.log(info.value, "全量信息");
      var sourceIndex = info.value.findIndex(function (item) {
        return item.id === deleteLineInfo.sourceInfo.id;
      });
      var deleteTargetId = deleteLineInfo.targetInfo.id;
      var deleteTargetIndex = info.value[sourceIndex].to.findIndex(function (v) {
        return v === deleteTargetId;
      });
      info.value[sourceIndex].to.splice(deleteTargetIndex, 1);
      renderNode();
    };
    //删除节点
    var deleteNode = function deleteNode(nodeInfo) {
      console.log(activeNode.value);
      var nodeIndex = info.value.findIndex(function (item) {
        return item.id === activeNode.value.id;
      });
      info.value.splice(nodeIndex, 1);
      info.value.forEach(function (item) {
        var flagIndex = item.to.findIndex(function (v) {
          return v === activeNode.value.id;
        });
        if (flagIndex !== -1) {
          item.to.splice(flagIndex, 1);
        }
      });
      console.log(info.value, "节点列表");
      renderNode();
      activeNode.value = {};
      rightForm.value.changeFormData([]);
    };
    //暴露给父组件的值,需要父组件发送请求
    expose({
      plumbList: plumbList,
      info: info,
      scenario_name: scenario_name,
      mode_type: mode_type,
      doneType: doneType
    });
    var __returned__ = {
      get typeOptions() {
        return typeOptions;
      },
      set typeOptions(v) {
        typeOptions = v;
      },
      get scenario_name() {
        return scenario_name;
      },
      set scenario_name(v) {
        scenario_name = v;
      },
      get mode_type() {
        return mode_type;
      },
      set mode_type(v) {
        mode_type = v;
      },
      get doneFlag() {
        return doneFlag;
      },
      set doneFlag(v) {
        doneFlag = v;
      },
      draggable: draggable,
      get plumbBox() {
        return plumbBox;
      },
      set plumbBox(v) {
        plumbBox = v;
      },
      get plumbBoxPositionInfo() {
        return plumbBoxPositionInfo;
      },
      set plumbBoxPositionInfo(v) {
        plumbBoxPositionInfo = v;
      },
      get nodePositionDiff() {
        return nodePositionDiff;
      },
      set nodePositionDiff(v) {
        nodePositionDiff = v;
      },
      get plumbList() {
        return plumbList;
      },
      set plumbList(v) {
        plumbList = v;
      },
      get renderFlag() {
        return renderFlag;
      },
      set renderFlag(v) {
        renderFlag = v;
      },
      get activeNode() {
        return activeNode;
      },
      set activeNode(v) {
        activeNode = v;
      },
      get rightForm() {
        return rightForm;
      },
      set rightForm(v) {
        rightForm = v;
      },
      doneType: doneType,
      options: options,
      get globalConfig() {
        return globalConfig;
      },
      set globalConfig(v) {
        globalConfig = v;
      },
      get leftMenuData() {
        return leftMenuData;
      },
      set leftMenuData(v) {
        leftMenuData = v;
      },
      get info() {
        return info;
      },
      set info(v) {
        info = v;
      },
      addNode: addNode,
      addLine: addLine,
      mouseDownFun: mouseDownFun,
      moveStart: moveStart,
      moveEnd: moveEnd,
      judgePosition: judgePosition,
      refreshPlumbPostionInfo: refreshPlumbPostionInfo,
      renderNode: renderNode,
      makeFun: makeFun,
      getStyle: getStyle,
      get plumbInit() {
        return plumbInit;
      },
      set plumbInit(v) {
        plumbInit = v;
      },
      sendActive: sendActive,
      changeActiveNodeInfo: changeActiveNodeInfo,
      deleteLine: deleteLine,
      deleteNode: deleteNode,
      get jsPlumb() {
        return jsplumb__WEBPACK_IMPORTED_MODULE_0__.jsPlumb;
      },
      get VueDraggableNext() {
        return vue_draggable_next__WEBPACK_IMPORTED_MODULE_5__.VueDraggableNext;
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_7__.ElMessage;
      },
      get lodash() {
        return (lodash__WEBPACK_IMPORTED_MODULE_1___default());
      },
      get uuidv4() {
        return uuid__WEBPACK_IMPORTED_MODULE_6__["default"];
      },
      reactive: vue__WEBPACK_IMPORTED_MODULE_2__.reactive,
      get word() {
        return _dictionaries_business_json__WEBPACK_IMPORTED_MODULE_3__;
      },
      get RightForm() {
        return _rightForm__WEBPACK_IMPORTED_MODULE_4__["default"];
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 76566:
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/rightForm.vue?vue&type=template&id=0e622562&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-0e622562"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  key: 1
};
var _hoisted_2 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h6", null, "起始节点:", -1 /* HOISTED */);
});
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h6", null, "目标节点:", -1 /* HOISTED */);
});
var _hoisted_4 = {
  "class": "btnBox"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_form_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form-item");
  var _component_el_form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [$setup.infoType === 'node' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form, {
    key: 0,
    ref: "ruleFormRef",
    model: $setup.ruleForm,
    rules: $setup.rules,
    "label-width": "120px",
    "class": "demo-ruleForm",
    size: $setup.formSize,
    "status-icon": "",
    "label-position": "left"
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.formData, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
          label: item.label,
          prop: item.name,
          key: index
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [item.type === 'text' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_input, {
              key: 0,
              modelValue: $setup.ruleForm[item.name],
              "onUpdate:modelValue": function onUpdateModelValue($event) {
                return $setup.ruleForm[item.name] = $event;
              }
            }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue"])) : item.type === 'textarea' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_input, {
              key: 1,
              modelValue: $setup.ruleForm[item.name],
              "onUpdate:modelValue": function onUpdateModelValue($event) {
                return $setup.ruleForm[item.name] = $event;
              },
              type: "textarea"
            }, null, 8 /* PROPS */, ["modelValue", "onUpdate:modelValue"])) : item.type === 'select' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_select, {
              key: 2,
              modelValue: $setup.ruleForm[item.name],
              "onUpdate:modelValue": function onUpdateModelValue($event) {
                return $setup.ruleForm[item.name] = $event;
              }
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item.options, function (m, n) {
                  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                    label: m.label,
                    value: m.value,
                    key: n
                  }, null, 8 /* PROPS */, ["label", "value"]);
                }), 128 /* KEYED_FRAGMENT */))];
              }),

              _: 2 /* DYNAMIC */
            }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
          }),
          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label", "prop"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["model", "rules", "size"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.infoType === 'line' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [_hoisted_2, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.lineData.sourceInfo.config[0].value), 1 /* TEXT */), _hoisted_3, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.lineData.targetInfo.config[0].value), 1 /* TEXT */)])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: _cache[0] || (_cache[0] = function ($event) {
      return $setup.submitForm($setup.ruleFormRef);
    })
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 保存节点 ")];
    }),
    _: 1 /* STABLE */
  }, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.infoType === 'node' && $setup.formData.length > 0]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.delteNodeFun
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 删除节点 ")];
    }),
    _: 1 /* STABLE */
  }, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.infoType === 'node' && $setup.formData.length > 0]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.deleteLineFun
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 删除连线 ")];
    }),
    _: 1 /* STABLE */
  }, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.infoType === 'line']])], 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.listShow]])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 90084:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/business/components/visual.vue?vue&type=template&id=77713f64&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-77713f64"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "nameContent"
};
var _hoisted_2 = {
  "class": "box"
};
var _hoisted_3 = {
  "class": "leftMenu"
};
var _hoisted_4 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h3", null, "选择节点", -1 /* HOISTED */);
});
var _hoisted_5 = ["divOption"];
var _hoisted_6 = {
  "class": "plumbBox",
  id: "plumbBox"
};
var _hoisted_7 = ["id", "onClick"];
var _hoisted_8 = ["id"];
var _hoisted_9 = {
  "class": "rightContent"
};
var _hoisted_10 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h3", null, "节点操作", -1 /* HOISTED */);
});
var _hoisted_11 = {
  style: {
    "padding-left": "10px"
  }
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_collapse_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-collapse-item");
  var _component_el_collapse = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-collapse");
  var _component_CirclePlusFilled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("CirclePlusFilled");
  var _component_el_icon = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-icon");
  var _component_Loading = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("Loading");
  var _component_CircleCheckFilled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("CircleCheckFilled");
  var _component_CircleCloseFilled = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("CircleCloseFilled");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 方案名称:  "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    modelValue: $setup.scenario_name,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return $setup.scenario_name = $event;
    }),
    modelModifiers: {
      trim: true
    },
    style: {
      "width": "200px",
      "margin-left": "30px'",
      "margin-right": "20px"
    }
  }, null, 8 /* PROPS */, ["modelValue"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" 模型规范:  "), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
    modelValue: $setup.mode_type,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
      return $setup.mode_type = $event;
    }),
    style: {
      "width": "200px",
      "margin-left": "30px'",
      "margin-right": "20px"
    }
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.typeOptions, function (item, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
          key: index,
          label: item.label,
          value: item.value
        }, null, 8 /* PROPS */, ["label", "value"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ul", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_3, [_hoisted_4, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_collapse, null, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.leftMenuData, function (item1, index) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_collapse_item, {
          title: item1.name,
          key: index
        }, {
          "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
            return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["draggable"], {
              onStart: $setup.moveStart,
              onEnd: $setup.moveEnd,
              modelValue: item1.children,
              "onUpdate:modelValue": function onUpdateModelValue($event) {
                return item1.children = $event;
              },
              options: $setup.options
            }, {
              "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)(item1.children, function (item2, n) {
                  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
                    "class": "content",
                    divOption: JSON.stringify(item2),
                    onMousedown: $setup.mouseDownFun,
                    key: n
                  }, (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item2.config[0].value), 41 /* TEXT, PROPS, HYDRATE_EVENTS */, _hoisted_5);
                }), 128 /* KEYED_FRAGMENT */))];
              }),

              _: 2 /* DYNAMIC */
            }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["modelValue", "onUpdate:modelValue"])];
          }),
          _: 2 /* DYNAMIC */
        }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["title"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  })]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_6, [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.info, function (item, index) {
    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", {
      key: index,
      id: item.id,
      style: (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeStyle)($setup.getStyle(item)),
      "class": (0,vue__WEBPACK_IMPORTED_MODULE_0__.normalizeClass)(item.id === $setup.activeNode.id ? 'activeNode' : 'normalNode'),
      onClick: function onClick($event) {
        return $setup.sendActive(item);
      }
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
      "class": "plumbNode",
      id: item.id + 'plumbNode'
    }, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_icon, {
      size: 20
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_CirclePlusFilled)];
      }),
      _: 1 /* STABLE */
    })], 8 /* PROPS */, _hoisted_8), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.config[0].value) + " ", 1 /* TEXT */), item.status === 'loading' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_icon, {
      key: 0,
      "class": "is-loading",
      color: "blue"
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_Loading)];
      }),
      _: 1 /* STABLE */
    })) : item.status === 'success' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_icon, {
      key: 1,
      color: "green"
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_CircleCheckFilled)];
      }),
      _: 1 /* STABLE */
    })) : item.status === 'error' ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_icon, {
      key: 2,
      color: "red"
    }, {
      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_CircleCloseFilled)];
      }),
      _: 1 /* STABLE */
    })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 14 /* CLASS, STYLE, PROPS */, _hoisted_7);
  }), 128 /* KEYED_FRAGMENT */))]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", _hoisted_9, [_hoisted_10, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_11, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)($setup["RightForm"], {
    ref: "rightForm",
    onChangeActiveNodeInfo: $setup.changeActiveNodeInfo,
    onDeleteLine: $setup.deleteLine,
    onDeleteNode: $setup.deleteNode
  }, null, 512 /* NEED_PATCH */)])])])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 25493:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true */ 24420);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 35609:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/business/components/visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true */ 90105);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 63770:
/*!*****************************************************!*\
  !*** ./src/pages/business/components/rightForm.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rightForm_vue_vue_type_template_id_0e622562_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rightForm.vue?vue&type=template&id=0e622562&scoped=true */ 38761);
/* harmony import */ var _rightForm_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rightForm.vue?vue&type=script&setup=true&lang=js */ 20645);
/* harmony import */ var _rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true */ 89637);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_rightForm_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_rightForm_vue_vue_type_template_id_0e622562_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-0e622562"],['__file',"src/pages/business/components/rightForm.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 27742:
/*!**************************************************!*\
  !*** ./src/pages/business/components/visual.vue ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _visual_vue_vue_type_template_id_77713f64_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./visual.vue?vue&type=template&id=77713f64&scoped=true */ 20250);
/* harmony import */ var _visual_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./visual.vue?vue&type=script&setup=true&lang=js */ 30268);
/* harmony import */ var _visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true */ 16040);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_visual_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_visual_vue_vue_type_template_id_77713f64_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-77713f64"],['__file',"src/pages/business/components/visual.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 20645:
/*!****************************************************************************************!*\
  !*** ./src/pages/business/components/rightForm.vue?vue&type=script&setup=true&lang=js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_rightForm_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_rightForm_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./rightForm.vue?vue&type=script&setup=true&lang=js */ 30923);
 

/***/ }),

/***/ 30268:
/*!*************************************************************************************!*\
  !*** ./src/pages/business/components/visual.vue?vue&type=script&setup=true&lang=js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_visual_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_visual_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./visual.vue?vue&type=script&setup=true&lang=js */ 25523);
 

/***/ }),

/***/ 38761:
/*!***********************************************************************************************!*\
  !*** ./src/pages/business/components/rightForm.vue?vue&type=template&id=0e622562&scoped=true ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_rightForm_vue_vue_type_template_id_0e622562_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_rightForm_vue_vue_type_template_id_0e622562_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./rightForm.vue?vue&type=template&id=0e622562&scoped=true */ 76566);


/***/ }),

/***/ 20250:
/*!********************************************************************************************!*\
  !*** ./src/pages/business/components/visual.vue?vue&type=template&id=77713f64&scoped=true ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_visual_vue_vue_type_template_id_77713f64_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_visual_vue_vue_type_template_id_77713f64_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./visual.vue?vue&type=template&id=77713f64&scoped=true */ 90084);


/***/ }),

/***/ 89637:
/*!**************************************************************************************************************!*\
  !*** ./src/pages/business/components/rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_rightForm_vue_vue_type_style_index_0_id_0e622562_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./rightForm.vue?vue&type=style&index=0&id=0e622562&lang=less&scoped=true */ 25493);


/***/ }),

/***/ 16040:
/*!***********************************************************************************************************!*\
  !*** ./src/pages/business/components/visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_visual_vue_vue_type_style_index_0_id_77713f64_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./visual.vue?vue&type=style&index=0&id=77713f64&lang=less&scoped=true */ 35609);


/***/ }),

/***/ 56789:
/*!****************************************!*\
  !*** ./src/dictionaries/business.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"status":[{"value":"1","label":"运营"},{"value":"2","label":"审核"},{"value":"3","label":"冻结"}],"user":[{"label":"王惊涛","value":"wjt"},{"label":"马师","value":"ms"}],"entiry":[{"label":"长城汽车","value":"1"},{"label":"富士康","value":"2"}],"type":[{"label":"金融资产","value":"1"},{"label":"不动产","value":"2"},{"label":"移动资产","value":"3"},{"label":"知识产权","value":"4"},{"label":"文艺资产","value":"5"},{"label":"公共基础设施","value":"6"}],"typeOptions":[{"value":1,"label":"精品"},{"value":2,"label":"标准"},{"value":3,"label":"草稿"}]}');

/***/ }),

/***/ 45990:
/*!**************************************!*\
  !*** ./src/pages/business/data.json ***!
  \**************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"type":[{"label":"金融资产","value":"1"},{"label":"不动产","value":"2"},{"label":"移动资产","value":"3"},{"label":"知识产权","value":"4"},{"label":"文艺资产","value":"5"},{"label":"公共基础设施","value":"6"},{"label":"自然资源","value":"7"},{"label":"个体经营","value":"8"}]}');

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2J1c2luZXNzX2NvbXBvbmVudHNfdmlzdWFsX3Z1ZS1zcmNfcGFnZXNfYnVzaW5lc3NfZGF0YV9qc29uLmJmY2RkMjY3MWNkZmNjMDU1NDRhLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDbUg7QUFDakI7QUFDbEcsOEJBQThCLG1GQUEyQixDQUFDLDRGQUFxQztBQUMvRjtBQUNBLDJFQUEyRSxrQkFBa0Isc0NBQXNDLEdBQUcsdUJBQXVCLG9CQUFvQixxQkFBcUIsZ0JBQWdCLHFCQUFxQixHQUFHLHNCQUFzQixpQkFBaUIsa0NBQWtDLHFCQUFxQixHQUFHLFNBQVMsMElBQTBJLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxXQUFXLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxXQUFXLFdBQVcscURBQXFELGtCQUFrQixzQ0FBc0MsR0FBRyxNQUFNLG9CQUFvQixxQkFBcUIsZ0JBQWdCLHFCQUFxQixHQUFHLEtBQUssaUJBQWlCLGtDQUFrQyxxQkFBcUIsR0FBRyw4QkFBOEIsa0JBQWtCLHNDQUFzQyxHQUFHLE1BQU0sb0JBQW9CLHFCQUFxQixnQkFBZ0IscUJBQXFCLEdBQUcsS0FBSyxpQkFBaUIsa0NBQWtDLHFCQUFxQixHQUFHLHFCQUFxQjtBQUNqb0M7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1B2QztBQUNtSDtBQUNqQjtBQUNsRyw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsaUVBQWlFLGdCQUFnQixpQkFBaUIsa0JBQWtCLEdBQUcsOEJBQThCLGlCQUFpQixvQ0FBb0MscUNBQXFDLEdBQUcsaUNBQWlDLGdCQUFnQixpQkFBaUIsc0JBQXNCLHFCQUFxQix1QkFBdUIsR0FBRyx1Q0FBdUMsaUJBQWlCLGlCQUFpQiwrQkFBK0IsdUJBQXVCLHNCQUFzQix3QkFBd0IsdUJBQXVCLG9CQUFvQixHQUFHLDhCQUE4QixxQkFBcUIsdUJBQXVCLGdCQUFnQixvQ0FBb0MsR0FBRyxrQ0FBa0MsaUJBQWlCLHFDQUFxQyxHQUFHLHFDQUFxQyxpQkFBaUIsaUJBQWlCLHNCQUFzQix1QkFBdUIsR0FBRywrQkFBK0IsZ0JBQWdCLHNCQUFzQixHQUFHLHFDQUFxQyxnQkFBZ0Isc0JBQXNCLHdCQUF3QixHQUFHLGdDQUFnQywyQkFBMkIsR0FBRyxnQ0FBZ0MsOEJBQThCLEdBQUcsaUNBQWlDLHlCQUF5QixrQ0FBa0MsR0FBRyxTQUFTLG9JQUFvSSxVQUFVLFVBQVUsVUFBVSxLQUFLLEtBQUssVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsVUFBVSxXQUFXLFdBQVcsV0FBVyxLQUFLLEtBQUssVUFBVSxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxVQUFVLEtBQUssS0FBSyxXQUFXLFdBQVcsVUFBVSxXQUFXLEtBQUssS0FBSyxVQUFVLFdBQVcsS0FBSyxLQUFLLFVBQVUsVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFVBQVUsV0FBVyxLQUFLLEtBQUssVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFdBQVcsV0FBVyxpQ0FBaUMsZ0JBQWdCLGlCQUFpQixrQkFBa0IsR0FBRyxlQUFlLGlCQUFpQixvQ0FBb0MscUNBQXFDLFFBQVEsa0JBQWtCLG1CQUFtQix3QkFBd0IsdUJBQXVCLHlCQUF5QixLQUFLLGNBQWMsbUJBQW1CLG1CQUFtQixpQ0FBaUMseUJBQXlCLHdCQUF3QiwwQkFBMEIseUJBQXlCLHNCQUFzQixLQUFLLEdBQUcsZUFBZSxxQkFBcUIsdUJBQXVCLHNCQUFzQixnQkFBZ0Isb0NBQW9DLEdBQUcsbUJBQW1CLGlCQUFpQixxQ0FBcUMsUUFBUSxtQkFBbUIsbUJBQW1CLHdCQUF3Qix5QkFBeUIsS0FBSyxHQUFHLGdCQUFnQixnQkFBZ0Isc0JBQXNCLEdBQUcsb0JBQW9CLGdCQUFnQixzQkFBc0Isd0JBQXdCLEdBQUcsZUFBZSwyQkFBMkIsR0FBRyxlQUFlLDhCQUE4QixHQUFHLGdCQUFnQix5QkFBeUIsa0NBQWtDLEdBQUcsV0FBVyxnQkFBZ0IsaUJBQWlCLGtCQUFrQixHQUFHLGFBQWEsaUJBQWlCLG9DQUFvQyxxQ0FBcUMsR0FBRyxnQkFBZ0IsZ0JBQWdCLGlCQUFpQixzQkFBc0IscUJBQXFCLHVCQUF1QixHQUFHLHNCQUFzQixpQkFBaUIsaUJBQWlCLCtCQUErQix1QkFBdUIsc0JBQXNCLHdCQUF3Qix1QkFBdUIsb0JBQW9CLEdBQUcsYUFBYSxxQkFBcUIsdUJBQXVCLGdCQUFnQixvQ0FBb0MsR0FBRyxpQkFBaUIsaUJBQWlCLHFDQUFxQyxHQUFHLG9CQUFvQixpQkFBaUIsaUJBQWlCLHNCQUFzQix1QkFBdUIsR0FBRyxjQUFjLGdCQUFnQixzQkFBc0IsR0FBRyxvQkFBb0IsZ0JBQWdCLHNCQUFzQix3QkFBd0IsR0FBRyxlQUFlLDJCQUEyQixHQUFHLGVBQWUsOEJBQThCLEdBQUcsZ0JBQWdCLHlCQUF5QixrQ0FBa0MsR0FBRyxxQkFBcUI7QUFDMXBJO0FBQ0EsaUVBQWUsdUJBQXVCLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHdDQUFHO0FBQ3RCLG1CQUFtQix3Q0FBRztBQUN0QixtQkFBbUIsd0NBQUc7QUFDdEIsc0JBQXNCLHdDQUFHO0FBQ3pCLG1CQUFtQix3Q0FBRztBQUN0QixtQkFBbUIsNkNBQVE7QUFDM0IsbUJBQW1CLHdDQUFHO0FBQ3RCLGdCQUFnQiw2Q0FBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4Q0FBUztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVKaUM7QUFDb0I7QUFDYjtBQUNiO0FBQ1E7QUFDTDtBQUNpQjtBQUNaOzs7QUFDcEM7QUFDQTtBQUNBLGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixvRUFBZ0I7QUFDdEMsd0JBQXdCLHdDQUFHO0FBQzNCLG9CQUFvQix3Q0FBRztBQUN2QixtQkFBbUIsd0NBQUc7QUFDdEI7QUFDQSxvQkFBb0IsZ0VBQWdCO0FBQ3BDO0FBQ0EsK0JBQStCLDZDQUFRO0FBQ3ZDO0FBQ0EsMkJBQTJCLDZDQUFRO0FBQ25DO0FBQ0Esb0JBQW9CLHdDQUFHO0FBQ3ZCO0FBQ0EscUJBQXFCLHdDQUFHO0FBQ3hCO0FBQ0EscUJBQXFCLHdDQUFHO0FBQ3hCLG9CQUFvQix3Q0FBRztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qix3Q0FBRztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3Q0FBRztBQUNsQjtBQUNBO0FBQ0EsbUJBQW1CLGdEQUFNO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSw2Q0FBUTtBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSx1REFBUztBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sNkNBQVE7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix3REFBbUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLDZDQUFRO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksOENBQVM7QUFDYjtBQUNBO0FBQ0EsUUFBUSw2Q0FBUTtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLDZDQUFRO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsNENBQU87QUFDdEI7QUFDQTtBQUNBLGVBQWUsZ0VBQWdCO0FBQy9CO0FBQ0E7QUFDQSxlQUFlLG1EQUFTO0FBQ3hCO0FBQ0E7QUFDQSxlQUFlLCtDQUFNO0FBQ3JCO0FBQ0E7QUFDQSxlQUFlLDRDQUFNO0FBQ3JCO0FBQ0EsZ0JBQWdCLHlDQUFRO0FBQ3hCO0FBQ0EsZUFBZSx3REFBSTtBQUNuQjtBQUNBO0FBQ0EsZUFBZSxrREFBUztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JDN29CR0EsdURBQUEsQ0FBYyxZQUFWLE9BQUs7QUFBQTs7c0JBRVRBLHVEQUFBLENBQWMsWUFBVixPQUFLO0FBQUE7O0VBR04sU0FBTTtBQUFROzs7Ozs7OztxS0F6Q1hDLE1BQUEsQ0FBQUMsUUFBUSxpRUFEaEJDLGdEQUFBLENBbUNVQyxrQkFBQTs7SUFqQ1JDLEdBQUcsRUFBQyxhQUFhO0lBQ2hCQyxLQUFLLEVBQUVMLE1BQUEsQ0FBQU0sUUFBUTtJQUNmQyxLQUFLLEVBQUVQLE1BQUEsQ0FBQU8sS0FBSztJQUNiLGFBQVcsRUFBQyxPQUFPO0lBQ25CLFNBQU0sZUFBZTtJQUNwQkMsSUFBSSxFQUFFUixNQUFBLENBQUFTLFFBQVE7SUFDZixhQUFXLEVBQVgsRUFBVztJQUNYLGdCQUFjLEVBQUM7OzREQUtiO01BQUEsT0FBaUMsd0RBSG5DQyx1REFBQSxDQXVCZUMseUNBQUEsUUFBQUMsK0NBQUEsQ0FwQldaLE1BQUEsQ0FBQWEsUUFBUSxZQUF4QkMsSUFBSSxFQUFFQyxLQUFLO2lFQUhyQmIsZ0RBQUEsQ0F1QmVjLHVCQUFBO1VBdEJaQyxLQUFLLEVBQUVILElBQUksQ0FBQ0csS0FBSztVQUNqQkMsSUFBSSxFQUFFSixJQUFJLENBQUNLLElBQUk7VUFFZkMsR0FBRyxFQUFFTDs7a0VBRU47WUFBQSxPQUFzRSxDQUF4QkQsSUFBSSxDQUFDTyxJQUFJLGlFQUF2RG5CLGdEQUFBLENBQXNFb0IsbUJBQUE7OzBCQUFuRHRCLE1BQUEsQ0FBQU0sUUFBUSxDQUFDUSxJQUFJLENBQUNLLElBQUk7O3VCQUFsQm5CLE1BQUEsQ0FBQU0sUUFBUSxDQUFDUSxJQUFJLENBQUNLLElBQUksSUFBQUksTUFBQTtjQUFBOzhFQUl4QlQsSUFBSSxDQUFDTyxJQUFJLHFFQUh0Qm5CLGdEQUFBLENBSUVvQixtQkFBQTs7MEJBSFN0QixNQUFBLENBQUFNLFFBQVEsQ0FBQ1EsSUFBSSxDQUFDSyxJQUFJOzt1QkFBbEJuQixNQUFBLENBQUFNLFFBQVEsQ0FBQ1EsSUFBSSxDQUFDSyxJQUFJLElBQUFJLE1BQUE7Y0FBQTtjQUMzQkYsSUFBSSxFQUFDOzhFQUtNUCxJQUFJLENBQUNPLElBQUksbUVBRnRCbkIsZ0RBQUEsQ0FVWXNCLG9CQUFBOzswQkFURHhCLE1BQUEsQ0FBQU0sUUFBUSxDQUFDUSxJQUFJLENBQUNLLElBQUk7O3VCQUFsQm5CLE1BQUEsQ0FBQU0sUUFBUSxDQUFDUSxJQUFJLENBQUNLLElBQUksSUFBQUksTUFBQTtjQUFBOztzRUFNekI7Z0JBQUEsT0FBOEIsd0RBSGhDYix1REFBQSxDQUtFQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUZpQkUsSUFBSSxDQUFDVyxPQUFPLFlBQXJCQyxDQUFDLEVBQUVDLENBQUM7MkVBSGR6QixnREFBQSxDQUtFMEIsb0JBQUE7b0JBSkNYLEtBQUssRUFBRVMsQ0FBQyxDQUFDVCxLQUFLO29CQUNkWSxLQUFLLEVBQUVILENBQUMsQ0FBQ0csS0FBSztvQkFFZFQsR0FBRyxFQUFFTzs7Ozs7Ozs7Ozs7Ozs7MEhBS0gzQixNQUFBLENBQUFDLFFBQVEsaUVBQW5CUyx1REFBQSxDQUtNLE9BQUFvQixVQUFBLEdBSkpDLFVBQWMsRUFDZGhDLHVEQUFBLENBQWdELFdBQUFpQyxvREFBQSxDQUExQ2hDLE1BQUEsQ0FBQWlDLFFBQVEsQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLElBQUlOLEtBQUssa0JBQ3pDTyxVQUFjLEVBQ2RyQyx1REFBQSxDQUFnRCxXQUFBaUMsb0RBQUEsQ0FBMUNoQyxNQUFBLENBQUFpQyxRQUFRLENBQUNJLFVBQVUsQ0FBQ0YsTUFBTSxJQUFJTixLQUFLLGlKQUUzQzlCLHVEQUFBLENBc0JNLE9BdEJOdUMsVUFzQk0sdURBckJKQyxnREFBQSxDQU1ZQyxvQkFBQTtJQUxWbkIsSUFBSSxFQUFDLFNBQVM7SUFDYm9CLE9BQUssRUFBQUMsTUFBQSxRQUFBQSxNQUFBLGdCQUFBbkIsTUFBQTtNQUFBLE9BQUV2QixNQUFBLENBQUEyQyxVQUFVLENBQUMzQyxNQUFBLENBQUE0QyxXQUFXO0lBQUE7OzREQUUvQjtNQUFBLE9BRUQsc0RBRkMsUUFFRDs7O3NFQUhVNUMsTUFBQSxDQUFBQyxRQUFRLGVBQWVELE1BQUEsQ0FBQWEsUUFBUSxDQUFDZ0MsTUFBTSw2REFJaEROLGdEQUFBLENBTVlDLG9CQUFBO0lBTFZuQixJQUFJLEVBQUMsU0FBUztJQUVib0IsT0FBSyxFQUFFekMsTUFBQSxDQUFBOEM7OzREQUNUO01BQUEsT0FFRCxzREFGQyxRQUVEOzs7c0VBSlU5QyxNQUFBLENBQUFDLFFBQVEsZUFBZUQsTUFBQSxDQUFBYSxRQUFRLENBQUNnQyxNQUFNLDZEQUtoRE4sZ0RBQUEsQ0FNWUMsb0JBQUE7SUFMVm5CLElBQUksRUFBQyxTQUFTO0lBRWJvQixPQUFLLEVBQUV6QyxNQUFBLENBQUErQzs7NERBQ1Q7TUFBQSxPQUVELHNEQUZDLFFBRUQ7OztzRUFKVS9DLE1BQUEsQ0FBQUMsUUFBUSxrRkFqQlFELE1BQUEsQ0FBQWdELFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQzFDL0IsU0FBTTtBQUFhOztFQWtCcEIsU0FBTTtBQUFLOztFQUNULFNBQU07QUFBVTs7c0JBQ2xCakQsdURBQUEsQ0FBYSxZQUFULE1BQUk7QUFBQTs7O0VBMEJOLFNBQU0sVUFBVTtFQUFDa0QsRUFBRSxFQUFDOzs7OztFQStCcEIsU0FBTTtBQUFjOztzQkFDdEJsRCx1REFBQSxDQUFhLFlBQVQsTUFBSTtBQUFBOztFQUNIbUQsS0FBMEIsRUFBMUI7SUFBQTtFQUFBO0FBQTBCOzs7Ozs7Ozs7Ozs7cUtBL0VuQ25ELHVEQUFBLENBaUJNLE9BakJOK0IsVUFpQk0sd0RBakJtQixVQUNOLEdBQUFTLGdEQUFBLENBR0xqQixtQkFBQTtnQkFGSXRCLE1BQUEsQ0FBQW1ELGFBQWE7O2FBQWJuRCxNQUFBLENBQUFtRCxhQUFhLEdBQUE1QixNQUFBO0lBQUE7b0JBQTNCO01BQUE2QixJQUFBO0lBQUEsQ0FBNEI7SUFDNUJGLEtBQTJELEVBQTNEO01BQUE7TUFBQTtNQUFBO0lBQUE7Z0dBQ1UsVUFDSyxHQUFBWCxnREFBQSxDQVdMZixvQkFBQTtnQkFWRHhCLE1BQUEsQ0FBQXFELFNBQVM7O2FBQVRyRCxNQUFBLENBQUFxRCxTQUFTLEdBQUE5QixNQUFBO0lBQUE7SUFDbEIyQixLQUEyRCxFQUEzRDtNQUFBO01BQUE7TUFBQTtJQUFBOzs0REFHRTtNQUFBLE9BQW9DLHdEQUR0Q3hDLHVEQUFBLENBTVlDLHlDQUFBLFFBQUFDLCtDQUFBLENBTGNaLE1BQUEsQ0FBQXNELFdBQVcsWUFBM0J4QyxJQUFJLEVBQUVDLEtBQUs7aUVBRHJCYixnREFBQSxDQU1ZMEIsb0JBQUE7VUFKVFIsR0FBRyxFQUFFTCxLQUFLO1VBQ1ZFLEtBQUssRUFBRUgsSUFBSSxDQUFDRyxLQUFLO1VBQ2pCWSxLQUFLLEVBQUVmLElBQUksQ0FBQ2U7Ozs7Ozt1Q0FLbkI5Qix1REFBQSxDQXNFSyxNQXRFTGdDLFVBc0VLLEdBckVIaEMsdURBQUEsQ0EwQkssTUExQkxxQyxVQTBCSyxHQXpCSEUsVUFBYSxFQUNiQyxnREFBQSxDQXVCY2dCLHNCQUFBOzREQXBCVjtNQUFBLE9BQXNDLHdEQUZ4QzdDLHVEQUFBLENBcUJtQkMseUNBQUEsUUFBQUMsK0NBQUEsQ0FuQlFaLE1BQUEsQ0FBQXdELFlBQVksWUFBN0JDLEtBQUssRUFBRTFDLEtBQUs7aUVBRnRCYixnREFBQSxDQXFCbUJ3RCwyQkFBQTtVQXBCaEJDLEtBQUssRUFBRUYsS0FBSyxDQUFDdEMsSUFBSTtVQUVqQkMsR0FBRyxFQUFFTDs7a0VBRU47WUFBQSxPQWVZLENBZlp3QixnREFBQSxDQWVZdkMsTUFBQTtjQWRUNEQsT0FBSyxFQUFFNUQsTUFBQSxDQUFBNkQsU0FBUztjQUNoQkMsS0FBRyxFQUFFOUQsTUFBQSxDQUFBK0QsT0FBTzswQkFDSk4sS0FBSyxDQUFDTyxRQUFROzt1QkFBZFAsS0FBSyxDQUFDTyxRQUFRLEdBQUF6QyxNQUFBO2NBQUE7Y0FDdEJFLE9BQU8sRUFBRXpCLE1BQUEsQ0FBQXlCOztzRUFHUjtnQkFBQSxPQUFvQyx3REFEdENmLHVEQUFBLENBUU1DLHlDQUFBLFFBQUFDLCtDQUFBLENBUGlCNkMsS0FBSyxDQUFDTyxRQUFRLFlBQTNCQyxLQUFLLEVBQUV0QyxDQUFDOzJFQURsQmpCLHVEQUFBLENBUU07b0JBTkosU0FBTSxTQUFTO29CQUNkd0QsU0FBUyxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsS0FBSztvQkFDL0JJLFdBQVMsRUFBRXJFLE1BQUEsQ0FBQXNFLFlBQVk7b0JBQ3ZCbEQsR0FBRyxFQUFFTzswRUFFSHNDLEtBQUssQ0FBQzlCLE1BQU0sSUFBSU4sS0FBSyx5Q0FBQTBDLFVBQUE7Ozs7Ozs7Ozs7Ozs7UUFNbEN4RSx1REFBQSxDQTZCSyxNQTdCTHlFLFVBNkJLLDBEQTVCSDlELHVEQUFBLENBMkJNQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQTFCb0JaLE1BQUEsQ0FBQXlFLElBQUksWUFBcEIzRCxJQUFJLEVBQUVDLEtBQUs7NkRBRHJCTCx1REFBQSxDQTJCTTtNQXpCSFUsR0FBRyxFQUFFTCxLQUFLO01BQ1ZrQyxFQUFFLEVBQUVuQyxJQUFJLENBQUNtQyxFQUFFO01BQ1hDLEtBQUssRUFBQXdCLG1EQUFBLENBQUUxRSxNQUFBLENBQUEyRSxRQUFRLENBQUM3RCxJQUFJO01BQ3BCLFNBQUs4RCxtREFBQSxDQUFFOUQsSUFBSSxDQUFDbUMsRUFBRSxLQUFLakQsTUFBQSxDQUFBNkUsVUFBVSxDQUFDNUIsRUFBRTtNQUNoQ1IsT0FBSyxXQUFBQSxRQUFBbEIsTUFBQTtRQUFBLE9BQUV2QixNQUFBLENBQUE4RSxVQUFVLENBQUNoRSxJQUFJO01BQUE7UUFFdkJmLHVEQUFBLENBSU07TUFKRCxTQUFNLFdBQVc7TUFBRWtELEVBQUUsRUFBRW5DLElBQUksQ0FBQ21DLEVBQUU7UUFDakNWLGdEQUFBLENBRVV3QyxrQkFBQTtNQUZBdkUsSUFBSSxFQUFFO0lBQUU7OERBQ2hCO1FBQUEsT0FBb0IsQ0FBcEIrQixnREFBQSxDQUFvQnlDLDJCQUFBOzs7MEZBRWxCLEdBQ04sR0FBQWhELG9EQUFBLENBQUdsQixJQUFJLENBQUNxQixNQUFNLElBQUlOLEtBQUssSUFBRyxHQUMxQixpQkFFUWYsSUFBSSxDQUFDbUUsTUFBTSxvRUFGbkIvRSxnREFBQSxDQU1VNkUsa0JBQUE7O01BTFIsU0FBTSxZQUFZO01BRWxCRyxLQUFLLEVBQUM7OzhEQUVOO1FBQUEsT0FBVyxDQUFYM0MsZ0RBQUEsQ0FBVzRDLGtCQUFBOzs7VUFFT3JFLElBQUksQ0FBQ21FLE1BQU0sb0VBQS9CL0UsZ0RBQUEsQ0FFVTZFLGtCQUFBOztNQUZxQ0csS0FBSyxFQUFDOzs4REFDbkQ7UUFBQSxPQUFxQixDQUFyQjNDLGdEQUFBLENBQXFCNkMsNEJBQUE7OztVQUVIdEUsSUFBSSxDQUFDbUUsTUFBTSxrRUFBL0IvRSxnREFBQSxDQUVVNkUsa0JBQUE7O01BRm1DRyxLQUFLLEVBQUM7OzhEQUNqRDtRQUFBLE9BQXFCLENBQXJCM0MsZ0RBQUEsQ0FBcUI4Qyw0QkFBQTs7OztvQ0FLM0J0Rix1REFBQSxDQVVLLE1BVkx1RixVQVVLLEdBVEhDLFdBQWEsRUFDYnhGLHVEQUFBLENBT00sT0FQTnlGLFdBT00sR0FOSmpELGdEQUFBLENBS2F2QyxNQUFBO0lBSlhJLEdBQUcsRUFBQyxXQUFXO0lBQ2RxRixzQkFBb0IsRUFBRXpGLE1BQUEsQ0FBQTBGLG9CQUFvQjtJQUMxQ0MsWUFBVSxFQUFFM0YsTUFBQSxDQUFBNEYsVUFBVTtJQUN0QkMsWUFBVSxFQUFFN0YsTUFBQSxDQUFBOEY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BGdkIsTUFBd0c7QUFDeEcsTUFBOEY7QUFDOUYsTUFBcUc7QUFDckcsTUFBd0g7QUFDeEgsTUFBaUg7QUFDakgsTUFBaUg7QUFDakgsTUFBcVc7QUFDclc7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyx1U0FBTzs7OztBQUkrUztBQUN2VSxPQUFPLGlFQUFlLHVTQUFPLElBQUksOFNBQWMsR0FBRyw4U0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekI3RSxNQUF3RztBQUN4RyxNQUE4RjtBQUM5RixNQUFxRztBQUNyRyxNQUF3SDtBQUN4SCxNQUFpSDtBQUNqSCxNQUFpSDtBQUNqSCxNQUFrVztBQUNsVztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLG9TQUFPOzs7O0FBSTRTO0FBQ3BVLE9BQU8saUVBQWUsb1NBQU8sSUFBSSwyU0FBYyxHQUFHLDJTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCSztBQUNYO0FBQ0w7O0FBRWxFLENBQWlGOztBQUVpQztBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyx5RkFBTSxhQUFhLDRGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCZ0U7QUFDWDtBQUNMOztBQUUvRCxDQUE4RTs7QUFFb0M7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsc0ZBQU0sYUFBYSx5RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7QUN4QnFYOzs7Ozs7Ozs7Ozs7Ozs7QUNBSCIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvcmlnaHRGb3JtLnZ1ZT9iYmNhIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvdmlzdWFsLnZ1ZT9hMWJiIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvcmlnaHRGb3JtLnZ1ZT80MjQ5Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvdmlzdWFsLnZ1ZT9mYzExIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvcmlnaHRGb3JtLnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL3Zpc3VhbC52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlP2MwYjUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlPzJkNDQiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlP2YyMjkiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlPzJlYzgiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlPzY1MTciLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlPzNkMTkiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlPzhjMDUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlP2FiNjkiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlPzMyY2QiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlPzU3MGIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCJbZGF0YS12LTBlNjIyNTYyXSAuZWwtZm9ybS1pdGVtIHtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XFxufVxcbmg2W2RhdGEtdi0wZTYyMjU2Ml0ge1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG4gIG1hcmdpbjogNXB4O1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxucFtkYXRhLXYtMGU2MjI1NjJdIHtcXG4gIG1hcmdpbjogMjBweDtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVlO1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL3BhZ2VzL2J1c2luZXNzL2NvbXBvbmVudHMvcmlnaHRGb3JtLnZ1ZVwiLFwid2VicGFjazovLy4vcmlnaHRGb3JtLnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGFBQUE7RUFDQSxpQ0FBQTtBQ0FGO0FERUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUNBRjtBREVBO0VBQ0UsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7QUNBRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG46OnYtZGVlcCguZWwtZm9ybS1pdGVtKSAge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcXG59XFxuaDYge1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG4gIG1hcmdpbjogNXB4O1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxucCB7XFxuICBtYXJnaW46IDIwcHg7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxufVxcblwiLFwiOjp2LWRlZXAoLmVsLWZvcm0taXRlbSkge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcXG59XFxuaDYge1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG4gIG1hcmdpbjogNXB4O1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxucCB7XFxuICBtYXJnaW46IDIwcHg7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5ib3hbZGF0YS12LTc3NzEzZjY0XSB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5sZWZ0TWVudVtkYXRhLXYtNzc3MTNmNjRdIHtcXG4gIHdpZHRoOiAyNDBweDtcXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNkM2QzZDM7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcXG59XFxuLmxlZnRNZW51IGgzW2RhdGEtdi03NzcxM2Y2NF0ge1xcbiAgd2lkdGg6IDEwMCU7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBsaW5lLWhlaWdodDogMzBweDtcXG4gIGJhY2tncm91bmQ6ICNlZWU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcbi5sZWZ0TWVudSAuY29udGVudFtkYXRhLXYtNzc3MTNmNjRdIHtcXG4gIHdpZHRoOiAxODBweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIGJvcmRlcjogZGFzaGVkIDFweCAjMDMwMzAzO1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgbGluZS1oZWlnaHQ6IDQwcHg7XFxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4ucGx1bWJCb3hbZGF0YS12LTc3NzEzZjY0XSB7XFxuICBvdmVyZmxvdzogc2Nyb2xsO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgd2lkdGg6IDEwMCU7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZDNkM2QzO1xcbn1cXG4ucmlnaHRDb250ZW50W2RhdGEtdi03NzcxM2Y2NF0ge1xcbiAgd2lkdGg6IDI0MHB4O1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkM2QzZDM7XFxufVxcbi5yaWdodENvbnRlbnQgaDNbZGF0YS12LTc3NzEzZjY0XSB7XFxuICB3aWR0aDogMjAwcHg7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBsaW5lLWhlaWdodDogMzBweDtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG59XFxuLnBsdW1iTm9kZVtkYXRhLXYtNzc3MTNmNjRdIHtcXG4gIGZsb2F0OiBsZWZ0O1xcbiAgbGluZS1oZWlnaHQ6IDQ1cHg7XFxufVxcbi5hY3RpdmVQbHVtYk5vZGVbZGF0YS12LTc3NzEzZjY0XSB7XFxuICBmbG9hdDogbGVmdDtcXG4gIGxpbmUtaGVpZ2h0OiA0NXB4O1xcbiAgYmFja2dyb3VuZDogIzBiY2ZlOTtcXG59XFxuLm5vcm1hbE5vZGVbZGF0YS12LTc3NzEzZjY0XSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbn1cXG4uYWN0aXZlTm9kZVtkYXRhLXYtNzc3MTNmNjRdIHtcXG4gIGJhY2tncm91bmQtY29sb3I6ICM4MGVhZjg7XFxufVxcbi5uYW1lQ29udGVudFtkYXRhLXYtNzc3MTNmNjRdIHtcXG4gIHBhZGRpbmctYm90dG9tOiAxNHB4O1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWU7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9idXNpbmVzcy9jb21wb25lbnRzL3Zpc3VhbC52dWVcIixcIndlYnBhY2s6Ly8uL3Zpc3VhbC52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNBRjtBREdBO0VBQ0UsWUFBQTtFQUNBLCtCQUFBO0VBQ0EsZ0NBQUE7QUNERjtBREZBO0VBS0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNBSjtBRFRBO0VBWUksWUFBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0FKO0FESUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBRUEsV0FBQTtFQUNBLCtCQUFBO0FDSEY7QURNQTtFQUNFLFlBQUE7RUFDQSxnQ0FBQTtBQ0pGO0FERUE7RUFJSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNISjtBRE9BO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0FDTEY7QURPQTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDTEY7QURPQTtFQUNFLHNCQUFBO0FDTEY7QURPQTtFQUNFLHlCQUFBO0FDTEY7QURPQTtFQUNFLG9CQUFBO0VBQ0EsNkJBQUE7QUNMRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4uYm94IHtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuXFxuLmxlZnRNZW51IHtcXG4gIHdpZHRoOiAyNDBweDtcXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNkM2QzZDM7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcXG4gIGgzIHtcXG4gICAgd2lkdGg6IDEwMCU7XFxuICAgIGhlaWdodDogMzBweDtcXG4gICAgbGluZS1oZWlnaHQ6IDMwcHg7XFxuICAgIGJhY2tncm91bmQ6ICNlZWU7XFxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIH1cXG4gIC5jb250ZW50IHtcXG4gICAgd2lkdGg6IDE4MHB4O1xcbiAgICBoZWlnaHQ6IDQwcHg7XFxuICAgIGJvcmRlcjogZGFzaGVkIDFweCAjMDMwMzAzO1xcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICAgIGxpbmUtaGVpZ2h0OiA0MHB4O1xcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XFxuICAgIGN1cnNvcjogcG9pbnRlcjtcXG4gIH1cXG59XFxuXFxuLnBsdW1iQm94IHtcXG4gIG92ZXJmbG93OiBzY3JvbGw7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAvLyBtYXJnaW46IDAgMjBweDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2QzZDNkMztcXG59XFxuXFxuLnJpZ2h0Q29udGVudCB7XFxuICB3aWR0aDogMjQwcHg7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcXG4gIGgzIHtcXG4gICAgd2lkdGg6IDIwMHB4O1xcbiAgICBoZWlnaHQ6IDMwcHg7XFxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB9XFxufVxcblxcbi5wbHVtYk5vZGUge1xcbiAgZmxvYXQ6IGxlZnQ7XFxuICBsaW5lLWhlaWdodDogNDVweDtcXG59XFxuLmFjdGl2ZVBsdW1iTm9kZSB7XFxuICBmbG9hdDogbGVmdDtcXG4gIGxpbmUtaGVpZ2h0OiA0NXB4O1xcbiAgYmFja2dyb3VuZDogIzBiY2ZlOTtcXG59XFxuLm5vcm1hbE5vZGUge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG59XFxuLmFjdGl2ZU5vZGUge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogIzgwZWFmODtcXG59XFxuLm5hbWVDb250ZW50IHtcXG4gIHBhZGRpbmctYm90dG9tOiAxNHB4O1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZWU7XFxufVxcblwiLFwiLmJveCB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5sZWZ0TWVudSB7XFxuICB3aWR0aDogMjQwcHg7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZDNkM2QzO1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkM2QzZDM7XFxufVxcbi5sZWZ0TWVudSBoMyB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMzBweDtcXG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xcbiAgYmFja2dyb3VuZDogI2VlZTtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG59XFxuLmxlZnRNZW51IC5jb250ZW50IHtcXG4gIHdpZHRoOiAxODBweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIGJvcmRlcjogZGFzaGVkIDFweCAjMDMwMzAzO1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgbGluZS1oZWlnaHQ6IDQwcHg7XFxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4ucGx1bWJCb3gge1xcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2QzZDNkMztcXG59XFxuLnJpZ2h0Q29udGVudCB7XFxuICB3aWR0aDogMjQwcHg7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcXG59XFxuLnJpZ2h0Q29udGVudCBoMyB7XFxuICB3aWR0aDogMjAwcHg7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICBsaW5lLWhlaWdodDogMzBweDtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG59XFxuLnBsdW1iTm9kZSB7XFxuICBmbG9hdDogbGVmdDtcXG4gIGxpbmUtaGVpZ2h0OiA0NXB4O1xcbn1cXG4uYWN0aXZlUGx1bWJOb2RlIHtcXG4gIGZsb2F0OiBsZWZ0O1xcbiAgbGluZS1oZWlnaHQ6IDQ1cHg7XFxuICBiYWNrZ3JvdW5kOiAjMGJjZmU5O1xcbn1cXG4ubm9ybWFsTm9kZSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbn1cXG4uYWN0aXZlTm9kZSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjODBlYWY4O1xcbn1cXG4ubmFtZUNvbnRlbnQge1xcbiAgcGFkZGluZy1ib3R0b206IDE0cHg7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsImZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7IFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjsgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAob2JqKSB7IHJldHVybiB0eXBlb2Ygb2JqOyB9IDogZnVuY3Rpb24gKG9iaikgeyByZXR1cm4gb2JqICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIG9iai5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG9iaiAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2Ygb2JqOyB9LCBfdHlwZW9mKG9iaik7IH1cbmZ1bmN0aW9uIF9yZWdlbmVyYXRvclJ1bnRpbWUoKSB7IFwidXNlIHN0cmljdFwiOyAvKiEgcmVnZW5lcmF0b3ItcnVudGltZSAtLSBDb3B5cmlnaHQgKGMpIDIwMTQtcHJlc2VudCwgRmFjZWJvb2ssIEluYy4gLS0gbGljZW5zZSAoTUlUKTogaHR0cHM6Ly9naXRodWIuY29tL2ZhY2Vib29rL3JlZ2VuZXJhdG9yL2Jsb2IvbWFpbi9MSUNFTlNFICovIF9yZWdlbmVyYXRvclJ1bnRpbWUgPSBmdW5jdGlvbiBfcmVnZW5lcmF0b3JSdW50aW1lKCkgeyByZXR1cm4gZXhwb3J0czsgfTsgdmFyIGV4cG9ydHMgPSB7fSwgT3AgPSBPYmplY3QucHJvdG90eXBlLCBoYXNPd24gPSBPcC5oYXNPd25Qcm9wZXJ0eSwgZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHkgfHwgZnVuY3Rpb24gKG9iaiwga2V5LCBkZXNjKSB7IG9ialtrZXldID0gZGVzYy52YWx1ZTsgfSwgJFN5bWJvbCA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sID8gU3ltYm9sIDoge30sIGl0ZXJhdG9yU3ltYm9sID0gJFN5bWJvbC5pdGVyYXRvciB8fCBcIkBAaXRlcmF0b3JcIiwgYXN5bmNJdGVyYXRvclN5bWJvbCA9ICRTeW1ib2wuYXN5bmNJdGVyYXRvciB8fCBcIkBAYXN5bmNJdGVyYXRvclwiLCB0b1N0cmluZ1RhZ1N5bWJvbCA9ICRTeW1ib2wudG9TdHJpbmdUYWcgfHwgXCJAQHRvU3RyaW5nVGFnXCI7IGZ1bmN0aW9uIGRlZmluZShvYmosIGtleSwgdmFsdWUpIHsgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwgeyB2YWx1ZTogdmFsdWUsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSksIG9ialtrZXldOyB9IHRyeSB7IGRlZmluZSh7fSwgXCJcIik7IH0gY2F0Y2ggKGVycikgeyBkZWZpbmUgPSBmdW5jdGlvbiBkZWZpbmUob2JqLCBrZXksIHZhbHVlKSB7IHJldHVybiBvYmpba2V5XSA9IHZhbHVlOyB9OyB9IGZ1bmN0aW9uIHdyYXAoaW5uZXJGbiwgb3V0ZXJGbiwgc2VsZiwgdHJ5TG9jc0xpc3QpIHsgdmFyIHByb3RvR2VuZXJhdG9yID0gb3V0ZXJGbiAmJiBvdXRlckZuLnByb3RvdHlwZSBpbnN0YW5jZW9mIEdlbmVyYXRvciA/IG91dGVyRm4gOiBHZW5lcmF0b3IsIGdlbmVyYXRvciA9IE9iamVjdC5jcmVhdGUocHJvdG9HZW5lcmF0b3IucHJvdG90eXBlKSwgY29udGV4dCA9IG5ldyBDb250ZXh0KHRyeUxvY3NMaXN0IHx8IFtdKTsgcmV0dXJuIGRlZmluZVByb3BlcnR5KGdlbmVyYXRvciwgXCJfaW52b2tlXCIsIHsgdmFsdWU6IG1ha2VJbnZva2VNZXRob2QoaW5uZXJGbiwgc2VsZiwgY29udGV4dCkgfSksIGdlbmVyYXRvcjsgfSBmdW5jdGlvbiB0cnlDYXRjaChmbiwgb2JqLCBhcmcpIHsgdHJ5IHsgcmV0dXJuIHsgdHlwZTogXCJub3JtYWxcIiwgYXJnOiBmbi5jYWxsKG9iaiwgYXJnKSB9OyB9IGNhdGNoIChlcnIpIHsgcmV0dXJuIHsgdHlwZTogXCJ0aHJvd1wiLCBhcmc6IGVyciB9OyB9IH0gZXhwb3J0cy53cmFwID0gd3JhcDsgdmFyIENvbnRpbnVlU2VudGluZWwgPSB7fTsgZnVuY3Rpb24gR2VuZXJhdG9yKCkge30gZnVuY3Rpb24gR2VuZXJhdG9yRnVuY3Rpb24oKSB7fSBmdW5jdGlvbiBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSgpIHt9IHZhciBJdGVyYXRvclByb3RvdHlwZSA9IHt9OyBkZWZpbmUoSXRlcmF0b3JQcm90b3R5cGUsIGl0ZXJhdG9yU3ltYm9sLCBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9KTsgdmFyIGdldFByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mLCBOYXRpdmVJdGVyYXRvclByb3RvdHlwZSA9IGdldFByb3RvICYmIGdldFByb3RvKGdldFByb3RvKHZhbHVlcyhbXSkpKTsgTmF0aXZlSXRlcmF0b3JQcm90b3R5cGUgJiYgTmF0aXZlSXRlcmF0b3JQcm90b3R5cGUgIT09IE9wICYmIGhhc093bi5jYWxsKE5hdGl2ZUl0ZXJhdG9yUHJvdG90eXBlLCBpdGVyYXRvclN5bWJvbCkgJiYgKEl0ZXJhdG9yUHJvdG90eXBlID0gTmF0aXZlSXRlcmF0b3JQcm90b3R5cGUpOyB2YXIgR3AgPSBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZS5wcm90b3R5cGUgPSBHZW5lcmF0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShJdGVyYXRvclByb3RvdHlwZSk7IGZ1bmN0aW9uIGRlZmluZUl0ZXJhdG9yTWV0aG9kcyhwcm90b3R5cGUpIHsgW1wibmV4dFwiLCBcInRocm93XCIsIFwicmV0dXJuXCJdLmZvckVhY2goZnVuY3Rpb24gKG1ldGhvZCkgeyBkZWZpbmUocHJvdG90eXBlLCBtZXRob2QsIGZ1bmN0aW9uIChhcmcpIHsgcmV0dXJuIHRoaXMuX2ludm9rZShtZXRob2QsIGFyZyk7IH0pOyB9KTsgfSBmdW5jdGlvbiBBc3luY0l0ZXJhdG9yKGdlbmVyYXRvciwgUHJvbWlzZUltcGwpIHsgZnVuY3Rpb24gaW52b2tlKG1ldGhvZCwgYXJnLCByZXNvbHZlLCByZWplY3QpIHsgdmFyIHJlY29yZCA9IHRyeUNhdGNoKGdlbmVyYXRvclttZXRob2RdLCBnZW5lcmF0b3IsIGFyZyk7IGlmIChcInRocm93XCIgIT09IHJlY29yZC50eXBlKSB7IHZhciByZXN1bHQgPSByZWNvcmQuYXJnLCB2YWx1ZSA9IHJlc3VsdC52YWx1ZTsgcmV0dXJuIHZhbHVlICYmIFwib2JqZWN0XCIgPT0gX3R5cGVvZih2YWx1ZSkgJiYgaGFzT3duLmNhbGwodmFsdWUsIFwiX19hd2FpdFwiKSA/IFByb21pc2VJbXBsLnJlc29sdmUodmFsdWUuX19hd2FpdCkudGhlbihmdW5jdGlvbiAodmFsdWUpIHsgaW52b2tlKFwibmV4dFwiLCB2YWx1ZSwgcmVzb2x2ZSwgcmVqZWN0KTsgfSwgZnVuY3Rpb24gKGVycikgeyBpbnZva2UoXCJ0aHJvd1wiLCBlcnIsIHJlc29sdmUsIHJlamVjdCk7IH0pIDogUHJvbWlzZUltcGwucmVzb2x2ZSh2YWx1ZSkudGhlbihmdW5jdGlvbiAodW53cmFwcGVkKSB7IHJlc3VsdC52YWx1ZSA9IHVud3JhcHBlZCwgcmVzb2x2ZShyZXN1bHQpOyB9LCBmdW5jdGlvbiAoZXJyb3IpIHsgcmV0dXJuIGludm9rZShcInRocm93XCIsIGVycm9yLCByZXNvbHZlLCByZWplY3QpOyB9KTsgfSByZWplY3QocmVjb3JkLmFyZyk7IH0gdmFyIHByZXZpb3VzUHJvbWlzZTsgZGVmaW5lUHJvcGVydHkodGhpcywgXCJfaW52b2tlXCIsIHsgdmFsdWU6IGZ1bmN0aW9uIHZhbHVlKG1ldGhvZCwgYXJnKSB7IGZ1bmN0aW9uIGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKCkgeyByZXR1cm4gbmV3IFByb21pc2VJbXBsKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHsgaW52b2tlKG1ldGhvZCwgYXJnLCByZXNvbHZlLCByZWplY3QpOyB9KTsgfSByZXR1cm4gcHJldmlvdXNQcm9taXNlID0gcHJldmlvdXNQcm9taXNlID8gcHJldmlvdXNQcm9taXNlLnRoZW4oY2FsbEludm9rZVdpdGhNZXRob2RBbmRBcmcsIGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKSA6IGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKCk7IH0gfSk7IH0gZnVuY3Rpb24gbWFrZUludm9rZU1ldGhvZChpbm5lckZuLCBzZWxmLCBjb250ZXh0KSB7IHZhciBzdGF0ZSA9IFwic3VzcGVuZGVkU3RhcnRcIjsgcmV0dXJuIGZ1bmN0aW9uIChtZXRob2QsIGFyZykgeyBpZiAoXCJleGVjdXRpbmdcIiA9PT0gc3RhdGUpIHRocm93IG5ldyBFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IHJ1bm5pbmdcIik7IGlmIChcImNvbXBsZXRlZFwiID09PSBzdGF0ZSkgeyBpZiAoXCJ0aHJvd1wiID09PSBtZXRob2QpIHRocm93IGFyZzsgcmV0dXJuIGRvbmVSZXN1bHQoKTsgfSBmb3IgKGNvbnRleHQubWV0aG9kID0gbWV0aG9kLCBjb250ZXh0LmFyZyA9IGFyZzs7KSB7IHZhciBkZWxlZ2F0ZSA9IGNvbnRleHQuZGVsZWdhdGU7IGlmIChkZWxlZ2F0ZSkgeyB2YXIgZGVsZWdhdGVSZXN1bHQgPSBtYXliZUludm9rZURlbGVnYXRlKGRlbGVnYXRlLCBjb250ZXh0KTsgaWYgKGRlbGVnYXRlUmVzdWx0KSB7IGlmIChkZWxlZ2F0ZVJlc3VsdCA9PT0gQ29udGludWVTZW50aW5lbCkgY29udGludWU7IHJldHVybiBkZWxlZ2F0ZVJlc3VsdDsgfSB9IGlmIChcIm5leHRcIiA9PT0gY29udGV4dC5tZXRob2QpIGNvbnRleHQuc2VudCA9IGNvbnRleHQuX3NlbnQgPSBjb250ZXh0LmFyZztlbHNlIGlmIChcInRocm93XCIgPT09IGNvbnRleHQubWV0aG9kKSB7IGlmIChcInN1c3BlbmRlZFN0YXJ0XCIgPT09IHN0YXRlKSB0aHJvdyBzdGF0ZSA9IFwiY29tcGxldGVkXCIsIGNvbnRleHQuYXJnOyBjb250ZXh0LmRpc3BhdGNoRXhjZXB0aW9uKGNvbnRleHQuYXJnKTsgfSBlbHNlIFwicmV0dXJuXCIgPT09IGNvbnRleHQubWV0aG9kICYmIGNvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsIGNvbnRleHQuYXJnKTsgc3RhdGUgPSBcImV4ZWN1dGluZ1wiOyB2YXIgcmVjb3JkID0gdHJ5Q2F0Y2goaW5uZXJGbiwgc2VsZiwgY29udGV4dCk7IGlmIChcIm5vcm1hbFwiID09PSByZWNvcmQudHlwZSkgeyBpZiAoc3RhdGUgPSBjb250ZXh0LmRvbmUgPyBcImNvbXBsZXRlZFwiIDogXCJzdXNwZW5kZWRZaWVsZFwiLCByZWNvcmQuYXJnID09PSBDb250aW51ZVNlbnRpbmVsKSBjb250aW51ZTsgcmV0dXJuIHsgdmFsdWU6IHJlY29yZC5hcmcsIGRvbmU6IGNvbnRleHQuZG9uZSB9OyB9IFwidGhyb3dcIiA9PT0gcmVjb3JkLnR5cGUgJiYgKHN0YXRlID0gXCJjb21wbGV0ZWRcIiwgY29udGV4dC5tZXRob2QgPSBcInRocm93XCIsIGNvbnRleHQuYXJnID0gcmVjb3JkLmFyZyk7IH0gfTsgfSBmdW5jdGlvbiBtYXliZUludm9rZURlbGVnYXRlKGRlbGVnYXRlLCBjb250ZXh0KSB7IHZhciBtZXRob2ROYW1lID0gY29udGV4dC5tZXRob2QsIG1ldGhvZCA9IGRlbGVnYXRlLml0ZXJhdG9yW21ldGhvZE5hbWVdOyBpZiAodW5kZWZpbmVkID09PSBtZXRob2QpIHJldHVybiBjb250ZXh0LmRlbGVnYXRlID0gbnVsbCwgXCJ0aHJvd1wiID09PSBtZXRob2ROYW1lICYmIGRlbGVnYXRlLml0ZXJhdG9yW1wicmV0dXJuXCJdICYmIChjb250ZXh0Lm1ldGhvZCA9IFwicmV0dXJuXCIsIGNvbnRleHQuYXJnID0gdW5kZWZpbmVkLCBtYXliZUludm9rZURlbGVnYXRlKGRlbGVnYXRlLCBjb250ZXh0KSwgXCJ0aHJvd1wiID09PSBjb250ZXh0Lm1ldGhvZCkgfHwgXCJyZXR1cm5cIiAhPT0gbWV0aG9kTmFtZSAmJiAoY29udGV4dC5tZXRob2QgPSBcInRocm93XCIsIGNvbnRleHQuYXJnID0gbmV3IFR5cGVFcnJvcihcIlRoZSBpdGVyYXRvciBkb2VzIG5vdCBwcm92aWRlIGEgJ1wiICsgbWV0aG9kTmFtZSArIFwiJyBtZXRob2RcIikpLCBDb250aW51ZVNlbnRpbmVsOyB2YXIgcmVjb3JkID0gdHJ5Q2F0Y2gobWV0aG9kLCBkZWxlZ2F0ZS5pdGVyYXRvciwgY29udGV4dC5hcmcpOyBpZiAoXCJ0aHJvd1wiID09PSByZWNvcmQudHlwZSkgcmV0dXJuIGNvbnRleHQubWV0aG9kID0gXCJ0aHJvd1wiLCBjb250ZXh0LmFyZyA9IHJlY29yZC5hcmcsIGNvbnRleHQuZGVsZWdhdGUgPSBudWxsLCBDb250aW51ZVNlbnRpbmVsOyB2YXIgaW5mbyA9IHJlY29yZC5hcmc7IHJldHVybiBpbmZvID8gaW5mby5kb25lID8gKGNvbnRleHRbZGVsZWdhdGUucmVzdWx0TmFtZV0gPSBpbmZvLnZhbHVlLCBjb250ZXh0Lm5leHQgPSBkZWxlZ2F0ZS5uZXh0TG9jLCBcInJldHVyblwiICE9PSBjb250ZXh0Lm1ldGhvZCAmJiAoY29udGV4dC5tZXRob2QgPSBcIm5leHRcIiwgY29udGV4dC5hcmcgPSB1bmRlZmluZWQpLCBjb250ZXh0LmRlbGVnYXRlID0gbnVsbCwgQ29udGludWVTZW50aW5lbCkgOiBpbmZvIDogKGNvbnRleHQubWV0aG9kID0gXCJ0aHJvd1wiLCBjb250ZXh0LmFyZyA9IG5ldyBUeXBlRXJyb3IoXCJpdGVyYXRvciByZXN1bHQgaXMgbm90IGFuIG9iamVjdFwiKSwgY29udGV4dC5kZWxlZ2F0ZSA9IG51bGwsIENvbnRpbnVlU2VudGluZWwpOyB9IGZ1bmN0aW9uIHB1c2hUcnlFbnRyeShsb2NzKSB7IHZhciBlbnRyeSA9IHsgdHJ5TG9jOiBsb2NzWzBdIH07IDEgaW4gbG9jcyAmJiAoZW50cnkuY2F0Y2hMb2MgPSBsb2NzWzFdKSwgMiBpbiBsb2NzICYmIChlbnRyeS5maW5hbGx5TG9jID0gbG9jc1syXSwgZW50cnkuYWZ0ZXJMb2MgPSBsb2NzWzNdKSwgdGhpcy50cnlFbnRyaWVzLnB1c2goZW50cnkpOyB9IGZ1bmN0aW9uIHJlc2V0VHJ5RW50cnkoZW50cnkpIHsgdmFyIHJlY29yZCA9IGVudHJ5LmNvbXBsZXRpb24gfHwge307IHJlY29yZC50eXBlID0gXCJub3JtYWxcIiwgZGVsZXRlIHJlY29yZC5hcmcsIGVudHJ5LmNvbXBsZXRpb24gPSByZWNvcmQ7IH0gZnVuY3Rpb24gQ29udGV4dCh0cnlMb2NzTGlzdCkgeyB0aGlzLnRyeUVudHJpZXMgPSBbeyB0cnlMb2M6IFwicm9vdFwiIH1dLCB0cnlMb2NzTGlzdC5mb3JFYWNoKHB1c2hUcnlFbnRyeSwgdGhpcyksIHRoaXMucmVzZXQoITApOyB9IGZ1bmN0aW9uIHZhbHVlcyhpdGVyYWJsZSkgeyBpZiAoaXRlcmFibGUpIHsgdmFyIGl0ZXJhdG9yTWV0aG9kID0gaXRlcmFibGVbaXRlcmF0b3JTeW1ib2xdOyBpZiAoaXRlcmF0b3JNZXRob2QpIHJldHVybiBpdGVyYXRvck1ldGhvZC5jYWxsKGl0ZXJhYmxlKTsgaWYgKFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgaXRlcmFibGUubmV4dCkgcmV0dXJuIGl0ZXJhYmxlOyBpZiAoIWlzTmFOKGl0ZXJhYmxlLmxlbmd0aCkpIHsgdmFyIGkgPSAtMSwgbmV4dCA9IGZ1bmN0aW9uIG5leHQoKSB7IGZvciAoOyArK2kgPCBpdGVyYWJsZS5sZW5ndGg7KSBpZiAoaGFzT3duLmNhbGwoaXRlcmFibGUsIGkpKSByZXR1cm4gbmV4dC52YWx1ZSA9IGl0ZXJhYmxlW2ldLCBuZXh0LmRvbmUgPSAhMSwgbmV4dDsgcmV0dXJuIG5leHQudmFsdWUgPSB1bmRlZmluZWQsIG5leHQuZG9uZSA9ICEwLCBuZXh0OyB9OyByZXR1cm4gbmV4dC5uZXh0ID0gbmV4dDsgfSB9IHJldHVybiB7IG5leHQ6IGRvbmVSZXN1bHQgfTsgfSBmdW5jdGlvbiBkb25lUmVzdWx0KCkgeyByZXR1cm4geyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiAhMCB9OyB9IHJldHVybiBHZW5lcmF0b3JGdW5jdGlvbi5wcm90b3R5cGUgPSBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSwgZGVmaW5lUHJvcGVydHkoR3AsIFwiY29uc3RydWN0b3JcIiwgeyB2YWx1ZTogR2VuZXJhdG9yRnVuY3Rpb25Qcm90b3R5cGUsIGNvbmZpZ3VyYWJsZTogITAgfSksIGRlZmluZVByb3BlcnR5KEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlLCBcImNvbnN0cnVjdG9yXCIsIHsgdmFsdWU6IEdlbmVyYXRvckZ1bmN0aW9uLCBjb25maWd1cmFibGU6ICEwIH0pLCBHZW5lcmF0b3JGdW5jdGlvbi5kaXNwbGF5TmFtZSA9IGRlZmluZShHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSwgdG9TdHJpbmdUYWdTeW1ib2wsIFwiR2VuZXJhdG9yRnVuY3Rpb25cIiksIGV4cG9ydHMuaXNHZW5lcmF0b3JGdW5jdGlvbiA9IGZ1bmN0aW9uIChnZW5GdW4pIHsgdmFyIGN0b3IgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIGdlbkZ1biAmJiBnZW5GdW4uY29uc3RydWN0b3I7IHJldHVybiAhIWN0b3IgJiYgKGN0b3IgPT09IEdlbmVyYXRvckZ1bmN0aW9uIHx8IFwiR2VuZXJhdG9yRnVuY3Rpb25cIiA9PT0gKGN0b3IuZGlzcGxheU5hbWUgfHwgY3Rvci5uYW1lKSk7IH0sIGV4cG9ydHMubWFyayA9IGZ1bmN0aW9uIChnZW5GdW4pIHsgcmV0dXJuIE9iamVjdC5zZXRQcm90b3R5cGVPZiA/IE9iamVjdC5zZXRQcm90b3R5cGVPZihnZW5GdW4sIEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlKSA6IChnZW5GdW4uX19wcm90b19fID0gR2VuZXJhdG9yRnVuY3Rpb25Qcm90b3R5cGUsIGRlZmluZShnZW5GdW4sIHRvU3RyaW5nVGFnU3ltYm9sLCBcIkdlbmVyYXRvckZ1bmN0aW9uXCIpKSwgZ2VuRnVuLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoR3ApLCBnZW5GdW47IH0sIGV4cG9ydHMuYXdyYXAgPSBmdW5jdGlvbiAoYXJnKSB7IHJldHVybiB7IF9fYXdhaXQ6IGFyZyB9OyB9LCBkZWZpbmVJdGVyYXRvck1ldGhvZHMoQXN5bmNJdGVyYXRvci5wcm90b3R5cGUpLCBkZWZpbmUoQXN5bmNJdGVyYXRvci5wcm90b3R5cGUsIGFzeW5jSXRlcmF0b3JTeW1ib2wsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0pLCBleHBvcnRzLkFzeW5jSXRlcmF0b3IgPSBBc3luY0l0ZXJhdG9yLCBleHBvcnRzLmFzeW5jID0gZnVuY3Rpb24gKGlubmVyRm4sIG91dGVyRm4sIHNlbGYsIHRyeUxvY3NMaXN0LCBQcm9taXNlSW1wbCkgeyB2b2lkIDAgPT09IFByb21pc2VJbXBsICYmIChQcm9taXNlSW1wbCA9IFByb21pc2UpOyB2YXIgaXRlciA9IG5ldyBBc3luY0l0ZXJhdG9yKHdyYXAoaW5uZXJGbiwgb3V0ZXJGbiwgc2VsZiwgdHJ5TG9jc0xpc3QpLCBQcm9taXNlSW1wbCk7IHJldHVybiBleHBvcnRzLmlzR2VuZXJhdG9yRnVuY3Rpb24ob3V0ZXJGbikgPyBpdGVyIDogaXRlci5uZXh0KCkudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7IHJldHVybiByZXN1bHQuZG9uZSA/IHJlc3VsdC52YWx1ZSA6IGl0ZXIubmV4dCgpOyB9KTsgfSwgZGVmaW5lSXRlcmF0b3JNZXRob2RzKEdwKSwgZGVmaW5lKEdwLCB0b1N0cmluZ1RhZ1N5bWJvbCwgXCJHZW5lcmF0b3JcIiksIGRlZmluZShHcCwgaXRlcmF0b3JTeW1ib2wsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0pLCBkZWZpbmUoR3AsIFwidG9TdHJpbmdcIiwgZnVuY3Rpb24gKCkgeyByZXR1cm4gXCJbb2JqZWN0IEdlbmVyYXRvcl1cIjsgfSksIGV4cG9ydHMua2V5cyA9IGZ1bmN0aW9uICh2YWwpIHsgdmFyIG9iamVjdCA9IE9iamVjdCh2YWwpLCBrZXlzID0gW107IGZvciAodmFyIGtleSBpbiBvYmplY3QpIGtleXMucHVzaChrZXkpOyByZXR1cm4ga2V5cy5yZXZlcnNlKCksIGZ1bmN0aW9uIG5leHQoKSB7IGZvciAoOyBrZXlzLmxlbmd0aDspIHsgdmFyIGtleSA9IGtleXMucG9wKCk7IGlmIChrZXkgaW4gb2JqZWN0KSByZXR1cm4gbmV4dC52YWx1ZSA9IGtleSwgbmV4dC5kb25lID0gITEsIG5leHQ7IH0gcmV0dXJuIG5leHQuZG9uZSA9ICEwLCBuZXh0OyB9OyB9LCBleHBvcnRzLnZhbHVlcyA9IHZhbHVlcywgQ29udGV4dC5wcm90b3R5cGUgPSB7IGNvbnN0cnVjdG9yOiBDb250ZXh0LCByZXNldDogZnVuY3Rpb24gcmVzZXQoc2tpcFRlbXBSZXNldCkgeyBpZiAodGhpcy5wcmV2ID0gMCwgdGhpcy5uZXh0ID0gMCwgdGhpcy5zZW50ID0gdGhpcy5fc2VudCA9IHVuZGVmaW5lZCwgdGhpcy5kb25lID0gITEsIHRoaXMuZGVsZWdhdGUgPSBudWxsLCB0aGlzLm1ldGhvZCA9IFwibmV4dFwiLCB0aGlzLmFyZyA9IHVuZGVmaW5lZCwgdGhpcy50cnlFbnRyaWVzLmZvckVhY2gocmVzZXRUcnlFbnRyeSksICFza2lwVGVtcFJlc2V0KSBmb3IgKHZhciBuYW1lIGluIHRoaXMpIFwidFwiID09PSBuYW1lLmNoYXJBdCgwKSAmJiBoYXNPd24uY2FsbCh0aGlzLCBuYW1lKSAmJiAhaXNOYU4oK25hbWUuc2xpY2UoMSkpICYmICh0aGlzW25hbWVdID0gdW5kZWZpbmVkKTsgfSwgc3RvcDogZnVuY3Rpb24gc3RvcCgpIHsgdGhpcy5kb25lID0gITA7IHZhciByb290UmVjb3JkID0gdGhpcy50cnlFbnRyaWVzWzBdLmNvbXBsZXRpb247IGlmIChcInRocm93XCIgPT09IHJvb3RSZWNvcmQudHlwZSkgdGhyb3cgcm9vdFJlY29yZC5hcmc7IHJldHVybiB0aGlzLnJ2YWw7IH0sIGRpc3BhdGNoRXhjZXB0aW9uOiBmdW5jdGlvbiBkaXNwYXRjaEV4Y2VwdGlvbihleGNlcHRpb24pIHsgaWYgKHRoaXMuZG9uZSkgdGhyb3cgZXhjZXB0aW9uOyB2YXIgY29udGV4dCA9IHRoaXM7IGZ1bmN0aW9uIGhhbmRsZShsb2MsIGNhdWdodCkgeyByZXR1cm4gcmVjb3JkLnR5cGUgPSBcInRocm93XCIsIHJlY29yZC5hcmcgPSBleGNlcHRpb24sIGNvbnRleHQubmV4dCA9IGxvYywgY2F1Z2h0ICYmIChjb250ZXh0Lm1ldGhvZCA9IFwibmV4dFwiLCBjb250ZXh0LmFyZyA9IHVuZGVmaW5lZCksICEhY2F1Z2h0OyB9IGZvciAodmFyIGkgPSB0aGlzLnRyeUVudHJpZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHsgdmFyIGVudHJ5ID0gdGhpcy50cnlFbnRyaWVzW2ldLCByZWNvcmQgPSBlbnRyeS5jb21wbGV0aW9uOyBpZiAoXCJyb290XCIgPT09IGVudHJ5LnRyeUxvYykgcmV0dXJuIGhhbmRsZShcImVuZFwiKTsgaWYgKGVudHJ5LnRyeUxvYyA8PSB0aGlzLnByZXYpIHsgdmFyIGhhc0NhdGNoID0gaGFzT3duLmNhbGwoZW50cnksIFwiY2F0Y2hMb2NcIiksIGhhc0ZpbmFsbHkgPSBoYXNPd24uY2FsbChlbnRyeSwgXCJmaW5hbGx5TG9jXCIpOyBpZiAoaGFzQ2F0Y2ggJiYgaGFzRmluYWxseSkgeyBpZiAodGhpcy5wcmV2IDwgZW50cnkuY2F0Y2hMb2MpIHJldHVybiBoYW5kbGUoZW50cnkuY2F0Y2hMb2MsICEwKTsgaWYgKHRoaXMucHJldiA8IGVudHJ5LmZpbmFsbHlMb2MpIHJldHVybiBoYW5kbGUoZW50cnkuZmluYWxseUxvYyk7IH0gZWxzZSBpZiAoaGFzQ2F0Y2gpIHsgaWYgKHRoaXMucHJldiA8IGVudHJ5LmNhdGNoTG9jKSByZXR1cm4gaGFuZGxlKGVudHJ5LmNhdGNoTG9jLCAhMCk7IH0gZWxzZSB7IGlmICghaGFzRmluYWxseSkgdGhyb3cgbmV3IEVycm9yKFwidHJ5IHN0YXRlbWVudCB3aXRob3V0IGNhdGNoIG9yIGZpbmFsbHlcIik7IGlmICh0aGlzLnByZXYgPCBlbnRyeS5maW5hbGx5TG9jKSByZXR1cm4gaGFuZGxlKGVudHJ5LmZpbmFsbHlMb2MpOyB9IH0gfSB9LCBhYnJ1cHQ6IGZ1bmN0aW9uIGFicnVwdCh0eXBlLCBhcmcpIHsgZm9yICh2YXIgaSA9IHRoaXMudHJ5RW50cmllcy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkgeyB2YXIgZW50cnkgPSB0aGlzLnRyeUVudHJpZXNbaV07IGlmIChlbnRyeS50cnlMb2MgPD0gdGhpcy5wcmV2ICYmIGhhc093bi5jYWxsKGVudHJ5LCBcImZpbmFsbHlMb2NcIikgJiYgdGhpcy5wcmV2IDwgZW50cnkuZmluYWxseUxvYykgeyB2YXIgZmluYWxseUVudHJ5ID0gZW50cnk7IGJyZWFrOyB9IH0gZmluYWxseUVudHJ5ICYmIChcImJyZWFrXCIgPT09IHR5cGUgfHwgXCJjb250aW51ZVwiID09PSB0eXBlKSAmJiBmaW5hbGx5RW50cnkudHJ5TG9jIDw9IGFyZyAmJiBhcmcgPD0gZmluYWxseUVudHJ5LmZpbmFsbHlMb2MgJiYgKGZpbmFsbHlFbnRyeSA9IG51bGwpOyB2YXIgcmVjb3JkID0gZmluYWxseUVudHJ5ID8gZmluYWxseUVudHJ5LmNvbXBsZXRpb24gOiB7fTsgcmV0dXJuIHJlY29yZC50eXBlID0gdHlwZSwgcmVjb3JkLmFyZyA9IGFyZywgZmluYWxseUVudHJ5ID8gKHRoaXMubWV0aG9kID0gXCJuZXh0XCIsIHRoaXMubmV4dCA9IGZpbmFsbHlFbnRyeS5maW5hbGx5TG9jLCBDb250aW51ZVNlbnRpbmVsKSA6IHRoaXMuY29tcGxldGUocmVjb3JkKTsgfSwgY29tcGxldGU6IGZ1bmN0aW9uIGNvbXBsZXRlKHJlY29yZCwgYWZ0ZXJMb2MpIHsgaWYgKFwidGhyb3dcIiA9PT0gcmVjb3JkLnR5cGUpIHRocm93IHJlY29yZC5hcmc7IHJldHVybiBcImJyZWFrXCIgPT09IHJlY29yZC50eXBlIHx8IFwiY29udGludWVcIiA9PT0gcmVjb3JkLnR5cGUgPyB0aGlzLm5leHQgPSByZWNvcmQuYXJnIDogXCJyZXR1cm5cIiA9PT0gcmVjb3JkLnR5cGUgPyAodGhpcy5ydmFsID0gdGhpcy5hcmcgPSByZWNvcmQuYXJnLCB0aGlzLm1ldGhvZCA9IFwicmV0dXJuXCIsIHRoaXMubmV4dCA9IFwiZW5kXCIpIDogXCJub3JtYWxcIiA9PT0gcmVjb3JkLnR5cGUgJiYgYWZ0ZXJMb2MgJiYgKHRoaXMubmV4dCA9IGFmdGVyTG9jKSwgQ29udGludWVTZW50aW5lbDsgfSwgZmluaXNoOiBmdW5jdGlvbiBmaW5pc2goZmluYWxseUxvYykgeyBmb3IgKHZhciBpID0gdGhpcy50cnlFbnRyaWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7IHZhciBlbnRyeSA9IHRoaXMudHJ5RW50cmllc1tpXTsgaWYgKGVudHJ5LmZpbmFsbHlMb2MgPT09IGZpbmFsbHlMb2MpIHJldHVybiB0aGlzLmNvbXBsZXRlKGVudHJ5LmNvbXBsZXRpb24sIGVudHJ5LmFmdGVyTG9jKSwgcmVzZXRUcnlFbnRyeShlbnRyeSksIENvbnRpbnVlU2VudGluZWw7IH0gfSwgXCJjYXRjaFwiOiBmdW5jdGlvbiBfY2F0Y2godHJ5TG9jKSB7IGZvciAodmFyIGkgPSB0aGlzLnRyeUVudHJpZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHsgdmFyIGVudHJ5ID0gdGhpcy50cnlFbnRyaWVzW2ldOyBpZiAoZW50cnkudHJ5TG9jID09PSB0cnlMb2MpIHsgdmFyIHJlY29yZCA9IGVudHJ5LmNvbXBsZXRpb247IGlmIChcInRocm93XCIgPT09IHJlY29yZC50eXBlKSB7IHZhciB0aHJvd24gPSByZWNvcmQuYXJnOyByZXNldFRyeUVudHJ5KGVudHJ5KTsgfSByZXR1cm4gdGhyb3duOyB9IH0gdGhyb3cgbmV3IEVycm9yKFwiaWxsZWdhbCBjYXRjaCBhdHRlbXB0XCIpOyB9LCBkZWxlZ2F0ZVlpZWxkOiBmdW5jdGlvbiBkZWxlZ2F0ZVlpZWxkKGl0ZXJhYmxlLCByZXN1bHROYW1lLCBuZXh0TG9jKSB7IHJldHVybiB0aGlzLmRlbGVnYXRlID0geyBpdGVyYXRvcjogdmFsdWVzKGl0ZXJhYmxlKSwgcmVzdWx0TmFtZTogcmVzdWx0TmFtZSwgbmV4dExvYzogbmV4dExvYyB9LCBcIm5leHRcIiA9PT0gdGhpcy5tZXRob2QgJiYgKHRoaXMuYXJnID0gdW5kZWZpbmVkKSwgQ29udGludWVTZW50aW5lbDsgfSB9LCBleHBvcnRzOyB9XG5mdW5jdGlvbiBhc3luY0dlbmVyYXRvclN0ZXAoZ2VuLCByZXNvbHZlLCByZWplY3QsIF9uZXh0LCBfdGhyb3csIGtleSwgYXJnKSB7IHRyeSB7IHZhciBpbmZvID0gZ2VuW2tleV0oYXJnKTsgdmFyIHZhbHVlID0gaW5mby52YWx1ZTsgfSBjYXRjaCAoZXJyb3IpIHsgcmVqZWN0KGVycm9yKTsgcmV0dXJuOyB9IGlmIChpbmZvLmRvbmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0gZWxzZSB7IFByb21pc2UucmVzb2x2ZSh2YWx1ZSkudGhlbihfbmV4dCwgX3Rocm93KTsgfSB9XG5mdW5jdGlvbiBfYXN5bmNUb0dlbmVyYXRvcihmbikgeyByZXR1cm4gZnVuY3Rpb24gKCkgeyB2YXIgc2VsZiA9IHRoaXMsIGFyZ3MgPSBhcmd1bWVudHM7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHZhciBnZW4gPSBmbi5hcHBseShzZWxmLCBhcmdzKTsgZnVuY3Rpb24gX25leHQodmFsdWUpIHsgYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBcIm5leHRcIiwgdmFsdWUpOyB9IGZ1bmN0aW9uIF90aHJvdyhlcnIpIHsgYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBcInRocm93XCIsIGVycik7IH0gX25leHQodW5kZWZpbmVkKTsgfSk7IH07IH1cbmV4cG9ydCBkZWZhdWx0IHtcbiAgX19uYW1lOiAncmlnaHRGb3JtJyxcbiAgZW1pdHM6IFtcImNoYW5nZUFjdGl2ZU5vZGVJbmZvXCIsIFwiZGVsZXRlTGluZVwiLCBcImRlbGV0ZU5vZGVcIl0sXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlLFxuICAgICAgZW1pdCA9IF9yZWYuZW1pdDtcbiAgICB2YXIgZm9ybURhdGEgPSByZWYoW10pO1xuICAgIHZhciBsaW5lRGF0YSA9IHJlZih7fSk7XG4gICAgdmFyIGZvcm1TaXplID0gcmVmKFwiZGVmYXVsdFwiKTtcbiAgICB2YXIgcnVsZUZvcm1SZWYgPSByZWYoKTtcbiAgICB2YXIgbGlzdFNob3cgPSByZWYoZmFsc2UpO1xuICAgIHZhciBydWxlRm9ybSA9IHJlYWN0aXZlKHt9KTtcbiAgICB2YXIgaW5mb1R5cGUgPSByZWYoXCJub2RlXCIpO1xuICAgIHZhciBydWxlcyA9IHJlYWN0aXZlKHtcbiAgICAgIGxhYmVsOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLoioLngrnlkI3np7DkuLrlv4XovpPpoblcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH0sIHtcbiAgICAgICAgbWluOiA0LFxuICAgICAgICBtYXg6IDgsXG4gICAgICAgIG1lc3NhZ2U6IFwi6K+36L6T5YWlNOiHszjkuYvpl7TnmoTlrZfnrKZcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH1dLFxuICAgICAgYWZmaWxpYXRpb246IFt7XG4gICAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIuivt+mAieaLqeW9kuWxnumhuVwiLFxuICAgICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiXG4gICAgICB9XVxuICAgIH0pO1xuICAgIHZhciBzdWJtaXRGb3JtID0gLyojX19QVVJFX18qL2Z1bmN0aW9uICgpIHtcbiAgICAgIHZhciBfcmVmMiA9IF9hc3luY1RvR2VuZXJhdG9yKCAvKiNfX1BVUkVfXyovX3JlZ2VuZXJhdG9yUnVudGltZSgpLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShmb3JtRWwpIHtcbiAgICAgICAgcmV0dXJuIF9yZWdlbmVyYXRvclJ1bnRpbWUoKS53cmFwKGZ1bmN0aW9uIF9jYWxsZWUkKF9jb250ZXh0KSB7XG4gICAgICAgICAgd2hpbGUgKDEpIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgaWYgKGZvcm1FbCkge1xuICAgICAgICAgICAgICAgIF9jb250ZXh0Lm5leHQgPSAyO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIik7XG4gICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgIF9jb250ZXh0Lm5leHQgPSA0O1xuICAgICAgICAgICAgICByZXR1cm4gZm9ybUVsLnZhbGlkYXRlKGZ1bmN0aW9uICh2YWxpZCwgZmllbGRzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh2YWxpZCwgcnVsZUZvcm0pO1xuICAgICAgICAgICAgICAgICAgZm9ybURhdGEudmFsdWUuZm9yRWFjaChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnZhbHVlID0gcnVsZUZvcm1baXRlbS5uYW1lXTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgZW1pdChcImNoYW5nZUFjdGl2ZU5vZGVJbmZvXCIsIGZvcm1EYXRhLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBzdWJtaXQhXCIsIGZpZWxkcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNhc2UgNDpcbiAgICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIF9jYWxsZWUpO1xuICAgICAgfSkpO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uIHN1Ym1pdEZvcm0oX3gpIHtcbiAgICAgICAgcmV0dXJuIF9yZWYyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICB9O1xuICAgIH0oKTtcbiAgICB2YXIgcmVzZXRGb3JtID0gZnVuY3Rpb24gcmVzZXRGb3JtKGZvcm1FbCkge1xuICAgICAgaWYgKCFmb3JtRWwpIHJldHVybjtcbiAgICAgIGZvcm1FbC5yZXNldEZpZWxkcygpO1xuICAgIH07XG4gICAgdmFyIG9wdGlvbnMgPSBBcnJheS5mcm9tKHtcbiAgICAgIGxlbmd0aDogMTAwMDBcbiAgICB9KS5tYXAoZnVuY3Rpb24gKF8sIGlkeCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFwiXCIuY29uY2F0KGlkeCArIDEpLFxuICAgICAgICBsYWJlbDogXCJcIi5jb25jYXQoaWR4ICsgMSlcbiAgICAgIH07XG4gICAgfSk7XG4gICAgdmFyIGdldEZvcm1EYXRhID0gZnVuY3Rpb24gZ2V0Rm9ybURhdGEoKSB7XG4gICAgICBjb25zb2xlLmxvZyhmb3JtRGF0YSwgXCLkv6Hmga9cIik7XG4gICAgfTtcbiAgICAvL+eItuiKgueCueS8oOmAkuS/oeaBr+WHveaVsFxuICAgIHZhciBjaGFuZ2VGb3JtRGF0YSA9IGZ1bmN0aW9uIGNoYW5nZUZvcm1EYXRhKHZhbCkge1xuICAgICAgaW5mb1R5cGUudmFsdWUgPSBcIm5vZGVcIjtcbiAgICAgIGxpc3RTaG93LnZhbHVlID0gdHJ1ZTtcbiAgICAgIGNvbnNvbGUubG9nKHZhbCk7XG4gICAgICBmb3JtRGF0YS52YWx1ZSA9IHZhbDtcbiAgICAgIGZvcm1EYXRhLnZhbHVlLmZvckVhY2goZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgY29uc29sZS5sb2coaXRlbSwgXCLpgY3ljoZcIik7XG4gICAgICAgIHJ1bGVGb3JtW2l0ZW0ubmFtZV0gPSBpdGVtLnZhbHVlO1xuICAgICAgfSk7XG4gICAgICBjb25zb2xlLmxvZyhydWxlRm9ybSwgXCI/Pz9cIik7XG4gICAgfTtcbiAgICAvL+eItuiKgueCueS8oOmAkui/nue6v+S/oeaBr1xuICAgIHZhciBnZXRMaW5lSW5mbyA9IGZ1bmN0aW9uIGdldExpbmVJbmZvKGxpbmVJbmZvKSB7XG4gICAgICBsaXN0U2hvdy52YWx1ZSA9IHRydWU7XG4gICAgICBjb25zb2xlLmxvZyhsaW5lSW5mbywgXCLov57nur/kv6Hmga9cIik7XG4gICAgICBpbmZvVHlwZS52YWx1ZSA9IFwibGluZVwiO1xuICAgICAgbGluZURhdGEudmFsdWUgPSBsaW5lSW5mbztcbiAgICB9O1xuICAgIC8v5Yig6Zmk6L+e57q/5L+h5oGvXG4gICAgdmFyIGRlbGV0ZUxpbmVGdW4gPSBmdW5jdGlvbiBkZWxldGVMaW5lRnVuKCkge1xuICAgICAgZW1pdChcImRlbGV0ZUxpbmVcIiwgbGluZURhdGEudmFsdWUpO1xuICAgICAgaW5mb1R5cGUudmFsdWUgPSBudWxsO1xuICAgIH07XG4gICAgLy/liKDpmaToioLngrlcbiAgICB2YXIgZGVsdGVOb2RlRnVuID0gZnVuY3Rpb24gZGVsdGVOb2RlRnVuKCkge1xuICAgICAgZW1pdChcImRlbGV0ZU5vZGVcIik7XG4gICAgfTtcbiAgICBvbk1vdW50ZWQoZnVuY3Rpb24gKCkge30pO1xuICAgIGV4cG9zZSh7XG4gICAgICBjaGFuZ2VGb3JtRGF0YTogY2hhbmdlRm9ybURhdGEsXG4gICAgICBnZXRMaW5lSW5mbzogZ2V0TGluZUluZm8sXG4gICAgICBmb3JtRGF0YTogZm9ybURhdGFcbiAgICB9KTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgZ2V0IGZvcm1EYXRhKCkge1xuICAgICAgICByZXR1cm4gZm9ybURhdGE7XG4gICAgICB9LFxuICAgICAgc2V0IGZvcm1EYXRhKHYpIHtcbiAgICAgICAgZm9ybURhdGEgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBsaW5lRGF0YSgpIHtcbiAgICAgICAgcmV0dXJuIGxpbmVEYXRhO1xuICAgICAgfSxcbiAgICAgIHNldCBsaW5lRGF0YSh2KSB7XG4gICAgICAgIGxpbmVEYXRhID0gdjtcbiAgICAgIH0sXG4gICAgICBmb3JtU2l6ZTogZm9ybVNpemUsXG4gICAgICBydWxlRm9ybVJlZjogcnVsZUZvcm1SZWYsXG4gICAgICBsaXN0U2hvdzogbGlzdFNob3csXG4gICAgICBnZXQgcnVsZUZvcm0oKSB7XG4gICAgICAgIHJldHVybiBydWxlRm9ybTtcbiAgICAgIH0sXG4gICAgICBzZXQgcnVsZUZvcm0odikge1xuICAgICAgICBydWxlRm9ybSA9IHY7XG4gICAgICB9LFxuICAgICAgaW5mb1R5cGU6IGluZm9UeXBlLFxuICAgICAgZW1pdDogZW1pdCxcbiAgICAgIHJ1bGVzOiBydWxlcyxcbiAgICAgIHN1Ym1pdEZvcm06IHN1Ym1pdEZvcm0sXG4gICAgICByZXNldEZvcm06IHJlc2V0Rm9ybSxcbiAgICAgIG9wdGlvbnM6IG9wdGlvbnMsXG4gICAgICBnZXRGb3JtRGF0YTogZ2V0Rm9ybURhdGEsXG4gICAgICBjaGFuZ2VGb3JtRGF0YTogY2hhbmdlRm9ybURhdGEsXG4gICAgICBnZXRMaW5lSW5mbzogZ2V0TGluZUluZm8sXG4gICAgICBkZWxldGVMaW5lRnVuOiBkZWxldGVMaW5lRnVuLFxuICAgICAgZGVsdGVOb2RlRnVuOiBkZWx0ZU5vZGVGdW5cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCJpbXBvcnQgeyBqc1BsdW1iIH0gZnJvbSBcImpzcGx1bWJcIjtcbmltcG9ydCB7IFZ1ZURyYWdnYWJsZU5leHQgfSBmcm9tIFwidnVlLWRyYWdnYWJsZS1uZXh0XCI7XG5pbXBvcnQgeyBFbE1lc3NhZ2UgfSBmcm9tIFwiZWxlbWVudC1wbHVzXCI7XG5pbXBvcnQgbG9kYXNoIGZyb20gXCJsb2Rhc2hcIjtcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XG5pbXBvcnQgeyByZWFjdGl2ZSB9IGZyb20gXCJ2dWVcIjtcbmltcG9ydCB3b3JkIGZyb20gXCJAL2RpY3Rpb25hcmllcy9idXNpbmVzcy5qc29uXCI7XG5pbXBvcnQgUmlnaHRGb3JtIGZyb20gXCIuL3JpZ2h0Rm9ybVwiO1xuLy/lkI3np7Dlkozop4TojINcblxuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICd2aXN1YWwnLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICAvL+W8leWFpWpzUGx1bWJcbiAgICBjb25zb2xlLmxvZyh0eXBlT3B0aW9ucywgJ+S4i+aLieahhuexu+WeiycpO1xuICAgIHZhciB0eXBlT3B0aW9ucyA9IHdvcmQudHlwZU9wdGlvbnM7XG4gICAgdmFyIHNjZW5hcmlvX25hbWUgPSByZWYoXCJcIik7XG4gICAgdmFyIG1vZGVfdHlwZSA9IHJlZihcIlwiKTtcbiAgICB2YXIgZG9uZUZsYWcgPSByZWYoXCJuZXdcIik7XG4gICAgLy/mi5bmi73nu4Tku7blrp7kvotcbiAgICB2YXIgZHJhZ2dhYmxlID0gVnVlRHJhZ2dhYmxlTmV4dDtcbiAgICB2YXIgcGx1bWJCb3ggPSBudWxsO1xuICAgIHZhciBwbHVtYkJveFBvc2l0aW9uSW5mbyA9IHJlYWN0aXZlKHt9KTtcbiAgICAvL+m8oOagh+WSjOiKgueCueeahOWGhemDqOW3rui3nSzkuLrkuoborqnoioLngrnmm7Tnsr7lh4bnmoTliKTmlq3ljLrln59cbiAgICB2YXIgbm9kZVBvc2l0aW9uRGlmZiA9IHJlYWN0aXZlKHt9KTtcbiAgICAvL+WQjumdoumcgOimgeWbnuS8oOe7meeItue7hOS7tueahOWAvFxuICAgIHZhciBwbHVtYkxpc3QgPSByZWYoW10pO1xuICAgIC8v57uY5Yi25qCH6K+GXG4gICAgdmFyIHJlbmRlckZsYWcgPSByZWYodW5kZWZpbmVkKTtcbiAgICAvL+WKqOaAgeiKgueCuVxuICAgIHZhciBhY3RpdmVOb2RlID0gcmVmKHt9KTtcbiAgICB2YXIgcmlnaHRGb3JtID0gcmVmKG51bGwpO1xuICAgIC8qXHJcbiAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAvL+i/nue6v+WfuuehgOmFjee9rlxyXG4gICAgbGV0IGpzUGx1bWJDb25uZWN0T3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgaXNTb3VyY2U6IHRydWUsXHJcbiAgICAgICAgICAgIGlzVGFyZ2V0OiB0cnVlLFxyXG4gICAgICAgICAgICAvLyDliqjmgIHplJrngrnjgIHmj5DkvpvkuoY05Liq5pa55ZCRIENvbnRpbnVvdXPjgIFBdXRvRGVmYXVsdFxyXG4gICAgICAgICAgICBhbmNob3I6IFtcIkNvbnRpbnVvdXNcIix7c2hhcGU6XCJDaXJjbGVcIn1dLFxyXG4gICAgICAgICAgICBvdmVybGF5czogW1snQXJyb3cnLCB7IHdpZHRoOiA4LCBsZW5ndGg6IDgsIGxvY2F0aW9uOiAxIH1dXSAvLyBvdmVybGF5XHJcbiAgICAgICAgICB9XHJcbiAgICAvL+eUu+W4g+iKgueCueeahOaLluaLvei/nue6v+mFjee9rlxyXG4gICAgY29uc3QganNwbHVtYlNvdXJjZU9wdGlvbnMgPSB7XHJcbiAgICAgIGZpbHRlcjonLnBsdW1iTm9kZScsXHJcbiAgICAgIGZpbHRlckV4Y2x1ZGU6ZmFsc2UsXHJcbiAgICAgIGFuY2hvcjonQ29udGludW91cycsXHJcbiAgICAgIGFsbG93TG9vcGJhY2s6dHJ1ZSxcclxuICAgICAgbWF4Q29ubmVjdGlvbnM6IC0xLFxyXG4gICAgICBvbk1heENvbm5lY3Rpb25zOmZ1bmN0aW9uIChpbmZvLGUpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGDotoXov4fkuobmnIDlpKflgLzov57nur86JHtpbmZvLm1heENvbm5lY3Rpb25zfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICovXG4gICAgLy/kv67mlLlcbiAgICB2YXIgZG9uZVR5cGUgPSBmdW5jdGlvbiBkb25lVHlwZShmbGFnLCByb3cpIHtcbiAgICAgIGRvbmVGbGFnLnZhbHVlID0gZmxhZztcbiAgICAgIGlmIChyb3cpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCI/Pz9cIiwgcm93KTtcbiAgICAgICAgc2NlbmFyaW9fbmFtZS52YWx1ZSA9IHJvdy5zY2VuYXJpb05hbWU7XG4gICAgICAgIG1vZGVfdHlwZS52YWx1ZSA9IHJvdy5tb2RlVHlwZTtcbiAgICAgICAgaW5mby52YWx1ZSA9IHJvdy5mbG93SW5mbztcbiAgICAgIH1cbiAgICB9O1xuICAgIC8v5bem5L6n6I+c5Y2V6IqC54K555qE5ouW5ou96YWN572uXG4gICAgdmFyIG9wdGlvbnMgPSB7XG4gICAgICBwcmV2ZW50T25GaWx0ZXI6IGZhbHNlLFxuICAgICAgc29ydDogZmFsc2UsXG4gICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICBnaG9zdENsYXNzOiBcInR0XCIsXG4gICAgICAvLyDkuI3kvb/nlKhINeWOn+eUn+eahOmFjee9rlxuICAgICAgZm9yY2VGYWxsYmFjazogdHJ1ZVxuICAgIH07XG4gICAgLy/pu5jorqTphY3nva5cbiAgICB2YXIgZ2xvYmFsQ29uZmlnID0ge1xuICAgICAgQ29udGFpbmVyOiBcInBsdW1iQm94XCIsXG4gICAgICBhbmNob3I6IFtcIkJvdHRvbVwiLCBcIlRvcFwiLCBcIkxlZnRcIiwgXCJSaWdodFwiXSxcbiAgICAgIGNvbm5lY3RvcjogXCJCZXppZXJcIixcbiAgICAgIGVuZHBvaW50OiBcIkJsYW5rXCIsXG4gICAgICBwYWludFN0eWxlOiB7XG4gICAgICAgIHN0cm9rZTogXCIjMzY0MjQ5XCIsXG4gICAgICAgIHN0cm9rZVdpZHRoOiAxLFxuICAgICAgICBvdXRsaW5lU3Ryb2tlOiBcInRyYW5zcGFyZW50XCIsXG4gICAgICAgIG91dGxpbmVXaWR0aDogMTBcbiAgICAgIH0sXG4gICAgICBob3ZlclBhaW50U3R5bGU6IHtcbiAgICAgICAgc3Ryb2tlOiBcIiMwMDBcIixcbiAgICAgICAgc3Ryb2tlV2lkdGg6IDEuM1xuICAgICAgfSxcbiAgICAgIG92ZXJsYXlzOiBbW1wiQXJyb3dcIiwge1xuICAgICAgICB3aWR0aDogNSxcbiAgICAgICAgbGVuZ3RoOiA1LFxuICAgICAgICBsb2NhdGlvbjogMVxuICAgICAgfV1dLFxuICAgICAgZW5kcG9pbnRTdHlsZToge1xuICAgICAgICBmaWxsOiBcImxpZ2h0Z3JheVwiLFxuICAgICAgICBvdXRsaW5lU3Ryb2tlOiBcImRhcmtncmF5XCIsXG4gICAgICAgIG91dGxpbmVXaWR0aDogMlxuICAgICAgfVxuICAgIH07XG4gICAgLy/lt6bkvqdcbiAgICB2YXIgbGVmdE1lbnVEYXRhID0gcmVmKFt7XG4gICAgICBuYW1lOiBcIui1t+Wni+WIl+ihqFwiLFxuICAgICAgY2hpbGRyZW46IFt7XG4gICAgICAgIHRvOiBbXSxcbiAgICAgICAgdG9wOiAwLFxuICAgICAgICBsZWZ0OiAwLFxuICAgICAgICBzdGF0dXM6IFwibG9hZGluZ1wiLFxuICAgICAgICBpc1NvdXJjZTogdHJ1ZSxcbiAgICAgICAgaXNUYXJnZXQ6IGZhbHNlLFxuICAgICAgICBjb25maWc6IFt7XG4gICAgICAgICAgbGFiZWw6IFwi5ZCN56ewXCIsXG4gICAgICAgICAgbmFtZTogXCJsYWJlbFwiLFxuICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxuICAgICAgICAgIHZhbHVlOiBcIui1t+Wni+iKgueCuTFcIixcbiAgICAgICAgICByZXF1aXJlOiB0cnVlXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBsYWJlbDogXCLmj4/ov7BcIixcbiAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXG4gICAgICAgICAgdHlwZTogXCJ0ZXh0YXJlYVwiLFxuICAgICAgICAgIHZhbHVlOiBcIlwiLFxuICAgICAgICAgIHJlcXVpcmU6IGZhbHNlXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBsYWJlbDogXCLlvZLlsZ5cIixcbiAgICAgICAgICBuYW1lOiBcImFmZmlsaWF0aW9uXCIsXG4gICAgICAgICAgdHlwZTogXCJzZWxlY3RcIixcbiAgICAgICAgICB2YWx1ZTogXCJjaGVja1wiLFxuICAgICAgICAgIHJlcXVpcmU6IHRydWUsXG4gICAgICAgICAgb3B0aW9uczogW3tcbiAgICAgICAgICAgIGxhYmVsOiBcIuWuoeaguOS/oeaBr1wiLFxuICAgICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIlxuICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgIGxhYmVsOiBcIueUn+S6p+e7j+iQpVwiLFxuICAgICAgICAgICAgdmFsdWU6IFwibWFuYWdlXCJcbiAgICAgICAgICB9LCB7XG4gICAgICAgICAgICBsYWJlbDogXCLnu5PnrpfmiqXplIBcIixcbiAgICAgICAgICAgIHZhbHVlOiBcImFjY291bnRcIlxuICAgICAgICAgIH1dXG4gICAgICAgIH1dXG4gICAgICB9LCB7XG4gICAgICAgIHRvOiBbXSxcbiAgICAgICAgdG9wOiAwLFxuICAgICAgICBsZWZ0OiAwLFxuICAgICAgICBzdGF0dXM6IFwibG9hZGluZ1wiLFxuICAgICAgICBpc1NvdXJjZTogdHJ1ZSxcbiAgICAgICAgaXNUYXJnZXQ6IHRydWUsXG4gICAgICAgIGNvbmZpZzogW3tcbiAgICAgICAgICBsYWJlbDogXCLlkI3np7BcIixcbiAgICAgICAgICBuYW1lOiBcImxhYmVsXCIsXG4gICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXG4gICAgICAgICAgdmFsdWU6IFwi6LW35aeL6IqC54K5MlwiLFxuICAgICAgICAgIHJlcXVpcmU6IHRydWVcbiAgICAgICAgfSwge1xuICAgICAgICAgIGxhYmVsOiBcIuaPj+i/sFwiLFxuICAgICAgICAgIG5hbWU6IFwiZGVzY3JpcHRpb25cIixcbiAgICAgICAgICB0eXBlOiBcInRleHRhcmVhXCIsXG4gICAgICAgICAgdmFsdWU6IFwiXCIsXG4gICAgICAgICAgcmVxdWlyZTogZmFsc2VcbiAgICAgICAgfSwge1xuICAgICAgICAgIGxhYmVsOiBcIuW9kuWxnlwiLFxuICAgICAgICAgIG5hbWU6IFwiYWZmaWxpYXRpb25cIixcbiAgICAgICAgICB0eXBlOiBcInNlbGVjdFwiLFxuICAgICAgICAgIHZhbHVlOiBcImNoZWNrXCIsXG4gICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcbiAgICAgICAgICBvcHRpb25zOiBbe1xuICAgICAgICAgICAgbGFiZWw6IFwi5a6h5qC45L+h5oGvXCIsXG4gICAgICAgICAgICB2YWx1ZTogXCJjaGVja1wiXG4gICAgICAgICAgfSwge1xuICAgICAgICAgICAgbGFiZWw6IFwi55Sf5Lqn57uP6JClXCIsXG4gICAgICAgICAgICB2YWx1ZTogXCJtYW5hZ2VcIlxuICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgIGxhYmVsOiBcIue7k+eul+aKpemUgFwiLFxuICAgICAgICAgICAgdmFsdWU6IFwiYWNjb3VudFwiXG4gICAgICAgICAgfV1cbiAgICAgICAgfV1cbiAgICAgIH1dXG4gICAgfSwge1xuICAgICAgbmFtZTogXCLlroznu5PliJfooahcIixcbiAgICAgIGNoaWxkcmVuOiBbe1xuICAgICAgICB0bzogW10sXG4gICAgICAgIHRvcDogMCxcbiAgICAgICAgbGVmdDogMCxcbiAgICAgICAgc3RhdHVzOiBcImxvYWRpbmdcIixcbiAgICAgICAgdHlwZTogXCJ0YXJnZXRcIixcbiAgICAgICAgaXNTb3VyY2U6IGZhbHNlLFxuICAgICAgICBpc1RhcmdldDogZmFsc2UsXG4gICAgICAgIGNvbmZpZzogW3tcbiAgICAgICAgICBsYWJlbDogXCLlkI3np7BcIixcbiAgICAgICAgICBuYW1lOiBcImxhYmVsXCIsXG4gICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXG4gICAgICAgICAgdmFsdWU6IFwi5a6M57uT6IqC54K5MVwiLFxuICAgICAgICAgIHJlcXVpcmU6IHRydWVcbiAgICAgICAgfSwge1xuICAgICAgICAgIGxhYmVsOiBcIuaPj+i/sFwiLFxuICAgICAgICAgIG5hbWU6IFwiZGVzY3JpcHRpb25cIixcbiAgICAgICAgICB0eXBlOiBcInRleHRhcmVhXCIsXG4gICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIixcbiAgICAgICAgICByZXF1aXJlOiBmYWxzZVxuICAgICAgICB9LCB7XG4gICAgICAgICAgbGFiZWw6IFwi5b2S5bGeXCIsXG4gICAgICAgICAgbmFtZTogXCJhZmZpbGlhdGlvblwiLFxuICAgICAgICAgIHR5cGU6IFwic2VsZWN0XCIsXG4gICAgICAgICAgdmFsdWU6IFwiXCIsXG4gICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcbiAgICAgICAgICBvcHRpb25zOiBbe1xuICAgICAgICAgICAgbGFiZWw6IFwi5a6h5qC45L+h5oGvXCIsXG4gICAgICAgICAgICB2YWx1ZTogXCJjaGVja1wiXG4gICAgICAgICAgfSwge1xuICAgICAgICAgICAgbGFiZWw6IFwi55Sf5Lqn57uP6JClXCIsXG4gICAgICAgICAgICB2YWx1ZTogXCJtYW5hZ2VcIlxuICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgIGxhYmVsOiBcIue7k+eul+aKpemUgFwiLFxuICAgICAgICAgICAgdmFsdWU6IFwiYWNjb3VudFwiXG4gICAgICAgICAgfV1cbiAgICAgICAgfV1cbiAgICAgIH0sIHtcbiAgICAgICAgdG86IFtdLFxuICAgICAgICB0b3A6IDAsXG4gICAgICAgIGxlZnQ6IDAsXG4gICAgICAgIHN0YXR1czogXCJsb2FkaW5nXCIsXG4gICAgICAgIGlzU291cmNlOiBmYWxzZSxcbiAgICAgICAgaXNUYXJnZXQ6IGZhbHNlLFxuICAgICAgICBjb25maWc6IFt7XG4gICAgICAgICAgbGFiZWw6IFwi5ZCN56ewXCIsXG4gICAgICAgICAgbmFtZTogXCJsYWJlbFwiLFxuICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxuICAgICAgICAgIHZhbHVlOiBcIuWujOe7k+iKgueCuTJcIixcbiAgICAgICAgICByZXF1aXJlOiB0cnVlXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBsYWJlbDogXCLmj4/ov7BcIixcbiAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXG4gICAgICAgICAgdHlwZTogXCJ0ZXh0YXJlYVwiLFxuICAgICAgICAgIHZhbHVlOiBcIlwiLFxuICAgICAgICAgIHJlcXVpcmU6IGZhbHNlXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBsYWJlbDogXCLlvZLlsZ5cIixcbiAgICAgICAgICBuYW1lOiBcImFmZmlsaWF0aW9uXCIsXG4gICAgICAgICAgdHlwZTogXCJzZWxlY3RcIixcbiAgICAgICAgICB2YWx1ZTogXCJjaGVja1wiLFxuICAgICAgICAgIHJlcXVpcmU6IHRydWUsXG4gICAgICAgICAgb3B0aW9uczogW3tcbiAgICAgICAgICAgIGxhYmVsOiBcIuWuoeaguOS/oeaBr1wiLFxuICAgICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIlxuICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgIGxhYmVsOiBcIueUn+S6p+e7j+iQpVwiLFxuICAgICAgICAgICAgdmFsdWU6IFwibWFuYWdlXCJcbiAgICAgICAgICB9LCB7XG4gICAgICAgICAgICBsYWJlbDogXCLnu5PnrpfmiqXplIBcIixcbiAgICAgICAgICAgIHZhbHVlOiBcImFjY291bnRcIlxuICAgICAgICAgIH1dXG4gICAgICAgIH1dXG4gICAgICB9XVxuICAgIH1dKTtcbiAgICAvL+a4suafk+iKgueCueS/oeaBryjpu5jorqTmmK/lkI7lj7DkvKDov4fmnaXnmoQpXG4gICAgdmFyIGluZm8gPSByZWYoW10pO1xuICAgIC8v5paw5aKe5LiA5Liq6IqC54K5XG4gICAgdmFyIGFkZE5vZGUgPSBmdW5jdGlvbiBhZGROb2RlKG5ld0luZm8pIHtcbiAgICAgIG5ld0luZm8uaWQgPSB1dWlkdjQoKTtcbiAgICAgIG5ld0luZm8gPSBPYmplY3QuYXNzaWduKG5ld0luZm8sIGdsb2JhbENvbmZpZyk7XG4gICAgICBpbmZvLnZhbHVlLnB1c2gobmV3SW5mbyk7XG4gICAgICBjb25zb2xlLmxvZyhuZXdJbmZvLCBcIj8/P+aWsOWinuiKgueCueeahOS/oeaBr1wiKTtcbiAgICAgIC8vIG1ha2VGdW4obmV3SW5mbylcbiAgICAgIG5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmVuZGVyRmxhZy52YWx1ZSA9IFwibmV3XCI7XG4gICAgICAgIG1ha2VGdW4obmV3SW5mbyk7XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgLy/mlrDlop7kuIDmnaHov57nur9cbiAgICB2YXIgYWRkTGluZSA9IGZ1bmN0aW9uIGFkZExpbmUoKSB7XG4gICAgICBpbmZvLnZhbHVlWzNdLnRvID0gW1wiZGl2NlwiXTtcbiAgICAgIHJlbmRlck5vZGUoKTtcbiAgICB9O1xuICAgIHZhciBtb3VzZURvd25GdW4gPSBmdW5jdGlvbiBtb3VzZURvd25GdW4oZXZlbnQpIHtcbiAgICAgIC8v5YW35L2T5L2N572u6byg5qCH5L+h5oGvXG4gICAgICB2YXIgbW91c2Vkb3duUG9zaXRpb25JbmZvID0ge1xuICAgICAgICB4OiBldmVudC5jbGllbnRYLFxuICAgICAgICB5OiBldmVudC5jbGllbnRZXG4gICAgICB9O1xuICAgICAgLy/ooqvmi5bmi73oioLngrnliJ3lp4vnmoTkvY3nva7kv6Hmga9cbiAgICAgIHZhciBtb3ZlQm94QmVmb3JlUG9zaXRpb24gPSB7XG4gICAgICAgIHg6IGV2ZW50LnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS54LFxuICAgICAgICB5OiBldmVudC50YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkueVxuICAgICAgfTtcbiAgICAgIG5vZGVQb3NpdGlvbkRpZmYgPSB7XG4gICAgICAgIGxlZnREaWZmOiBtb3VzZWRvd25Qb3NpdGlvbkluZm8ueCAtIG1vdmVCb3hCZWZvcmVQb3NpdGlvbi54LFxuICAgICAgICB0b3BEaWZmOiBtb3VzZWRvd25Qb3NpdGlvbkluZm8ueSAtIG1vdmVCb3hCZWZvcmVQb3NpdGlvbi55XG4gICAgICB9O1xuICAgIH07XG4gICAgLy/lvIDlp4vmi5bliqhcbiAgICB2YXIgbW92ZVN0YXJ0ID0gZnVuY3Rpb24gbW92ZVN0YXJ0KGVsKSB7XG4gICAgICBjb25zb2xlLmxvZyhlbCwgXCLlvIDlp4vmi5bliqhcIik7XG4gICAgfTtcbiAgICAvL+WBnOatouaLluWKqFxuICAgIHZhciBtb3ZlRW5kID0gZnVuY3Rpb24gbW92ZUVuZChlbCkge1xuICAgICAgcmVmcmVzaFBsdW1iUG9zdGlvbkluZm8oKTtcbiAgICAgIHZhciBkcmFnTm9kZUluZm8gPSBKU09OLnBhcnNlKGVsLml0ZW0uYXR0cmlidXRlcy5kaXZPcHRpb24ubm9kZVZhbHVlKTtcbiAgICAgIGp1ZGdlUG9zaXRpb24oZHJhZ05vZGVJbmZvLCBwbHVtYkJveFBvc2l0aW9uSW5mbywgZWwub3JpZ2luYWxFdmVudC54LCBlbC5vcmlnaW5hbEV2ZW50LnkpO1xuICAgIH07XG4gICAgLy/liKTmlq3mi5bliqjljLrln59cbiAgICB2YXIganVkZ2VQb3NpdGlvbiA9IGZ1bmN0aW9uIGp1ZGdlUG9zaXRpb24oZHJhZ05vZGVJbmZvLCBwbHVtYkJveFBvc2l0aW9uSW5mbywgeCwgeSkge1xuICAgICAgLy/mi5bmi73oh7PnlLvluIPlpJbpg6hcbiAgICAgIGlmICh4IC0gbm9kZVBvc2l0aW9uRGlmZi5sZWZ0RGlmZiA8IHBsdW1iQm94UG9zaXRpb25JbmZvLmxlZnQgfHwgeCArIDE4MCAtIG5vZGVQb3NpdGlvbkRpZmYubGVmdERpZmYgPiBwbHVtYkJveFBvc2l0aW9uSW5mby5yaWdodCB8fCB5IC0gbm9kZVBvc2l0aW9uRGlmZi50b3BEaWZmIDwgcGx1bWJCb3hQb3NpdGlvbkluZm8udG9wIHx8IHkgKyA0MCAtIG5vZGVQb3NpdGlvbkRpZmYudG9wRGlmZiA+IHBsdW1iQm94UG9zaXRpb25JbmZvLmJvdHRvbSkge1xuICAgICAgICBFbE1lc3NhZ2Uoe1xuICAgICAgICAgIG1lc3NhZ2U6IFwi6IqC54K55LiN6IO95ouW5ou96Iez55S75biD5LmL5aSWXCIsXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZHJhZ05vZGVJbmZvLmxlZnQgPSB4IC0gcGx1bWJCb3hQb3NpdGlvbkluZm8ubGVmdCAtIG5vZGVQb3NpdGlvbkRpZmYubGVmdERpZmY7XG4gICAgICAgIGRyYWdOb2RlSW5mby50b3AgPSB5IC0gcGx1bWJCb3hQb3NpdGlvbkluZm8udG9wIC0gbm9kZVBvc2l0aW9uRGlmZi50b3BEaWZmO1xuICAgICAgICBhZGROb2RlKGRyYWdOb2RlSW5mbyk7XG4gICAgICB9XG4gICAgfTtcbiAgICAvL+WIt+aWsOeUu+W4g+WMuuWfn+S/oeaBr1xuICAgIHZhciByZWZyZXNoUGx1bWJQb3N0aW9uSW5mbyA9IGZ1bmN0aW9uIHJlZnJlc2hQbHVtYlBvc3Rpb25JbmZvKCkge1xuICAgICAgcGx1bWJCb3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnBsdW1iQm94XCIpO1xuICAgICAgaWYgKHBsdW1iQm94KSB7XG4gICAgICAgIHZhciBwb3NpdGlvbkluZm8gPSBwbHVtYkJveC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgcGx1bWJCb3hQb3NpdGlvbkluZm8gPSBwb3NpdGlvbkluZm87XG4gICAgICAgIGNvbnNvbGUubG9nKHBsdW1iQm94UG9zaXRpb25JbmZvLCAn55S75biD5L+h5oGvJyk7XG4gICAgICB9XG4gICAgfTtcbiAgICAvL+a4suafk+iKgueCuVxuICAgIHZhciByZW5kZXJOb2RlID0gZnVuY3Rpb24gcmVuZGVyTm9kZShmbGFnKSB7XG4gICAgICAvL+WQiOW5tuiKgueCueS/oeaBr+WSjOmFjee9rlxuICAgICAgaW5mby52YWx1ZS5tYXAoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW0gPSBPYmplY3QuYXNzaWduKGl0ZW0sIGdsb2JhbENvbmZpZyk7XG4gICAgICB9KTtcbiAgICAgIC8v6L+Z6YeM6ZyA6KaB562J5omA5L6d6LWW55qERE9N6IqC54K55YWo6YOo5riy5p+T5a6M5q+VLOaJjeiDvei/m+ihjOWbvuW9oua4suafk1xuICAgICAgbmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoZmxhZyA9PT0gXCJuZXdcIikge1xuICAgICAgICAgIHJlbmRlckZsYWcudmFsdWUgPSBcIm9uY2VcIjtcbiAgICAgICAgfVxuICAgICAgICAvL+a4hemZpOS5i+WJjeeahOWGheWuuVxuICAgICAgICBwbHVtYkluaXQuZGVsZXRlRXZlcnlDb25uZWN0aW9uKCk7XG4gICAgICAgIHBsdW1iSW5pdC5kZWxldGVFdmVyeUVuZHBvaW50KCk7XG4gICAgICAgIHJlZnJlc2hQbHVtYlBvc3Rpb25JbmZvKCk7XG4gICAgICAgIC8v5riy5p+T55S75biD5Lit55qE5L+h5oGv6IqC54K5XG4gICAgICAgIHZhciByZW5kZXJMaXN0ID0gW107XG4gICAgICAgIC8vIGlmKGluZm8udmFsdWUubGVuZ3RoPDEpe3JldHVybn1cbiAgICAgICAgaW5mby52YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgaWYgKGl0ZW0udG8ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgaXRlbS50by5mb3JFYWNoKGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICAgIHJlbmRlckxpc3QucHVzaCh7XG4gICAgICAgICAgICAgICAgc291cmNlOiBpdGVtLmlkLFxuICAgICAgICAgICAgICAgIHRhcmdldDogdixcbiAgICAgICAgICAgICAgICBhbmNob3I6IGl0ZW0uYW5jaG9yLFxuICAgICAgICAgICAgICAgIGNvbm5lY3RvcjogaXRlbS5jb25uZWN0b3IsXG4gICAgICAgICAgICAgICAgZW5kcG9pbnQ6IGl0ZW0uZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgb3ZlcmxheXM6IGl0ZW0ub3ZlcmxheXMsXG4gICAgICAgICAgICAgICAgcGFpbnRTdHlsZTogaXRlbS5wYWludFN0eWxlLFxuICAgICAgICAgICAgICAgIGhvdmVyUGFpbnRTdHlsZTogaXRlbS5ob3ZlclBhaW50U3R5bGUsXG4gICAgICAgICAgICAgICAgZW5kcG9pbnRTdHlsZTogaXRlbS5lbmRwb2ludFN0eWxlXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcGx1bWJMaXN0LnZhbHVlID0gcmVuZGVyTGlzdDtcbiAgICAgICAgLy/muLLmn5Plh73mlbBcbiAgICAgICAgcGx1bWJJbml0LnJlYWR5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZW5kZXJMaXN0LmZvckVhY2goZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIC8vIHBsdW1iSW5pdC5jb25uZWN0KGl0ZW0sanNQbHVtYkNvbm5lY3RPcHRpb25zKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGl0ZW0sICfmuLLmn5Plj4LmlbA9PT0nKTtcbiAgICAgICAgICAgIHBsdW1iSW5pdC5jb25uZWN0KGl0ZW0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGluZm8udmFsdWUuZm9yRWFjaChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgbWFrZUZ1bihpdGVtKTtcbiAgICAgICAgICAgIHBsdW1iSW5pdC5kcmFnZ2FibGUoaXRlbS5pZCwge1xuICAgICAgICAgICAgICBjb250YWlubWVudDogXCJwYXJlbnRcIixcbiAgICAgICAgICAgICAgc3RvcDogZnVuY3Rpb24gc3RvcChlbCkge1xuICAgICAgICAgICAgICAgIGl0ZW0ubGVmdCA9IGVsLnBvc1swXTtcbiAgICAgICAgICAgICAgICBpdGVtLnRvcCA9IGVsLnBvc1sxXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICAvL+iuvue9ruiKgueCueWPr+i/nuaOpeWxnuaAp1xuICAgIHZhciBtYWtlRnVuID0gZnVuY3Rpb24gbWFrZUZ1bihpdGVtKSB7XG4gICAgICBwbHVtYkluaXQuc2V0U291cmNlRW5hYmxlZChpdGVtLmlkLCBpdGVtLmlzU291cmNlKTtcbiAgICAgIHBsdW1iSW5pdC5zZXRUYXJnZXRFbmFibGVkKGl0ZW0uaWQsIGl0ZW0uaXNUYXJnZXQpO1xuICAgICAgcGx1bWJJbml0LnNldERyYWdnYWJsZShpdGVtLmlkLCB0cnVlKTtcbiAgICAgIHBsdW1iSW5pdC5tYWtlU291cmNlKGl0ZW0uaWQsIHtcbiAgICAgICAgZmlsdGVyOiBcIi5wbHVtYk5vZGVcIixcbiAgICAgICAgZmlsdGVyRXhjbHVkZTogZmFsc2UsXG4gICAgICAgIGFsbG93TG9vcGJhY2s6IGZhbHNlLFxuICAgICAgICBtYXhDb25uZWN0aW9uczogLTEsXG4gICAgICAgIENvbnRhaW5lcjogXCJwbHVtYkJveFwiLFxuICAgICAgICBhbmNob3I6IGl0ZW0uYW5jaG9yLFxuICAgICAgICBjb25uZWN0b3I6IGl0ZW0uY29ubmVjdG9yLFxuICAgICAgICBlbmRwb2ludDogaXRlbS5lbmRwb2ludCxcbiAgICAgICAgb3ZlcmxheXM6IGl0ZW0ub3ZlcmxheXMsXG4gICAgICAgIHBhaW50U3R5bGU6IGl0ZW0ucGFpbnRTdHlsZSxcbiAgICAgICAgaG92ZXJQYWludFN0eWxlOiBpdGVtLmhvdmVyUGFpbnRTdHlsZSxcbiAgICAgICAgZW5kcG9pbnRTdHlsZTogaXRlbS5lbmRwb2ludFN0eWxlXG4gICAgICB9KTtcbiAgICAgIHBsdW1iSW5pdC5tYWtlVGFyZ2V0KGl0ZW0uaWQsIHtcbiAgICAgICAgZmlsdGVyOiBcIi5wbHVtYk5vZGVcIixcbiAgICAgICAgZmlsdGVyRXhjbHVkZTogZmFsc2UsXG4gICAgICAgIGFsbG93TG9vcGJhY2s6IGZhbHNlLFxuICAgICAgICBtYXhDb25uZWN0aW9uczogMSxcbiAgICAgICAgQ29udGFpbmVyOiBcInBsdW1iQm94XCIsXG4gICAgICAgIGFuY2hvcjogaXRlbS5hbmNob3IsXG4gICAgICAgIGNvbm5lY3RvcjogaXRlbS5jb25uZWN0b3IsXG4gICAgICAgIGVuZHBvaW50OiBpdGVtLmVuZHBvaW50LFxuICAgICAgICBvdmVybGF5czogaXRlbS5vdmVybGF5cyxcbiAgICAgICAgcGFpbnRTdHlsZTogaXRlbS5wYWludFN0eWxlLFxuICAgICAgICBob3ZlclBhaW50U3R5bGU6IGl0ZW0uaG92ZXJQYWludFN0eWxlLFxuICAgICAgICBlbmRwb2ludFN0eWxlOiBpdGVtLmVuZHBvaW50U3R5bGVcbiAgICAgIH0pO1xuICAgICAgcGx1bWJJbml0LmRyYWdnYWJsZShpdGVtLmlkLCB7XG4gICAgICAgIGNvbnRhaW5tZW50OiBcInBhcmVudFwiLFxuICAgICAgICBzdG9wOiBmdW5jdGlvbiBzdG9wKGVsKSB7XG4gICAgICAgICAgaXRlbS5sZWZ0ID0gZWwucG9zWzBdO1xuICAgICAgICAgIGl0ZW0udG9wID0gZWwucG9zWzFdO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgLy8g57uZ5YWD57Sg6K6+572u5riy5p+T5qC35byPXG4gICAgdmFyIGdldFN0eWxlID0gZnVuY3Rpb24gZ2V0U3R5bGUoaXRlbSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgbGVmdDogaXRlbS5sZWZ0ICsgXCJweFwiLFxuICAgICAgICB0b3A6IGl0ZW0udG9wICsgXCJweFwiLFxuICAgICAgICAvLyBjb2xvcjppdGVtLmNvbG9yLFxuICAgICAgICAvLyBib3JkZXI6JzFweCBzb2xpZCAjJyxcbiAgICAgICAgd2lkdGg6IFwiMTgwcHhcIixcbiAgICAgICAgaGVpZ2h0OiBcIjM2cHhcIixcbiAgICAgICAgbGluZUhlaWdodDogXCIzNnB4XCIsXG4gICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgYm9yZGVyTGVmdDogXCI1cHggc29saWQgYmx1ZVwiLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiNCVcIixcbiAgICAgICAgYm94U2hhZG93OiBcIiNlZWUgM3B4IDNweCAzcHggM3B4XCIsXG4gICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCJcbiAgICAgIH07XG4gICAgfTtcbiAgICAvL+WIneWni+WMlmpzcGx1bWLlrp7kvotcbiAgICB2YXIgcGx1bWJJbml0ID0ganNQbHVtYi5nZXRJbnN0YW5jZSgpO1xuXG4gICAgLy/ngrnlh7vov57nur/kuovku7ZcbiAgICBwbHVtYkluaXQuYmluZChcImNsaWNrXCIsIGZ1bmN0aW9uIChjb25uLCBvcmlnaW5hbEV2ZW50KSB7XG4gICAgICBjb25zb2xlLmxvZyhjb25uLCBcIueCueWHu+i/nue6v1wiKTtcbiAgICAgIHZhciBsaW5lSW5mbyA9IHt9O1xuICAgICAgY29uc29sZS5sb2coaW5mby52YWx1ZSwgXCLmlbTkvZPkv6Hmga9cIik7XG4gICAgICB2YXIgc291cmNlSW5mbyA9IGluZm8udmFsdWUuZmluZChmdW5jdGlvbiAodikge1xuICAgICAgICByZXR1cm4gdi5pZCA9PT0gY29ubi5zb3VyY2VJZDtcbiAgICAgIH0pO1xuICAgICAgdmFyIHRhcmdldEluZm8gPSBpbmZvLnZhbHVlLmZpbmQoZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgcmV0dXJuIHYuaWQgPT09IGNvbm4udGFyZ2V0SWQ7XG4gICAgICB9KTtcbiAgICAgIGxpbmVJbmZvID0ge1xuICAgICAgICBzb3VyY2VJbmZvOiBzb3VyY2VJbmZvLFxuICAgICAgICB0YXJnZXRJbmZvOiB0YXJnZXRJbmZvXG4gICAgICB9O1xuICAgICAgcmlnaHRGb3JtLnZhbHVlLmdldExpbmVJbmZvKGxpbmVJbmZvKTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwi54K55Ye75LqGXCIsIGNvb24sIG9yaWdpbmFsRXZlbnQpO1xuICAgICAgLy8gcGx1bWJJbml0LmRlbGV0ZUNvbm5lY3Rpb24oY29ubik7XG4gICAgfSk7XG4gICAgLy/ov57nur/op6blj5Hkuovku7ZcbiAgICBwbHVtYkluaXQuYmluZChcImNvbm5lY3Rpb25cIiwgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICBjb25zb2xlLmxvZyhldmVudCwgXCLmlrDnmoTov57nur/kuovku7bop6blj5FcIik7XG4gICAgICAvLyBmb3JjZVVwZGF0ZSgpO1xuICAgICAgdmFyIHNvdXJjZU5vZGUgPSBpbmZvLnZhbHVlLmZpbmQoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW0uaWQgPT09IGV2ZW50LnNvdXJjZUlkO1xuICAgICAgfSk7XG4gICAgICBjb25zb2xlLmxvZyhzb3VyY2VOb2RlLnRvLCBldmVudC50YXJnZXRJZCwgXCI/Pz9cIik7XG4gICAgICBpZiAoc291cmNlTm9kZS50by5maW5kSW5kZXgoZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgcmV0dXJuIHYgPT09IGV2ZW50LnRhcmdldElkO1xuICAgICAgfSkgPT09IC0xKSB7XG4gICAgICAgIHNvdXJjZU5vZGUudG8ucHVzaChldmVudC50YXJnZXRJZCk7XG4gICAgICB9XG4gICAgICBwbHVtYkluaXQucmVwYWludCgpO1xuICAgICAgbmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICByZW5kZXJGbGFnLnZhbHVlID0gXCJuZXdcIjtcbiAgICAgIH0pO1xuICAgICAgaWYgKHJlbmRlckZsYWcudmFsdWUgPT09IFwibmV3XCIpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCLmlrDnmoTpobXpnaLliLfmlrBcIik7XG4gICAgICAgIHJlbmRlckZsYWcudmFsdWUgPSBcIm9uY2VcIjtcbiAgICAgICAgcmVuZGVyTm9kZShcIm5ld1wiKTtcbiAgICAgIH1cbiAgICAgIC8vIGNvbnNvbGUubG9nKGluZm8udmFsdWUsJ+aJgOacieiKgueCuScpXG4gICAgICAvLyByZW5kZXJOb2RlKClcbiAgICB9KTtcblxuICAgIC8v5YiH5o2i5Yqo5oCB6IqC54K5XG4gICAgZnVuY3Rpb24gc2VuZEFjdGl2ZShub2RlKSB7XG4gICAgICBhY3RpdmVOb2RlLnZhbHVlID0gbm9kZTtcbiAgICAgIGNvbnNvbGUubG9nKGFjdGl2ZU5vZGUudmFsdWUsIFwi5Yqo5oCB6IqC54K5XCIpO1xuICAgICAgcmlnaHRGb3JtLnZhbHVlLmNoYW5nZUZvcm1EYXRhKGFjdGl2ZU5vZGUudmFsdWUuY29uZmlnKTtcbiAgICB9XG4gICAgb25Nb3VudGVkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICByZW5kZXJOb2RlKCk7XG4gICAgICAgIG5leHRUaWNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIumhtemdouWIneasoea4suafk+WujOavlVwiKTtcbiAgICAgICAgICByZW5kZXJGbGFnLnZhbHVlID0gXCJyZW5kZXJcIjtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICAvL+WPs+S+p+S/neWtmOWAvFxuICAgIHZhciBjaGFuZ2VBY3RpdmVOb2RlSW5mbyA9IGZ1bmN0aW9uIGNoYW5nZUFjdGl2ZU5vZGVJbmZvKGluZm8pIHtcbiAgICAgIGNvbnNvbGUubG9nKGluZm8sIFwi5L+d5a2Y5ZCO55qE5paw5YC8XCIpO1xuICAgICAgYWN0aXZlTm9kZS52YWx1ZS5jb25maWcgPSBpbmZvO1xuICAgICAgbmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICByZW5kZXJGbGFnLnZhbHVlID0gXCJuZXdcIjtcbiAgICAgICAgbWFrZUZ1bihhY3RpdmVOb2RlLnZhbHVlKTtcbiAgICAgIH0pO1xuICAgIH07XG4gICAgLy/liKDpmaTnur9cbiAgICB2YXIgZGVsZXRlTGluZSA9IGZ1bmN0aW9uIGRlbGV0ZUxpbmUoZGVsZXRlTGluZUluZm8pIHtcbiAgICAgIGNvbnNvbGUubG9nKGRlbGV0ZUxpbmVJbmZvLCBcIuimgeWIoOmZpOeahOi/nue6v+S/oeaBr1wiKTtcbiAgICAgIGNvbnNvbGUubG9nKGluZm8udmFsdWUsIFwi5YWo6YeP5L+h5oGvXCIpO1xuICAgICAgdmFyIHNvdXJjZUluZGV4ID0gaW5mby52YWx1ZS5maW5kSW5kZXgoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW0uaWQgPT09IGRlbGV0ZUxpbmVJbmZvLnNvdXJjZUluZm8uaWQ7XG4gICAgICB9KTtcbiAgICAgIHZhciBkZWxldGVUYXJnZXRJZCA9IGRlbGV0ZUxpbmVJbmZvLnRhcmdldEluZm8uaWQ7XG4gICAgICB2YXIgZGVsZXRlVGFyZ2V0SW5kZXggPSBpbmZvLnZhbHVlW3NvdXJjZUluZGV4XS50by5maW5kSW5kZXgoZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgcmV0dXJuIHYgPT09IGRlbGV0ZVRhcmdldElkO1xuICAgICAgfSk7XG4gICAgICBpbmZvLnZhbHVlW3NvdXJjZUluZGV4XS50by5zcGxpY2UoZGVsZXRlVGFyZ2V0SW5kZXgsIDEpO1xuICAgICAgcmVuZGVyTm9kZSgpO1xuICAgIH07XG4gICAgLy/liKDpmaToioLngrlcbiAgICB2YXIgZGVsZXRlTm9kZSA9IGZ1bmN0aW9uIGRlbGV0ZU5vZGUobm9kZUluZm8pIHtcbiAgICAgIGNvbnNvbGUubG9nKGFjdGl2ZU5vZGUudmFsdWUpO1xuICAgICAgdmFyIG5vZGVJbmRleCA9IGluZm8udmFsdWUuZmluZEluZGV4KGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHJldHVybiBpdGVtLmlkID09PSBhY3RpdmVOb2RlLnZhbHVlLmlkO1xuICAgICAgfSk7XG4gICAgICBpbmZvLnZhbHVlLnNwbGljZShub2RlSW5kZXgsIDEpO1xuICAgICAgaW5mby52YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHZhciBmbGFnSW5kZXggPSBpdGVtLnRvLmZpbmRJbmRleChmdW5jdGlvbiAodikge1xuICAgICAgICAgIHJldHVybiB2ID09PSBhY3RpdmVOb2RlLnZhbHVlLmlkO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGZsYWdJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICBpdGVtLnRvLnNwbGljZShmbGFnSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKGluZm8udmFsdWUsIFwi6IqC54K55YiX6KGoXCIpO1xuICAgICAgcmVuZGVyTm9kZSgpO1xuICAgICAgYWN0aXZlTm9kZS52YWx1ZSA9IHt9O1xuICAgICAgcmlnaHRGb3JtLnZhbHVlLmNoYW5nZUZvcm1EYXRhKFtdKTtcbiAgICB9O1xuICAgIC8v5pq06Zyy57uZ54i257uE5Lu255qE5YC8LOmcgOimgeeItue7hOS7tuWPkemAgeivt+axglxuICAgIGV4cG9zZSh7XG4gICAgICBwbHVtYkxpc3Q6IHBsdW1iTGlzdCxcbiAgICAgIGluZm86IGluZm8sXG4gICAgICBzY2VuYXJpb19uYW1lOiBzY2VuYXJpb19uYW1lLFxuICAgICAgbW9kZV90eXBlOiBtb2RlX3R5cGUsXG4gICAgICBkb25lVHlwZTogZG9uZVR5cGVcbiAgICB9KTtcbiAgICB2YXIgX19yZXR1cm5lZF9fID0ge1xuICAgICAgZ2V0IHR5cGVPcHRpb25zKCkge1xuICAgICAgICByZXR1cm4gdHlwZU9wdGlvbnM7XG4gICAgICB9LFxuICAgICAgc2V0IHR5cGVPcHRpb25zKHYpIHtcbiAgICAgICAgdHlwZU9wdGlvbnMgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBzY2VuYXJpb19uYW1lKCkge1xuICAgICAgICByZXR1cm4gc2NlbmFyaW9fbmFtZTtcbiAgICAgIH0sXG4gICAgICBzZXQgc2NlbmFyaW9fbmFtZSh2KSB7XG4gICAgICAgIHNjZW5hcmlvX25hbWUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBtb2RlX3R5cGUoKSB7XG4gICAgICAgIHJldHVybiBtb2RlX3R5cGU7XG4gICAgICB9LFxuICAgICAgc2V0IG1vZGVfdHlwZSh2KSB7XG4gICAgICAgIG1vZGVfdHlwZSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGRvbmVGbGFnKCkge1xuICAgICAgICByZXR1cm4gZG9uZUZsYWc7XG4gICAgICB9LFxuICAgICAgc2V0IGRvbmVGbGFnKHYpIHtcbiAgICAgICAgZG9uZUZsYWcgPSB2O1xuICAgICAgfSxcbiAgICAgIGRyYWdnYWJsZTogZHJhZ2dhYmxlLFxuICAgICAgZ2V0IHBsdW1iQm94KCkge1xuICAgICAgICByZXR1cm4gcGx1bWJCb3g7XG4gICAgICB9LFxuICAgICAgc2V0IHBsdW1iQm94KHYpIHtcbiAgICAgICAgcGx1bWJCb3ggPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBwbHVtYkJveFBvc2l0aW9uSW5mbygpIHtcbiAgICAgICAgcmV0dXJuIHBsdW1iQm94UG9zaXRpb25JbmZvO1xuICAgICAgfSxcbiAgICAgIHNldCBwbHVtYkJveFBvc2l0aW9uSW5mbyh2KSB7XG4gICAgICAgIHBsdW1iQm94UG9zaXRpb25JbmZvID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgbm9kZVBvc2l0aW9uRGlmZigpIHtcbiAgICAgICAgcmV0dXJuIG5vZGVQb3NpdGlvbkRpZmY7XG4gICAgICB9LFxuICAgICAgc2V0IG5vZGVQb3NpdGlvbkRpZmYodikge1xuICAgICAgICBub2RlUG9zaXRpb25EaWZmID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgcGx1bWJMaXN0KCkge1xuICAgICAgICByZXR1cm4gcGx1bWJMaXN0O1xuICAgICAgfSxcbiAgICAgIHNldCBwbHVtYkxpc3Qodikge1xuICAgICAgICBwbHVtYkxpc3QgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCByZW5kZXJGbGFnKCkge1xuICAgICAgICByZXR1cm4gcmVuZGVyRmxhZztcbiAgICAgIH0sXG4gICAgICBzZXQgcmVuZGVyRmxhZyh2KSB7XG4gICAgICAgIHJlbmRlckZsYWcgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBhY3RpdmVOb2RlKCkge1xuICAgICAgICByZXR1cm4gYWN0aXZlTm9kZTtcbiAgICAgIH0sXG4gICAgICBzZXQgYWN0aXZlTm9kZSh2KSB7XG4gICAgICAgIGFjdGl2ZU5vZGUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCByaWdodEZvcm0oKSB7XG4gICAgICAgIHJldHVybiByaWdodEZvcm07XG4gICAgICB9LFxuICAgICAgc2V0IHJpZ2h0Rm9ybSh2KSB7XG4gICAgICAgIHJpZ2h0Rm9ybSA9IHY7XG4gICAgICB9LFxuICAgICAgZG9uZVR5cGU6IGRvbmVUeXBlLFxuICAgICAgb3B0aW9uczogb3B0aW9ucyxcbiAgICAgIGdldCBnbG9iYWxDb25maWcoKSB7XG4gICAgICAgIHJldHVybiBnbG9iYWxDb25maWc7XG4gICAgICB9LFxuICAgICAgc2V0IGdsb2JhbENvbmZpZyh2KSB7XG4gICAgICAgIGdsb2JhbENvbmZpZyA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IGxlZnRNZW51RGF0YSgpIHtcbiAgICAgICAgcmV0dXJuIGxlZnRNZW51RGF0YTtcbiAgICAgIH0sXG4gICAgICBzZXQgbGVmdE1lbnVEYXRhKHYpIHtcbiAgICAgICAgbGVmdE1lbnVEYXRhID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgaW5mbygpIHtcbiAgICAgICAgcmV0dXJuIGluZm87XG4gICAgICB9LFxuICAgICAgc2V0IGluZm8odikge1xuICAgICAgICBpbmZvID0gdjtcbiAgICAgIH0sXG4gICAgICBhZGROb2RlOiBhZGROb2RlLFxuICAgICAgYWRkTGluZTogYWRkTGluZSxcbiAgICAgIG1vdXNlRG93bkZ1bjogbW91c2VEb3duRnVuLFxuICAgICAgbW92ZVN0YXJ0OiBtb3ZlU3RhcnQsXG4gICAgICBtb3ZlRW5kOiBtb3ZlRW5kLFxuICAgICAganVkZ2VQb3NpdGlvbjoganVkZ2VQb3NpdGlvbixcbiAgICAgIHJlZnJlc2hQbHVtYlBvc3Rpb25JbmZvOiByZWZyZXNoUGx1bWJQb3N0aW9uSW5mbyxcbiAgICAgIHJlbmRlck5vZGU6IHJlbmRlck5vZGUsXG4gICAgICBtYWtlRnVuOiBtYWtlRnVuLFxuICAgICAgZ2V0U3R5bGU6IGdldFN0eWxlLFxuICAgICAgZ2V0IHBsdW1iSW5pdCgpIHtcbiAgICAgICAgcmV0dXJuIHBsdW1iSW5pdDtcbiAgICAgIH0sXG4gICAgICBzZXQgcGx1bWJJbml0KHYpIHtcbiAgICAgICAgcGx1bWJJbml0ID0gdjtcbiAgICAgIH0sXG4gICAgICBzZW5kQWN0aXZlOiBzZW5kQWN0aXZlLFxuICAgICAgY2hhbmdlQWN0aXZlTm9kZUluZm86IGNoYW5nZUFjdGl2ZU5vZGVJbmZvLFxuICAgICAgZGVsZXRlTGluZTogZGVsZXRlTGluZSxcbiAgICAgIGRlbGV0ZU5vZGU6IGRlbGV0ZU5vZGUsXG4gICAgICBnZXQganNQbHVtYigpIHtcbiAgICAgICAgcmV0dXJuIGpzUGx1bWI7XG4gICAgICB9LFxuICAgICAgZ2V0IFZ1ZURyYWdnYWJsZU5leHQoKSB7XG4gICAgICAgIHJldHVybiBWdWVEcmFnZ2FibGVOZXh0O1xuICAgICAgfSxcbiAgICAgIGdldCBFbE1lc3NhZ2UoKSB7XG4gICAgICAgIHJldHVybiBFbE1lc3NhZ2U7XG4gICAgICB9LFxuICAgICAgZ2V0IGxvZGFzaCgpIHtcbiAgICAgICAgcmV0dXJuIGxvZGFzaDtcbiAgICAgIH0sXG4gICAgICBnZXQgdXVpZHY0KCkge1xuICAgICAgICByZXR1cm4gdXVpZHY0O1xuICAgICAgfSxcbiAgICAgIHJlYWN0aXZlOiByZWFjdGl2ZSxcbiAgICAgIGdldCB3b3JkKCkge1xuICAgICAgICByZXR1cm4gd29yZDtcbiAgICAgIH0sXG4gICAgICBnZXQgUmlnaHRGb3JtKCkge1xuICAgICAgICByZXR1cm4gUmlnaHRGb3JtO1xuICAgICAgfVxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsIjx0ZW1wbGF0ZT5cclxuICA8ZWwtZm9ybVxyXG4gICAgdi1pZj1cImluZm9UeXBlID09PSAnbm9kZSdcIlxyXG4gICAgcmVmPVwicnVsZUZvcm1SZWZcIlxyXG4gICAgOm1vZGVsPVwicnVsZUZvcm1cIlxyXG4gICAgOnJ1bGVzPVwicnVsZXNcIlxyXG4gICAgbGFiZWwtd2lkdGg9XCIxMjBweFwiXHJcbiAgICBjbGFzcz1cImRlbW8tcnVsZUZvcm1cIlxyXG4gICAgOnNpemU9XCJmb3JtU2l6ZVwiXHJcbiAgICBzdGF0dXMtaWNvblxyXG4gICAgbGFiZWwtcG9zaXRpb249XCJsZWZ0XCJcclxuICA+XHJcbiAgICA8ZWwtZm9ybS1pdGVtXHJcbiAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICA6cHJvcD1cIml0ZW0ubmFtZVwiXHJcbiAgICAgIHYtZm9yPVwiKGl0ZW0sIGluZGV4KSBpbiBmb3JtRGF0YVwiXHJcbiAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICA+XHJcbiAgICAgIDxlbC1pbnB1dCB2LW1vZGVsPVwicnVsZUZvcm1baXRlbS5uYW1lXVwiIHYtaWY9XCJpdGVtLnR5cGUgPT09ICd0ZXh0J1wiIC8+XHJcbiAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybVtpdGVtLm5hbWVdXCJcclxuICAgICAgICB0eXBlPVwidGV4dGFyZWFcIlxyXG4gICAgICAgIHYtZWxzZS1pZj1cIml0ZW0udHlwZSA9PT0gJ3RleHRhcmVhJ1wiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxlbC1zZWxlY3RcclxuICAgICAgICB2LW1vZGVsPVwicnVsZUZvcm1baXRlbS5uYW1lXVwiXHJcbiAgICAgICAgdi1lbHNlLWlmPVwiaXRlbS50eXBlID09PSAnc2VsZWN0J1wiXHJcbiAgICAgID5cclxuICAgICAgICA8ZWwtb3B0aW9uXHJcbiAgICAgICAgICA6bGFiZWw9XCJtLmxhYmVsXCJcclxuICAgICAgICAgIDp2YWx1ZT1cIm0udmFsdWVcIlxyXG4gICAgICAgICAgdi1mb3I9XCIobSwgbikgaW4gaXRlbS5vcHRpb25zXCJcclxuICAgICAgICAgIDprZXk9XCJuXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2VsLXNlbGVjdD5cclxuICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gIDwvZWwtZm9ybT5cclxuICA8ZGl2IHYtaWY9XCJpbmZvVHlwZSA9PT0gJ2xpbmUnXCI+XHJcbiAgICA8aDY+6LW35aeL6IqC54K5OjwvaDY+XHJcbiAgICA8cD57eyBsaW5lRGF0YS5zb3VyY2VJbmZvLmNvbmZpZ1swXS52YWx1ZSB9fTwvcD5cclxuICAgIDxoNj7nm67moIfoioLngrk6PC9oNj5cclxuICAgIDxwPnt7IGxpbmVEYXRhLnRhcmdldEluZm8uY29uZmlnWzBdLnZhbHVlIH19PC9wPlxyXG4gIDwvZGl2PlxyXG4gIDxkaXYgY2xhc3M9XCJidG5Cb3hcIiB2LXNob3c9XCJsaXN0U2hvd1wiPlxyXG4gICAgPGVsLWJ1dHRvblxyXG4gICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgIEBjbGljaz1cInN1Ym1pdEZvcm0ocnVsZUZvcm1SZWYpXCJcclxuICAgICAgdi1zaG93PVwiaW5mb1R5cGUgPT09ICdub2RlJyAmJiBmb3JtRGF0YS5sZW5ndGggPiAwXCJcclxuICAgID5cclxuICAgICAg5L+d5a2Y6IqC54K5XHJcbiAgICA8L2VsLWJ1dHRvbj5cclxuICAgIDxlbC1idXR0b25cclxuICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICB2LXNob3c9XCJpbmZvVHlwZSA9PT0gJ25vZGUnICYmIGZvcm1EYXRhLmxlbmd0aCA+IDBcIlxyXG4gICAgICBAY2xpY2s9XCJkZWx0ZU5vZGVGdW5cIlxyXG4gICAgPlxyXG4gICAgICDliKDpmaToioLngrlcclxuICAgIDwvZWwtYnV0dG9uPlxyXG4gICAgPGVsLWJ1dHRvblxyXG4gICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgIHYtc2hvdz1cImluZm9UeXBlID09PSAnbGluZSdcIlxyXG4gICAgICBAY2xpY2s9XCJkZWxldGVMaW5lRnVuXCJcclxuICAgID5cclxuICAgICAg5Yig6Zmk6L+e57q/XHJcbiAgICA8L2VsLWJ1dHRvbj5cclxuICA8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuPHNjcmlwdCBzZXR1cD5cclxubGV0IGZvcm1EYXRhID0gcmVmKFtdKTtcclxubGV0IGxpbmVEYXRhID0gcmVmKHt9KTtcclxuY29uc3QgZm9ybVNpemUgPSByZWYoXCJkZWZhdWx0XCIpO1xyXG5jb25zdCBydWxlRm9ybVJlZiA9IHJlZigpO1xyXG5jb25zdCBsaXN0U2hvdyA9IHJlZihmYWxzZSk7XHJcbmxldCBydWxlRm9ybSA9IHJlYWN0aXZlKHt9KTtcclxuY29uc3QgaW5mb1R5cGUgPSByZWYoXCJub2RlXCIpO1xyXG5jb25zdCBlbWl0ID0gZGVmaW5lRW1pdHMoW1wiY2hhbmdlQWN0aXZlTm9kZUluZm9cIiwgXCJkZWxldGVMaW5lXCIsIFwiZGVsZXRlTm9kZVwiXSk7XHJcbmNvbnN0IHJ1bGVzID0gcmVhY3RpdmUoe1xyXG4gIGxhYmVsOiBbXHJcbiAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIuiKgueCueWQjeensOS4uuW/hei+k+mhuVwiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gICAgeyBtaW46IDQsIG1heDogOCwgbWVzc2FnZTogXCLor7fovpPlhaU06IezOOS5i+mXtOeahOWtl+esplwiLCB0cmlnZ2VyOiBcImJsdXJcIiB9LFxyXG4gIF0sXHJcbiAgYWZmaWxpYXRpb246IFtcclxuICAgIHtcclxuICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgIG1lc3NhZ2U6IFwi6K+36YCJ5oup5b2S5bGe6aG5XCIsXHJcbiAgICAgIHRyaWdnZXI6IFwiY2hhbmdlXCIsXHJcbiAgICB9LFxyXG4gIF0sXHJcbn0pO1xyXG5jb25zdCBzdWJtaXRGb3JtID0gYXN5bmMgKGZvcm1FbCkgPT4ge1xyXG4gIGlmICghZm9ybUVsKSByZXR1cm47XHJcbiAgYXdhaXQgZm9ybUVsLnZhbGlkYXRlKCh2YWxpZCwgZmllbGRzKSA9PiB7XHJcbiAgICBpZiAodmFsaWQpIHtcclxuICAgICAgY29uc29sZS5sb2codmFsaWQsIHJ1bGVGb3JtKTtcclxuICAgICAgZm9ybURhdGEudmFsdWUuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGl0ZW0udmFsdWUgPSBydWxlRm9ybVtpdGVtLm5hbWVdO1xyXG4gICAgICB9KTtcclxuICAgICAgZW1pdChcImNoYW5nZUFjdGl2ZU5vZGVJbmZvXCIsIGZvcm1EYXRhLnZhbHVlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3Igc3VibWl0IVwiLCBmaWVsZHMpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5cclxuY29uc3QgcmVzZXRGb3JtID0gKGZvcm1FbCkgPT4ge1xyXG4gIGlmICghZm9ybUVsKSByZXR1cm47XHJcbiAgZm9ybUVsLnJlc2V0RmllbGRzKCk7XHJcbn07XHJcblxyXG5jb25zdCBvcHRpb25zID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogMTAwMDAgfSkubWFwKChfLCBpZHgpID0+ICh7XHJcbiAgdmFsdWU6IGAke2lkeCArIDF9YCxcclxuICBsYWJlbDogYCR7aWR4ICsgMX1gLFxyXG59KSk7XHJcbmNvbnN0IGdldEZvcm1EYXRhID0gKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKGZvcm1EYXRhLCBcIuS/oeaBr1wiKTtcclxufTtcclxuLy/niLboioLngrnkvKDpgJLkv6Hmga/lh73mlbBcclxuY29uc3QgY2hhbmdlRm9ybURhdGEgPSAodmFsKSA9PiB7XHJcbiAgaW5mb1R5cGUudmFsdWUgPSBcIm5vZGVcIjtcclxuICBsaXN0U2hvdy52YWx1ZSA9IHRydWU7XHJcbiAgY29uc29sZS5sb2codmFsKTtcclxuICBmb3JtRGF0YS52YWx1ZSA9IHZhbDtcclxuICBmb3JtRGF0YS52YWx1ZS5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhpdGVtLCBcIumBjeWOhlwiKTtcclxuICAgIHJ1bGVGb3JtW2l0ZW0ubmFtZV0gPSBpdGVtLnZhbHVlO1xyXG4gIH0pO1xyXG4gIGNvbnNvbGUubG9nKHJ1bGVGb3JtLCBcIj8/P1wiKTtcclxufTtcclxuLy/niLboioLngrnkvKDpgJLov57nur/kv6Hmga9cclxuY29uc3QgZ2V0TGluZUluZm8gPSAobGluZUluZm8pID0+IHtcclxuICBsaXN0U2hvdy52YWx1ZSA9IHRydWU7XHJcbiAgY29uc29sZS5sb2cobGluZUluZm8sIFwi6L+e57q/5L+h5oGvXCIpO1xyXG4gIGluZm9UeXBlLnZhbHVlID0gXCJsaW5lXCI7XHJcbiAgbGluZURhdGEudmFsdWUgPSBsaW5lSW5mbztcclxufTtcclxuLy/liKDpmaTov57nur/kv6Hmga9cclxuY29uc3QgZGVsZXRlTGluZUZ1biA9ICgpID0+IHtcclxuICBlbWl0KFwiZGVsZXRlTGluZVwiLCBsaW5lRGF0YS52YWx1ZSk7XHJcbiAgaW5mb1R5cGUudmFsdWUgPSBudWxsO1xyXG59O1xyXG4vL+WIoOmZpOiKgueCuVxyXG5jb25zdCBkZWx0ZU5vZGVGdW4gPSAoKSA9PiB7XHJcbiAgZW1pdChcImRlbGV0ZU5vZGVcIik7XHJcbn07XHJcbm9uTW91bnRlZCgoKSA9PiB7fSk7XHJcbmRlZmluZUV4cG9zZSh7XHJcbiAgY2hhbmdlRm9ybURhdGEsXHJcbiAgZ2V0TGluZUluZm8sXHJcbiAgZm9ybURhdGEsXHJcbn0pO1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG46OnYtZGVlcCguZWwtZm9ybS1pdGVtKSAge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbiAhaW1wb3J0YW50O1xyXG59XHJcbmg2IHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBtYXJnaW46IDVweDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbnAge1xyXG4gIG1hcmdpbjogMjBweDtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcbjwvc3R5bGU+IiwiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJuYW1lQ29udGVudFwiPlxyXG4gICAg5pa55qGI5ZCN56ewOiZuYnNwOyZuYnNwOzxlbC1pbnB1dFxyXG4gICAgICB2LW1vZGVsLnRyaW09XCJzY2VuYXJpb19uYW1lXCJcclxuICAgICAgc3R5bGU9XCJ3aWR0aDogMjAwcHg7IG1hcmdpbi1sZWZ0OiAzMHB4JzttYXJnaW4tcmlnaHQ6MjBweDtcIlxyXG4gICAgPjwvZWwtaW5wdXQ+XHJcbiAgICDmqKHlnovop4TojIM6Jm5ic3A7Jm5ic3A7PGVsLXNlbGVjdFxyXG4gICAgICB2LW1vZGVsPVwibW9kZV90eXBlXCJcclxuICAgICAgc3R5bGU9XCJ3aWR0aDogMjAwcHg7IG1hcmdpbi1sZWZ0OiAzMHB4JzttYXJnaW4tcmlnaHQ6MjBweDtcIlxyXG4gICAgPlxyXG4gICAgICA8ZWwtb3B0aW9uXHJcbiAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHR5cGVPcHRpb25zXCJcclxuICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgIDp2YWx1ZT1cIml0ZW0udmFsdWVcIlxyXG4gICAgICA+XHJcbiAgICAgIDwvZWwtb3B0aW9uPlxyXG4gICAgPC9lbC1zZWxlY3Q+XHJcbiAgPC9kaXY+XHJcbiAgPHVsIGNsYXNzPVwiYm94XCI+XHJcbiAgICA8bGkgY2xhc3M9XCJsZWZ0TWVudVwiPlxyXG4gICAgICA8aDM+6YCJ5oup6IqC54K5PC9oMz5cclxuICAgICAgPGVsLWNvbGxhcHNlPlxyXG4gICAgICAgIDxlbC1jb2xsYXBzZS1pdGVtXHJcbiAgICAgICAgICA6dGl0bGU9XCJpdGVtMS5uYW1lXCJcclxuICAgICAgICAgIHYtZm9yPVwiKGl0ZW0xLCBpbmRleCkgaW4gbGVmdE1lbnVEYXRhXCJcclxuICAgICAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRyYWdnYWJsZVxyXG4gICAgICAgICAgICBAc3RhcnQ9XCJtb3ZlU3RhcnRcIlxyXG4gICAgICAgICAgICBAZW5kPVwibW92ZUVuZFwiXHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJpdGVtMS5jaGlsZHJlblwiXHJcbiAgICAgICAgICAgIDpvcHRpb25zPVwib3B0aW9uc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICB2LWZvcj1cIihpdGVtMiwgbikgaW4gaXRlbTEuY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiY29udGVudFwiXHJcbiAgICAgICAgICAgICAgOmRpdk9wdGlvbj1cIkpTT04uc3RyaW5naWZ5KGl0ZW0yKVwiXHJcbiAgICAgICAgICAgICAgQG1vdXNlZG93bj1cIm1vdXNlRG93bkZ1blwiXHJcbiAgICAgICAgICAgICAgOmtleT1cIm5cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3sgaXRlbTIuY29uZmlnWzBdLnZhbHVlIH19XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kcmFnZ2FibGU+XHJcbiAgICAgICAgPC9lbC1jb2xsYXBzZS1pdGVtPlxyXG4gICAgICA8L2VsLWNvbGxhcHNlPlxyXG4gICAgPC9saT5cclxuICAgIDxsaSBjbGFzcz1cInBsdW1iQm94XCIgaWQ9XCJwbHVtYkJveFwiPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIGluZm9cIlxyXG4gICAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICAgICAgOmlkPVwiaXRlbS5pZFwiXHJcbiAgICAgICAgOnN0eWxlPVwiZ2V0U3R5bGUoaXRlbSlcIlxyXG4gICAgICAgIDpjbGFzcz1cIml0ZW0uaWQgPT09IGFjdGl2ZU5vZGUuaWQgPyAnYWN0aXZlTm9kZScgOiAnbm9ybWFsTm9kZSdcIlxyXG4gICAgICAgIEBjbGljaz1cInNlbmRBY3RpdmUoaXRlbSlcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInBsdW1iTm9kZVwiIDppZD1cIml0ZW0uaWQgKyAncGx1bWJOb2RlJ1wiPlxyXG4gICAgICAgICAgPGVsLWljb24gOnNpemU9XCIyMFwiPlxyXG4gICAgICAgICAgICA8Q2lyY2xlUGx1c0ZpbGxlZCAvPlxyXG4gICAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHt7IGl0ZW0uY29uZmlnWzBdLnZhbHVlIH19XHJcbiAgICAgICAgPGVsLWljb25cclxuICAgICAgICAgIGNsYXNzPVwiaXMtbG9hZGluZ1wiXHJcbiAgICAgICAgICB2LWlmPVwiaXRlbS5zdGF0dXMgPT09ICdsb2FkaW5nJ1wiXHJcbiAgICAgICAgICBjb2xvcj1cImJsdWVcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxMb2FkaW5nIC8+XHJcbiAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICAgIDxlbC1pY29uIHYtZWxzZS1pZj1cIml0ZW0uc3RhdHVzID09PSAnc3VjY2VzcydcIiBjb2xvcj1cImdyZWVuXCI+XHJcbiAgICAgICAgICA8Q2lyY2xlQ2hlY2tGaWxsZWQgLz5cclxuICAgICAgICA8L2VsLWljb24+XHJcbiAgICAgICAgPGVsLWljb24gdi1lbHNlLWlmPVwiaXRlbS5zdGF0dXMgPT09ICdlcnJvcidcIiBjb2xvcj1cInJlZFwiPlxyXG4gICAgICAgICAgPENpcmNsZUNsb3NlRmlsbGVkIC8+XHJcbiAgICAgICAgPC9lbC1pY29uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbGk+XHJcblxyXG4gICAgPGxpIGNsYXNzPVwicmlnaHRDb250ZW50XCI+XHJcbiAgICAgIDxoMz7oioLngrnmk43kvZw8L2gzPlxyXG4gICAgICA8ZGl2IHN0eWxlPVwicGFkZGluZy1sZWZ0OiAxMHB4XCI+XHJcbiAgICAgICAgPFJpZ2h0Rm9ybVxyXG4gICAgICAgICAgcmVmPVwicmlnaHRGb3JtXCJcclxuICAgICAgICAgIEBjaGFuZ2VBY3RpdmVOb2RlSW5mbz1cImNoYW5nZUFjdGl2ZU5vZGVJbmZvXCJcclxuICAgICAgICAgIEBkZWxldGVMaW5lPVwiZGVsZXRlTGluZVwiXHJcbiAgICAgICAgICBAZGVsZXRlTm9kZT1cImRlbGV0ZU5vZGVcIlxyXG4gICAgICAgID48L1JpZ2h0Rm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2xpPlxyXG4gIDwvdWw+XHJcbjwvdGVtcGxhdGU+XHJcbjxzY3JpcHQgc2V0dXA+XHJcbi8v5byV5YWlanNQbHVtYlxyXG5pbXBvcnQgeyBqc1BsdW1iIH0gZnJvbSBcImpzcGx1bWJcIjtcclxuaW1wb3J0IHsgVnVlRHJhZ2dhYmxlTmV4dCB9IGZyb20gXCJ2dWUtZHJhZ2dhYmxlLW5leHRcIjtcclxuaW1wb3J0IHsgRWxNZXNzYWdlIH0gZnJvbSBcImVsZW1lbnQtcGx1c1wiO1xyXG5pbXBvcnQgbG9kYXNoIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IHsgdjQgYXMgdXVpZHY0IH0gZnJvbSBcInV1aWRcIjtcclxuaW1wb3J0IHsgcmVhY3RpdmUgfSBmcm9tIFwidnVlXCI7XHJcbmltcG9ydCB3b3JkIGZyb20gXCJAL2RpY3Rpb25hcmllcy9idXNpbmVzcy5qc29uXCI7XHJcbmltcG9ydCBSaWdodEZvcm0gZnJvbSBcIi4vcmlnaHRGb3JtXCI7XHJcbi8v5ZCN56ew5ZKM6KeE6IyDXHJcbmNvbnNvbGUubG9nKHR5cGVPcHRpb25zLCfkuIvmi4nmoYbnsbvlnosnKVxyXG5sZXQgdHlwZU9wdGlvbnMgPSB3b3JkLnR5cGVPcHRpb25zXHJcbmxldCBzY2VuYXJpb19uYW1lID0gcmVmKFwiXCIpO1xyXG5sZXQgbW9kZV90eXBlID0gcmVmKFwiXCIpO1xyXG5sZXQgZG9uZUZsYWcgPSByZWYoXCJuZXdcIik7XHJcbi8v5ouW5ou957uE5Lu25a6e5L6LXHJcbmNvbnN0IGRyYWdnYWJsZSA9IFZ1ZURyYWdnYWJsZU5leHQ7XHJcbmxldCBwbHVtYkJveCA9IG51bGw7XHJcbmxldCBwbHVtYkJveFBvc2l0aW9uSW5mbyA9IHJlYWN0aXZlKHt9KTtcclxuLy/pvKDmoIflkozoioLngrnnmoTlhoXpg6jlt67ot50s5Li65LqG6K6p6IqC54K55pu057K+5YeG55qE5Yik5pat5Yy65Z+fXHJcbmxldCBub2RlUG9zaXRpb25EaWZmID0gcmVhY3RpdmUoe30pO1xyXG4vL+WQjumdoumcgOimgeWbnuS8oOe7meeItue7hOS7tueahOWAvFxyXG5sZXQgcGx1bWJMaXN0ID0gcmVmKFtdKTtcclxuLy/nu5jliLbmoIfor4ZcclxubGV0IHJlbmRlckZsYWcgPSByZWYodW5kZWZpbmVkKTtcclxuLy/liqjmgIHoioLngrlcclxubGV0IGFjdGl2ZU5vZGUgPSByZWYoe30pO1xyXG5sZXQgcmlnaHRGb3JtID0gcmVmKG51bGwpO1xyXG4vKlxyXG4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8v6L+e57q/5Z+656GA6YWN572uXHJcbmxldCBqc1BsdW1iQ29ubmVjdE9wdGlvbnMgPSB7XHJcbiAgICAgICAgaXNTb3VyY2U6IHRydWUsXHJcbiAgICAgICAgaXNUYXJnZXQ6IHRydWUsXHJcbiAgICAgICAgLy8g5Yqo5oCB6ZSa54K544CB5o+Q5L6b5LqGNOS4quaWueWQkSBDb250aW51b3Vz44CBQXV0b0RlZmF1bHRcclxuICAgICAgICBhbmNob3I6IFtcIkNvbnRpbnVvdXNcIix7c2hhcGU6XCJDaXJjbGVcIn1dLFxyXG4gICAgICAgIG92ZXJsYXlzOiBbWydBcnJvdycsIHsgd2lkdGg6IDgsIGxlbmd0aDogOCwgbG9jYXRpb246IDEgfV1dIC8vIG92ZXJsYXlcclxuICAgICAgfVxyXG4vL+eUu+W4g+iKgueCueeahOaLluaLvei/nue6v+mFjee9rlxyXG5jb25zdCBqc3BsdW1iU291cmNlT3B0aW9ucyA9IHtcclxuICBmaWx0ZXI6Jy5wbHVtYk5vZGUnLFxyXG4gIGZpbHRlckV4Y2x1ZGU6ZmFsc2UsXHJcbiAgYW5jaG9yOidDb250aW51b3VzJyxcclxuICBhbGxvd0xvb3BiYWNrOnRydWUsXHJcbiAgbWF4Q29ubmVjdGlvbnM6IC0xLFxyXG4gIG9uTWF4Q29ubmVjdGlvbnM6ZnVuY3Rpb24gKGluZm8sZSl7XHJcbiAgICBjb25zb2xlLmxvZyhg6LaF6L+H5LqG5pyA5aSn5YC86L+e57q/OiR7aW5mby5tYXhDb25uZWN0aW9uc31gKVxyXG4gIH1cclxufVxyXG4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiovXHJcbi8v5L+u5pS5XHJcbmNvbnN0IGRvbmVUeXBlID0gKGZsYWcsIHJvdykgPT4ge1xyXG4gIGRvbmVGbGFnLnZhbHVlID0gZmxhZztcclxuICBpZiAocm93KSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIj8/P1wiLCByb3cpO1xyXG4gICAgc2NlbmFyaW9fbmFtZS52YWx1ZSA9IHJvdy5zY2VuYXJpb05hbWU7XHJcbiAgICBtb2RlX3R5cGUudmFsdWUgPSByb3cubW9kZVR5cGU7XHJcbiAgICBpbmZvLnZhbHVlID0gcm93LmZsb3dJbmZvO1xyXG4gIH1cclxufTtcclxuLy/lt6bkvqfoj5zljZXoioLngrnnmoTmi5bmi73phY3nva5cclxuY29uc3Qgb3B0aW9ucyA9IHtcclxuICBwcmV2ZW50T25GaWx0ZXI6IGZhbHNlLFxyXG4gIHNvcnQ6IGZhbHNlLFxyXG4gIGRpc2FibGVkOiBmYWxzZSxcclxuICBnaG9zdENsYXNzOiBcInR0XCIsXHJcbiAgLy8g5LiN5L2/55SoSDXljp/nlJ/nmoTphY3nva5cclxuICBmb3JjZUZhbGxiYWNrOiB0cnVlLFxyXG59O1xyXG4vL+m7mOiupOmFjee9rlxyXG5sZXQgZ2xvYmFsQ29uZmlnID0ge1xyXG4gIENvbnRhaW5lcjogXCJwbHVtYkJveFwiLFxyXG4gIGFuY2hvcjogW1wiQm90dG9tXCIsIFwiVG9wXCIsIFwiTGVmdFwiLCBcIlJpZ2h0XCJdLFxyXG4gIGNvbm5lY3RvcjogXCJCZXppZXJcIixcclxuICBlbmRwb2ludDogXCJCbGFua1wiLFxyXG4gIHBhaW50U3R5bGU6IHtcclxuICAgIHN0cm9rZTogXCIjMzY0MjQ5XCIsXHJcbiAgICBzdHJva2VXaWR0aDogMSxcclxuICAgIG91dGxpbmVTdHJva2U6IFwidHJhbnNwYXJlbnRcIixcclxuICAgIG91dGxpbmVXaWR0aDogMTAsXHJcbiAgfSxcclxuICBob3ZlclBhaW50U3R5bGU6IHsgc3Ryb2tlOiBcIiMwMDBcIiwgc3Ryb2tlV2lkdGg6IDEuMyB9LFxyXG4gIG92ZXJsYXlzOiBbW1wiQXJyb3dcIiwgeyB3aWR0aDogNSwgbGVuZ3RoOiA1LCBsb2NhdGlvbjogMSB9XV0sXHJcbiAgZW5kcG9pbnRTdHlsZToge1xyXG4gICAgZmlsbDogXCJsaWdodGdyYXlcIixcclxuICAgIG91dGxpbmVTdHJva2U6IFwiZGFya2dyYXlcIixcclxuICAgIG91dGxpbmVXaWR0aDogMixcclxuICB9LFxyXG59O1xyXG4vL+W3puS+p1xyXG5sZXQgbGVmdE1lbnVEYXRhID0gcmVmKFtcclxuICB7XHJcbiAgICBuYW1lOiBcIui1t+Wni+WIl+ihqFwiLFxyXG4gICAgY2hpbGRyZW46IFtcclxuICAgICAge1xyXG4gICAgICAgIHRvOiBbXSxcclxuICAgICAgICB0b3A6IDAsXHJcbiAgICAgICAgbGVmdDogMCxcclxuICAgICAgICBzdGF0dXM6IFwibG9hZGluZ1wiLFxyXG4gICAgICAgIGlzU291cmNlOiB0cnVlLFxyXG4gICAgICAgIGlzVGFyZ2V0OiBmYWxzZSxcclxuICAgICAgICBjb25maWc6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwi5ZCN56ewXCIsXHJcbiAgICAgICAgICAgIG5hbWU6IFwibGFiZWxcIixcclxuICAgICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBcIui1t+Wni+iKgueCuTFcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIuaPj+i/sFwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dGFyZWFcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiXCIsXHJcbiAgICAgICAgICAgIHJlcXVpcmU6IGZhbHNlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwi5b2S5bGeXCIsXHJcbiAgICAgICAgICAgIG5hbWU6IFwiYWZmaWxpYXRpb25cIixcclxuICAgICAgICAgICAgdHlwZTogXCJzZWxlY3RcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgICAgb3B0aW9uczogW1xyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi5a6h5qC45L+h5oGvXCIsIHZhbHVlOiBcImNoZWNrXCIgfSxcclxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIueUn+S6p+e7j+iQpVwiLCB2YWx1ZTogXCJtYW5hZ2VcIiB9LFxyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi57uT566X5oql6ZSAXCIsIHZhbHVlOiBcImFjY291bnRcIiB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdG86IFtdLFxyXG4gICAgICAgIHRvcDogMCxcclxuICAgICAgICBsZWZ0OiAwLFxyXG4gICAgICAgIHN0YXR1czogXCJsb2FkaW5nXCIsXHJcbiAgICAgICAgaXNTb3VyY2U6IHRydWUsXHJcbiAgICAgICAgaXNUYXJnZXQ6IHRydWUsXHJcbiAgICAgICAgY29uZmlnOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIuWQjeensFwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcImxhYmVsXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogXCLotbflp4voioLngrkyXCIsXHJcbiAgICAgICAgICAgIHJlcXVpcmU6IHRydWUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogXCLmj4/ov7BcIixcclxuICAgICAgICAgICAgbmFtZTogXCJkZXNjcmlwdGlvblwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcInRleHRhcmVhXCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBcIlwiLFxyXG4gICAgICAgICAgICByZXF1aXJlOiBmYWxzZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIuW9kuWxnlwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcImFmZmlsaWF0aW9uXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwic2VsZWN0XCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBcImNoZWNrXCIsXHJcbiAgICAgICAgICAgIHJlcXVpcmU6IHRydWUsXHJcbiAgICAgICAgICAgIG9wdGlvbnM6IFtcclxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIuWuoeaguOS/oeaBr1wiLCB2YWx1ZTogXCJjaGVja1wiIH0sXHJcbiAgICAgICAgICAgICAgeyBsYWJlbDogXCLnlJ/kuqfnu4/okKVcIiwgdmFsdWU6IFwibWFuYWdlXCIgfSxcclxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIue7k+eul+aKpemUgFwiLCB2YWx1ZTogXCJhY2NvdW50XCIgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIuWujOe7k+WIl+ihqFwiLFxyXG4gICAgY2hpbGRyZW46IFtcclxuICAgICAge1xyXG4gICAgICAgIHRvOiBbXSxcclxuICAgICAgICB0b3A6IDAsXHJcbiAgICAgICAgbGVmdDogMCxcclxuICAgICAgICBzdGF0dXM6IFwibG9hZGluZ1wiLFxyXG4gICAgICAgIHR5cGU6IFwidGFyZ2V0XCIsXHJcbiAgICAgICAgaXNTb3VyY2U6IGZhbHNlLFxyXG4gICAgICAgIGlzVGFyZ2V0OiBmYWxzZSxcclxuICAgICAgICBjb25maWc6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwi5ZCN56ewXCIsXHJcbiAgICAgICAgICAgIG5hbWU6IFwibGFiZWxcIixcclxuICAgICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBcIuWujOe7k+iKgueCuTFcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIuaPj+i/sFwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dGFyZWFcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogZmFsc2UsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogXCLlvZLlsZ5cIixcclxuICAgICAgICAgICAgbmFtZTogXCJhZmZpbGlhdGlvblwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcInNlbGVjdFwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogXCJcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgICAgb3B0aW9uczogW1xyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi5a6h5qC45L+h5oGvXCIsIHZhbHVlOiBcImNoZWNrXCIgfSxcclxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIueUn+S6p+e7j+iQpVwiLCB2YWx1ZTogXCJtYW5hZ2VcIiB9LFxyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi57uT566X5oql6ZSAXCIsIHZhbHVlOiBcImFjY291bnRcIiB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdG86IFtdLFxyXG4gICAgICAgIHRvcDogMCxcclxuICAgICAgICBsZWZ0OiAwLFxyXG4gICAgICAgIHN0YXR1czogXCJsb2FkaW5nXCIsXHJcbiAgICAgICAgaXNTb3VyY2U6IGZhbHNlLFxyXG4gICAgICAgIGlzVGFyZ2V0OiBmYWxzZSxcclxuICAgICAgICBjb25maWc6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwi5ZCN56ewXCIsXHJcbiAgICAgICAgICAgIG5hbWU6IFwibGFiZWxcIixcclxuICAgICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBcIuWujOe7k+iKgueCuTJcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIuaPj+i/sFwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dGFyZWFcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiXCIsXHJcbiAgICAgICAgICAgIHJlcXVpcmU6IGZhbHNlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwi5b2S5bGeXCIsXHJcbiAgICAgICAgICAgIG5hbWU6IFwiYWZmaWxpYXRpb25cIixcclxuICAgICAgICAgICAgdHlwZTogXCJzZWxlY3RcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiY2hlY2tcIixcclxuICAgICAgICAgICAgcmVxdWlyZTogdHJ1ZSxcclxuICAgICAgICAgICAgb3B0aW9uczogW1xyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi5a6h5qC45L+h5oGvXCIsIHZhbHVlOiBcImNoZWNrXCIgfSxcclxuICAgICAgICAgICAgICB7IGxhYmVsOiBcIueUn+S6p+e7j+iQpVwiLCB2YWx1ZTogXCJtYW5hZ2VcIiB9LFxyXG4gICAgICAgICAgICAgIHsgbGFiZWw6IFwi57uT566X5oql6ZSAXCIsIHZhbHVlOiBcImFjY291bnRcIiB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9LFxyXG5dKTtcclxuLy/muLLmn5PoioLngrnkv6Hmga8o6buY6K6k5piv5ZCO5Y+w5Lyg6L+H5p2l55qEKVxyXG5sZXQgaW5mbyA9IHJlZihbXSk7XHJcbi8v5paw5aKe5LiA5Liq6IqC54K5XHJcbmNvbnN0IGFkZE5vZGUgPSAobmV3SW5mbykgPT4ge1xyXG4gIG5ld0luZm8uaWQgPSB1dWlkdjQoKTtcclxuICBuZXdJbmZvID0gT2JqZWN0LmFzc2lnbihuZXdJbmZvLCBnbG9iYWxDb25maWcpO1xyXG4gIGluZm8udmFsdWUucHVzaChuZXdJbmZvKTtcclxuICBjb25zb2xlLmxvZyhuZXdJbmZvLCBcIj8/P+aWsOWinuiKgueCueeahOS/oeaBr1wiKTtcclxuICAvLyBtYWtlRnVuKG5ld0luZm8pXHJcbiAgbmV4dFRpY2soKCkgPT4ge1xyXG4gICAgcmVuZGVyRmxhZy52YWx1ZSA9IFwibmV3XCI7XHJcbiAgICBtYWtlRnVuKG5ld0luZm8pO1xyXG4gIH0pO1xyXG59O1xyXG5cclxuLy/mlrDlop7kuIDmnaHov57nur9cclxuY29uc3QgYWRkTGluZSA9ICgpID0+IHtcclxuICBpbmZvLnZhbHVlWzNdLnRvID0gW1wiZGl2NlwiXTtcclxuICByZW5kZXJOb2RlKCk7XHJcbn07XHJcbmNvbnN0IG1vdXNlRG93bkZ1biA9IChldmVudCkgPT4ge1xyXG4gIC8v5YW35L2T5L2N572u6byg5qCH5L+h5oGvXHJcbiAgbGV0IG1vdXNlZG93blBvc2l0aW9uSW5mbyA9IHsgeDogZXZlbnQuY2xpZW50WCwgeTogZXZlbnQuY2xpZW50WSB9O1xyXG4gIC8v6KKr5ouW5ou96IqC54K55Yid5aeL55qE5L2N572u5L+h5oGvXHJcbiAgbGV0IG1vdmVCb3hCZWZvcmVQb3NpdGlvbiA9IHtcclxuICAgIHg6IGV2ZW50LnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS54LFxyXG4gICAgeTogZXZlbnQudGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnksXHJcbiAgfTtcclxuICBub2RlUG9zaXRpb25EaWZmID0ge1xyXG4gICAgbGVmdERpZmY6IG1vdXNlZG93blBvc2l0aW9uSW5mby54IC0gbW92ZUJveEJlZm9yZVBvc2l0aW9uLngsXHJcbiAgICB0b3BEaWZmOiBtb3VzZWRvd25Qb3NpdGlvbkluZm8ueSAtIG1vdmVCb3hCZWZvcmVQb3NpdGlvbi55LFxyXG4gIH07XHJcbn07XHJcbi8v5byA5aeL5ouW5YqoXHJcbmNvbnN0IG1vdmVTdGFydCA9IChlbCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKGVsLCBcIuW8gOWni+aLluWKqFwiKTtcclxufTtcclxuLy/lgZzmraLmi5bliqhcclxuY29uc3QgbW92ZUVuZCA9IChlbCkgPT4ge1xyXG4gIHJlZnJlc2hQbHVtYlBvc3Rpb25JbmZvKCk7XHJcbiAgbGV0IGRyYWdOb2RlSW5mbyA9IEpTT04ucGFyc2UoZWwuaXRlbS5hdHRyaWJ1dGVzLmRpdk9wdGlvbi5ub2RlVmFsdWUpO1xyXG4gIGp1ZGdlUG9zaXRpb24oXHJcbiAgICBkcmFnTm9kZUluZm8sXHJcbiAgICBwbHVtYkJveFBvc2l0aW9uSW5mbyxcclxuICAgIGVsLm9yaWdpbmFsRXZlbnQueCxcclxuICAgIGVsLm9yaWdpbmFsRXZlbnQueVxyXG4gICk7XHJcbn07XHJcbi8v5Yik5pat5ouW5Yqo5Yy65Z+fXHJcbmNvbnN0IGp1ZGdlUG9zaXRpb24gPSAoZHJhZ05vZGVJbmZvLCBwbHVtYkJveFBvc2l0aW9uSW5mbywgeCwgeSkgPT4ge1xyXG4gIC8v5ouW5ou96Iez55S75biD5aSW6YOoXHJcbiAgaWYgKFxyXG4gICAgeCAtIG5vZGVQb3NpdGlvbkRpZmYubGVmdERpZmYgPCBwbHVtYkJveFBvc2l0aW9uSW5mby5sZWZ0IHx8XHJcbiAgICB4ICsgMTgwIC0gbm9kZVBvc2l0aW9uRGlmZi5sZWZ0RGlmZiA+IHBsdW1iQm94UG9zaXRpb25JbmZvLnJpZ2h0IHx8XHJcbiAgICB5IC0gbm9kZVBvc2l0aW9uRGlmZi50b3BEaWZmIDwgcGx1bWJCb3hQb3NpdGlvbkluZm8udG9wIHx8XHJcbiAgICB5ICsgNDAgLSBub2RlUG9zaXRpb25EaWZmLnRvcERpZmYgPiBwbHVtYkJveFBvc2l0aW9uSW5mby5ib3R0b21cclxuICApIHtcclxuICAgIEVsTWVzc2FnZSh7XHJcbiAgICAgIG1lc3NhZ2U6IFwi6IqC54K55LiN6IO95ouW5ou96Iez55S75biD5LmL5aSWXCIsXHJcbiAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgIH0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBkcmFnTm9kZUluZm8ubGVmdCA9XHJcbiAgICAgIHggLSBwbHVtYkJveFBvc2l0aW9uSW5mby5sZWZ0IC0gbm9kZVBvc2l0aW9uRGlmZi5sZWZ0RGlmZjtcclxuICAgIGRyYWdOb2RlSW5mby50b3AgPSB5IC0gcGx1bWJCb3hQb3NpdGlvbkluZm8udG9wIC0gbm9kZVBvc2l0aW9uRGlmZi50b3BEaWZmO1xyXG4gICAgYWRkTm9kZShkcmFnTm9kZUluZm8pO1xyXG4gIH1cclxufTtcclxuLy/liLfmlrDnlLvluIPljLrln5/kv6Hmga9cclxuY29uc3QgcmVmcmVzaFBsdW1iUG9zdGlvbkluZm8gPSAoKSA9PiB7XHJcbiAgcGx1bWJCb3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnBsdW1iQm94XCIpO1xyXG4gIGlmIChwbHVtYkJveCkge1xyXG4gICAgbGV0IHBvc2l0aW9uSW5mbyA9IHBsdW1iQm94LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgcGx1bWJCb3hQb3NpdGlvbkluZm8gPSBwb3NpdGlvbkluZm87XHJcbiAgICBjb25zb2xlLmxvZyhwbHVtYkJveFBvc2l0aW9uSW5mbywn55S75biD5L+h5oGvJylcclxuICB9XHJcbn07XHJcbi8v5riy5p+T6IqC54K5XHJcbmNvbnN0IHJlbmRlck5vZGUgPSAoZmxhZykgPT4ge1xyXG4gIC8v5ZCI5bm26IqC54K55L+h5oGv5ZKM6YWN572uXHJcbiAgaW5mby52YWx1ZS5tYXAoKGl0ZW0pID0+IChpdGVtID0gT2JqZWN0LmFzc2lnbihpdGVtLCBnbG9iYWxDb25maWcpKSk7XHJcbiAgLy/ov5nph4zpnIDopoHnrYnmiYDkvp3otZbnmoRET03oioLngrnlhajpg6jmuLLmn5Plrozmr5Us5omN6IO96L+b6KGM5Zu+5b2i5riy5p+TXHJcbiAgbmV4dFRpY2soKCkgPT4ge1xyXG4gICAgaWYgKGZsYWcgPT09IFwibmV3XCIpIHtcclxuICAgICAgcmVuZGVyRmxhZy52YWx1ZSA9IFwib25jZVwiO1xyXG4gICAgfVxyXG4gICAgLy/muIXpmaTkuYvliY3nmoTlhoXlrrlcclxuICAgIHBsdW1iSW5pdC5kZWxldGVFdmVyeUNvbm5lY3Rpb24oKTtcclxuICAgIHBsdW1iSW5pdC5kZWxldGVFdmVyeUVuZHBvaW50KCk7XHJcbiAgICByZWZyZXNoUGx1bWJQb3N0aW9uSW5mbygpO1xyXG4gICAgLy/muLLmn5PnlLvluIPkuK3nmoTkv6Hmga/oioLngrlcclxuICAgIGxldCByZW5kZXJMaXN0ID0gW107XHJcbiAgICAvLyBpZihpbmZvLnZhbHVlLmxlbmd0aDwxKXtyZXR1cm59XHJcbiAgICBpbmZvLnZhbHVlLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKGl0ZW0udG8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGl0ZW0udG8uZm9yRWFjaCgodikgPT4ge1xyXG4gICAgICAgICAgcmVuZGVyTGlzdC5wdXNoKHtcclxuICAgICAgICAgICAgc291cmNlOiBpdGVtLmlkLFxyXG4gICAgICAgICAgICB0YXJnZXQ6IHYsXHJcbiAgICAgICAgICAgIGFuY2hvcjogaXRlbS5hbmNob3IsXHJcbiAgICAgICAgICAgIGNvbm5lY3RvcjogaXRlbS5jb25uZWN0b3IsXHJcbiAgICAgICAgICAgIGVuZHBvaW50OiBpdGVtLmVuZHBvaW50LFxyXG4gICAgICAgICAgICBvdmVybGF5czogaXRlbS5vdmVybGF5cyxcclxuICAgICAgICAgICAgcGFpbnRTdHlsZTogaXRlbS5wYWludFN0eWxlLFxyXG4gICAgICAgICAgICBob3ZlclBhaW50U3R5bGU6IGl0ZW0uaG92ZXJQYWludFN0eWxlLFxyXG4gICAgICAgICAgICBlbmRwb2ludFN0eWxlOiBpdGVtLmVuZHBvaW50U3R5bGUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBwbHVtYkxpc3QudmFsdWUgPSByZW5kZXJMaXN0O1xyXG4gICAgLy/muLLmn5Plh73mlbBcclxuICAgIHBsdW1iSW5pdC5yZWFkeSgoKSA9PiB7XHJcbiAgICAgIHJlbmRlckxpc3QuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIC8vIHBsdW1iSW5pdC5jb25uZWN0KGl0ZW0sanNQbHVtYkNvbm5lY3RPcHRpb25zKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhpdGVtLCfmuLLmn5Plj4LmlbA9PT0nKVxyXG4gICAgICAgIHBsdW1iSW5pdC5jb25uZWN0KGl0ZW0pO1xyXG4gICAgICB9KTtcclxuICAgICAgaW5mby52YWx1ZS5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgICAgbWFrZUZ1bihpdGVtKTtcclxuICAgICAgICBwbHVtYkluaXQuZHJhZ2dhYmxlKGl0ZW0uaWQsIHtcclxuICAgICAgICAgIGNvbnRhaW5tZW50OiBcInBhcmVudFwiLFxyXG4gICAgICAgICAgc3RvcDogZnVuY3Rpb24gKGVsKSB7XHJcbiAgICAgICAgICAgIGl0ZW0ubGVmdCA9IGVsLnBvc1swXTtcclxuICAgICAgICAgICAgaXRlbS50b3AgPSBlbC5wb3NbMV07XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59O1xyXG4vL+iuvue9ruiKgueCueWPr+i/nuaOpeWxnuaAp1xyXG5jb25zdCBtYWtlRnVuID0gKGl0ZW0pID0+IHtcclxuICBwbHVtYkluaXQuc2V0U291cmNlRW5hYmxlZChpdGVtLmlkLCBpdGVtLmlzU291cmNlKTtcclxuICBwbHVtYkluaXQuc2V0VGFyZ2V0RW5hYmxlZChpdGVtLmlkLCBpdGVtLmlzVGFyZ2V0KTtcclxuICBwbHVtYkluaXQuc2V0RHJhZ2dhYmxlKGl0ZW0uaWQsIHRydWUpO1xyXG4gIHBsdW1iSW5pdC5tYWtlU291cmNlKGl0ZW0uaWQsIHtcclxuICAgIGZpbHRlcjogXCIucGx1bWJOb2RlXCIsXHJcbiAgICBmaWx0ZXJFeGNsdWRlOiBmYWxzZSxcclxuICAgIGFsbG93TG9vcGJhY2s6IGZhbHNlLFxyXG4gICAgbWF4Q29ubmVjdGlvbnM6IC0xLFxyXG4gICAgQ29udGFpbmVyOiBcInBsdW1iQm94XCIsXHJcbiAgICBhbmNob3I6IGl0ZW0uYW5jaG9yLFxyXG4gICAgY29ubmVjdG9yOiBpdGVtLmNvbm5lY3RvcixcclxuICAgIGVuZHBvaW50OiBpdGVtLmVuZHBvaW50LFxyXG4gICAgb3ZlcmxheXM6IGl0ZW0ub3ZlcmxheXMsXHJcbiAgICBwYWludFN0eWxlOiBpdGVtLnBhaW50U3R5bGUsXHJcbiAgICBob3ZlclBhaW50U3R5bGU6IGl0ZW0uaG92ZXJQYWludFN0eWxlLFxyXG4gICAgZW5kcG9pbnRTdHlsZTogaXRlbS5lbmRwb2ludFN0eWxlLFxyXG4gIH0pO1xyXG4gIHBsdW1iSW5pdC5tYWtlVGFyZ2V0KGl0ZW0uaWQsIHtcclxuICAgIGZpbHRlcjogXCIucGx1bWJOb2RlXCIsXHJcbiAgICBmaWx0ZXJFeGNsdWRlOiBmYWxzZSxcclxuICAgIGFsbG93TG9vcGJhY2s6IGZhbHNlLFxyXG4gICAgbWF4Q29ubmVjdGlvbnM6IDEsXHJcbiAgICBDb250YWluZXI6IFwicGx1bWJCb3hcIixcclxuICAgIGFuY2hvcjogaXRlbS5hbmNob3IsXHJcbiAgICBjb25uZWN0b3I6IGl0ZW0uY29ubmVjdG9yLFxyXG4gICAgZW5kcG9pbnQ6IGl0ZW0uZW5kcG9pbnQsXHJcbiAgICBvdmVybGF5czogaXRlbS5vdmVybGF5cyxcclxuICAgIHBhaW50U3R5bGU6IGl0ZW0ucGFpbnRTdHlsZSxcclxuICAgIGhvdmVyUGFpbnRTdHlsZTogaXRlbS5ob3ZlclBhaW50U3R5bGUsXHJcbiAgICBlbmRwb2ludFN0eWxlOiBpdGVtLmVuZHBvaW50U3R5bGUsXHJcbiAgfSk7XHJcbiAgcGx1bWJJbml0LmRyYWdnYWJsZShpdGVtLmlkLCB7XHJcbiAgICBjb250YWlubWVudDogXCJwYXJlbnRcIixcclxuICAgIHN0b3A6IGZ1bmN0aW9uIChlbCkge1xyXG4gICAgICBpdGVtLmxlZnQgPSBlbC5wb3NbMF07XHJcbiAgICAgIGl0ZW0udG9wID0gZWwucG9zWzFdO1xyXG4gICAgfSxcclxuICB9KTtcclxufTtcclxuXHJcbi8vIOe7meWFg+e0oOiuvue9rua4suafk+agt+W8j1xyXG5jb25zdCBnZXRTdHlsZSA9IGZ1bmN0aW9uIChpdGVtKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXHJcbiAgICBsZWZ0OiBpdGVtLmxlZnQgKyBcInB4XCIsXHJcbiAgICB0b3A6IGl0ZW0udG9wICsgXCJweFwiLFxyXG4gICAgLy8gY29sb3I6aXRlbS5jb2xvcixcclxuICAgIC8vIGJvcmRlcjonMXB4IHNvbGlkICMnLFxyXG4gICAgd2lkdGg6IFwiMTgwcHhcIixcclxuICAgIGhlaWdodDogXCIzNnB4XCIsXHJcbiAgICBsaW5lSGVpZ2h0OiBcIjM2cHhcIixcclxuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcclxuICAgIGJvcmRlckxlZnQ6IFwiNXB4IHNvbGlkIGJsdWVcIixcclxuICAgIGJvcmRlclJhZGl1czogXCI0JVwiLFxyXG4gICAgYm94U2hhZG93OiBcIiNlZWUgM3B4IDNweCAzcHggM3B4XCIsXHJcbiAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gIH07XHJcbn07XHJcbi8v5Yid5aeL5YyWanNwbHVtYuWunuS+i1xyXG5sZXQgcGx1bWJJbml0ID0ganNQbHVtYi5nZXRJbnN0YW5jZSgpO1xyXG5cclxuLy/ngrnlh7vov57nur/kuovku7ZcclxucGx1bWJJbml0LmJpbmQoXCJjbGlja1wiLCAoY29ubiwgb3JpZ2luYWxFdmVudCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKGNvbm4sIFwi54K55Ye76L+e57q/XCIpO1xyXG4gIGxldCBsaW5lSW5mbyA9IHt9O1xyXG4gIGNvbnNvbGUubG9nKGluZm8udmFsdWUsIFwi5pW05L2T5L+h5oGvXCIpO1xyXG4gIGxldCBzb3VyY2VJbmZvID0gaW5mby52YWx1ZS5maW5kKCh2KSA9PiB2LmlkID09PSBjb25uLnNvdXJjZUlkKTtcclxuICBsZXQgdGFyZ2V0SW5mbyA9IGluZm8udmFsdWUuZmluZCgodikgPT4gdi5pZCA9PT0gY29ubi50YXJnZXRJZCk7XHJcbiAgbGluZUluZm8gPSB7XHJcbiAgICBzb3VyY2VJbmZvLFxyXG4gICAgdGFyZ2V0SW5mbyxcclxuICB9O1xyXG4gIHJpZ2h0Rm9ybS52YWx1ZS5nZXRMaW5lSW5mbyhsaW5lSW5mbyk7XHJcbiAgLy8gY29uc29sZS5sb2coXCLngrnlh7vkuoZcIiwgY29vbiwgb3JpZ2luYWxFdmVudCk7XHJcbiAgLy8gcGx1bWJJbml0LmRlbGV0ZUNvbm5lY3Rpb24oY29ubik7XHJcbn0pO1xyXG4vL+i/nue6v+inpuWPkeS6i+S7tlxyXG5wbHVtYkluaXQuYmluZChcImNvbm5lY3Rpb25cIiwgKGV2ZW50KSA9PiB7XHJcbiAgY29uc29sZS5sb2coZXZlbnQsIFwi5paw55qE6L+e57q/5LqL5Lu26Kem5Y+RXCIpO1xyXG4gIC8vIGZvcmNlVXBkYXRlKCk7XHJcbiAgbGV0IHNvdXJjZU5vZGUgPSBpbmZvLnZhbHVlLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGV2ZW50LnNvdXJjZUlkKTtcclxuICBjb25zb2xlLmxvZyhzb3VyY2VOb2RlLnRvLCBldmVudC50YXJnZXRJZCwgXCI/Pz9cIik7XHJcbiAgaWYgKHNvdXJjZU5vZGUudG8uZmluZEluZGV4KCh2KSA9PiB2ID09PSBldmVudC50YXJnZXRJZCkgPT09IC0xKSB7XHJcbiAgICBzb3VyY2VOb2RlLnRvLnB1c2goZXZlbnQudGFyZ2V0SWQpO1xyXG4gIH1cclxuICBwbHVtYkluaXQucmVwYWludCgpO1xyXG4gIG5leHRUaWNrKCgpID0+IHtcclxuICAgIHJlbmRlckZsYWcudmFsdWUgPSBcIm5ld1wiO1xyXG4gIH0pO1xyXG4gIGlmIChyZW5kZXJGbGFnLnZhbHVlID09PSBcIm5ld1wiKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIuaWsOeahOmhtemdouWIt+aWsFwiKTtcclxuICAgIHJlbmRlckZsYWcudmFsdWUgPSBcIm9uY2VcIjtcclxuICAgIHJlbmRlck5vZGUoXCJuZXdcIik7XHJcbiAgfVxyXG4gIC8vIGNvbnNvbGUubG9nKGluZm8udmFsdWUsJ+aJgOacieiKgueCuScpXHJcbiAgLy8gcmVuZGVyTm9kZSgpXHJcbn0pO1xyXG5cclxuLy/liIfmjaLliqjmgIHoioLngrlcclxuZnVuY3Rpb24gc2VuZEFjdGl2ZShub2RlKSB7XHJcbiAgYWN0aXZlTm9kZS52YWx1ZSA9IG5vZGU7XHJcbiAgY29uc29sZS5sb2coYWN0aXZlTm9kZS52YWx1ZSwgXCLliqjmgIHoioLngrlcIik7XHJcbiAgcmlnaHRGb3JtLnZhbHVlLmNoYW5nZUZvcm1EYXRhKGFjdGl2ZU5vZGUudmFsdWUuY29uZmlnKTtcclxufVxyXG5cclxub25Nb3VudGVkKCgpID0+IHtcclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIHJlbmRlck5vZGUoKTtcclxuICAgIG5leHRUaWNrKCgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCLpobXpnaLliJ3mrKHmuLLmn5Plrozmr5VcIik7XHJcbiAgICAgIHJlbmRlckZsYWcudmFsdWUgPSBcInJlbmRlclwiO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn0pO1xyXG4vL+WPs+S+p+S/neWtmOWAvFxyXG5jb25zdCBjaGFuZ2VBY3RpdmVOb2RlSW5mbyA9IChpbmZvKSA9PiB7XHJcbiAgY29uc29sZS5sb2coaW5mbywgXCLkv53lrZjlkI7nmoTmlrDlgLxcIik7XHJcbiAgYWN0aXZlTm9kZS52YWx1ZS5jb25maWcgPSBpbmZvO1xyXG4gIG5leHRUaWNrKCgpID0+IHtcclxuICAgIHJlbmRlckZsYWcudmFsdWUgPSBcIm5ld1wiO1xyXG4gICAgbWFrZUZ1bihhY3RpdmVOb2RlLnZhbHVlKTtcclxuICB9KTtcclxufTtcclxuLy/liKDpmaTnur9cclxuY29uc3QgZGVsZXRlTGluZSA9IChkZWxldGVMaW5lSW5mbykgPT4ge1xyXG4gIGNvbnNvbGUubG9nKGRlbGV0ZUxpbmVJbmZvLCBcIuimgeWIoOmZpOeahOi/nue6v+S/oeaBr1wiKTtcclxuICBjb25zb2xlLmxvZyhpbmZvLnZhbHVlLCBcIuWFqOmHj+S/oeaBr1wiKTtcclxuICBsZXQgc291cmNlSW5kZXggPSBpbmZvLnZhbHVlLmZpbmRJbmRleChcclxuICAgIChpdGVtKSA9PiBpdGVtLmlkID09PSBkZWxldGVMaW5lSW5mby5zb3VyY2VJbmZvLmlkXHJcbiAgKTtcclxuICBsZXQgZGVsZXRlVGFyZ2V0SWQgPSBkZWxldGVMaW5lSW5mby50YXJnZXRJbmZvLmlkO1xyXG4gIGxldCBkZWxldGVUYXJnZXRJbmRleCA9IGluZm8udmFsdWVbc291cmNlSW5kZXhdLnRvLmZpbmRJbmRleChcclxuICAgICh2KSA9PiB2ID09PSBkZWxldGVUYXJnZXRJZFxyXG4gICk7XHJcbiAgaW5mby52YWx1ZVtzb3VyY2VJbmRleF0udG8uc3BsaWNlKGRlbGV0ZVRhcmdldEluZGV4LCAxKTtcclxuICByZW5kZXJOb2RlKCk7XHJcbn07XHJcbi8v5Yig6Zmk6IqC54K5XHJcbmNvbnN0IGRlbGV0ZU5vZGUgPSAobm9kZUluZm8pID0+IHtcclxuICBjb25zb2xlLmxvZyhhY3RpdmVOb2RlLnZhbHVlKTtcclxuICBsZXQgbm9kZUluZGV4ID0gaW5mby52YWx1ZS5maW5kSW5kZXgoXHJcbiAgICAoaXRlbSkgPT4gaXRlbS5pZCA9PT0gYWN0aXZlTm9kZS52YWx1ZS5pZFxyXG4gICk7XHJcbiAgaW5mby52YWx1ZS5zcGxpY2Uobm9kZUluZGV4LCAxKTtcclxuICBpbmZvLnZhbHVlLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgIGxldCBmbGFnSW5kZXggPSBpdGVtLnRvLmZpbmRJbmRleCgodikgPT4gdiA9PT0gYWN0aXZlTm9kZS52YWx1ZS5pZCk7XHJcbiAgICBpZiAoZmxhZ0luZGV4ICE9PSAtMSkge1xyXG4gICAgICBpdGVtLnRvLnNwbGljZShmbGFnSW5kZXgsIDEpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG4gIGNvbnNvbGUubG9nKGluZm8udmFsdWUsIFwi6IqC54K55YiX6KGoXCIpO1xyXG4gIHJlbmRlck5vZGUoKTtcclxuICBhY3RpdmVOb2RlLnZhbHVlID0ge307XHJcbiAgcmlnaHRGb3JtLnZhbHVlLmNoYW5nZUZvcm1EYXRhKFtdKTtcclxufTtcclxuLy/mmrTpnLLnu5nniLbnu4Tku7bnmoTlgLws6ZyA6KaB54i257uE5Lu25Y+R6YCB6K+35rGCXHJcbmRlZmluZUV4cG9zZSh7XHJcbiAgcGx1bWJMaXN0LFxyXG4gIGluZm8sXHJcbiAgc2NlbmFyaW9fbmFtZSxcclxuICBtb2RlX3R5cGUsXHJcbiAgZG9uZVR5cGUsXHJcbn0pO1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4uYm94IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLmxlZnRNZW51IHtcclxuICB3aWR0aDogMjQwcHg7XHJcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2QzZDNkMztcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcclxuICBoMyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgYmFja2dyb3VuZDogI2VlZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbiAgLmNvbnRlbnQge1xyXG4gICAgd2lkdGg6IDE4MHB4O1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgYm9yZGVyOiBkYXNoZWQgMXB4ICMwMzAzMDM7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBsaW5lLWhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG59XHJcblxyXG4ucGx1bWJCb3gge1xyXG4gIG92ZXJmbG93OiBzY3JvbGw7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC8vIG1hcmdpbjogMCAyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNkM2QzZDM7XHJcbn1cclxuXHJcbi5yaWdodENvbnRlbnQge1xyXG4gIHdpZHRoOiAyNDBweDtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2QzZDNkMztcclxuICBoMyB7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbn1cclxuXHJcbi5wbHVtYk5vZGUge1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG4gIGxpbmUtaGVpZ2h0OiA0NXB4O1xyXG59XHJcbi5hY3RpdmVQbHVtYk5vZGUge1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG4gIGxpbmUtaGVpZ2h0OiA0NXB4O1xyXG4gIGJhY2tncm91bmQ6ICMwYmNmZTk7XHJcbn1cclxuLm5vcm1hbE5vZGUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbn1cclxuLmFjdGl2ZU5vZGUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM4MGVhZjg7XHJcbn1cclxuLm5hbWVDb250ZW50IHtcclxuICBwYWRkaW5nLWJvdHRvbTogMTRweDtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VlZTtcclxufVxyXG48L3N0eWxlPlxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuIFxyXG5cclxuXHJcblxyXG4gICAgIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTBlNjIyNTYyJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9yaWdodEZvcm0udnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9MGU2MjI1NjImbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVEb21BUEkuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRGbiBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0U3R5bGVFbGVtZW50LmpzXCI7XG4gICAgICBpbXBvcnQgc3R5bGVUYWdUcmFuc2Zvcm1GbiBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vdmlzdWFsLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTc3NzEzZjY0Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi92aXN1YWwudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9Nzc3MTNmNjQmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wZTYyMjU2MiZzY29wZWQ9dHJ1ZVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL3JpZ2h0Rm9ybS52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9yaWdodEZvcm0udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL3JpZ2h0Rm9ybS52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0wZTYyMjU2MiZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCJEOlxcXFzpobnnm65cXFxcd2VicGFjay12dWVcXFxcd2VicGFjay0tLS12dWVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1sb2FkZXJcXFxcZGlzdFxcXFxleHBvcnRIZWxwZXIuanNcIlxuY29uc3QgX19leHBvcnRzX18gPSAvKiNfX1BVUkVfXyovZXhwb3J0Q29tcG9uZW50KHNjcmlwdCwgW1sncmVuZGVyJyxyZW5kZXJdLFsnX19zY29wZUlkJyxcImRhdGEtdi0wZTYyMjU2MlwiXSxbJ19fZmlsZScsXCJzcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy9yaWdodEZvcm0udnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcIjBlNjIyNTYyXCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnMGU2MjI1NjInLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCcwZTYyMjU2MicsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wZTYyMjU2MiZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCcwZTYyMjU2MicsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vdmlzdWFsLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD03NzcxM2Y2NCZzY29wZWQ9dHJ1ZVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL3Zpc3VhbC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi92aXN1YWwudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL3Zpc3VhbC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD03NzcxM2Y2NCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCJEOlxcXFzpobnnm65cXFxcd2VicGFjay12dWVcXFxcd2VicGFjay0tLS12dWVcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1sb2FkZXJcXFxcZGlzdFxcXFxleHBvcnRIZWxwZXIuanNcIlxuY29uc3QgX19leHBvcnRzX18gPSAvKiNfX1BVUkVfXyovZXhwb3J0Q29tcG9uZW50KHNjcmlwdCwgW1sncmVuZGVyJyxyZW5kZXJdLFsnX19zY29wZUlkJyxcImRhdGEtdi03NzcxM2Y2NFwiXSxbJ19fZmlsZScsXCJzcmMvcGFnZXMvYnVzaW5lc3MvY29tcG9uZW50cy92aXN1YWwudnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcIjc3NzEzZjY0XCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnNzc3MTNmNjQnLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCc3NzcxM2Y2NCcsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vdmlzdWFsLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD03NzcxM2Y2NCZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCc3NzcxM2Y2NCcsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCIiLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi92aXN1YWwudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi92aXN1YWwudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3RlbXBsYXRlTG9hZGVyLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzRdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9yaWdodEZvcm0udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTBlNjIyNTYyJnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vdmlzdWFsLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD03NzcxM2Y2NCZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vcmlnaHRGb3JtLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTBlNjIyNTYyJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vdmlzdWFsLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTc3NzEzZjY0Jmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiIl0sIm5hbWVzIjpbIl9jcmVhdGVFbGVtZW50Vk5vZGUiLCIkc2V0dXAiLCJpbmZvVHlwZSIsIl9jcmVhdGVCbG9jayIsIl9jb21wb25lbnRfZWxfZm9ybSIsInJlZiIsIm1vZGVsIiwicnVsZUZvcm0iLCJydWxlcyIsInNpemUiLCJmb3JtU2l6ZSIsIl9jcmVhdGVFbGVtZW50QmxvY2siLCJfRnJhZ21lbnQiLCJfcmVuZGVyTGlzdCIsImZvcm1EYXRhIiwiaXRlbSIsImluZGV4IiwiX2NvbXBvbmVudF9lbF9mb3JtX2l0ZW0iLCJsYWJlbCIsInByb3AiLCJuYW1lIiwia2V5IiwidHlwZSIsIl9jb21wb25lbnRfZWxfaW5wdXQiLCIkZXZlbnQiLCJfY29tcG9uZW50X2VsX3NlbGVjdCIsIm9wdGlvbnMiLCJtIiwibiIsIl9jb21wb25lbnRfZWxfb3B0aW9uIiwidmFsdWUiLCJfaG9pc3RlZF8xIiwiX2hvaXN0ZWRfMiIsIl90b0Rpc3BsYXlTdHJpbmciLCJsaW5lRGF0YSIsInNvdXJjZUluZm8iLCJjb25maWciLCJfaG9pc3RlZF8zIiwidGFyZ2V0SW5mbyIsIl9ob2lzdGVkXzQiLCJfY3JlYXRlVk5vZGUiLCJfY29tcG9uZW50X2VsX2J1dHRvbiIsIm9uQ2xpY2siLCJfY2FjaGUiLCJzdWJtaXRGb3JtIiwicnVsZUZvcm1SZWYiLCJsZW5ndGgiLCJkZWx0ZU5vZGVGdW4iLCJkZWxldGVMaW5lRnVuIiwibGlzdFNob3ciLCJpZCIsInN0eWxlIiwic2NlbmFyaW9fbmFtZSIsInRyaW0iLCJtb2RlX3R5cGUiLCJ0eXBlT3B0aW9ucyIsIl9jb21wb25lbnRfZWxfY29sbGFwc2UiLCJsZWZ0TWVudURhdGEiLCJpdGVtMSIsIl9jb21wb25lbnRfZWxfY29sbGFwc2VfaXRlbSIsInRpdGxlIiwib25TdGFydCIsIm1vdmVTdGFydCIsIm9uRW5kIiwibW92ZUVuZCIsImNoaWxkcmVuIiwiaXRlbTIiLCJkaXZPcHRpb24iLCJKU09OIiwic3RyaW5naWZ5Iiwib25Nb3VzZWRvd24iLCJtb3VzZURvd25GdW4iLCJfaG9pc3RlZF81IiwiX2hvaXN0ZWRfNiIsImluZm8iLCJfbm9ybWFsaXplU3R5bGUiLCJnZXRTdHlsZSIsIl9ub3JtYWxpemVDbGFzcyIsImFjdGl2ZU5vZGUiLCJzZW5kQWN0aXZlIiwiX2NvbXBvbmVudF9lbF9pY29uIiwiX2NvbXBvbmVudF9DaXJjbGVQbHVzRmlsbGVkIiwic3RhdHVzIiwiY29sb3IiLCJfY29tcG9uZW50X0xvYWRpbmciLCJfY29tcG9uZW50X0NpcmNsZUNoZWNrRmlsbGVkIiwiX2NvbXBvbmVudF9DaXJjbGVDbG9zZUZpbGxlZCIsIl9ob2lzdGVkXzkiLCJfaG9pc3RlZF8xMCIsIl9ob2lzdGVkXzExIiwib25DaGFuZ2VBY3RpdmVOb2RlSW5mbyIsImNoYW5nZUFjdGl2ZU5vZGVJbmZvIiwib25EZWxldGVMaW5lIiwiZGVsZXRlTGluZSIsIm9uRGVsZXRlTm9kZSIsImRlbGV0ZU5vZGUiXSwic291cmNlUm9vdCI6IiJ9