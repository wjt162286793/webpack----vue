"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_components_creatRisk_vue"],{

/***/ 12462:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".content[data-v-e36921d0] {\n  padding: 16px;\n}\n.content[data-v-e36921d0] .el-range-editor.el-input__wrapper {\n  max-width: max-content;\n}\n.content .form_item[data-v-e36921d0] {\n  width: 400px;\n}\n.btnList[data-v-e36921d0] {\n  display: flex;\n  justify-content: center;\n}\n", "",{"version":3,"sources":["webpack://./src/components/creatRisk.vue","webpack://./creatRisk.vue"],"names":[],"mappings":"AACA;EACE,aAAA;ACAF;ADDA;EAII,sBAAA;ACAJ;ADJA;EAQI,YAAA;ACDJ;ADKA;EACE,aAAA;EACA,uBAAA;ACHF","sourcesContent":["\n.content {\n  padding: 16px;\n\n  /deep/ .el-range-editor.el-input__wrapper {\n    max-width: max-content;\n  }\n\n  .form_item {\n    width: 400px;\n  }\n}\n\n.btnList {\n  display: flex;\n  justify-content: center;\n}\n",".content {\n  padding: 16px;\n}\n.content /deep/ .el-range-editor.el-input__wrapper {\n  max-width: max-content;\n}\n.content .form_item {\n  width: 400px;\n}\n.btnList {\n  display: flex;\n  justify-content: center;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 88832:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/creatRisk.vue?vue&type=script&setup=true&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var _store_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store/index.js */ 28360);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/dictionaries/risk.json */ 39753);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var element_plus__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! element-plus */ 93971);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ 62494);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'creatRisk',
  emits: ["addRiskSuccess"],
  setup: function setup(__props, _ref) {
    var expose = _ref.expose,
      emit = _ref.emit;
    var riskVisible = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(false);
    var stepValue = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(0);
    var ruleFormRef0 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var ruleFormRef1 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var ruleFormRef2 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var informList = ["手机", "微信", "OA系统", "邮箱", "IAM"];
    var ruleForm0 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({
      name: "",
      riskAlias: "",
      riskPosition: "purchase",
      riskLevel: "normal"
    });
    var ruleForm1 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({
      isControl: true,
      controlSize: "year",
      times: []
    });
    var ruleForm2 = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({
      auditUser: null,
      explain: "",
      inform: ["IAM"]
    });
    var rules0 = {
      riskAlias: [{
        required: true,
        message: "请输入风险别名",
        trigger: "blur"
      }, {
        min: 6,
        message: "账号至少为6位数",
        trigger: "blur"
      }, {
        max: 12,
        message: "账号最多为12位数",
        trigger: "blur"
      }, {
        pattern: new RegExp("^[\\u4e00-\\u9fa5][\\u4e00-\\u9fa5a-zA-Z0-9-]*$"),
        message: "只可以输入中文和数字",
        trigger: "blur"
      }],
      riskPosition: [{
        required: true,
        message: "风险定位必须选择",
        trigger: "change"
      }],
      riskLevel: [{
        required: true,
        message: "风险等级必须选择",
        trigger: "change"
      }]
    };
    var rules1 = {
      controlSize: [{
        required: true,
        message: "监控粒度必须选择",
        trigger: "change"
      }],
      times: [{
        required: true,
        message: "监控时间必须选择",
        trigger: "change"
      }]
    };
    var rules2 = {
      auditUser: [{
        required: true,
        message: "审核负责人必须选择",
        trigger: "change"
      }],
      explain: [{
        required: true,
        message: "审核提交说明必须填写",
        trigger: "blur"
      }]
    };
    var userList = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)([]);
    var recordInfo = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({});
    var openDialog = function openDialog(record) {
      riskVisible.value = true;
      recordInfo.value = record;
      ruleForm0.value.name = recordInfo.value.name || recordInfo.value["".concat(recordInfo.value.mode, "Name")];
      console.log(recordInfo.value, "资产信息");
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].get("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/user/userAllList")).then(function (res) {
        if (res.code == 200) {
          userList.value = res.data;
        }
      });
    };
    var riskDiaCancel = function riskDiaCancel() {
      riskVisible.value = false;
      ruleForm0.value = {
        name: "",
        riskAlias: "",
        riskPosition: "purchase",
        riskLevel: "normal"
      };
      ruleForm1 = {
        isControl: true,
        controlSize: "year",
        times: []
      };
      ruleForm2 = {
        auditUser: null,
        explain: "",
        inform: ["IAM"]
      };
    };
    var riskSure = function riskSure() {
      if (stepValue.value !== 2) {
        (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
          message: "请提交完整的信息",
          type: "warning"
        });
        return;
      }
      ruleFormRef2.value.validate(function (valid, fields) {
        if (valid) {
          console.log(recordInfo.value, "本位资产信息");
          console.log(ruleForm0.value, ruleForm1.value, ruleForm2.value, "三个表单的信息");
          var queryData = {};
          queryData.mode = recordInfo.value.mode;
          queryData.propertyId = recordInfo.value.uuid;
          queryData.status = "unreviewed";
          queryData.propertyName = recordInfo.value.name || recordInfo.value["".concat(recordInfo.value.mode, "Name")];
          queryData.propertyCnName = recordInfo.value.cname || recordInfo.value["".concat(recordInfo.value.mode, "CnName")];
          queryData.progress = 1;
          queryData.recordList = [];
          var doneUser = {
            name: JSON.parse(localStorage.getItem("userInfo")).name,
            userName: JSON.parse(localStorage.getItem("userInfo")).userName
          };
          queryData.doneUser = doneUser;
          queryData = Object.assign(queryData, ruleForm0.value);
          queryData = Object.assign(queryData, ruleForm1.value);
          queryData = Object.assign(queryData, ruleForm2.value);
          console.log(queryData, "最终的提交值");
          _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/risk/new"), queryData).then(function (res) {
            if (res.code == 200) {
              (0,element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage)({
                message: "新增成功",
                type: "success"
              });
              riskDiaCancel();
              emit("addRiskSuccess");
            }
          });
          // query.type = ''
          // riskDiaCancel()
        }
      });
    };

    var next = function next() {
      if (stepValue.value === 0) {
        ruleFormRef0.value.validate(function (valid, fields) {
          if (valid) {
            if (stepValue.value++ > 1) {
              stepValue.value = 0;
            }
          }
        });
      } else if (stepValue.value === 1) {
        ruleFormRef1.value.validate(function (valid, fields) {
          if (valid) {
            if (stepValue.value++ > 1) {
              stepValue.value = 0;
            }
          }
        });
      }
    };
    var callBack = function callBack() {
      stepValue.value -= 1;
    };
    var setDisableDate = function setDisableDate(time) {
      return time.getTime() < Date.now();
    };
    expose({
      openDialog: openDialog
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_4__.onMounted)(function () {
      console.log(_dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_2__, "配置");
      console.log(_store_index_js__WEBPACK_IMPORTED_MODULE_1__["default"].state.user.userInfo, "全局变量", JSON.parse(localStorage.getItem("userInfo")));
    });
    var __returned__ = {
      emit: emit,
      riskVisible: riskVisible,
      get stepValue() {
        return stepValue;
      },
      set stepValue(v) {
        stepValue = v;
      },
      ruleFormRef0: ruleFormRef0,
      ruleFormRef1: ruleFormRef1,
      ruleFormRef2: ruleFormRef2,
      get informList() {
        return informList;
      },
      set informList(v) {
        informList = v;
      },
      get ruleForm0() {
        return ruleForm0;
      },
      set ruleForm0(v) {
        ruleForm0 = v;
      },
      get ruleForm1() {
        return ruleForm1;
      },
      set ruleForm1(v) {
        ruleForm1 = v;
      },
      get ruleForm2() {
        return ruleForm2;
      },
      set ruleForm2(v) {
        ruleForm2 = v;
      },
      get rules0() {
        return rules0;
      },
      set rules0(v) {
        rules0 = v;
      },
      get rules1() {
        return rules1;
      },
      set rules1(v) {
        rules1 = v;
      },
      get rules2() {
        return rules2;
      },
      set rules2(v) {
        rules2 = v;
      },
      get userList() {
        return userList;
      },
      set userList(v) {
        userList = v;
      },
      get recordInfo() {
        return recordInfo;
      },
      set recordInfo(v) {
        recordInfo = v;
      },
      openDialog: openDialog,
      riskDiaCancel: riskDiaCancel,
      riskSure: riskSure,
      get next() {
        return next;
      },
      set next(v) {
        next = v;
      },
      get callBack() {
        return callBack;
      },
      set callBack(v) {
        callBack = v;
      },
      setDisableDate: setDisableDate,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get store() {
        return _store_index_js__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      get Location() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__.Location;
      },
      get Tools() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__.Tools;
      },
      get Tickets() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__.Tickets;
      },
      get riskOptions() {
        return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_2__;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_3__["default"];
      },
      get ElMessage() {
        return element_plus__WEBPACK_IMPORTED_MODULE_5__.ElMessage;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 9823:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/components/creatRisk.vue?vue&type=template&id=e36921d0&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-e36921d0"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "content"
};
var _hoisted_2 = {
  "class": "content"
};
var _hoisted_3 = {
  "class": "content"
};
var _hoisted_4 = {
  "class": "btnList"
};
var _hoisted_5 = {
  "class": "dialog-footer"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_step = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-step");
  var _component_el_steps = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-steps");
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_form_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form-item");
  var _component_el_radio = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-radio");
  var _component_el_radio_group = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-radio-group");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_form = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-form");
  var _component_el_switch = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-switch");
  var _component_el_date_picker = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-date-picker");
  var _component_el_checkbox = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-checkbox");
  var _component_el_checkbox_group = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-checkbox-group");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_dialog = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-dialog");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_dialog, {
    modelValue: $setup.riskVisible,
    "onUpdate:modelValue": _cache[10] || (_cache[10] = function ($event) {
      return $setup.riskVisible = $event;
    }),
    title: "标记风险",
    width: "700px",
    "destroy-on-close": true
  }, {
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: $setup.riskDiaCancel
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("取消")];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        type: "primary",
        onClick: $setup.riskSure
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("确定")];
        }),
        _: 1 /* STABLE */
      })])];
    }),

    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_steps, {
        active: $setup.stepValue
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "风险设置",
            icon: $setup.Location
          }, null, 8 /* PROPS */, ["icon"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "监控设置",
            icon: $setup.Tools
          }, null, 8 /* PROPS */, ["icon"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "审核设置",
            icon: $setup.Tickets
          }, null, 8 /* PROPS */, ["icon"])];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["active"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
        ref: "ruleFormRef0",
        model: $setup.ruleForm0,
        rules: $setup.rules0,
        "label-width": "160px",
        "class": "demo-ruleForm",
        "status-icon": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "资产名称",
            prop: "name"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $setup.ruleForm0.name,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
                  return $setup.ruleForm0.name = $event;
                }),
                disabled: true,
                "class": "form_item"
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "风险别名",
            prop: "riskAlias"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $setup.ruleForm0.riskAlias,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
                  return $setup.ruleForm0.riskAlias = $event;
                }),
                "class": "form_item"
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "风险定位",
            prop: "riskPosition"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_radio_group, {
                modelValue: $setup.ruleForm0.riskPosition,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
                  return $setup.ruleForm0.riskPosition = $event;
                })
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.riskOptions.riskPositionList, function (item, index) {
                    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_radio, {
                      label: item.value,
                      key: index
                    }, {
                      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.label), 1 /* TEXT */)];
                      }),

                      _: 2 /* DYNAMIC */
                    }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label"]);
                  }), 128 /* KEYED_FRAGMENT */))];
                }),

                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "风险等级",
            prop: "riskLevel"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                modelValue: $setup.ruleForm0.riskLevel,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = function ($event) {
                  return $setup.ruleForm0.riskLevel = $event;
                }),
                placeholder: "Select",
                size: "large",
                "class": "form_item"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.riskOptions.riskLevelOptions, function (item) {
                    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                      key: item.value,
                      label: item.label,
                      value: item.value
                    }, null, 8 /* PROPS */, ["label", "value"]);
                  }), 128 /* KEYED_FRAGMENT */))];
                }),

                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["model", "rules"])], 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.stepValue === 0]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
        ref: "ruleFormRef1",
        model: $setup.ruleForm1,
        rules: $setup.rules1,
        "label-width": "160px",
        "class": "demo-ruleForm",
        "status-icon": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "监控开关",
            prop: "isControl"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_switch, {
                modelValue: $setup.ruleForm1.isControl,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = function ($event) {
                  return $setup.ruleForm1.isControl = $event;
                }),
                size: "large",
                "active-text": "打开",
                "inactive-text": "关闭"
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), $setup.ruleForm1.isControl ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
            key: 0,
            label: "监控粒度",
            prop: "controlSize"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_radio_group, {
                modelValue: $setup.ruleForm1.controlSize,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
                  return $setup.ruleForm1.controlSize = $event;
                })
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.riskOptions.controlSizeList, function (item, index) {
                    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_radio, {
                      label: item.value,
                      key: index
                    }, {
                      "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                        return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(item.label), 1 /* TEXT */)];
                      }),

                      _: 2 /* DYNAMIC */
                    }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["label"]);
                  }), 128 /* KEYED_FRAGMENT */))];
                }),

                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.ruleForm1.isControl ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
            key: 1,
            label: "监控时间",
            prop: "times"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_date_picker, {
                modelValue: $setup.ruleForm1.times,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = function ($event) {
                  return $setup.ruleForm1.times = $event;
                }),
                type: "daterange",
                "start-placeholder": "起始时间",
                "value-format": "YYYY-MM-DD",
                "disabled-date": $setup.setDisableDate,
                "end-placeholder": "终结时间"
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["model", "rules"])], 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.stepValue === 1]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form, {
        ref: "ruleFormRef2",
        model: $setup.ruleForm2,
        rules: $setup.rules2,
        "label-width": "160px",
        "class": "demo-ruleForm",
        "status-icon": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "审核人员",
            prop: "auditUser"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
                modelValue: $setup.ruleForm2.auditUser,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = function ($event) {
                  return $setup.ruleForm2.auditUser = $event;
                }),
                placeholder: "请选择审核人员",
                size: "large",
                "class": "form_item"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.userList, function (item) {
                    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
                      key: item.value,
                      label: item.label,
                      value: item.value
                    }, null, 8 /* PROPS */, ["label", "value"]);
                  }), 128 /* KEYED_FRAGMENT */))];
                }),

                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_form_item, {
            label: "提交说明",
            prop: "explain"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
                modelValue: $setup.ruleForm2.explain,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = function ($event) {
                  return $setup.ruleForm2.explain = $event;
                }),
                rows: 2,
                type: "textarea",
                placeholder: "请输入提交说明",
                "class": "form_item"
              }, null, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          }), $setup.ruleForm1.times ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_form_item, {
            key: 0,
            label: "通知方式",
            prop: "times"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_checkbox_group, {
                modelValue: $setup.ruleForm2.inform,
                "onUpdate:modelValue": _cache[9] || (_cache[9] = function ($event) {
                  return $setup.ruleForm2.inform = $event;
                })
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.informList, function (item) {
                    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_checkbox, {
                      key: item,
                      label: item,
                      size: "large",
                      disabled: item === 'IAM'
                    }, null, 8 /* PROPS */, ["label", "disabled"]);
                  }), 128 /* KEYED_FRAGMENT */))];
                }),

                _: 1 /* STABLE */
              }, 8 /* PROPS */, ["modelValue"])];
            }),
            _: 1 /* STABLE */
          })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["model", "rules"])], 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.stepValue === 2]]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [$setup.stepValue !== 0 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
        key: 0,
        onClick: $setup.callBack
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("上一步")];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["onClick"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.stepValue !== 2 ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_button, {
        key: 1,
        onClick: $setup.next
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("下一步")];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["onClick"])) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)])];
    }),
    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"]);
}

/***/ }),

/***/ 34707:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/components/creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true */ 12462);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 55473:
/*!**************************************!*\
  !*** ./src/components/creatRisk.vue ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _creatRisk_vue_vue_type_template_id_e36921d0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./creatRisk.vue?vue&type=template&id=e36921d0&scoped=true */ 44274);
/* harmony import */ var _creatRisk_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./creatRisk.vue?vue&type=script&setup=true&lang=js */ 8206);
/* harmony import */ var _creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true */ 43811);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_creatRisk_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_creatRisk_vue_vue_type_template_id_e36921d0_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-e36921d0"],['__file',"src/components/creatRisk.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 8206:
/*!*************************************************************************!*\
  !*** ./src/components/creatRisk.vue?vue&type=script&setup=true&lang=js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_creatRisk_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_creatRisk_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./creatRisk.vue?vue&type=script&setup=true&lang=js */ 88832);
 

/***/ }),

/***/ 44274:
/*!********************************************************************************!*\
  !*** ./src/components/creatRisk.vue?vue&type=template&id=e36921d0&scoped=true ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_creatRisk_vue_vue_type_template_id_e36921d0_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_creatRisk_vue_vue_type_template_id_e36921d0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../node_modules/source-map-loader/dist/cjs.js!./creatRisk.vue?vue&type=template&id=e36921d0&scoped=true */ 9823);


/***/ }),

/***/ 43811:
/*!***********************************************************************************************!*\
  !*** ./src/components/creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_creatRisk_vue_vue_type_style_index_0_id_e36921d0_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../node_modules/style-loader/dist/cjs.js!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/less-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./creatRisk.vue?vue&type=style&index=0&id=e36921d0&lang=less&scoped=true */ 34707);


/***/ }),

/***/ 39753:
/*!************************************!*\
  !*** ./src/dictionaries/risk.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"riskPositionList":[{"value":"purchase","label":"购置"},{"value":"product","label":"生产"},{"value":"check","label":"检验"},{"value":"storage","label":"入库"},{"value":"scrap","label":"报废"}],"riskLevelOptions":[{"value":"normal","label":"正常"},{"value":"attention","label":"关注"},{"value":"secondary","label":"次级"},{"value":"suspicious","label":"可疑"},{"value":"loss","label":"损失"}],"controlSizeList":[{"value":"year","label":"年"},{"value":"quarter","label":"季度"},{"value":"month","label":"月"},{"value":"week","label":"周"},{"value":"day","label":"日"}],"status":{"unreviewed":"未审批","reviewed":"已审批","missed":"已过期"}}');

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2NvbXBvbmVudHNfY3JlYXRSaXNrX3Z1ZS4yYWFkYmQ4YTc4N2MzN2ZjMjk3YS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQzZHO0FBQ2pCO0FBQzVGLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxxRUFBcUUsa0JBQWtCLEdBQUcsZ0VBQWdFLDJCQUEyQixHQUFHLHdDQUF3QyxpQkFBaUIsR0FBRyw2QkFBNkIsa0JBQWtCLDRCQUE0QixHQUFHLFNBQVMsMkhBQTJILFVBQVUsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLFVBQVUsV0FBVyxxQ0FBcUMsa0JBQWtCLGlEQUFpRCw2QkFBNkIsS0FBSyxrQkFBa0IsbUJBQW1CLEtBQUssR0FBRyxjQUFjLGtCQUFrQiw0QkFBNEIsR0FBRyxlQUFlLGtCQUFrQixHQUFHLHNEQUFzRCwyQkFBMkIsR0FBRyx1QkFBdUIsaUJBQWlCLEdBQUcsWUFBWSxrQkFBa0IsNEJBQTRCLEdBQUcscUJBQXFCO0FBQ25nQztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUFE7QUFDVjtBQUM4QjtBQUNoQjtBQUNSO0FBQ0Y7OztBQUN6QyxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isd0NBQUc7QUFDekIsb0JBQW9CLHdDQUFHO0FBQ3ZCLHVCQUF1Qix3Q0FBRztBQUMxQix1QkFBdUIsd0NBQUc7QUFDMUIsdUJBQXVCLHdDQUFHO0FBQzFCO0FBQ0Esb0JBQW9CLHdDQUFHO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHdDQUFHO0FBQ3RCLHFCQUFxQix3Q0FBRztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSwrREFBVyxXQUFXLCtEQUFjO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLHVEQUFTO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLGdFQUFZLFdBQVcsK0RBQWM7QUFDL0M7QUFDQSxjQUFjLHVEQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhDQUFTO0FBQ2Isa0JBQWtCLG9EQUFXO0FBQzdCLGtCQUFrQiwyRUFBeUI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3REFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSx1REFBSztBQUNwQjtBQUNBO0FBQ0EsZUFBZSw2REFBUTtBQUN2QjtBQUNBO0FBQ0EsZUFBZSwwREFBSztBQUNwQjtBQUNBO0FBQ0EsZUFBZSw0REFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSxvREFBVztBQUMxQjtBQUNBO0FBQ0EsZUFBZSwyREFBTztBQUN0QjtBQUNBO0FBQ0EsZUFBZSxtREFBUztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUN6U2lDLFNBQU07QUFBUzs7RUE4Q2YsU0FBTTtBQUFTOztFQTJDZixTQUFNO0FBQVM7O0VBOEN4QyxTQUFNO0FBQVM7O0VBS1osU0FBTTtBQUFlOzs7Ozs7Ozs7Ozs7Ozs7OzsyREF2Si9CQSxnREFBQSxDQTRKWUMsb0JBQUE7Z0JBM0pEQyxNQUFBLENBQUFDLFdBQVc7O2FBQVhELE1BQUEsQ0FBQUMsV0FBVyxHQUFBQyxNQUFBO0lBQUE7SUFDcEJDLEtBQUssRUFBQyxNQUFNO0lBQ1pDLEtBQUssRUFBQyxPQUFPO0lBQ1osa0JBQWdCLEVBQUU7O0lBa0pSQyxNQUFNLEVBQUFDLDRDQUFBLENBQ2Y7TUFBQSxPQUdPLENBSFBDLHVEQUFBLENBR08sUUFIUEMsVUFHTyxHQUZMQyxnREFBQSxDQUFnREMsb0JBQUE7UUFBcENDLE9BQUssRUFBRVgsTUFBQSxDQUFBWTtNQUFhO2dFQUFFO1VBQUEsT0FBRSxzREFBRixJQUFFOzs7VUFDcENILGdEQUFBLENBQTBEQyxvQkFBQTtRQUEvQ0csSUFBSSxFQUFDLFNBQVM7UUFBRUYsT0FBSyxFQUFFWCxNQUFBLENBQUFjOztnRUFBVTtVQUFBLE9BQUUsc0RBQUYsSUFBRTs7Ozs7OzREQW5KbEQ7TUFBQSxPQUlXLENBSlhMLGdEQUFBLENBSVdNLG1CQUFBO1FBSkFDLE1BQU0sRUFBRWhCLE1BQUEsQ0FBQWlCO01BQVM7Z0VBQzFCO1VBQUEsT0FBeUMsQ0FBekNSLGdEQUFBLENBQXlDUyxrQkFBQTtZQUFoQ2YsS0FBSyxFQUFDLE1BQU07WUFBRWdCLElBQUksRUFBRW5CLE1BQUEsQ0FBQW9COzZDQUM3QlgsZ0RBQUEsQ0FBc0NTLGtCQUFBO1lBQTdCZixLQUFLLEVBQUMsTUFBTTtZQUFFZ0IsSUFBSSxFQUFFbkIsTUFBQSxDQUFBcUI7NkNBQzdCWixnREFBQSxDQUF3Q1Msa0JBQUE7WUFBL0JmLEtBQUssRUFBQyxNQUFNO1lBQUVnQixJQUFJLEVBQUVuQixNQUFBLENBQUFzQjs7Ozt5RkFFL0JmLHVEQUFBLENBNkNNLE9BN0NOZ0IsVUE2Q00sR0E1Q0pkLGdEQUFBLENBMkNVZSxrQkFBQTtRQTFDUkMsR0FBRyxFQUFDLGNBQWM7UUFDakJDLEtBQUssRUFBRTFCLE1BQUEsQ0FBQTJCLFNBQVM7UUFDaEJDLEtBQUssRUFBRTVCLE1BQUEsQ0FBQTZCLE1BQU07UUFDZCxhQUFXLEVBQUMsT0FBTztRQUNuQixTQUFNLGVBQWU7UUFDckIsYUFBVyxFQUFYOztnRUFFQTtVQUFBLE9BTWUsQ0FOZnBCLGdEQUFBLENBTWVxQix1QkFBQTtZQU5EQyxLQUFLLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUM7O29FQUM5QjtjQUFBLE9BSUUsQ0FKRnZCLGdEQUFBLENBSUV3QixtQkFBQTs0QkFIU2pDLE1BQUEsQ0FBQTJCLFNBQVMsQ0FBQ08sSUFBSTs7eUJBQWRsQyxNQUFBLENBQUEyQixTQUFTLENBQUNPLElBQUksR0FBQWhDLE1BQUE7Z0JBQUE7Z0JBQ3RCaUMsUUFBUSxFQUFFLElBQUk7Z0JBQ2YsU0FBTTs7OztjQUdWMUIsZ0RBQUEsQ0FFZXFCLHVCQUFBO1lBRkRDLEtBQUssRUFBQyxNQUFNO1lBQUNDLElBQUksRUFBQzs7b0VBQzlCO2NBQUEsT0FBNEQsQ0FBNUR2QixnREFBQSxDQUE0RHdCLG1CQUFBOzRCQUF6Q2pDLE1BQUEsQ0FBQTJCLFNBQVMsQ0FBQ1MsU0FBUzs7eUJBQW5CcEMsTUFBQSxDQUFBMkIsU0FBUyxDQUFDUyxTQUFTLEdBQUFsQyxNQUFBO2dCQUFBO2dCQUFFLFNBQU07Ozs7Y0FFaERPLGdEQUFBLENBU2VxQix1QkFBQTtZQVREQyxLQUFLLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUM7O29FQUM5QjtjQUFBLE9BT2lCLENBUGpCdkIsZ0RBQUEsQ0FPaUI0Qix5QkFBQTs0QkFQUXJDLE1BQUEsQ0FBQTJCLFNBQVMsQ0FBQ1csWUFBWTs7eUJBQXRCdEMsTUFBQSxDQUFBMkIsU0FBUyxDQUFDVyxZQUFZLEdBQUFwQyxNQUFBO2dCQUFBOzt3RUFFM0M7a0JBQUEsT0FBcUQsd0RBRHZEcUMsdURBQUEsQ0FLQ0MseUNBQUEsUUFBQUMsK0NBQUEsQ0FKeUJ6QyxNQUFBLENBQUEwQyxXQUFXLENBQUNDLGdCQUFnQixZQUE1Q0MsSUFBSSxFQUFFQyxLQUFLOzZFQURyQi9DLGdEQUFBLENBS0NnRCxtQkFBQTtzQkFIRWYsS0FBSyxFQUFFYSxJQUFJLENBQUNHLEtBQUs7c0JBQ2pCQyxHQUFHLEVBQUVIOzs4RUFDTDt3QkFBQSxPQUFnQiwyR0FBYkQsSUFBSSxDQUFDYixLQUFLOzs7Ozs7Ozs7Ozs7Y0FJcEJ0QixnREFBQSxDQWNlcUIsdUJBQUE7WUFkREMsS0FBSyxFQUFDLE1BQU07WUFBQ0MsSUFBSSxFQUFDOztvRUFDOUI7Y0FBQSxPQVlZLENBWlp2QixnREFBQSxDQVlZd0Msb0JBQUE7NEJBWERqRCxNQUFBLENBQUEyQixTQUFTLENBQUN1QixTQUFTOzt5QkFBbkJsRCxNQUFBLENBQUEyQixTQUFTLENBQUN1QixTQUFTLEdBQUFoRCxNQUFBO2dCQUFBO2dCQUM1QmlELFdBQVcsRUFBQyxRQUFRO2dCQUNwQkMsSUFBSSxFQUFDLE9BQU87Z0JBQ1osU0FBTTs7d0VBR0o7a0JBQUEsT0FBNEMsd0RBRDlDYix1REFBQSxDQUtFQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUplekMsTUFBQSxDQUFBMEMsV0FBVyxDQUFDVyxnQkFBZ0IsWUFBcENULElBQUk7NkVBRGI5QyxnREFBQSxDQUtFd0Qsb0JBQUE7c0JBSENOLEdBQUcsRUFBRUosSUFBSSxDQUFDRyxLQUFLO3NCQUNmaEIsS0FBSyxFQUFFYSxJQUFJLENBQUNiLEtBQUs7c0JBQ2pCZ0IsS0FBSyxFQUFFSCxJQUFJLENBQUNHOzs7Ozs7Ozs7Ozs7OytHQXhDVi9DLE1BQUEsQ0FBQWlCLFNBQVMsK0RBOEN0QlYsdURBQUEsQ0EwQ00sT0ExQ05nRCxVQTBDTSxHQXpDSjlDLGdEQUFBLENBd0NVZSxrQkFBQTtRQXZDUkMsR0FBRyxFQUFDLGNBQWM7UUFDakJDLEtBQUssRUFBRTFCLE1BQUEsQ0FBQXdELFNBQVM7UUFDaEI1QixLQUFLLEVBQUU1QixNQUFBLENBQUF5RCxNQUFNO1FBQ2QsYUFBVyxFQUFDLE9BQU87UUFDbkIsU0FBTSxlQUFlO1FBQ3JCLGFBQVcsRUFBWDs7Z0VBRUE7VUFBQSxPQU9lLENBUGZoRCxnREFBQSxDQU9lcUIsdUJBQUE7WUFQREMsS0FBSyxFQUFDLE1BQU07WUFBQ0MsSUFBSSxFQUFDOztvRUFDOUI7Y0FBQSxPQUtFLENBTEZ2QixnREFBQSxDQUtFaUQsb0JBQUE7NEJBSlMxRCxNQUFBLENBQUF3RCxTQUFTLENBQUNHLFNBQVM7O3lCQUFuQjNELE1BQUEsQ0FBQXdELFNBQVMsQ0FBQ0csU0FBUyxHQUFBekQsTUFBQTtnQkFBQTtnQkFDNUJrRCxJQUFJLEVBQUMsT0FBTztnQkFDWixhQUFXLEVBQUMsSUFBSTtnQkFDaEIsZUFBYSxFQUFDOzs7O2NBTVZwRCxNQUFBLENBQUF3RCxTQUFTLENBQUNHLFNBQVMsc0RBSDNCN0QsZ0RBQUEsQ0FhZWdDLHVCQUFBOztZQVpiQyxLQUFLLEVBQUMsTUFBTTtZQUNaQyxJQUFJLEVBQUM7O29FQUdMO2NBQUEsT0FPaUIsQ0FQakJ2QixnREFBQSxDQU9pQjRCLHlCQUFBOzRCQVBRckMsTUFBQSxDQUFBd0QsU0FBUyxDQUFDSSxXQUFXOzt5QkFBckI1RCxNQUFBLENBQUF3RCxTQUFTLENBQUNJLFdBQVcsR0FBQTFELE1BQUE7Z0JBQUE7O3dFQUUxQztrQkFBQSxPQUFvRCx3REFEdERxQyx1REFBQSxDQUtDQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUp5QnpDLE1BQUEsQ0FBQTBDLFdBQVcsQ0FBQ21CLGVBQWUsWUFBM0NqQixJQUFJLEVBQUVDLEtBQUs7NkVBRHJCL0MsZ0RBQUEsQ0FLQ2dELG1CQUFBO3NCQUhFZixLQUFLLEVBQUVhLElBQUksQ0FBQ0csS0FBSztzQkFDakJDLEdBQUcsRUFBRUg7OzhFQUNMO3dCQUFBLE9BQWdCLDJHQUFiRCxJQUFJLENBQUNiLEtBQUs7Ozs7Ozs7Ozs7Ozt1RkFJMEIvQixNQUFBLENBQUF3RCxTQUFTLENBQUNHLFNBQVMsc0RBQWpFN0QsZ0RBQUEsQ0FTZWdDLHVCQUFBOztZQVREQyxLQUFLLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUM7O29FQUM5QjtjQUFBLE9BT0UsQ0FQRnZCLGdEQUFBLENBT0VxRCx5QkFBQTs0QkFOUzlELE1BQUEsQ0FBQXdELFNBQVMsQ0FBQ08sS0FBSzs7eUJBQWYvRCxNQUFBLENBQUF3RCxTQUFTLENBQUNPLEtBQUssR0FBQTdELE1BQUE7Z0JBQUE7Z0JBQ3hCVyxJQUFJLEVBQUMsV0FBVztnQkFDaEIsbUJBQWlCLEVBQUMsTUFBTTtnQkFDeEIsY0FBWSxFQUFDLFlBQVk7Z0JBQ3hCLGVBQWEsRUFBRWIsTUFBQSxDQUFBZ0UsY0FBYztnQkFDOUIsaUJBQWUsRUFBQzs7Ozs7OzsrR0F0Q1hoRSxNQUFBLENBQUFpQixTQUFTLCtEQTJDdEJWLHVEQUFBLENBNkNNLE9BN0NOMEQsVUE2Q00sR0E1Q0p4RCxnREFBQSxDQTJDVWUsa0JBQUE7UUExQ1JDLEdBQUcsRUFBQyxjQUFjO1FBQ2pCQyxLQUFLLEVBQUUxQixNQUFBLENBQUFrRSxTQUFTO1FBQ2hCdEMsS0FBSyxFQUFFNUIsTUFBQSxDQUFBbUUsTUFBTTtRQUNkLGFBQVcsRUFBQyxPQUFPO1FBQ25CLFNBQU0sZUFBZTtRQUNyQixhQUFXLEVBQVg7O2dFQUVBO1VBQUEsT0FjZSxDQWRmMUQsZ0RBQUEsQ0FjZXFCLHVCQUFBO1lBZERDLEtBQUssRUFBQyxNQUFNO1lBQUNDLElBQUksRUFBQzs7b0VBQzlCO2NBQUEsT0FZWSxDQVpadkIsZ0RBQUEsQ0FZWXdDLG9CQUFBOzRCQVhEakQsTUFBQSxDQUFBa0UsU0FBUyxDQUFDRSxTQUFTOzt5QkFBbkJwRSxNQUFBLENBQUFrRSxTQUFTLENBQUNFLFNBQVMsR0FBQWxFLE1BQUE7Z0JBQUE7Z0JBQzVCaUQsV0FBVyxFQUFDLFNBQVM7Z0JBQ3JCQyxJQUFJLEVBQUMsT0FBTztnQkFDWixTQUFNOzt3RUFHSjtrQkFBQSxPQUF3Qix3REFEMUJiLHVEQUFBLENBS0VDLHlDQUFBLFFBQUFDLCtDQUFBLENBSmV6QyxNQUFBLENBQUFxRSxRQUFRLFlBQWhCekIsSUFBSTs2RUFEYjlDLGdEQUFBLENBS0V3RCxvQkFBQTtzQkFIQ04sR0FBRyxFQUFFSixJQUFJLENBQUNHLEtBQUs7c0JBQ2ZoQixLQUFLLEVBQUVhLElBQUksQ0FBQ2IsS0FBSztzQkFDakJnQixLQUFLLEVBQUVILElBQUksQ0FBQ0c7Ozs7Ozs7OztjQUluQnRDLGdEQUFBLENBUWVxQix1QkFBQTtZQVJEQyxLQUFLLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUM7O29FQUM5QjtjQUFBLE9BTUUsQ0FORnZCLGdEQUFBLENBTUV3QixtQkFBQTs0QkFMU2pDLE1BQUEsQ0FBQWtFLFNBQVMsQ0FBQ0ksT0FBTzs7eUJBQWpCdEUsTUFBQSxDQUFBa0UsU0FBUyxDQUFDSSxPQUFPLEdBQUFwRSxNQUFBO2dCQUFBO2dCQUN6QnFFLElBQUksRUFBRSxDQUFDO2dCQUNSMUQsSUFBSSxFQUFDLFVBQVU7Z0JBQ2ZzQyxXQUFXLEVBQUMsU0FBUztnQkFDckIsU0FBTTs7OztjQUdvQ25ELE1BQUEsQ0FBQXdELFNBQVMsQ0FBQ08sS0FBSyxzREFBN0RqRSxnREFBQSxDQVVlZ0MsdUJBQUE7O1lBVkRDLEtBQUssRUFBQyxNQUFNO1lBQUNDLElBQUksRUFBQzs7b0VBQzlCO2NBQUEsT0FRb0IsQ0FScEJ2QixnREFBQSxDQVFvQitELDRCQUFBOzRCQVJReEUsTUFBQSxDQUFBa0UsU0FBUyxDQUFDTyxNQUFNOzt5QkFBaEJ6RSxNQUFBLENBQUFrRSxTQUFTLENBQUNPLE1BQU0sR0FBQXZFLE1BQUE7Z0JBQUE7O3dFQUV4QztrQkFBQSxPQUEwQix3REFENUJxQyx1REFBQSxDQU1FQyx5Q0FBQSxRQUFBQywrQ0FBQSxDQUxlekMsTUFBQSxDQUFBMEUsVUFBVSxZQUFsQjlCLElBQUk7NkVBRGI5QyxnREFBQSxDQU1FNkUsc0JBQUE7c0JBSkMzQixHQUFHLEVBQUVKLElBQUk7c0JBQ1RiLEtBQUssRUFBRWEsSUFBSTtzQkFDWlEsSUFBSSxFQUFDLE9BQU87c0JBQ1hqQixRQUFRLEVBQUVTLElBQUk7Ozs7Ozs7Ozs7OzsrR0F4Q1o1QyxNQUFBLENBQUFpQixTQUFTLFdBOEN0QlYsdURBQUEsQ0FHTSxPQUhOcUUsVUFHTSxHQUYrQjVFLE1BQUEsQ0FBQWlCLFNBQVMsNERBQTVDbkIsZ0RBQUEsQ0FBbUVZLG9CQUFBOztRQUF2REMsT0FBSyxFQUFFWCxNQUFBLENBQUE2RTs7Z0VBQWlDO1VBQUEsT0FBRyxzREFBSCxLQUFHOzs7K0dBQ3hCN0UsTUFBQSxDQUFBaUIsU0FBUyw0REFBeENuQixnREFBQSxDQUErRFksb0JBQUE7O1FBQW5EQyxPQUFLLEVBQUVYLE1BQUEsQ0FBQThFOztnRUFBNkI7VUFBQSxPQUFHLHNEQUFILEtBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEp6RCxNQUFrRztBQUNsRyxNQUF3RjtBQUN4RixNQUErRjtBQUMvRixNQUFrSDtBQUNsSCxNQUEyRztBQUMzRyxNQUEyRztBQUMzRyxNQUE2VTtBQUM3VTtBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLHVTQUFPOzs7O0FBSXVSO0FBQy9TLE9BQU8saUVBQWUsdVNBQU8sSUFBSSw4U0FBYyxHQUFHLDhTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCSztBQUNYO0FBQ0w7O0FBRWxFLENBQWlGOztBQUVpQztBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyx5RkFBTSxhQUFhLDRGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7OztBQ3hCNlYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2NyZWF0Umlzay52dWU/NmYzYiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2NyZWF0Umlzay52dWU/MDczNSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9jb21wb25lbnRzL2NyZWF0Umlzay52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9jcmVhdFJpc2sudnVlPzBkYWYiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9jcmVhdFJpc2sudnVlP2IwZjciLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9jcmVhdFJpc2sudnVlPzBhNGEiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9jcmVhdFJpc2sudnVlP2NjM2YiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvY29tcG9uZW50cy9jcmVhdFJpc2sudnVlP2IyODkiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIuY29udGVudFtkYXRhLXYtZTM2OTIxZDBdIHtcXG4gIHBhZGRpbmc6IDE2cHg7XFxufVxcbi5jb250ZW50W2RhdGEtdi1lMzY5MjFkMF0gLmVsLXJhbmdlLWVkaXRvci5lbC1pbnB1dF9fd3JhcHBlciB7XFxuICBtYXgtd2lkdGg6IG1heC1jb250ZW50O1xcbn1cXG4uY29udGVudCAuZm9ybV9pdGVtW2RhdGEtdi1lMzY5MjFkMF0ge1xcbiAgd2lkdGg6IDQwMHB4O1xcbn1cXG4uYnRuTGlzdFtkYXRhLXYtZTM2OTIxZDBdIHtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL2NvbXBvbmVudHMvY3JlYXRSaXNrLnZ1ZVwiLFwid2VicGFjazovLy4vY3JlYXRSaXNrLnZ1ZVwiXSxcIm5hbWVzXCI6W10sXCJtYXBwaW5nc1wiOlwiQUFDQTtFQUNFLGFBQUE7QUNBRjtBRERBO0VBSUksc0JBQUE7QUNBSjtBREpBO0VBUUksWUFBQTtBQ0RKO0FES0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7QUNIRlwiLFwic291cmNlc0NvbnRlbnRcIjpbXCJcXG4uY29udGVudCB7XFxuICBwYWRkaW5nOiAxNnB4O1xcblxcbiAgL2RlZXAvIC5lbC1yYW5nZS1lZGl0b3IuZWwtaW5wdXRfX3dyYXBwZXIge1xcbiAgICBtYXgtd2lkdGg6IG1heC1jb250ZW50O1xcbiAgfVxcblxcbiAgLmZvcm1faXRlbSB7XFxuICAgIHdpZHRoOiA0MDBweDtcXG4gIH1cXG59XFxuXFxuLmJ0bkxpc3Qge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xcbn1cXG5cIixcIi5jb250ZW50IHtcXG4gIHBhZGRpbmc6IDE2cHg7XFxufVxcbi5jb250ZW50IC9kZWVwLyAuZWwtcmFuZ2UtZWRpdG9yLmVsLWlucHV0X193cmFwcGVyIHtcXG4gIG1heC13aWR0aDogbWF4LWNvbnRlbnQ7XFxufVxcbi5jb250ZW50IC5mb3JtX2l0ZW0ge1xcbiAgd2lkdGg6IDQwMHB4O1xcbn1cXG4uYnRuTGlzdCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJpbXBvcnQgeyBlbnZuYW1lIH0gZnJvbSBcIkAvamF2YXNjcmlwdC9lbnZuYW1lXCI7XG5pbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvaW5kZXguanNcIjtcbmltcG9ydCB7IExvY2F0aW9uLCBUb29scywgVGlja2V0cyB9IGZyb20gXCJAZWxlbWVudC1wbHVzL2ljb25zLXZ1ZVwiO1xuaW1wb3J0IHJpc2tPcHRpb25zIGZyb20gXCJAL2RpY3Rpb25hcmllcy9yaXNrLmpzb25cIjtcbmltcG9ydCByZXF1ZXN0IGZyb20gXCJAL3V0aWxzL3JlcXVlc3RVdGlsc1wiO1xuaW1wb3J0IHsgRWxNZXNzYWdlIH0gZnJvbSBcImVsZW1lbnQtcGx1c1wiO1xuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdjcmVhdFJpc2snLFxuICBlbWl0czogW1wiYWRkUmlza1N1Y2Nlc3NcIl0sXG4gIHNldHVwOiBmdW5jdGlvbiBzZXR1cChfX3Byb3BzLCBfcmVmKSB7XG4gICAgdmFyIGV4cG9zZSA9IF9yZWYuZXhwb3NlLFxuICAgICAgZW1pdCA9IF9yZWYuZW1pdDtcbiAgICB2YXIgcmlza1Zpc2libGUgPSByZWYoZmFsc2UpO1xuICAgIHZhciBzdGVwVmFsdWUgPSByZWYoMCk7XG4gICAgdmFyIHJ1bGVGb3JtUmVmMCA9IHJlZihudWxsKTtcbiAgICB2YXIgcnVsZUZvcm1SZWYxID0gcmVmKG51bGwpO1xuICAgIHZhciBydWxlRm9ybVJlZjIgPSByZWYobnVsbCk7XG4gICAgdmFyIGluZm9ybUxpc3QgPSBbXCLmiYvmnLpcIiwgXCLlvq7kv6FcIiwgXCJPQeezu+e7n1wiLCBcIumCrueusVwiLCBcIklBTVwiXTtcbiAgICB2YXIgcnVsZUZvcm0wID0gcmVmKHtcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICByaXNrQWxpYXM6IFwiXCIsXG4gICAgICByaXNrUG9zaXRpb246IFwicHVyY2hhc2VcIixcbiAgICAgIHJpc2tMZXZlbDogXCJub3JtYWxcIlxuICAgIH0pO1xuICAgIHZhciBydWxlRm9ybTEgPSByZWYoe1xuICAgICAgaXNDb250cm9sOiB0cnVlLFxuICAgICAgY29udHJvbFNpemU6IFwieWVhclwiLFxuICAgICAgdGltZXM6IFtdXG4gICAgfSk7XG4gICAgdmFyIHJ1bGVGb3JtMiA9IHJlZih7XG4gICAgICBhdWRpdFVzZXI6IG51bGwsXG4gICAgICBleHBsYWluOiBcIlwiLFxuICAgICAgaW5mb3JtOiBbXCJJQU1cIl1cbiAgICB9KTtcbiAgICB2YXIgcnVsZXMwID0ge1xuICAgICAgcmlza0FsaWFzOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXpo47pmanliKvlkI1cIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH0sIHtcbiAgICAgICAgbWluOiA2LFxuICAgICAgICBtZXNzYWdlOiBcIui0puWPt+iHs+WwkeS4ujbkvY3mlbBcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH0sIHtcbiAgICAgICAgbWF4OiAxMixcbiAgICAgICAgbWVzc2FnZTogXCLotKblj7fmnIDlpJrkuLoxMuS9jeaVsFwiLFxuICAgICAgICB0cmlnZ2VyOiBcImJsdXJcIlxuICAgICAgfSwge1xuICAgICAgICBwYXR0ZXJuOiBuZXcgUmVnRXhwKFwiXltcXFxcdTRlMDAtXFxcXHU5ZmE1XVtcXFxcdTRlMDAtXFxcXHU5ZmE1YS16QS1aMC05LV0qJFwiKSxcbiAgICAgICAgbWVzc2FnZTogXCLlj6rlj6/ku6XovpPlhaXkuK3mloflkozmlbDlrZdcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH1dLFxuICAgICAgcmlza1Bvc2l0aW9uOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLpo47pmanlrprkvY3lv4XpobvpgInmi6lcIixcbiAgICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIlxuICAgICAgfV0sXG4gICAgICByaXNrTGV2ZWw6IFt7XG4gICAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIumjjumZqeetiee6p+W/hemhu+mAieaLqVwiLFxuICAgICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiXG4gICAgICB9XVxuICAgIH07XG4gICAgdmFyIHJ1bGVzMSA9IHtcbiAgICAgIGNvbnRyb2xTaXplOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLnm5HmjqfnspLluqblv4XpobvpgInmi6lcIixcbiAgICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIlxuICAgICAgfV0sXG4gICAgICB0aW1lczogW3tcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXG4gICAgICAgIG1lc3NhZ2U6IFwi55uR5o6n5pe26Ze05b+F6aG76YCJ5oupXCIsXG4gICAgICAgIHRyaWdnZXI6IFwiY2hhbmdlXCJcbiAgICAgIH1dXG4gICAgfTtcbiAgICB2YXIgcnVsZXMyID0ge1xuICAgICAgYXVkaXRVc2VyOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLlrqHmoLjotJ/otKPkurrlv4XpobvpgInmi6lcIixcbiAgICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIlxuICAgICAgfV0sXG4gICAgICBleHBsYWluOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCLlrqHmoLjmj5DkuqTor7TmmI7lv4XpobvloavlhplcIixcbiAgICAgICAgdHJpZ2dlcjogXCJibHVyXCJcbiAgICAgIH1dXG4gICAgfTtcbiAgICB2YXIgdXNlckxpc3QgPSByZWYoW10pO1xuICAgIHZhciByZWNvcmRJbmZvID0gcmVmKHt9KTtcbiAgICB2YXIgb3BlbkRpYWxvZyA9IGZ1bmN0aW9uIG9wZW5EaWFsb2cocmVjb3JkKSB7XG4gICAgICByaXNrVmlzaWJsZS52YWx1ZSA9IHRydWU7XG4gICAgICByZWNvcmRJbmZvLnZhbHVlID0gcmVjb3JkO1xuICAgICAgcnVsZUZvcm0wLnZhbHVlLm5hbWUgPSByZWNvcmRJbmZvLnZhbHVlLm5hbWUgfHwgcmVjb3JkSW5mby52YWx1ZVtcIlwiLmNvbmNhdChyZWNvcmRJbmZvLnZhbHVlLm1vZGUsIFwiTmFtZVwiKV07XG4gICAgICBjb25zb2xlLmxvZyhyZWNvcmRJbmZvLnZhbHVlLCBcIui1hOS6p+S/oeaBr1wiKTtcbiAgICAgIHJlcXVlc3QuZ2V0KFwiXCIuY29uY2F0KGVudm5hbWUuYXBpVXJsLCBcIi9hcHAvdXNlci91c2VyQWxsTGlzdFwiKSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgIGlmIChyZXMuY29kZSA9PSAyMDApIHtcbiAgICAgICAgICB1c2VyTGlzdC52YWx1ZSA9IHJlcy5kYXRhO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIHZhciByaXNrRGlhQ2FuY2VsID0gZnVuY3Rpb24gcmlza0RpYUNhbmNlbCgpIHtcbiAgICAgIHJpc2tWaXNpYmxlLnZhbHVlID0gZmFsc2U7XG4gICAgICBydWxlRm9ybTAudmFsdWUgPSB7XG4gICAgICAgIG5hbWU6IFwiXCIsXG4gICAgICAgIHJpc2tBbGlhczogXCJcIixcbiAgICAgICAgcmlza1Bvc2l0aW9uOiBcInB1cmNoYXNlXCIsXG4gICAgICAgIHJpc2tMZXZlbDogXCJub3JtYWxcIlxuICAgICAgfTtcbiAgICAgIHJ1bGVGb3JtMSA9IHtcbiAgICAgICAgaXNDb250cm9sOiB0cnVlLFxuICAgICAgICBjb250cm9sU2l6ZTogXCJ5ZWFyXCIsXG4gICAgICAgIHRpbWVzOiBbXVxuICAgICAgfTtcbiAgICAgIHJ1bGVGb3JtMiA9IHtcbiAgICAgICAgYXVkaXRVc2VyOiBudWxsLFxuICAgICAgICBleHBsYWluOiBcIlwiLFxuICAgICAgICBpbmZvcm06IFtcIklBTVwiXVxuICAgICAgfTtcbiAgICB9O1xuICAgIHZhciByaXNrU3VyZSA9IGZ1bmN0aW9uIHJpc2tTdXJlKCkge1xuICAgICAgaWYgKHN0ZXBWYWx1ZS52YWx1ZSAhPT0gMikge1xuICAgICAgICBFbE1lc3NhZ2Uoe1xuICAgICAgICAgIG1lc3NhZ2U6IFwi6K+35o+Q5Lqk5a6M5pW055qE5L+h5oGvXCIsXG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCJcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJ1bGVGb3JtUmVmMi52YWx1ZS52YWxpZGF0ZShmdW5jdGlvbiAodmFsaWQsIGZpZWxkcykge1xuICAgICAgICBpZiAodmFsaWQpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZWNvcmRJbmZvLnZhbHVlLCBcIuacrOS9jei1hOS6p+S/oeaBr1wiKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhydWxlRm9ybTAudmFsdWUsIHJ1bGVGb3JtMS52YWx1ZSwgcnVsZUZvcm0yLnZhbHVlLCBcIuS4ieS4quihqOWNleeahOS/oeaBr1wiKTtcbiAgICAgICAgICB2YXIgcXVlcnlEYXRhID0ge307XG4gICAgICAgICAgcXVlcnlEYXRhLm1vZGUgPSByZWNvcmRJbmZvLnZhbHVlLm1vZGU7XG4gICAgICAgICAgcXVlcnlEYXRhLnByb3BlcnR5SWQgPSByZWNvcmRJbmZvLnZhbHVlLnV1aWQ7XG4gICAgICAgICAgcXVlcnlEYXRhLnN0YXR1cyA9IFwidW5yZXZpZXdlZFwiO1xuICAgICAgICAgIHF1ZXJ5RGF0YS5wcm9wZXJ0eU5hbWUgPSByZWNvcmRJbmZvLnZhbHVlLm5hbWUgfHwgcmVjb3JkSW5mby52YWx1ZVtcIlwiLmNvbmNhdChyZWNvcmRJbmZvLnZhbHVlLm1vZGUsIFwiTmFtZVwiKV07XG4gICAgICAgICAgcXVlcnlEYXRhLnByb3BlcnR5Q25OYW1lID0gcmVjb3JkSW5mby52YWx1ZS5jbmFtZSB8fCByZWNvcmRJbmZvLnZhbHVlW1wiXCIuY29uY2F0KHJlY29yZEluZm8udmFsdWUubW9kZSwgXCJDbk5hbWVcIildO1xuICAgICAgICAgIHF1ZXJ5RGF0YS5wcm9ncmVzcyA9IDE7XG4gICAgICAgICAgcXVlcnlEYXRhLnJlY29yZExpc3QgPSBbXTtcbiAgICAgICAgICB2YXIgZG9uZVVzZXIgPSB7XG4gICAgICAgICAgICBuYW1lOiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlckluZm9cIikpLm5hbWUsXG4gICAgICAgICAgICB1c2VyTmFtZTogSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJJbmZvXCIpKS51c2VyTmFtZVxuICAgICAgICAgIH07XG4gICAgICAgICAgcXVlcnlEYXRhLmRvbmVVc2VyID0gZG9uZVVzZXI7XG4gICAgICAgICAgcXVlcnlEYXRhID0gT2JqZWN0LmFzc2lnbihxdWVyeURhdGEsIHJ1bGVGb3JtMC52YWx1ZSk7XG4gICAgICAgICAgcXVlcnlEYXRhID0gT2JqZWN0LmFzc2lnbihxdWVyeURhdGEsIHJ1bGVGb3JtMS52YWx1ZSk7XG4gICAgICAgICAgcXVlcnlEYXRhID0gT2JqZWN0LmFzc2lnbihxdWVyeURhdGEsIHJ1bGVGb3JtMi52YWx1ZSk7XG4gICAgICAgICAgY29uc29sZS5sb2cocXVlcnlEYXRhLCBcIuacgOe7iOeahOaPkOS6pOWAvFwiKTtcbiAgICAgICAgICByZXF1ZXN0LnBvc3QoXCJcIi5jb25jYXQoZW52bmFtZS5hcGlVcmwsIFwiL2FwcC9yaXNrL25ld1wiKSwgcXVlcnlEYXRhKS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgIGlmIChyZXMuY29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgICAgRWxNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIuaWsOWinuaIkOWKn1wiLFxuICAgICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICByaXNrRGlhQ2FuY2VsKCk7XG4gICAgICAgICAgICAgIGVtaXQoXCJhZGRSaXNrU3VjY2Vzc1wiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICAvLyBxdWVyeS50eXBlID0gJydcbiAgICAgICAgICAvLyByaXNrRGlhQ2FuY2VsKClcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIHZhciBuZXh0ID0gZnVuY3Rpb24gbmV4dCgpIHtcbiAgICAgIGlmIChzdGVwVmFsdWUudmFsdWUgPT09IDApIHtcbiAgICAgICAgcnVsZUZvcm1SZWYwLnZhbHVlLnZhbGlkYXRlKGZ1bmN0aW9uICh2YWxpZCwgZmllbGRzKSB7XG4gICAgICAgICAgaWYgKHZhbGlkKSB7XG4gICAgICAgICAgICBpZiAoc3RlcFZhbHVlLnZhbHVlKysgPiAxKSB7XG4gICAgICAgICAgICAgIHN0ZXBWYWx1ZS52YWx1ZSA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoc3RlcFZhbHVlLnZhbHVlID09PSAxKSB7XG4gICAgICAgIHJ1bGVGb3JtUmVmMS52YWx1ZS52YWxpZGF0ZShmdW5jdGlvbiAodmFsaWQsIGZpZWxkcykge1xuICAgICAgICAgIGlmICh2YWxpZCkge1xuICAgICAgICAgICAgaWYgKHN0ZXBWYWx1ZS52YWx1ZSsrID4gMSkge1xuICAgICAgICAgICAgICBzdGVwVmFsdWUudmFsdWUgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcbiAgICB2YXIgY2FsbEJhY2sgPSBmdW5jdGlvbiBjYWxsQmFjaygpIHtcbiAgICAgIHN0ZXBWYWx1ZS52YWx1ZSAtPSAxO1xuICAgIH07XG4gICAgdmFyIHNldERpc2FibGVEYXRlID0gZnVuY3Rpb24gc2V0RGlzYWJsZURhdGUodGltZSkge1xuICAgICAgcmV0dXJuIHRpbWUuZ2V0VGltZSgpIDwgRGF0ZS5ub3coKTtcbiAgICB9O1xuICAgIGV4cG9zZSh7XG4gICAgICBvcGVuRGlhbG9nOiBvcGVuRGlhbG9nXG4gICAgfSk7XG4gICAgb25Nb3VudGVkKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbnNvbGUubG9nKHJpc2tPcHRpb25zLCBcIumFjee9rlwiKTtcbiAgICAgIGNvbnNvbGUubG9nKHN0b3JlLnN0YXRlLnVzZXIudXNlckluZm8sIFwi5YWo5bGA5Y+Y6YePXCIsIEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VySW5mb1wiKSkpO1xuICAgIH0pO1xuICAgIHZhciBfX3JldHVybmVkX18gPSB7XG4gICAgICBlbWl0OiBlbWl0LFxuICAgICAgcmlza1Zpc2libGU6IHJpc2tWaXNpYmxlLFxuICAgICAgZ2V0IHN0ZXBWYWx1ZSgpIHtcbiAgICAgICAgcmV0dXJuIHN0ZXBWYWx1ZTtcbiAgICAgIH0sXG4gICAgICBzZXQgc3RlcFZhbHVlKHYpIHtcbiAgICAgICAgc3RlcFZhbHVlID0gdjtcbiAgICAgIH0sXG4gICAgICBydWxlRm9ybVJlZjA6IHJ1bGVGb3JtUmVmMCxcbiAgICAgIHJ1bGVGb3JtUmVmMTogcnVsZUZvcm1SZWYxLFxuICAgICAgcnVsZUZvcm1SZWYyOiBydWxlRm9ybVJlZjIsXG4gICAgICBnZXQgaW5mb3JtTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIGluZm9ybUxpc3Q7XG4gICAgICB9LFxuICAgICAgc2V0IGluZm9ybUxpc3Qodikge1xuICAgICAgICBpbmZvcm1MaXN0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgcnVsZUZvcm0wKCkge1xuICAgICAgICByZXR1cm4gcnVsZUZvcm0wO1xuICAgICAgfSxcbiAgICAgIHNldCBydWxlRm9ybTAodikge1xuICAgICAgICBydWxlRm9ybTAgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBydWxlRm9ybTEoKSB7XG4gICAgICAgIHJldHVybiBydWxlRm9ybTE7XG4gICAgICB9LFxuICAgICAgc2V0IHJ1bGVGb3JtMSh2KSB7XG4gICAgICAgIHJ1bGVGb3JtMSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJ1bGVGb3JtMigpIHtcbiAgICAgICAgcmV0dXJuIHJ1bGVGb3JtMjtcbiAgICAgIH0sXG4gICAgICBzZXQgcnVsZUZvcm0yKHYpIHtcbiAgICAgICAgcnVsZUZvcm0yID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgcnVsZXMwKCkge1xuICAgICAgICByZXR1cm4gcnVsZXMwO1xuICAgICAgfSxcbiAgICAgIHNldCBydWxlczAodikge1xuICAgICAgICBydWxlczAgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBydWxlczEoKSB7XG4gICAgICAgIHJldHVybiBydWxlczE7XG4gICAgICB9LFxuICAgICAgc2V0IHJ1bGVzMSh2KSB7XG4gICAgICAgIHJ1bGVzMSA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJ1bGVzMigpIHtcbiAgICAgICAgcmV0dXJuIHJ1bGVzMjtcbiAgICAgIH0sXG4gICAgICBzZXQgcnVsZXMyKHYpIHtcbiAgICAgICAgcnVsZXMyID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgdXNlckxpc3QoKSB7XG4gICAgICAgIHJldHVybiB1c2VyTGlzdDtcbiAgICAgIH0sXG4gICAgICBzZXQgdXNlckxpc3Qodikge1xuICAgICAgICB1c2VyTGlzdCA9IHY7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlY29yZEluZm8oKSB7XG4gICAgICAgIHJldHVybiByZWNvcmRJbmZvO1xuICAgICAgfSxcbiAgICAgIHNldCByZWNvcmRJbmZvKHYpIHtcbiAgICAgICAgcmVjb3JkSW5mbyA9IHY7XG4gICAgICB9LFxuICAgICAgb3BlbkRpYWxvZzogb3BlbkRpYWxvZyxcbiAgICAgIHJpc2tEaWFDYW5jZWw6IHJpc2tEaWFDYW5jZWwsXG4gICAgICByaXNrU3VyZTogcmlza1N1cmUsXG4gICAgICBnZXQgbmV4dCgpIHtcbiAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICB9LFxuICAgICAgc2V0IG5leHQodikge1xuICAgICAgICBuZXh0ID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgY2FsbEJhY2soKSB7XG4gICAgICAgIHJldHVybiBjYWxsQmFjaztcbiAgICAgIH0sXG4gICAgICBzZXQgY2FsbEJhY2sodikge1xuICAgICAgICBjYWxsQmFjayA9IHY7XG4gICAgICB9LFxuICAgICAgc2V0RGlzYWJsZURhdGU6IHNldERpc2FibGVEYXRlLFxuICAgICAgZ2V0IGVudm5hbWUoKSB7XG4gICAgICAgIHJldHVybiBlbnZuYW1lO1xuICAgICAgfSxcbiAgICAgIGdldCBzdG9yZSgpIHtcbiAgICAgICAgcmV0dXJuIHN0b3JlO1xuICAgICAgfSxcbiAgICAgIGdldCBMb2NhdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIExvY2F0aW9uO1xuICAgICAgfSxcbiAgICAgIGdldCBUb29scygpIHtcbiAgICAgICAgcmV0dXJuIFRvb2xzO1xuICAgICAgfSxcbiAgICAgIGdldCBUaWNrZXRzKCkge1xuICAgICAgICByZXR1cm4gVGlja2V0cztcbiAgICAgIH0sXG4gICAgICBnZXQgcmlza09wdGlvbnMoKSB7XG4gICAgICAgIHJldHVybiByaXNrT3B0aW9ucztcbiAgICAgIH0sXG4gICAgICBnZXQgcmVxdWVzdCgpIHtcbiAgICAgICAgcmV0dXJuIHJlcXVlc3Q7XG4gICAgICB9LFxuICAgICAgZ2V0IEVsTWVzc2FnZSgpIHtcbiAgICAgICAgcmV0dXJuIEVsTWVzc2FnZTtcbiAgICAgIH1cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCI8dGVtcGxhdGU+XHJcbiAgPGVsLWRpYWxvZ1xyXG4gICAgdi1tb2RlbD1cInJpc2tWaXNpYmxlXCJcclxuICAgIHRpdGxlPVwi5qCH6K6w6aOO6ZmpXCJcclxuICAgIHdpZHRoPVwiNzAwcHhcIlxyXG4gICAgOmRlc3Ryb3ktb24tY2xvc2U9XCJ0cnVlXCJcclxuICA+XHJcbiAgICA8ZWwtc3RlcHMgOmFjdGl2ZT1cInN0ZXBWYWx1ZVwiPlxyXG4gICAgICA8ZWwtc3RlcCB0aXRsZT1cIumjjumZqeiuvue9rlwiIDppY29uPVwiTG9jYXRpb25cIiAvPlxyXG4gICAgICA8ZWwtc3RlcCB0aXRsZT1cIuebkeaOp+iuvue9rlwiIDppY29uPVwiVG9vbHNcIiAvPlxyXG4gICAgICA8ZWwtc3RlcCB0aXRsZT1cIuWuoeaguOiuvue9rlwiIDppY29uPVwiVGlja2V0c1wiIC8+XHJcbiAgICA8L2VsLXN0ZXBzPlxyXG4gICAgPGRpdiB2LXNob3c9XCJzdGVwVmFsdWUgPT09IDBcIiBjbGFzcz1cImNvbnRlbnRcIj5cclxuICAgICAgPGVsLWZvcm1cclxuICAgICAgICByZWY9XCJydWxlRm9ybVJlZjBcIlxyXG4gICAgICAgIDptb2RlbD1cInJ1bGVGb3JtMFwiXHJcbiAgICAgICAgOnJ1bGVzPVwicnVsZXMwXCJcclxuICAgICAgICBsYWJlbC13aWR0aD1cIjE2MHB4XCJcclxuICAgICAgICBjbGFzcz1cImRlbW8tcnVsZUZvcm1cIlxyXG4gICAgICAgIHN0YXR1cy1pY29uXHJcbiAgICAgID5cclxuICAgICAgICA8ZWwtZm9ybS1pdGVtIGxhYmVsPVwi6LWE5Lqn5ZCN56ewXCIgcHJvcD1cIm5hbWVcIj5cclxuICAgICAgICAgIDxlbC1pbnB1dFxyXG4gICAgICAgICAgICB2LW1vZGVsPVwicnVsZUZvcm0wLm5hbWVcIlxyXG4gICAgICAgICAgICA6ZGlzYWJsZWQ9XCJ0cnVlXCJcclxuICAgICAgICAgICAgY2xhc3M9XCJmb3JtX2l0ZW1cIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2VsLWZvcm0taXRlbT5cclxuICAgICAgICA8ZWwtZm9ybS1pdGVtIGxhYmVsPVwi6aOO6Zmp5Yir5ZCNXCIgcHJvcD1cInJpc2tBbGlhc1wiPlxyXG4gICAgICAgICAgPGVsLWlucHV0IHYtbW9kZWw9XCJydWxlRm9ybTAucmlza0FsaWFzXCIgY2xhc3M9XCJmb3JtX2l0ZW1cIiAvPlxyXG4gICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLpo47pmanlrprkvY1cIiBwcm9wPVwicmlza1Bvc2l0aW9uXCI+XHJcbiAgICAgICAgICA8ZWwtcmFkaW8tZ3JvdXAgdi1tb2RlbD1cInJ1bGVGb3JtMC5yaXNrUG9zaXRpb25cIj5cclxuICAgICAgICAgICAgPGVsLXJhZGlvXHJcbiAgICAgICAgICAgICAgdi1mb3I9XCIoaXRlbSwgaW5kZXgpIGluIHJpc2tPcHRpb25zLnJpc2tQb3NpdGlvbkxpc3RcIlxyXG4gICAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0udmFsdWVcIlxyXG4gICAgICAgICAgICAgIDprZXk9XCJpbmRleFwiXHJcbiAgICAgICAgICAgICAgPnt7IGl0ZW0ubGFiZWwgfX08L2VsLXJhZGlvXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgIDwvZWwtcmFkaW8tZ3JvdXA+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbSBsYWJlbD1cIumjjumZqeetiee6p1wiIHByb3A9XCJyaXNrTGV2ZWxcIj5cclxuICAgICAgICAgIDxlbC1zZWxlY3RcclxuICAgICAgICAgICAgdi1tb2RlbD1cInJ1bGVGb3JtMC5yaXNrTGV2ZWxcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdFwiXHJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybV9pdGVtXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGVsLW9wdGlvblxyXG4gICAgICAgICAgICAgIHYtZm9yPVwiaXRlbSBpbiByaXNrT3B0aW9ucy5yaXNrTGV2ZWxPcHRpb25zXCJcclxuICAgICAgICAgICAgICA6a2V5PVwiaXRlbS52YWx1ZVwiXHJcbiAgICAgICAgICAgICAgOmxhYmVsPVwiaXRlbS5sYWJlbFwiXHJcbiAgICAgICAgICAgICAgOnZhbHVlPVwiaXRlbS52YWx1ZVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2VsLXNlbGVjdD5cclxuICAgICAgICA8L2VsLWZvcm0taXRlbT5cclxuICAgICAgPC9lbC1mb3JtPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IHYtc2hvdz1cInN0ZXBWYWx1ZSA9PT0gMVwiIGNsYXNzPVwiY29udGVudFwiPlxyXG4gICAgICA8ZWwtZm9ybVxyXG4gICAgICAgIHJlZj1cInJ1bGVGb3JtUmVmMVwiXHJcbiAgICAgICAgOm1vZGVsPVwicnVsZUZvcm0xXCJcclxuICAgICAgICA6cnVsZXM9XCJydWxlczFcIlxyXG4gICAgICAgIGxhYmVsLXdpZHRoPVwiMTYwcHhcIlxyXG4gICAgICAgIGNsYXNzPVwiZGVtby1ydWxlRm9ybVwiXHJcbiAgICAgICAgc3RhdHVzLWljb25cclxuICAgICAgPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLnm5HmjqflvIDlhbNcIiBwcm9wPVwiaXNDb250cm9sXCI+XHJcbiAgICAgICAgICA8ZWwtc3dpdGNoXHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybTEuaXNDb250cm9sXCJcclxuICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgYWN0aXZlLXRleHQ9XCLmiZPlvIBcIlxyXG4gICAgICAgICAgICBpbmFjdGl2ZS10ZXh0PVwi5YWz6ZetXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbVxyXG4gICAgICAgICAgbGFiZWw9XCLnm5HmjqfnspLluqZcIlxyXG4gICAgICAgICAgcHJvcD1cImNvbnRyb2xTaXplXCJcclxuICAgICAgICAgIHYtaWY9XCJydWxlRm9ybTEuaXNDb250cm9sXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZWwtcmFkaW8tZ3JvdXAgdi1tb2RlbD1cInJ1bGVGb3JtMS5jb250cm9sU2l6ZVwiPlxyXG4gICAgICAgICAgICA8ZWwtcmFkaW9cclxuICAgICAgICAgICAgICB2LWZvcj1cIihpdGVtLCBpbmRleCkgaW4gcmlza09wdGlvbnMuY29udHJvbFNpemVMaXN0XCJcclxuICAgICAgICAgICAgICA6bGFiZWw9XCJpdGVtLnZhbHVlXCJcclxuICAgICAgICAgICAgICA6a2V5PVwiaW5kZXhcIlxyXG4gICAgICAgICAgICAgID57eyBpdGVtLmxhYmVsIH19PC9lbC1yYWRpb1xyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICA8L2VsLXJhZGlvLWdyb3VwPlxyXG4gICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLnm5Hmjqfml7bpl7RcIiBwcm9wPVwidGltZXNcIiB2LWlmPVwicnVsZUZvcm0xLmlzQ29udHJvbFwiPlxyXG4gICAgICAgICAgPGVsLWRhdGUtcGlja2VyXHJcbiAgICAgICAgICAgIHYtbW9kZWw9XCJydWxlRm9ybTEudGltZXNcIlxyXG4gICAgICAgICAgICB0eXBlPVwiZGF0ZXJhbmdlXCJcclxuICAgICAgICAgICAgc3RhcnQtcGxhY2Vob2xkZXI9XCLotbflp4vml7bpl7RcIlxyXG4gICAgICAgICAgICB2YWx1ZS1mb3JtYXQ9XCJZWVlZLU1NLUREXCJcclxuICAgICAgICAgICAgOmRpc2FibGVkLWRhdGU9XCJzZXREaXNhYmxlRGF0ZVwiXHJcbiAgICAgICAgICAgIGVuZC1wbGFjZWhvbGRlcj1cIue7iOe7k+aXtumXtFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICA8L2VsLWZvcm0+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgdi1zaG93PVwic3RlcFZhbHVlID09PSAyXCIgY2xhc3M9XCJjb250ZW50XCI+XHJcbiAgICAgIDxlbC1mb3JtXHJcbiAgICAgICAgcmVmPVwicnVsZUZvcm1SZWYyXCJcclxuICAgICAgICA6bW9kZWw9XCJydWxlRm9ybTJcIlxyXG4gICAgICAgIDpydWxlcz1cInJ1bGVzMlwiXHJcbiAgICAgICAgbGFiZWwtd2lkdGg9XCIxNjBweFwiXHJcbiAgICAgICAgY2xhc3M9XCJkZW1vLXJ1bGVGb3JtXCJcclxuICAgICAgICBzdGF0dXMtaWNvblxyXG4gICAgICA+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbSBsYWJlbD1cIuWuoeaguOS6uuWRmFwiIHByb3A9XCJhdWRpdFVzZXJcIj5cclxuICAgICAgICAgIDxlbC1zZWxlY3RcclxuICAgICAgICAgICAgdi1tb2RlbD1cInJ1bGVGb3JtMi5hdWRpdFVzZXJcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+mAieaLqeWuoeaguOS6uuWRmFwiXHJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybV9pdGVtXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGVsLW9wdGlvblxyXG4gICAgICAgICAgICAgIHYtZm9yPVwiaXRlbSBpbiB1c2VyTGlzdFwiXHJcbiAgICAgICAgICAgICAgOmtleT1cIml0ZW0udmFsdWVcIlxyXG4gICAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICAgIDp2YWx1ZT1cIml0ZW0udmFsdWVcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9lbC1zZWxlY3Q+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgICAgPGVsLWZvcm0taXRlbSBsYWJlbD1cIuaPkOS6pOivtOaYjlwiIHByb3A9XCJleHBsYWluXCI+XHJcbiAgICAgICAgICA8ZWwtaW5wdXRcclxuICAgICAgICAgICAgdi1tb2RlbD1cInJ1bGVGb3JtMi5leHBsYWluXCJcclxuICAgICAgICAgICAgOnJvd3M9XCIyXCJcclxuICAgICAgICAgICAgdHlwZT1cInRleHRhcmVhXCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLor7fovpPlhaXmj5DkuqTor7TmmI5cIlxyXG4gICAgICAgICAgICBjbGFzcz1cImZvcm1faXRlbVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZWwtZm9ybS1pdGVtPlxyXG4gICAgICAgIDxlbC1mb3JtLWl0ZW0gbGFiZWw9XCLpgJrnn6XmlrnlvI9cIiBwcm9wPVwidGltZXNcIiB2LWlmPVwicnVsZUZvcm0xLnRpbWVzXCI+XHJcbiAgICAgICAgICA8ZWwtY2hlY2tib3gtZ3JvdXAgdi1tb2RlbD1cInJ1bGVGb3JtMi5pbmZvcm1cIj5cclxuICAgICAgICAgICAgPGVsLWNoZWNrYm94XHJcbiAgICAgICAgICAgICAgdi1mb3I9XCJpdGVtIGluIGluZm9ybUxpc3RcIlxyXG4gICAgICAgICAgICAgIDprZXk9XCJpdGVtXCJcclxuICAgICAgICAgICAgICA6bGFiZWw9XCJpdGVtXCJcclxuICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgIDpkaXNhYmxlZD1cIml0ZW0gPT09ICdJQU0nXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZWwtY2hlY2tib3gtZ3JvdXA+XHJcbiAgICAgICAgPC9lbC1mb3JtLWl0ZW0+XHJcbiAgICAgIDwvZWwtZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cImJ0bkxpc3RcIj5cclxuICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJjYWxsQmFja1wiIHYtaWY9XCJzdGVwVmFsdWUgIT09IDBcIj7kuIrkuIDmraU8L2VsLWJ1dHRvbj5cclxuICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJuZXh0XCIgdi1pZj1cInN0ZXBWYWx1ZSAhPT0gMlwiPuS4i+S4gOatpTwvZWwtYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8dGVtcGxhdGUgI2Zvb3Rlcj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJkaWFsb2ctZm9vdGVyXCI+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJyaXNrRGlhQ2FuY2VsXCI+5Y+W5raIPC9lbC1idXR0b24+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cInJpc2tTdXJlXCI+56Gu5a6aPC9lbC1idXR0b24+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvdGVtcGxhdGU+XHJcbiAgPC9lbC1kaWFsb2c+XHJcbjwvdGVtcGxhdGU+XHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcclxuaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL2luZGV4LmpzXCI7XHJcbmltcG9ydCB7IExvY2F0aW9uLCBUb29scywgVGlja2V0cyB9IGZyb20gXCJAZWxlbWVudC1wbHVzL2ljb25zLXZ1ZVwiO1xyXG5pbXBvcnQgcmlza09wdGlvbnMgZnJvbSBcIkAvZGljdGlvbmFyaWVzL3Jpc2suanNvblwiO1xyXG5pbXBvcnQgcmVxdWVzdCBmcm9tIFwiQC91dGlscy9yZXF1ZXN0VXRpbHNcIjtcclxuaW1wb3J0IHsgRWxNZXNzYWdlIH0gZnJvbSBcImVsZW1lbnQtcGx1c1wiO1xyXG5jb25zdCBlbWl0ID0gZGVmaW5lRW1pdHMoW1wiYWRkUmlza1N1Y2Nlc3NcIl0pO1xyXG5jb25zdCByaXNrVmlzaWJsZSA9IHJlZihmYWxzZSk7XHJcbmxldCBzdGVwVmFsdWUgPSByZWYoMCk7XHJcbmNvbnN0IHJ1bGVGb3JtUmVmMCA9IHJlZihudWxsKTtcclxuY29uc3QgcnVsZUZvcm1SZWYxID0gcmVmKG51bGwpO1xyXG5jb25zdCBydWxlRm9ybVJlZjIgPSByZWYobnVsbCk7XHJcbmxldCBpbmZvcm1MaXN0ID0gW1wi5omL5py6XCIsIFwi5b6u5L+hXCIsIFwiT0Hns7vnu59cIiwgXCLpgq7nrrFcIiwgXCJJQU1cIl07XHJcbmxldCBydWxlRm9ybTAgPSByZWYoe1xyXG4gIG5hbWU6IFwiXCIsXHJcbiAgcmlza0FsaWFzOiBcIlwiLFxyXG4gIHJpc2tQb3NpdGlvbjogXCJwdXJjaGFzZVwiLFxyXG4gIHJpc2tMZXZlbDogXCJub3JtYWxcIixcclxufSk7XHJcbmxldCBydWxlRm9ybTEgPSByZWYoe1xyXG4gIGlzQ29udHJvbDogdHJ1ZSxcclxuICBjb250cm9sU2l6ZTogXCJ5ZWFyXCIsXHJcbiAgdGltZXM6IFtdLFxyXG59KTtcclxubGV0IHJ1bGVGb3JtMiA9IHJlZih7XHJcbiAgYXVkaXRVc2VyOiBudWxsLFxyXG4gIGV4cGxhaW46IFwiXCIsXHJcbiAgaW5mb3JtOiBbXCJJQU1cIl0sXHJcbn0pO1xyXG5sZXQgcnVsZXMwID0ge1xyXG4gIHJpc2tBbGlhczogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLor7fovpPlhaXpo47pmanliKvlkI1cIixcclxuICAgICAgdHJpZ2dlcjogXCJibHVyXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBtaW46IDYsXHJcbiAgICAgIG1lc3NhZ2U6IFwi6LSm5Y+36Iez5bCR5Li6NuS9jeaVsFwiLFxyXG4gICAgICB0cmlnZ2VyOiBcImJsdXJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG1heDogMTIsXHJcbiAgICAgIG1lc3NhZ2U6IFwi6LSm5Y+35pyA5aSa5Li6MTLkvY3mlbBcIixcclxuICAgICAgdHJpZ2dlcjogXCJibHVyXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXR0ZXJuOiBuZXcgUmVnRXhwKFwiXltcXFxcdTRlMDAtXFxcXHU5ZmE1XVtcXFxcdTRlMDAtXFxcXHU5ZmE1YS16QS1aMC05LV0qJFwiKSxcclxuICAgICAgbWVzc2FnZTogXCLlj6rlj6/ku6XovpPlhaXkuK3mloflkozmlbDlrZdcIixcclxuICAgICAgdHJpZ2dlcjogXCJibHVyXCIsXHJcbiAgICB9LFxyXG4gIF0sXHJcbiAgcmlza1Bvc2l0aW9uOiBbXHJcbiAgICB7XHJcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICBtZXNzYWdlOiBcIumjjumZqeWumuS9jeW/hemhu+mAieaLqVwiLFxyXG4gICAgICB0cmlnZ2VyOiBcImNoYW5nZVwiLFxyXG4gICAgfSxcclxuICBdLFxyXG4gIHJpc2tMZXZlbDogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLpo47pmannrYnnuqflv4XpobvpgInmi6lcIixcclxuICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIixcclxuICAgIH0sXHJcbiAgXSxcclxufTtcclxubGV0IHJ1bGVzMSA9IHtcclxuICBjb250cm9sU2l6ZTogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLnm5HmjqfnspLluqblv4XpobvpgInmi6lcIixcclxuICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIixcclxuICAgIH0sXHJcbiAgXSxcclxuICB0aW1lczogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLnm5Hmjqfml7bpl7Tlv4XpobvpgInmi6lcIixcclxuICAgICAgdHJpZ2dlcjogXCJjaGFuZ2VcIixcclxuICAgIH0sXHJcbiAgXSxcclxufTtcclxubGV0IHJ1bGVzMiA9IHtcclxuICBhdWRpdFVzZXI6IFtcclxuICAgIHtcclxuICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgIG1lc3NhZ2U6IFwi5a6h5qC46LSf6LSj5Lq65b+F6aG76YCJ5oupXCIsXHJcbiAgICAgIHRyaWdnZXI6IFwiY2hhbmdlXCIsXHJcbiAgICB9LFxyXG4gIF0sXHJcbiAgZXhwbGFpbjogW1xyXG4gICAge1xyXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogXCLlrqHmoLjmj5DkuqTor7TmmI7lv4XpobvloavlhplcIixcclxuICAgICAgdHJpZ2dlcjogXCJibHVyXCIsXHJcbiAgICB9LFxyXG4gIF0sXHJcbn07XHJcbmxldCB1c2VyTGlzdCA9IHJlZihbXSk7XHJcbmxldCByZWNvcmRJbmZvID0gcmVmKHt9KTtcclxuY29uc3Qgb3BlbkRpYWxvZyA9IChyZWNvcmQpID0+IHtcclxuICByaXNrVmlzaWJsZS52YWx1ZSA9IHRydWU7XHJcbiAgcmVjb3JkSW5mby52YWx1ZSA9IHJlY29yZDtcclxuICBydWxlRm9ybTAudmFsdWUubmFtZSA9XHJcbiAgICByZWNvcmRJbmZvLnZhbHVlLm5hbWUgfHwgcmVjb3JkSW5mby52YWx1ZVtgJHtyZWNvcmRJbmZvLnZhbHVlLm1vZGV9TmFtZWBdO1xyXG4gIGNvbnNvbGUubG9nKHJlY29yZEluZm8udmFsdWUsIFwi6LWE5Lqn5L+h5oGvXCIpO1xyXG4gIHJlcXVlc3QuZ2V0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvdXNlci91c2VyQWxsTGlzdGApLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgaWYgKHJlcy5jb2RlID09IDIwMCkge1xyXG4gICAgICB1c2VyTGlzdC52YWx1ZSA9IHJlcy5kYXRhO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCByaXNrRGlhQ2FuY2VsID0gKCkgPT4ge1xyXG4gIHJpc2tWaXNpYmxlLnZhbHVlID0gZmFsc2U7XHJcbiAgcnVsZUZvcm0wLnZhbHVlID0ge1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIHJpc2tBbGlhczogXCJcIixcclxuICAgIHJpc2tQb3NpdGlvbjogXCJwdXJjaGFzZVwiLFxyXG4gICAgcmlza0xldmVsOiBcIm5vcm1hbFwiLFxyXG4gIH07XHJcbiAgcnVsZUZvcm0xID0ge1xyXG4gICAgaXNDb250cm9sOiB0cnVlLFxyXG4gICAgY29udHJvbFNpemU6IFwieWVhclwiLFxyXG4gICAgdGltZXM6IFtdLFxyXG4gIH07XHJcbiAgcnVsZUZvcm0yID0ge1xyXG4gICAgYXVkaXRVc2VyOiBudWxsLFxyXG4gICAgZXhwbGFpbjogXCJcIixcclxuICAgIGluZm9ybTogW1wiSUFNXCJdLFxyXG4gIH07XHJcbn07XHJcbmNvbnN0IHJpc2tTdXJlID0gKCkgPT4ge1xyXG4gIGlmIChzdGVwVmFsdWUudmFsdWUgIT09IDIpIHtcclxuICAgIEVsTWVzc2FnZSh7XHJcbiAgICAgIG1lc3NhZ2U6IFwi6K+35o+Q5Lqk5a6M5pW055qE5L+h5oGvXCIsXHJcbiAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIHJ1bGVGb3JtUmVmMi52YWx1ZS52YWxpZGF0ZSgodmFsaWQsIGZpZWxkcykgPT4ge1xyXG4gICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHJlY29yZEluZm8udmFsdWUsIFwi5pys5L2N6LWE5Lqn5L+h5oGvXCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICBydWxlRm9ybTAudmFsdWUsXHJcbiAgICAgICAgcnVsZUZvcm0xLnZhbHVlLFxyXG4gICAgICAgIHJ1bGVGb3JtMi52YWx1ZSxcclxuICAgICAgICBcIuS4ieS4quihqOWNleeahOS/oeaBr1wiXHJcbiAgICAgICk7XHJcbiAgICAgIGxldCBxdWVyeURhdGEgPSB7fTtcclxuICAgICAgcXVlcnlEYXRhLm1vZGUgPSByZWNvcmRJbmZvLnZhbHVlLm1vZGU7XHJcbiAgICAgIHF1ZXJ5RGF0YS5wcm9wZXJ0eUlkID0gcmVjb3JkSW5mby52YWx1ZS51dWlkO1xyXG4gICAgICBxdWVyeURhdGEuc3RhdHVzID0gXCJ1bnJldmlld2VkXCI7XHJcbiAgICAgIHF1ZXJ5RGF0YS5wcm9wZXJ0eU5hbWUgPVxyXG4gICAgICAgIHJlY29yZEluZm8udmFsdWUubmFtZSB8fFxyXG4gICAgICAgIHJlY29yZEluZm8udmFsdWVbYCR7cmVjb3JkSW5mby52YWx1ZS5tb2RlfU5hbWVgXTtcclxuICAgICAgcXVlcnlEYXRhLnByb3BlcnR5Q25OYW1lID1cclxuICAgICAgICByZWNvcmRJbmZvLnZhbHVlLmNuYW1lIHx8XHJcbiAgICAgICAgcmVjb3JkSW5mby52YWx1ZVtgJHtyZWNvcmRJbmZvLnZhbHVlLm1vZGV9Q25OYW1lYF07XHJcbiAgICAgIHF1ZXJ5RGF0YS5wcm9ncmVzcyA9IDE7XHJcbiAgICAgIHF1ZXJ5RGF0YS5yZWNvcmRMaXN0ID0gW107XHJcbiAgICAgIGxldCBkb25lVXNlciA9IHtcclxuICAgICAgICBuYW1lOiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlckluZm9cIikpLm5hbWUsXHJcbiAgICAgICAgdXNlck5hbWU6IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VySW5mb1wiKSkudXNlck5hbWUsXHJcbiAgICAgIH07XHJcbiAgICAgIHF1ZXJ5RGF0YS5kb25lVXNlciA9IGRvbmVVc2VyO1xyXG4gICAgICBxdWVyeURhdGEgPSBPYmplY3QuYXNzaWduKHF1ZXJ5RGF0YSwgcnVsZUZvcm0wLnZhbHVlKTtcclxuICAgICAgcXVlcnlEYXRhID0gT2JqZWN0LmFzc2lnbihxdWVyeURhdGEsIHJ1bGVGb3JtMS52YWx1ZSk7XHJcbiAgICAgIHF1ZXJ5RGF0YSA9IE9iamVjdC5hc3NpZ24ocXVlcnlEYXRhLCBydWxlRm9ybTIudmFsdWUpO1xyXG4gICAgICBjb25zb2xlLmxvZyhxdWVyeURhdGEsIFwi5pyA57uI55qE5o+Q5Lqk5YC8XCIpO1xyXG4gICAgICByZXF1ZXN0LnBvc3QoYCR7ZW52bmFtZS5hcGlVcmx9L2FwcC9yaXNrL25ld2AsIHF1ZXJ5RGF0YSkudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlcy5jb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgRWxNZXNzYWdlKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCLmlrDlop7miJDlip9cIixcclxuICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHJpc2tEaWFDYW5jZWwoKTtcclxuICAgICAgICAgIGVtaXQoXCJhZGRSaXNrU3VjY2Vzc1wiKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBxdWVyeS50eXBlID0gJydcclxuICAgICAgLy8gcmlza0RpYUNhbmNlbCgpXHJcbiAgICB9XHJcbiAgfSk7XHJcbn07XHJcbmxldCBuZXh0ID0gKCkgPT4ge1xyXG4gIGlmIChzdGVwVmFsdWUudmFsdWUgPT09IDApIHtcclxuICAgIHJ1bGVGb3JtUmVmMC52YWx1ZS52YWxpZGF0ZSgodmFsaWQsIGZpZWxkcykgPT4ge1xyXG4gICAgICBpZiAodmFsaWQpIHtcclxuICAgICAgICBpZiAoc3RlcFZhbHVlLnZhbHVlKysgPiAxKSB7XHJcbiAgICAgICAgICBzdGVwVmFsdWUudmFsdWUgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfSBlbHNlIGlmIChzdGVwVmFsdWUudmFsdWUgPT09IDEpIHtcclxuICAgIHJ1bGVGb3JtUmVmMS52YWx1ZS52YWxpZGF0ZSgodmFsaWQsIGZpZWxkcykgPT4ge1xyXG4gICAgICBpZiAodmFsaWQpIHtcclxuICAgICAgICBpZiAoc3RlcFZhbHVlLnZhbHVlKysgPiAxKSB7XHJcbiAgICAgICAgICBzdGVwVmFsdWUudmFsdWUgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG59O1xyXG5sZXQgY2FsbEJhY2sgPSAoKSA9PiB7XHJcbiAgc3RlcFZhbHVlLnZhbHVlIC09IDE7XHJcbn07XHJcbmNvbnN0IHNldERpc2FibGVEYXRlID0gKHRpbWUpID0+IHtcclxuICByZXR1cm4gdGltZS5nZXRUaW1lKCkgPCBEYXRlLm5vdygpO1xyXG59O1xyXG5kZWZpbmVFeHBvc2Uoe1xyXG4gIG9wZW5EaWFsb2csXHJcbn0pO1xyXG5vbk1vdW50ZWQoKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKHJpc2tPcHRpb25zLCBcIumFjee9rlwiKTtcclxuICBjb25zb2xlLmxvZyhcclxuICAgIHN0b3JlLnN0YXRlLnVzZXIudXNlckluZm8sXHJcbiAgICBcIuWFqOWxgOWPmOmHj1wiLFxyXG4gICAgSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJJbmZvXCIpKVxyXG4gICk7XHJcbn0pO1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4uY29udGVudCB7XHJcbiAgcGFkZGluZzogMTZweDtcclxuXHJcbiAgL2RlZXAvIC5lbC1yYW5nZS1lZGl0b3IuZWwtaW5wdXRfX3dyYXBwZXIge1xyXG4gICAgbWF4LXdpZHRoOiBtYXgtY29udGVudDtcclxuICB9XHJcblxyXG4gIC5mb3JtX2l0ZW0ge1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLmJ0bkxpc3Qge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuPC9zdHlsZT4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9ZTM2OTIxZDAmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2NyZWF0Umlzay52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD1lMzY5MjFkMCZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWUzNjkyMWQwJnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vY3JlYXRSaXNrLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL2NyZWF0Umlzay52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vY3JlYXRSaXNrLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPWUzNjkyMWQwJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LWUzNjkyMWQwXCJdLFsnX19maWxlJyxcInNyYy9jb21wb25lbnRzL2NyZWF0Umlzay52dWVcIl1dKVxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgX19leHBvcnRzX18uX19obXJJZCA9IFwiZTM2OTIxZDBcIlxuICBjb25zdCBhcGkgPSBfX1ZVRV9ITVJfUlVOVElNRV9fXG4gIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgaWYgKCFhcGkuY3JlYXRlUmVjb3JkKCdlMzY5MjFkMCcsIF9fZXhwb3J0c19fKSkge1xuICAgIGFwaS5yZWxvYWQoJ2UzNjkyMWQwJywgX19leHBvcnRzX18pXG4gIH1cbiAgXG4gIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWUzNjkyMWQwJnNjb3BlZD10cnVlXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJ2UzNjkyMWQwJywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3RlbXBsYXRlTG9hZGVyLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzRdIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPWUzNjkyMWQwJnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9jcmVhdFJpc2sudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9ZTM2OTIxZDAmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiXSwibmFtZXMiOlsiX2NyZWF0ZUJsb2NrIiwiX2NvbXBvbmVudF9lbF9kaWFsb2ciLCIkc2V0dXAiLCJyaXNrVmlzaWJsZSIsIiRldmVudCIsInRpdGxlIiwid2lkdGgiLCJmb290ZXIiLCJfd2l0aEN0eCIsIl9jcmVhdGVFbGVtZW50Vk5vZGUiLCJfaG9pc3RlZF81IiwiX2NyZWF0ZVZOb2RlIiwiX2NvbXBvbmVudF9lbF9idXR0b24iLCJvbkNsaWNrIiwicmlza0RpYUNhbmNlbCIsInR5cGUiLCJyaXNrU3VyZSIsIl9jb21wb25lbnRfZWxfc3RlcHMiLCJhY3RpdmUiLCJzdGVwVmFsdWUiLCJfY29tcG9uZW50X2VsX3N0ZXAiLCJpY29uIiwiTG9jYXRpb24iLCJUb29scyIsIlRpY2tldHMiLCJfaG9pc3RlZF8xIiwiX2NvbXBvbmVudF9lbF9mb3JtIiwicmVmIiwibW9kZWwiLCJydWxlRm9ybTAiLCJydWxlcyIsInJ1bGVzMCIsIl9jb21wb25lbnRfZWxfZm9ybV9pdGVtIiwibGFiZWwiLCJwcm9wIiwiX2NvbXBvbmVudF9lbF9pbnB1dCIsIm5hbWUiLCJkaXNhYmxlZCIsInJpc2tBbGlhcyIsIl9jb21wb25lbnRfZWxfcmFkaW9fZ3JvdXAiLCJyaXNrUG9zaXRpb24iLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJyaXNrT3B0aW9ucyIsInJpc2tQb3NpdGlvbkxpc3QiLCJpdGVtIiwiaW5kZXgiLCJfY29tcG9uZW50X2VsX3JhZGlvIiwidmFsdWUiLCJrZXkiLCJfY29tcG9uZW50X2VsX3NlbGVjdCIsInJpc2tMZXZlbCIsInBsYWNlaG9sZGVyIiwic2l6ZSIsInJpc2tMZXZlbE9wdGlvbnMiLCJfY29tcG9uZW50X2VsX29wdGlvbiIsIl9ob2lzdGVkXzIiLCJydWxlRm9ybTEiLCJydWxlczEiLCJfY29tcG9uZW50X2VsX3N3aXRjaCIsImlzQ29udHJvbCIsImNvbnRyb2xTaXplIiwiY29udHJvbFNpemVMaXN0IiwiX2NvbXBvbmVudF9lbF9kYXRlX3BpY2tlciIsInRpbWVzIiwic2V0RGlzYWJsZURhdGUiLCJfaG9pc3RlZF8zIiwicnVsZUZvcm0yIiwicnVsZXMyIiwiYXVkaXRVc2VyIiwidXNlckxpc3QiLCJleHBsYWluIiwicm93cyIsIl9jb21wb25lbnRfZWxfY2hlY2tib3hfZ3JvdXAiLCJpbmZvcm0iLCJpbmZvcm1MaXN0IiwiX2NvbXBvbmVudF9lbF9jaGVja2JveCIsIl9ob2lzdGVkXzQiLCJjYWxsQmFjayIsIm5leHQiXSwic291cmNlUm9vdCI6IiJ9