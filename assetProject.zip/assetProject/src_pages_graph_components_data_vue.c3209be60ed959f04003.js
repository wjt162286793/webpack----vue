"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_graph_components_data_vue"],{

/***/ 26360:
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/graph/components/data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#chart[data-v-44bd0b6e] {\n  width: 1400px;\n  height: 600px;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/graph/components/data.vue","webpack://./data.vue"],"names":[],"mappings":"AACA;EACE,aAAA;EACA,aAAA;ACAF","sourcesContent":["\n#chart {\n  width: 1400px;\n  height: 600px;\n}\n","#chart {\n  width: 1400px;\n  height: 600px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 8193:
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/graph/components/data.vue?vue&type=script&setup=true&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'data',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var echarts = (0,vue__WEBPACK_IMPORTED_MODULE_0__.inject)("echarts");
    var option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)({});
    var nameList = ["煤炭", "石油", "天然气", "水", "电", "电信", "交通", "医疗", "住房", "教育"];
    var genData = function genData(count) {
      // prettier-ignore
      var legendData = [];
      var seriesData = [];
      nameList.forEach(function (item) {
        legendData.push(item);
        seriesData.push({
          name: item,
          value: Math.round(Math.random() * 100)
        });
      });
      return {
        legendData: legendData,
        seriesData: seriesData
      };
    };
    var data = genData(11);
    var chartFun = function chartFun() {
      var chartDom = document.getElementById("chart");
      var myChart = echarts.init(chartDom);
      option.value = {
        title: {
          text: "投资&消费收益比重",
          subtext: "纯属虚构",
          left: "center",
          top: 50
        },
        color: ["#91cc75", "#f1b2c3", "#6b5428", "#1497db", "#ef6c00", "#d33428", "#9ad653", "#d6b3f4", "#1e1e1e", "#fb5865"],
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
          type: "scroll",
          orient: "vertical",
          right: 10,
          top: 200,
          bottom: 20,
          data: data.legendData
        },
        series: [{
          name: "姓名",
          type: "pie",
          radius: "55%",
          center: ["40%", "50%"],
          data: data.seriesData,
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)"
            }
          }
        }]
      };
      myChart.setOption(option.value);
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(function () {
      (0,vue__WEBPACK_IMPORTED_MODULE_0__.nextTick)(function () {
        chartFun();
      });
    });
    var __returned__ = {
      get echarts() {
        return echarts;
      },
      set echarts(v) {
        echarts = v;
      },
      option: option,
      nameList: nameList,
      genData: genData,
      data: data,
      chartFun: chartFun
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 90496:
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/graph/components/data.vue?vue&type=template&id=44bd0b6e&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-44bd0b6e"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  id: "chart"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1);
}

/***/ }),

/***/ 62040:
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/graph/components/data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true */ 26360);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 34369:
/*!*********************************************!*\
  !*** ./src/pages/graph/components/data.vue ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _data_vue_vue_type_template_id_44bd0b6e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.vue?vue&type=template&id=44bd0b6e&scoped=true */ 22995);
/* harmony import */ var _data_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.vue?vue&type=script&setup=true&lang=js */ 63181);
/* harmony import */ var _data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true */ 27499);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_data_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_data_vue_vue_type_template_id_44bd0b6e_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-44bd0b6e"],['__file',"src/pages/graph/components/data.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 63181:
/*!********************************************************************************!*\
  !*** ./src/pages/graph/components/data.vue?vue&type=script&setup=true&lang=js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_data_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_data_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./data.vue?vue&type=script&setup=true&lang=js */ 8193);
 

/***/ }),

/***/ 22995:
/*!***************************************************************************************!*\
  !*** ./src/pages/graph/components/data.vue?vue&type=template&id=44bd0b6e&scoped=true ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_data_vue_vue_type_template_id_44bd0b6e_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_data_vue_vue_type_template_id_44bd0b6e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./data.vue?vue&type=template&id=44bd0b6e&scoped=true */ 90496);


/***/ }),

/***/ 27499:
/*!******************************************************************************************************!*\
  !*** ./src/pages/graph/components/data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_data_vue_vue_type_style_index_0_id_44bd0b6e_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./data.vue?vue&type=style&index=0&id=44bd0b6e&lang=less&scoped=true */ 62040);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2dyYXBoX2NvbXBvbmVudHNfZGF0YV92dWUuYzMyMDliZTYwZWQ5NTlmMDQwMDMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNtSDtBQUNqQjtBQUNsRyw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EsbUVBQW1FLGtCQUFrQixrQkFBa0IsR0FBRyxTQUFTLDZIQUE2SCxVQUFVLFVBQVUsbUNBQW1DLGtCQUFrQixrQkFBa0IsR0FBRyxhQUFhLGtCQUFrQixrQkFBa0IsR0FBRyxxQkFBcUI7QUFDdlo7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQdkMsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiwyQ0FBTTtBQUN4QixpQkFBaUIsd0NBQUc7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhDQUFTO0FBQ2IsTUFBTSw2Q0FBUTtBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUN4Rk1BLEVBQUUsRUFBQztBQUFPOzsyREFBZkMsdURBQUEsQ0FBc0IsT0FBdEJDLFVBQXNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0F4QixNQUF3RztBQUN4RyxNQUE4RjtBQUM5RixNQUFxRztBQUNyRyxNQUF3SDtBQUN4SCxNQUFpSDtBQUNqSCxNQUFpSDtBQUNqSCxNQUFnVztBQUNoVztBQUNBOztBQUVBOztBQUVBLDRCQUE0QixxR0FBbUI7QUFDL0Msd0JBQXdCLGtIQUFhOztBQUVyQyx1QkFBdUIsdUdBQWE7QUFDcEM7QUFDQSxpQkFBaUIsK0ZBQU07QUFDdkIsNkJBQTZCLHNHQUFrQjs7QUFFL0MsYUFBYSwwR0FBRyxDQUFDLGtTQUFPOzs7O0FBSTBTO0FBQ2xVLE9BQU8saUVBQWUsa1NBQU8sSUFBSSx5U0FBYyxHQUFHLHlTQUFjLFlBQVksRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCQTtBQUNYO0FBQ0w7O0FBRTdELENBQTRFOztBQUVzQztBQUNsSCxpQ0FBaUMsa0hBQWUsQ0FBQyxvRkFBTSxhQUFhLHVGQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUUsRUFZZjs7O0FBR0QsaUVBQWU7Ozs7Ozs7Ozs7Ozs7OztBQ3hCZ1giLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9ncmFwaC9jb21wb25lbnRzL2RhdGEudnVlPzBmZjciLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9kYXRhLnZ1ZT9lNzViIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvZGF0YS52dWUiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9kYXRhLnZ1ZT84MTk5Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvZGF0YS52dWU/Y2Q4MiIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9ncmFwaC9jb21wb25lbnRzL2RhdGEudnVlP2U1N2MiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9kYXRhLnZ1ZT82NTdjIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2dyYXBoL2NvbXBvbmVudHMvZGF0YS52dWU/MDk0NyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIiNjaGFydFtkYXRhLXYtNDRiZDBiNmVdIHtcXG4gIHdpZHRoOiAxNDAwcHg7XFxuICBoZWlnaHQ6IDYwMHB4O1xcbn1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vLi9zcmMvcGFnZXMvZ3JhcGgvY29tcG9uZW50cy9kYXRhLnZ1ZVwiLFwid2VicGFjazovLy4vZGF0YS52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxhQUFBO0VBQ0EsYUFBQTtBQ0FGXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcbiNjaGFydCB7XFxuICB3aWR0aDogMTQwMHB4O1xcbiAgaGVpZ2h0OiA2MDBweDtcXG59XFxuXCIsXCIjY2hhcnQge1xcbiAgd2lkdGg6IDE0MDBweDtcXG4gIGhlaWdodDogNjAwcHg7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCJleHBvcnQgZGVmYXVsdCB7XG4gIF9fbmFtZTogJ2RhdGEnLFxuICBzZXR1cDogZnVuY3Rpb24gc2V0dXAoX19wcm9wcywgX3JlZikge1xuICAgIHZhciBleHBvc2UgPSBfcmVmLmV4cG9zZTtcbiAgICBleHBvc2UoKTtcbiAgICB2YXIgZWNoYXJ0cyA9IGluamVjdChcImVjaGFydHNcIik7XG4gICAgdmFyIG9wdGlvbiA9IHJlZih7fSk7XG4gICAgdmFyIG5hbWVMaXN0ID0gW1wi54Wk54KtXCIsIFwi55+z5rK5XCIsIFwi5aSp54S25rCUXCIsIFwi5rC0XCIsIFwi55S1XCIsIFwi55S15L+hXCIsIFwi5Lqk6YCaXCIsIFwi5Yy755aXXCIsIFwi5L2P5oi/XCIsIFwi5pWZ6IKyXCJdO1xuICAgIHZhciBnZW5EYXRhID0gZnVuY3Rpb24gZ2VuRGF0YShjb3VudCkge1xuICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICB2YXIgbGVnZW5kRGF0YSA9IFtdO1xuICAgICAgdmFyIHNlcmllc0RhdGEgPSBbXTtcbiAgICAgIG5hbWVMaXN0LmZvckVhY2goZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgbGVnZW5kRGF0YS5wdXNoKGl0ZW0pO1xuICAgICAgICBzZXJpZXNEYXRhLnB1c2goe1xuICAgICAgICAgIG5hbWU6IGl0ZW0sXG4gICAgICAgICAgdmFsdWU6IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIDEwMClcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZ2VuZERhdGE6IGxlZ2VuZERhdGEsXG4gICAgICAgIHNlcmllc0RhdGE6IHNlcmllc0RhdGFcbiAgICAgIH07XG4gICAgfTtcbiAgICB2YXIgZGF0YSA9IGdlbkRhdGEoMTEpO1xuICAgIHZhciBjaGFydEZ1biA9IGZ1bmN0aW9uIGNoYXJ0RnVuKCkge1xuICAgICAgdmFyIGNoYXJ0RG9tID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjaGFydFwiKTtcbiAgICAgIHZhciBteUNoYXJ0ID0gZWNoYXJ0cy5pbml0KGNoYXJ0RG9tKTtcbiAgICAgIG9wdGlvbi52YWx1ZSA9IHtcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICB0ZXh0OiBcIuaKlei1hCbmtojotLnmlLbnm4rmr5Tph41cIixcbiAgICAgICAgICBzdWJ0ZXh0OiBcIue6r+WxnuiZmuaehFwiLFxuICAgICAgICAgIGxlZnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgdG9wOiA1MFxuICAgICAgICB9LFxuICAgICAgICBjb2xvcjogW1wiIzkxY2M3NVwiLCBcIiNmMWIyYzNcIiwgXCIjNmI1NDI4XCIsIFwiIzE0OTdkYlwiLCBcIiNlZjZjMDBcIiwgXCIjZDMzNDI4XCIsIFwiIzlhZDY1M1wiLCBcIiNkNmIzZjRcIiwgXCIjMWUxZTFlXCIsIFwiI2ZiNTg2NVwiXSxcbiAgICAgICAgdG9vbHRpcDoge1xuICAgICAgICAgIHRyaWdnZXI6IFwiaXRlbVwiLFxuICAgICAgICAgIGZvcm1hdHRlcjogXCJ7YX0gPGJyLz57Yn0gOiB7Y30gKHtkfSUpXCJcbiAgICAgICAgfSxcbiAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgdHlwZTogXCJzY3JvbGxcIixcbiAgICAgICAgICBvcmllbnQ6IFwidmVydGljYWxcIixcbiAgICAgICAgICByaWdodDogMTAsXG4gICAgICAgICAgdG9wOiAyMDAsXG4gICAgICAgICAgYm90dG9tOiAyMCxcbiAgICAgICAgICBkYXRhOiBkYXRhLmxlZ2VuZERhdGFcbiAgICAgICAgfSxcbiAgICAgICAgc2VyaWVzOiBbe1xuICAgICAgICAgIG5hbWU6IFwi5aeT5ZCNXCIsXG4gICAgICAgICAgdHlwZTogXCJwaWVcIixcbiAgICAgICAgICByYWRpdXM6IFwiNTUlXCIsXG4gICAgICAgICAgY2VudGVyOiBbXCI0MCVcIiwgXCI1MCVcIl0sXG4gICAgICAgICAgZGF0YTogZGF0YS5zZXJpZXNEYXRhLFxuICAgICAgICAgIGVtcGhhc2lzOiB7XG4gICAgICAgICAgICBpdGVtU3R5bGU6IHtcbiAgICAgICAgICAgICAgc2hhZG93Qmx1cjogMTAsXG4gICAgICAgICAgICAgIHNoYWRvd09mZnNldFg6IDAsXG4gICAgICAgICAgICAgIHNoYWRvd0NvbG9yOiBcInJnYmEoMCwgMCwgMCwgMC41KVwiXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XVxuICAgICAgfTtcbiAgICAgIG15Q2hhcnQuc2V0T3B0aW9uKG9wdGlvbi52YWx1ZSk7XG4gICAgfTtcbiAgICBvbk1vdW50ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgbmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICBjaGFydEZ1bigpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgdmFyIF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIGdldCBlY2hhcnRzKCkge1xuICAgICAgICByZXR1cm4gZWNoYXJ0cztcbiAgICAgIH0sXG4gICAgICBzZXQgZWNoYXJ0cyh2KSB7XG4gICAgICAgIGVjaGFydHMgPSB2O1xuICAgICAgfSxcbiAgICAgIG9wdGlvbjogb3B0aW9uLFxuICAgICAgbmFtZUxpc3Q6IG5hbWVMaXN0LFxuICAgICAgZ2VuRGF0YTogZ2VuRGF0YSxcbiAgICAgIGRhdGE6IGRhdGEsXG4gICAgICBjaGFydEZ1bjogY2hhcnRGdW5cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3JldHVybmVkX18sICdfX2lzU2NyaXB0U2V0dXAnLCB7XG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIHZhbHVlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIF9fcmV0dXJuZWRfXztcbiAgfVxufTsiLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBpZD1cImNoYXJ0XCI+PC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0IHNldHVwPlxyXG5sZXQgZWNoYXJ0cyA9IGluamVjdChcImVjaGFydHNcIik7XHJcblxyXG5jb25zdCBvcHRpb24gPSByZWYoe30pO1xyXG5jb25zdCBuYW1lTGlzdCA9IFtcclxuICBcIueFpOeCrVwiLFxyXG4gIFwi55+z5rK5XCIsXHJcbiAgXCLlpKnnhLbmsJRcIixcclxuICBcIuawtFwiLFxyXG4gIFwi55S1XCIsXHJcbiAgXCLnlLXkv6FcIixcclxuICBcIuS6pOmAmlwiLFxyXG4gIFwi5Yy755aXXCIsXHJcbiAgXCLkvY/miL9cIixcclxuICBcIuaVmeiCslwiLFxyXG5dO1xyXG5jb25zdCBnZW5EYXRhID0gKGNvdW50KSA9PiB7XHJcbiAgLy8gcHJldHRpZXItaWdub3JlXHJcbiAgY29uc3QgbGVnZW5kRGF0YSA9IFtdO1xyXG4gIGNvbnN0IHNlcmllc0RhdGEgPSBbXTtcclxuICBuYW1lTGlzdC5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICBsZWdlbmREYXRhLnB1c2goaXRlbSk7XHJcbiAgICBzZXJpZXNEYXRhLnB1c2goe1xyXG4gICAgICBuYW1lOiBpdGVtLFxyXG4gICAgICB2YWx1ZTogTWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMTAwKSxcclxuICAgIH0pO1xyXG4gIH0pO1xyXG4gIHJldHVybiB7XHJcbiAgICBsZWdlbmREYXRhOiBsZWdlbmREYXRhLFxyXG4gICAgc2VyaWVzRGF0YTogc2VyaWVzRGF0YSxcclxuICB9O1xyXG59O1xyXG5jb25zdCBkYXRhID0gZ2VuRGF0YSgxMSk7XHJcbmNvbnN0IGNoYXJ0RnVuID0gKCkgPT4ge1xyXG4gIGNvbnN0IGNoYXJ0RG9tID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjaGFydFwiKTtcclxuICBjb25zdCBteUNoYXJ0ID0gZWNoYXJ0cy5pbml0KGNoYXJ0RG9tKTtcclxuICBvcHRpb24udmFsdWUgPSB7XHJcbiAgICB0aXRsZToge1xyXG4gICAgICB0ZXh0OiBcIuaKlei1hCbmtojotLnmlLbnm4rmr5Tph41cIixcclxuICAgICAgc3VidGV4dDogXCLnuq/lsZ7omZrmnoRcIixcclxuICAgICAgbGVmdDogXCJjZW50ZXJcIixcclxuICAgICAgdG9wOiA1MCxcclxuICAgIH0sXHJcbiAgICBjb2xvcjogW1xyXG4gICAgICBcIiM5MWNjNzVcIixcclxuICAgICAgXCIjZjFiMmMzXCIsXHJcbiAgICAgIFwiIzZiNTQyOFwiLFxyXG4gICAgICBcIiMxNDk3ZGJcIixcclxuICAgICAgXCIjZWY2YzAwXCIsXHJcbiAgICAgIFwiI2QzMzQyOFwiLFxyXG4gICAgICBcIiM5YWQ2NTNcIixcclxuICAgICAgXCIjZDZiM2Y0XCIsXHJcbiAgICAgIFwiIzFlMWUxZVwiLFxyXG4gICAgICBcIiNmYjU4NjVcIixcclxuICAgIF0sXHJcbiAgICB0b29sdGlwOiB7XHJcbiAgICAgIHRyaWdnZXI6IFwiaXRlbVwiLFxyXG4gICAgICBmb3JtYXR0ZXI6IFwie2F9IDxici8+e2J9IDoge2N9ICh7ZH0lKVwiLFxyXG4gICAgfSxcclxuICAgIGxlZ2VuZDoge1xyXG4gICAgICB0eXBlOiBcInNjcm9sbFwiLFxyXG4gICAgICBvcmllbnQ6IFwidmVydGljYWxcIixcclxuICAgICAgcmlnaHQ6IDEwLFxyXG4gICAgICB0b3A6IDIwMCxcclxuICAgICAgYm90dG9tOiAyMCxcclxuICAgICAgZGF0YTogZGF0YS5sZWdlbmREYXRhLFxyXG4gICAgfSxcclxuICAgIHNlcmllczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogXCLlp5PlkI1cIixcclxuICAgICAgICB0eXBlOiBcInBpZVwiLFxyXG4gICAgICAgIHJhZGl1czogXCI1NSVcIixcclxuICAgICAgICBjZW50ZXI6IFtcIjQwJVwiLCBcIjUwJVwiXSxcclxuICAgICAgICBkYXRhOiBkYXRhLnNlcmllc0RhdGEsXHJcbiAgICAgICAgZW1waGFzaXM6IHtcclxuICAgICAgICAgIGl0ZW1TdHlsZToge1xyXG4gICAgICAgICAgICBzaGFkb3dCbHVyOiAxMCxcclxuICAgICAgICAgICAgc2hhZG93T2Zmc2V0WDogMCxcclxuICAgICAgICAgICAgc2hhZG93Q29sb3I6IFwicmdiYSgwLCAwLCAwLCAwLjUpXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH07XHJcblxyXG4gIG15Q2hhcnQuc2V0T3B0aW9uKG9wdGlvbi52YWx1ZSk7XHJcbn07XHJcbm9uTW91bnRlZCgoKSA9PiB7XHJcbiAgbmV4dFRpY2soKCkgPT4ge1xyXG4gICAgY2hhcnRGdW4oKTtcclxuICB9KTtcclxufSk7XHJcbjwvc2NyaXB0PlxyXG5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4jY2hhcnQge1xyXG4gIHdpZHRoOiAxNDAwcHg7XHJcbiAgaGVpZ2h0OiA2MDBweDtcclxufVxyXG48L3N0eWxlPlxyXG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9kYXRhLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ0YmQwYjZlJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9kYXRhLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ0YmQwYjZlJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgIGV4cG9ydCBkZWZhdWx0IGNvbnRlbnQgJiYgY29udGVudC5sb2NhbHMgPyBjb250ZW50LmxvY2FscyA6IHVuZGVmaW5lZDtcbiIsImltcG9ydCB7IHJlbmRlciB9IGZyb20gXCIuL2RhdGEudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTQ0YmQwYjZlJnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vZGF0YS52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9kYXRhLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcblxuaW1wb3J0IFwiLi9kYXRhLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ0YmQwYjZlJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIkQ6XFxcXOmhueebrlxcXFx3ZWJwYWNrLXZ1ZVxcXFx3ZWJwYWNrLS0tLXZ1ZVxcXFxub2RlX21vZHVsZXNcXFxcdnVlLWxvYWRlclxcXFxkaXN0XFxcXGV4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LTQ0YmQwYjZlXCJdLFsnX19maWxlJyxcInNyYy9wYWdlcy9ncmFwaC9jb21wb25lbnRzL2RhdGEudnVlXCJdXSlcbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIF9fZXhwb3J0c19fLl9faG1ySWQgPSBcIjQ0YmQwYjZlXCJcbiAgY29uc3QgYXBpID0gX19WVUVfSE1SX1JVTlRJTUVfX1xuICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gIGlmICghYXBpLmNyZWF0ZVJlY29yZCgnNDRiZDBiNmUnLCBfX2V4cG9ydHNfXykpIHtcbiAgICBhcGkucmVsb2FkKCc0NGJkMGI2ZScsIF9fZXhwb3J0c19fKVxuICB9XG4gIFxuICBtb2R1bGUuaG90LmFjY2VwdChcIi4vZGF0YS52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDRiZDBiNmUmc2NvcGVkPXRydWVcIiwgKCkgPT4ge1xuICAgIGFwaS5yZXJlbmRlcignNDRiZDBiNmUnLCByZW5kZXIpXG4gIH0pXG5cbn1cblxuXG5leHBvcnQgZGVmYXVsdCBfX2V4cG9ydHNfXyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2RhdGEudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz91bnBsdWdpbk5hbWU9dW5wbHVnaW4tYXV0by1pbXBvcnQhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMTAudXNlIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9kYXRhLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vZGF0YS52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDRiZDBiNmUmc2NvcGVkPXRydWVcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL2RhdGEudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NDRiZDBiNmUmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCIiXSwibmFtZXMiOlsiaWQiLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX2hvaXN0ZWRfMSJdLCJzb3VyY2VSb290IjoiIn0=