"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_brochure_index_vue"],{

/***/ 88531:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/brochure/index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".box[data-v-7b97c9aa] {\n  height: 1400px;\n  position: relative;\n}\n.box .brochureHeader[data-v-7b97c9aa] {\n  box-sizing: border-box;\n  position: fixed;\n  z-index: 10;\n  height: 100px;\n  width: 100%;\n  background-color: #fff;\n  display: flex;\n}\n.box .brochureHeader justify-content:flex-start .logo[data-v-7b97c9aa] {\n  height: 100px;\n  padding: 10px;\n}\n.box .brochureHeader .headerTitle[data-v-7b97c9aa] {\n  display: flex;\n}\n.box .brochureHeader .headerTitle li[data-v-7b97c9aa] {\n  font-size: 24px;\n  margin-right: 30px;\n  margin-left: 30px;\n  line-height: 100px;\n  color: var(--text-color2);\n  cursor: pointer;\n}\n.box .content[data-v-7b97c9aa] {\n  background-image: linear-gradient(var(--background-color2), #fff);\n  width: 100%;\n  position: absolute;\n  top: 100px;\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  padding-top: 20px;\n}\n.box .content .imgSwiper[data-v-7b97c9aa] {\n  width: 800px;\n}\n.box .content .imgSwiper img[data-v-7b97c9aa] {\n  width: 800px;\n}\n.box .content .introduce[data-v-7b97c9aa] {\n  width: 100%;\n  height: 1300px;\n  padding: 50px 100px 50px;\n}\n.box .content .introduce .text[data-v-7b97c9aa] {\n  font-size: 20px;\n  margin: 10px;\n}\n.box .content .introduce .contentMoudle[data-v-7b97c9aa] {\n  display: flex;\n  height: 500px;\n  justify-content: center;\n}\n.box .content .introduce .activeMoudle[data-v-7b97c9aa] {\n  display: flex;\n  height: 500px;\n  justify-content: center;\n}\n.box .footer[data-v-7b97c9aa] {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  width: 100%;\n  height: 100px;\n  background: var(--backround-color4);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 30px;\n}\n.box .footer li[data-v-7b97c9aa] {\n  color: var(--text-color1);\n}\n.jumpLogin[data-v-7b97c9aa] {\n  position: absolute;\n  right: 0px;\n  top: 0px;\n  font-size: 24px;\n  margin-left: 100px;\n  padding: 0 50px 0;\n  line-height: 100px;\n  color: var(--text-color1);\n  background: var(--background-color1);\n  cursor: pointer;\n}\n.el-carousel__item h3[data-v-7b97c9aa] {\n  display: flex;\n  color: #475669;\n  opacity: 0.75;\n  line-height: 300px;\n  margin: 0;\n}\n.el-carousel__item[data-v-7b97c9aa]:nth-child(2n) {\n  background-color: #99a9bf;\n}\n.el-carousel__item[data-v-7b97c9aa]:nth-child(2n + 1) {\n  background-color: #d3dce6;\n}\n[data-v-7b97c9aa] .el-carousel__container {\n  height: 480px;\n}\n[data-v-7b97c9aa] .el-carousel__container {\n  height: 440px !important;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/brochure/index.vue","webpack://./index.vue"],"names":[],"mappings":"AACA;EACE,cAAA;EACA,kBAAA;ACAF;ADFA;EAII,sBAAA;EACA,eAAA;EACA,WAAA;EACA,aAAA;EACA,WAAA;EACA,sBAAA;EACA,aAAA;ACCJ;ADXA;EAYM,aAAA;EACA,aAAA;ACEN;ADfA;EAiBM,aAAA;ACCN;ADlBA;EAmBQ,eAAA;EACA,kBAAA;EACA,iBAAA;EACA,kBAAA;EACA,yBAAA;EACA,eAAA;ACER;AD1BA;EA8BI,iEAAA;EACA,WAAA;EACA,kBAAA;EACA,UAAA;EACA,aAAA;EACA,eAAA;EACA,uBAAA;EACA,iBAAA;ACDJ;ADpCA;EAuCM,YAAA;ACAN;ADvCA;EA0CQ,YAAA;ACAR;AD1CA;EAkDM,WAAA;EACA,cAAA;EACA,wBAAA;ACLN;AD/CA;EAuDQ,eAAA;EACA,YAAA;ACLR;ADnDA;EA2DQ,aAAA;EAEA,aAAA;EACA,uBAAA;ACNR;ADxDA;EAwEQ,aAAA;EAEA,aAAA;EACA,uBAAA;ACdR;AD7DA;EAyFI,eAAA;EACA,WAAA;EACA,SAAA;EACA,WAAA;EACA,aAAA;EACA,mCAAA;EACA,aAAA;EACA,8BAAA;EACA,mBAAA;EACA,eAAA;ACzBJ;ADzEA;EAsGM,yBAAA;AC1BN;AD8BA;EACE,kBAAA;EACA,UAAA;EACA,QAAA;EACA,eAAA;EACA,kBAAA;EACA,iBAAA;EACA,kBAAA;EACA,yBAAA;EAEA,oCAAA;EAEA,eAAA;AC9BF;ADoCA;EACE,aAAA;EACA,cAAA;EACA,aAAA;EACA,kBAAA;EACA,SAAA;AClCF;ADqCA;EACE,yBAAA;ACnCF;ADsCA;EACE,yBAAA;ACpCF;ADsCA;EACE,aAAA;ACpCF;ADsCA;EACE,wBAAA;ACpCF","sourcesContent":["\n.box {\n  height: 1400px;\n  position: relative;\n  .brochureHeader {\n    box-sizing: border-box;\n    position: fixed;\n    z-index: 10;\n    height: 100px;\n    width: 100%;\n    background-color: #fff;\n    display: flex;\n    justify-content:flex-start .logo {\n      height: 100px;\n      padding: 10px;\n      // background: #fff;\n    }\n    .headerTitle {\n      display: flex;\n      li {\n        font-size: 24px;\n        margin-right: 30px;\n        margin-left: 30px;\n        line-height: 100px;\n        color: var(--text-color2);\n        cursor: pointer;\n      }\n    }\n  }\n  .content {\n    // margin-top: 100px;\n    background-image: linear-gradient(var(--background-color2), #fff);\n    width: 100%;\n    position: absolute;\n    top: 100px;\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: center;\n    padding-top: 20px;\n    .imgSwiper {\n      width: 800px;\n      // padding: 10px 10vw 50px;\n      img {\n        width: 800px;\n        // width: 80vw;\n        // height: 70vh;\n      }\n    }\n    .introduce {\n      // display: flex;\n      // background: var(--background-color1);\n      width: 100%;\n      height: 1300px;\n      padding: 50px 100px 50px;\n      // display: flex;\n      .text {\n        font-size: 20px;\n        margin: 10px;\n      }\n      .contentMoudle {\n        display: flex;\n        // width: 800px;\n        height: 500px;\n        justify-content: center;\n        // .contentLeft {\n        //   float: left;\n        // }\n        // .contentRight {\n        //   float: left;\n        //   margin-top: 10px;\n        // }\n      }\n      .activeMoudle {\n        display: flex;\n        // width: 800px;\n        height: 500px;\n        justify-content: center;\n        // .activeImg {\n        //   float: left;\n        //   margin-top: 100px;\n        // }\n        // .activeRight {\n        //   float: left;\n        //   margin-top: 100px;\n        //   margin-left: 20px;\n        // }\n      }\n    }\n  }\n  .footer {\n    position: fixed;\n    bottom: 0px;\n    left: 0px;\n    width: 100%;\n    height: 100px;\n    background: var(--backround-color4);\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    padding: 0 30px;\n    li {\n      // float: left;\n      // margin: 40px 50px 10px;\n      color: var(--text-color1);\n    }\n  }\n}\n.jumpLogin {\n  position: absolute;\n  right: 0px;\n  top: 0px;\n  font-size: 24px;\n  margin-left: 100px;\n  padding: 0 50px 0;\n  line-height: 100px;\n  color: var(--text-color1);\n  // border-radius: 50%;\n  background: var(--background-color1);\n  // background: var(--background-color0);\n  cursor: pointer;\n}\n// .jumpLogin:hover {\n//   background: var(--background-color1);\n//   color: #fff;\n// }\n.el-carousel__item h3 {\n  display: flex;\n  color: #475669;\n  opacity: 0.75;\n  line-height: 300px;\n  margin: 0;\n}\n\n.el-carousel__item:nth-child(2n) {\n  background-color: #99a9bf;\n}\n\n.el-carousel__item:nth-child(2n + 1) {\n  background-color: #d3dce6;\n}\n::v-deep(.el-carousel__container) {\n  height: 480px;\n}\n::v-deep(.el-carousel__container) {\n  height: 440px !important;\n}\n",".box {\n  height: 1400px;\n  position: relative;\n}\n.box .brochureHeader {\n  box-sizing: border-box;\n  position: fixed;\n  z-index: 10;\n  height: 100px;\n  width: 100%;\n  background-color: #fff;\n  display: flex;\n}\n.box .brochureHeader justify-content:flex-start .logo {\n  height: 100px;\n  padding: 10px;\n}\n.box .brochureHeader .headerTitle {\n  display: flex;\n}\n.box .brochureHeader .headerTitle li {\n  font-size: 24px;\n  margin-right: 30px;\n  margin-left: 30px;\n  line-height: 100px;\n  color: var(--text-color2);\n  cursor: pointer;\n}\n.box .content {\n  background-image: linear-gradient(var(--background-color2), #fff);\n  width: 100%;\n  position: absolute;\n  top: 100px;\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  padding-top: 20px;\n}\n.box .content .imgSwiper {\n  width: 800px;\n}\n.box .content .imgSwiper img {\n  width: 800px;\n}\n.box .content .introduce {\n  width: 100%;\n  height: 1300px;\n  padding: 50px 100px 50px;\n}\n.box .content .introduce .text {\n  font-size: 20px;\n  margin: 10px;\n}\n.box .content .introduce .contentMoudle {\n  display: flex;\n  height: 500px;\n  justify-content: center;\n}\n.box .content .introduce .activeMoudle {\n  display: flex;\n  height: 500px;\n  justify-content: center;\n}\n.box .footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  width: 100%;\n  height: 100px;\n  background: var(--backround-color4);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 30px;\n}\n.box .footer li {\n  color: var(--text-color1);\n}\n.jumpLogin {\n  position: absolute;\n  right: 0px;\n  top: 0px;\n  font-size: 24px;\n  margin-left: 100px;\n  padding: 0 50px 0;\n  line-height: 100px;\n  color: var(--text-color1);\n  background: var(--background-color1);\n  cursor: pointer;\n}\n.el-carousel__item h3 {\n  display: flex;\n  color: #475669;\n  opacity: 0.75;\n  line-height: 300px;\n  margin: 0;\n}\n.el-carousel__item:nth-child(2n) {\n  background-color: #99a9bf;\n}\n.el-carousel__item:nth-child(2n + 1) {\n  background-color: #d3dce6;\n}\n::v-deep(.el-carousel__container) {\n  height: 480px;\n}\n::v-deep(.el-carousel__container) {\n  height: 440px !important;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 35632:
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/brochure/index.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: "brochure",
  methods: {
    jumpLogin: function jumpLogin() {
      var token = localStorage.getItem("token");
      if (token) {
        console.log(token, "token值???");
        this.$router.push({
          path: "/dashboard"
        });
      } else {
        this.$router.push({
          path: "/login"
        });
      }
    }
  }
});

/***/ }),

/***/ 71921:
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/brochure/index.vue?vue&type=template&id=7b97c9aa&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);
/* harmony import */ var _assets_Logo_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/Logo.png */ 24055);
/* harmony import */ var _assets_swiper1_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/swiper1.png */ 32430);
/* harmony import */ var _assets_swiper2_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/swiper2.png */ 43486);
/* harmony import */ var _assets_swiper3_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../assets/swiper3.png */ 92378);
/* harmony import */ var _assets_swiper4_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../assets/swiper4.png */ 52740);
/* harmony import */ var _assets_swiper5_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/swiper5.png */ 24649);
/* harmony import */ var _assets_img2_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/assets/img2.png */ 45516);
/* harmony import */ var _assets_img_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/assets/img.gif */ 22616);
/* harmony import */ var _assets_img_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/assets/img.png */ 40747);










var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-7b97c9aa"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "box"
};
var _hoisted_2 = {
  "class": "brochureHeader"
};
var _hoisted_3 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    "class": "logo"
  }, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_Logo_png__WEBPACK_IMPORTED_MODULE_1__,
    alt: ""
  })], -1 /* HOISTED */);
});
var _hoisted_4 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ul", {
    "class": "headerTitle"
  }, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "业务领域"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "价值流"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "任务管理"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "实体领域"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "风险资产")], -1 /* HOISTED */);
});
var _hoisted_5 = {
  "class": "content"
};
var _hoisted_6 = {
  "class": "imgSwiper"
};
var _hoisted_7 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_swiper1_png__WEBPACK_IMPORTED_MODULE_2__,
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_8 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_swiper2_png__WEBPACK_IMPORTED_MODULE_3__,
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_9 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_swiper3_png__WEBPACK_IMPORTED_MODULE_4__,
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_10 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_swiper4_png__WEBPACK_IMPORTED_MODULE_5__,
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_11 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
    src: _assets_swiper5_png__WEBPACK_IMPORTED_MODULE_6__,
    alt: ""
  }, null, -1 /* HOISTED */);
});
var _hoisted_12 = /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createStaticVNode)("<div class=\"introduce\" data-v-7b97c9aa><div class=\"contentMoudle\" data-v-7b97c9aa><div class=\"contentLeft\" data-v-7b97c9aa><h2 style=\"font-size:50px;font-weight:700;\" data-v-7b97c9aa> IAM架构资产管理系统 </h2><p class=\"text\" data-v-7b97c9aa>帮助企业对其IT架构资产进行全面管理和控制。</p><p class=\"text\" data-v-7b97c9aa> 通过对资产的全面了解，可以更好地评估IT资本价值和成本效益， </p><p class=\"text\" data-v-7b97c9aa>并确保其IT环境符合法规和行业标准。</p><p class=\"text\" data-v-7b97c9aa>降低运营成本,也可提高安全性和可靠性</p><p class=\"text\" data-v-7b97c9aa>帮助企业制定和实施关键决策,更好地管理其IT资产,</p><p class=\"text\" data-v-7b97c9aa>为企业的持续发展提供坚实的基础。</p></div><div class=\"contentRight\" data-v-7b97c9aa><img src=\"" + _assets_img2_png__WEBPACK_IMPORTED_MODULE_7__ + "\" alt=\"\" data-v-7b97c9aa></div></div><div class=\"activeMoudle\" data-v-7b97c9aa><div class=\"activeImg\" data-v-7b97c9aa><img src=\"" + _assets_img_gif__WEBPACK_IMPORTED_MODULE_8__ + "\" alt=\"\" data-v-7b97c9aa></div><div class=\"activeRight\" data-v-7b97c9aa><p class=\"text\" data-v-7b97c9aa>员工自主查看与管理资产状态</p><p class=\"text\" data-v-7b97c9aa>对所负责资产进行直接管理</p><p class=\"text\" data-v-7b97c9aa>各层级员工拥有不同的权限</p><p class=\"text\" data-v-7b97c9aa>对资产的创建,审批,评估的一体化管理</p><p class=\"text\" data-v-7b97c9aa>具有流程追踪和申办记录的能力</p><img src=\"" + _assets_img_png__WEBPACK_IMPORTED_MODULE_9__ + "\" style=\"margin-top:10px;\" alt=\"\" data-v-7b97c9aa></div></div></div>", 1);
var _hoisted_13 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("ul", {
    "class": "footer"
  }, [/*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "了解我们"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "招商电话"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "广告连接"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "售后服务"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "远程服务"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "在线咨询"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "漏洞上报"), /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("li", null, "关于其他")], -1 /* HOISTED */);
});

function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_carousel_item = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-carousel-item");
  var _component_el_carousel = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-carousel");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [_hoisted_3, _hoisted_4, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    "class": "jumpLogin",
    onClick: _cache[0] || (_cache[0] = function () {
      return $options.jumpLogin && $options.jumpLogin.apply($options, arguments);
    })
  }, "开始体验")]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_6, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel, {
    "indicator-position": "outside"
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [_hoisted_7];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [_hoisted_8];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [_hoisted_9];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [_hoisted_10];
        }),
        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_carousel_item, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [_hoisted_11];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  })]), _hoisted_12]), _hoisted_13]);
}

/***/ }),

/***/ 43700:
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/brochure/index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true */ 88531);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 22595:
/*!**************************************!*\
  !*** ./src/pages/brochure/index.vue ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_7b97c9aa_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=7b97c9aa&scoped=true */ 71318);
/* harmony import */ var _index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&lang=js */ 90031);
/* harmony import */ var _index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true */ 90638);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_index_vue_vue_type_template_id_7b97c9aa_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-7b97c9aa"],['__file',"src/pages/brochure/index.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 90031:
/*!**************************************************************!*\
  !*** ./src/pages/brochure/index.vue?vue&type=script&lang=js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=script&lang=js */ 35632);
 

/***/ }),

/***/ 71318:
/*!********************************************************************************!*\
  !*** ./src/pages/brochure/index.vue?vue&type=template&id=7b97c9aa&scoped=true ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_7b97c9aa_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_index_vue_vue_type_template_id_7b97c9aa_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../node_modules/source-map-loader/dist/cjs.js!./index.vue?vue&type=template&id=7b97c9aa&scoped=true */ 71921);


/***/ }),

/***/ 90638:
/*!***********************************************************************************************!*\
  !*** ./src/pages/brochure/index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_index_vue_vue_type_style_index_0_id_7b97c9aa_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/less-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./index.vue?vue&type=style&index=0&id=7b97c9aa&lang=less&scoped=true */ 43700);


/***/ }),

/***/ 24055:
/*!*****************************!*\
  !*** ./src/assets/Logo.png ***!
  \*****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "7bca2e97f33a295277fb.png";

/***/ }),

/***/ 22616:
/*!****************************!*\
  !*** ./src/assets/img.gif ***!
  \****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "29aca533a9975748d93b.gif";

/***/ }),

/***/ 40747:
/*!****************************!*\
  !*** ./src/assets/img.png ***!
  \****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "07589c89c5f5a79ee537.png";

/***/ }),

/***/ 45516:
/*!*****************************!*\
  !*** ./src/assets/img2.png ***!
  \*****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "88694a994794c386408e.png";

/***/ }),

/***/ 32430:
/*!********************************!*\
  !*** ./src/assets/swiper1.png ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "d82cc4c2d11ee46f3cb9.png";

/***/ }),

/***/ 43486:
/*!********************************!*\
  !*** ./src/assets/swiper2.png ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "781cf954b95b238ebb76.png";

/***/ }),

/***/ 92378:
/*!********************************!*\
  !*** ./src/assets/swiper3.png ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "fabc87802e814a05a991.png";

/***/ }),

/***/ 52740:
/*!********************************!*\
  !*** ./src/assets/swiper4.png ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "ba8034d1d8724b423352.png";

/***/ }),

/***/ 24649:
/*!********************************!*\
  !*** ./src/assets/swiper5.png ***!
  \********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "5e5e4e3cacbb647dfead.png";

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX2Jyb2NodXJlX2luZGV4X3Z1ZS45YTUwMGVlMDQ4NTUyYmQxYWVhZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ2dIO0FBQ2pCO0FBQy9GLDhCQUE4QixtRkFBMkIsQ0FBQyw0RkFBcUM7QUFDL0Y7QUFDQSxpRUFBaUUsbUJBQW1CLHVCQUF1QixHQUFHLHlDQUF5QywyQkFBMkIsb0JBQW9CLGdCQUFnQixrQkFBa0IsZ0JBQWdCLDJCQUEyQixrQkFBa0IsR0FBRywwRUFBMEUsa0JBQWtCLGtCQUFrQixHQUFHLHNEQUFzRCxrQkFBa0IsR0FBRyx5REFBeUQsb0JBQW9CLHVCQUF1QixzQkFBc0IsdUJBQXVCLDhCQUE4QixvQkFBb0IsR0FBRyxrQ0FBa0Msc0VBQXNFLGdCQUFnQix1QkFBdUIsZUFBZSxrQkFBa0Isb0JBQW9CLDRCQUE0QixzQkFBc0IsR0FBRyw2Q0FBNkMsaUJBQWlCLEdBQUcsaURBQWlELGlCQUFpQixHQUFHLDZDQUE2QyxnQkFBZ0IsbUJBQW1CLDZCQUE2QixHQUFHLG1EQUFtRCxvQkFBb0IsaUJBQWlCLEdBQUcsNERBQTRELGtCQUFrQixrQkFBa0IsNEJBQTRCLEdBQUcsMkRBQTJELGtCQUFrQixrQkFBa0IsNEJBQTRCLEdBQUcsaUNBQWlDLG9CQUFvQixnQkFBZ0IsY0FBYyxnQkFBZ0Isa0JBQWtCLHdDQUF3QyxrQkFBa0IsbUNBQW1DLHdCQUF3QixvQkFBb0IsR0FBRyxvQ0FBb0MsOEJBQThCLEdBQUcsK0JBQStCLHVCQUF1QixlQUFlLGFBQWEsb0JBQW9CLHVCQUF1QixzQkFBc0IsdUJBQXVCLDhCQUE4Qix5Q0FBeUMsb0JBQW9CLEdBQUcsMENBQTBDLGtCQUFrQixtQkFBbUIsa0JBQWtCLHVCQUF1QixjQUFjLEdBQUcscURBQXFELDhCQUE4QixHQUFHLHlEQUF5RCw4QkFBOEIsR0FBRyw2Q0FBNkMsa0JBQWtCLEdBQUcsNkNBQTZDLDZCQUE2QixHQUFHLFNBQVMsdUhBQXVILFVBQVUsV0FBVyxLQUFLLEtBQUssV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsVUFBVSxLQUFLLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSyxXQUFXLEtBQUssTUFBTSxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxLQUFLLE1BQU0sWUFBWSxVQUFVLFdBQVcsVUFBVSxVQUFVLFVBQVUsV0FBVyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXLFVBQVUsV0FBVyxLQUFLLE1BQU0sV0FBVyxVQUFVLEtBQUssTUFBTSxXQUFXLFVBQVUsV0FBVyxLQUFLLE1BQU0sV0FBVyxVQUFVLFdBQVcsS0FBSyxNQUFNLFdBQVcsVUFBVSxVQUFVLFVBQVUsVUFBVSxXQUFXLFVBQVUsV0FBVyxXQUFXLFVBQVUsTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLFdBQVcsVUFBVSxVQUFVLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsTUFBTSxNQUFNLFVBQVUsVUFBVSxVQUFVLFdBQVcsVUFBVSxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sV0FBVyxrQ0FBa0MsbUJBQW1CLHVCQUF1QixxQkFBcUIsNkJBQTZCLHNCQUFzQixrQkFBa0Isb0JBQW9CLGtCQUFrQiw2QkFBNkIsb0JBQW9CLHdDQUF3QyxzQkFBc0Isc0JBQXNCLDRCQUE0QixPQUFPLG9CQUFvQixzQkFBc0IsWUFBWSwwQkFBMEIsNkJBQTZCLDRCQUE0Qiw2QkFBNkIsb0NBQW9DLDBCQUEwQixTQUFTLE9BQU8sS0FBSyxjQUFjLDJCQUEyQix3RUFBd0Usa0JBQWtCLHlCQUF5QixpQkFBaUIsb0JBQW9CLHNCQUFzQiw4QkFBOEIsd0JBQXdCLGtCQUFrQixxQkFBcUIsbUNBQW1DLGFBQWEsdUJBQXVCLHlCQUF5QiwwQkFBMEIsU0FBUyxPQUFPLGtCQUFrQix5QkFBeUIsZ0RBQWdELG9CQUFvQix1QkFBdUIsaUNBQWlDLHlCQUF5QixlQUFlLDBCQUEwQix1QkFBdUIsU0FBUyx3QkFBd0Isd0JBQXdCLDBCQUEwQix3QkFBd0Isa0NBQWtDLDJCQUEyQiwyQkFBMkIsY0FBYyw0QkFBNEIsMkJBQTJCLGdDQUFnQyxjQUFjLFNBQVMsdUJBQXVCLHdCQUF3QiwwQkFBMEIsd0JBQXdCLGtDQUFrQyx5QkFBeUIsMkJBQTJCLGlDQUFpQyxjQUFjLDJCQUEyQiwyQkFBMkIsaUNBQWlDLGlDQUFpQyxjQUFjLFNBQVMsT0FBTyxLQUFLLGFBQWEsc0JBQXNCLGtCQUFrQixnQkFBZ0Isa0JBQWtCLG9CQUFvQiwwQ0FBMEMsb0JBQW9CLHFDQUFxQywwQkFBMEIsc0JBQXNCLFVBQVUsdUJBQXVCLGtDQUFrQyxrQ0FBa0MsT0FBTyxLQUFLLEdBQUcsY0FBYyx1QkFBdUIsZUFBZSxhQUFhLG9CQUFvQix1QkFBdUIsc0JBQXNCLHVCQUF1Qiw4QkFBOEIsMEJBQTBCLHlDQUF5Qyw0Q0FBNEMsb0JBQW9CLEdBQUcsdUJBQXVCLDRDQUE0QyxtQkFBbUIsTUFBTSx5QkFBeUIsa0JBQWtCLG1CQUFtQixrQkFBa0IsdUJBQXVCLGNBQWMsR0FBRyxzQ0FBc0MsOEJBQThCLEdBQUcsMENBQTBDLDhCQUE4QixHQUFHLHFDQUFxQyxrQkFBa0IsR0FBRyxxQ0FBcUMsNkJBQTZCLEdBQUcsV0FBVyxtQkFBbUIsdUJBQXVCLEdBQUcsd0JBQXdCLDJCQUEyQixvQkFBb0IsZ0JBQWdCLGtCQUFrQixnQkFBZ0IsMkJBQTJCLGtCQUFrQixHQUFHLHlEQUF5RCxrQkFBa0Isa0JBQWtCLEdBQUcscUNBQXFDLGtCQUFrQixHQUFHLHdDQUF3QyxvQkFBb0IsdUJBQXVCLHNCQUFzQix1QkFBdUIsOEJBQThCLG9CQUFvQixHQUFHLGlCQUFpQixzRUFBc0UsZ0JBQWdCLHVCQUF1QixlQUFlLGtCQUFrQixvQkFBb0IsNEJBQTRCLHNCQUFzQixHQUFHLDRCQUE0QixpQkFBaUIsR0FBRyxnQ0FBZ0MsaUJBQWlCLEdBQUcsNEJBQTRCLGdCQUFnQixtQkFBbUIsNkJBQTZCLEdBQUcsa0NBQWtDLG9CQUFvQixpQkFBaUIsR0FBRywyQ0FBMkMsa0JBQWtCLGtCQUFrQiw0QkFBNEIsR0FBRywwQ0FBMEMsa0JBQWtCLGtCQUFrQiw0QkFBNEIsR0FBRyxnQkFBZ0Isb0JBQW9CLGdCQUFnQixjQUFjLGdCQUFnQixrQkFBa0Isd0NBQXdDLGtCQUFrQixtQ0FBbUMsd0JBQXdCLG9CQUFvQixHQUFHLG1CQUFtQiw4QkFBOEIsR0FBRyxjQUFjLHVCQUF1QixlQUFlLGFBQWEsb0JBQW9CLHVCQUF1QixzQkFBc0IsdUJBQXVCLDhCQUE4Qix5Q0FBeUMsb0JBQW9CLEdBQUcseUJBQXlCLGtCQUFrQixtQkFBbUIsa0JBQWtCLHVCQUF1QixjQUFjLEdBQUcsb0NBQW9DLDhCQUE4QixHQUFHLHdDQUF3Qyw4QkFBOEIsR0FBRyxxQ0FBcUMsa0JBQWtCLEdBQUcscUNBQXFDLDZCQUE2QixHQUFHLHFCQUFxQjtBQUN6MlI7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7O0FDNEV2QyxpRUFBZTtFQUNiQSxJQUFJLEVBQUUsVUFBVTtFQUNoQkMsT0FBTyxFQUFFO0lBQ1BDLFNBQVMsV0FBQUEsVUFBQSxFQUFHO01BQ1YsSUFBSUMsS0FBSSxHQUFJQyxZQUFZLENBQUNDLE9BQU8sQ0FBQyxPQUFPLENBQUM7TUFDekMsSUFBSUYsS0FBSyxFQUFFO1FBQ1RHLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSixLQUFLLEVBQUUsV0FBVyxDQUFDO1FBQy9CLElBQUksQ0FBQ0ssT0FBTyxDQUFDQyxJQUFJLENBQUM7VUFBRUMsSUFBSSxFQUFFO1FBQWEsQ0FBQyxDQUFDO01BQzNDLE9BQU87UUFDTCxJQUFJLENBQUNGLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDO1VBQUVDLElBQUksRUFBRTtRQUFTLENBQUMsQ0FBQztNQUN2QztJQUNGO0VBQ0Y7QUFDRixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNUZtQztBQWVXO0FBR0E7QUFHQTtBQUdBO0FBR0E7QUFvQlA7QUFLRDtBQVFBOzs7OztFQS9EaEMsU0FBTTtBQUFLOztFQUNULFNBQU07QUFBZ0I7O3NCQUN6QlUsdURBQUEsQ0FFTTtJQUZELFNBQU07RUFBTSxpQkFDZkEsdURBQUEsQ0FBc0M7SUFBakNDLEdBQXVCLEVBQXZCViw2Q0FBdUI7SUFBQ1csR0FBRyxFQUFDOzs7O3NCQUVuQ0YsdURBQUEsQ0FNSztJQU5ELFNBQU07RUFBYSxpQkFDckJBLHVEQUFBLENBQWEsWUFBVCxNQUFJLGdCQUNSQSx1REFBQSxDQUFZLFlBQVIsS0FBRyxnQkFDUEEsdURBQUEsQ0FBYSxZQUFULE1BQUksZ0JBQ1JBLHVEQUFBLENBQWEsWUFBVCxNQUFJLGdCQUNSQSx1REFBQSxDQUFhLFlBQVQsTUFBSTs7O0VBSVAsU0FBTTtBQUFTOztFQUNiLFNBQU07QUFBVzs7c0JBR2hCQSx1REFBQSxDQUE2QztJQUF4Q0MsR0FBOEIsRUFBOUJULGdEQUE4QjtJQUFDVSxHQUFHLEVBQUM7Ozs7c0JBR3hDRix1REFBQSxDQUE2QztJQUF4Q0MsR0FBOEIsRUFBOUJSLGdEQUE4QjtJQUFDUyxHQUFHLEVBQUM7Ozs7c0JBR3hDRix1REFBQSxDQUE2QztJQUF4Q0MsR0FBOEIsRUFBOUJQLGdEQUE4QjtJQUFDUSxHQUFHLEVBQUM7Ozs7c0JBR3hDRix1REFBQSxDQUE2QztJQUF4Q0MsR0FBOEIsRUFBOUJOLGdEQUE4QjtJQUFDTyxHQUFHLEVBQUM7Ozs7c0JBR3hDRix1REFBQSxDQUE2QztJQUF4Q0MsR0FBOEIsRUFBOUJMLGdEQUE4QjtJQUFDTSxHQUFHLEVBQUM7Ozs7O3NCQXNDaERGLHVEQUFBLENBU0s7SUFURCxTQUFNO0VBQVEsaUJBQ2hCQSx1REFBQSxDQUFhLFlBQVQsTUFBSSxnQkFDUkEsdURBQUEsQ0FBYSxZQUFULE1BQUksZ0JBQ1JBLHVEQUFBLENBQWEsWUFBVCxNQUFJLGdCQUNSQSx1REFBQSxDQUFhLFlBQVQsTUFBSSxnQkFDUkEsdURBQUEsQ0FBYSxZQUFULE1BQUksZ0JBQ1JBLHVEQUFBLENBQWEsWUFBVCxNQUFJLGdCQUNSQSx1REFBQSxDQUFhLFlBQVQsTUFBSSxnQkFDUkEsdURBQUEsQ0FBYSxZQUFULE1BQUk7Ozs7OzsyREE1RVpHLHVEQUFBLENBOEVNLE9BOUVOQyxVQThFTSxHQTdFSkosdURBQUEsQ0FZTSxPQVpOSyxVQVlNLEdBWEpDLFVBRU0sRUFDTkMsVUFNSyxFQUNMUCx1REFBQSxDQUFvRDtJQUEvQyxTQUFNLFdBQVc7SUFBRVEsT0FBSyxFQUFBQyxNQUFBLFFBQUFBLE1BQUE7TUFBQSxPQUFFQyxRQUFBLENBQUE1QixTQUFBLElBQUE0QixRQUFBLENBQUE1QixTQUFBLENBQUE2QixLQUFBLENBQUFELFFBQUEsRUFBQUUsU0FBQSxDQUFTO0lBQUE7S0FBRSxNQUFJLEtBRWhEWix1REFBQSxDQXFETSxPQXJETmEsVUFxRE0sR0FwREpiLHVEQUFBLENBa0JNLE9BbEJOYyxVQWtCTSxHQWpCSkMsZ0RBQUEsQ0FnQmNDLHNCQUFBO0lBaEJELG9CQUFrQixFQUFDO0VBQVM7NERBQ3ZDO01BQUEsT0FFbUIsQ0FGbkJELGdEQUFBLENBRW1CRSwyQkFBQTtnRUFEakI7VUFBQSxPQUE2QyxDQUE3Q0MsVUFBNkM7OztVQUUvQ0gsZ0RBQUEsQ0FFbUJFLDJCQUFBO2dFQURqQjtVQUFBLE9BQTZDLENBQTdDRSxVQUE2Qzs7O1VBRS9DSixnREFBQSxDQUVtQkUsMkJBQUE7Z0VBRGpCO1VBQUEsT0FBNkMsQ0FBN0NHLFVBQTZDOzs7VUFFL0NMLGdEQUFBLENBRW1CRSwyQkFBQTtnRUFEakI7VUFBQSxPQUE2QyxDQUE3Q0ksV0FBNkM7OztVQUUvQ04sZ0RBQUEsQ0FFbUJFLDJCQUFBO2dFQURqQjtVQUFBLE9BQTZDLENBQTdDSyxXQUE2Qzs7Ozs7OztRQUluREMsV0FnQ00sSUFFUkMsV0FTSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3RVQsTUFBcUc7QUFDckcsTUFBMkY7QUFDM0YsTUFBa0c7QUFDbEcsTUFBcUg7QUFDckgsTUFBOEc7QUFDOUcsTUFBOEc7QUFDOUcsTUFBcVY7QUFDclY7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyxtU0FBTzs7OztBQUkrUjtBQUN2VCxPQUFPLGlFQUFlLG1TQUFPLElBQUksMFNBQWMsR0FBRywwU0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQkM7QUFDdEI7QUFDTDs7QUFFbkQsQ0FBNkU7O0FBRXFDO0FBQ2xILGlDQUFpQyxrSEFBZSxDQUFDLDBFQUFNLGFBQWEsd0ZBQU07QUFDMUU7QUFDQSxJQUFJLEtBQVUsRUFBRSxFQVlmOzs7QUFHRCxpRUFBZTs7Ozs7Ozs7Ozs7Ozs7O0FDeEIwViIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2Jyb2NodXJlL2luZGV4LnZ1ZT81MGYxIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL2Jyb2NodXJlL2luZGV4LnZ1ZSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9icm9jaHVyZS9pbmRleC52dWU/ODJlZCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9icm9jaHVyZS9pbmRleC52dWU/ZTkzOSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9icm9jaHVyZS9pbmRleC52dWU/ZDRkNyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9icm9jaHVyZS9pbmRleC52dWU/OTViNyIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9icm9jaHVyZS9pbmRleC52dWU/YTI3MiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL3NvdXJjZU1hcHMuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanNcIjtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbi8vIE1vZHVsZVxuX19fQ1NTX0xPQURFUl9FWFBPUlRfX18ucHVzaChbbW9kdWxlLmlkLCBcIi5ib3hbZGF0YS12LTdiOTdjOWFhXSB7XFxuICBoZWlnaHQ6IDE0MDBweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXJbZGF0YS12LTdiOTdjOWFhXSB7XFxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgcG9zaXRpb246IGZpeGVkO1xcbiAgei1pbmRleDogMTA7XFxuICBoZWlnaHQ6IDEwMHB4O1xcbiAgd2lkdGg6IDEwMCU7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXIganVzdGlmeS1jb250ZW50OmZsZXgtc3RhcnQgLmxvZ29bZGF0YS12LTdiOTdjOWFhXSB7XFxuICBoZWlnaHQ6IDEwMHB4O1xcbiAgcGFkZGluZzogMTBweDtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXIgLmhlYWRlclRpdGxlW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXIgLmhlYWRlclRpdGxlIGxpW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgZm9udC1zaXplOiAyNHB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xcbiAgbWFyZ2luLWxlZnQ6IDMwcHg7XFxuICBsaW5lLWhlaWdodDogMTAwcHg7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjIpO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4uYm94IC5jb250ZW50W2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHZhcigtLWJhY2tncm91bmQtY29sb3IyKSwgI2ZmZik7XFxuICB3aWR0aDogMTAwJTtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMTAwcHg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgZmxleC13cmFwOiB3cmFwO1xcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XFxuICBwYWRkaW5nLXRvcDogMjBweDtcXG59XFxuLmJveCAuY29udGVudCAuaW1nU3dpcGVyW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgd2lkdGg6IDgwMHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5pbWdTd2lwZXIgaW1nW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgd2lkdGg6IDgwMHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5pbnRyb2R1Y2VbZGF0YS12LTdiOTdjOWFhXSB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTMwMHB4O1xcbiAgcGFkZGluZzogNTBweCAxMDBweCA1MHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5pbnRyb2R1Y2UgLnRleHRbZGF0YS12LTdiOTdjOWFhXSB7XFxuICBmb250LXNpemU6IDIwcHg7XFxuICBtYXJnaW46IDEwcHg7XFxufVxcbi5ib3ggLmNvbnRlbnQgLmludHJvZHVjZSAuY29udGVudE1vdWRsZVtkYXRhLXYtN2I5N2M5YWFdIHtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBoZWlnaHQ6IDUwMHB4O1xcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XFxufVxcbi5ib3ggLmNvbnRlbnQgLmludHJvZHVjZSAuYWN0aXZlTW91ZGxlW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGhlaWdodDogNTAwcHg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG59XFxuLmJveCAuZm9vdGVyW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgcG9zaXRpb246IGZpeGVkO1xcbiAgYm90dG9tOiAwcHg7XFxuICBsZWZ0OiAwcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwcHg7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrcm91bmQtY29sb3I0KTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XFxuICBhbGlnbi1pdGVtczogY2VudGVyO1xcbiAgcGFkZGluZzogMCAzMHB4O1xcbn1cXG4uYm94IC5mb290ZXIgbGlbZGF0YS12LTdiOTdjOWFhXSB7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjEpO1xcbn1cXG4uanVtcExvZ2luW2RhdGEtdi03Yjk3YzlhYV0ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgcmlnaHQ6IDBweDtcXG4gIHRvcDogMHB4O1xcbiAgZm9udC1zaXplOiAyNHB4O1xcbiAgbWFyZ2luLWxlZnQ6IDEwMHB4O1xcbiAgcGFkZGluZzogMCA1MHB4IDA7XFxuICBsaW5lLWhlaWdodDogMTAwcHg7XFxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcjEpO1xcbiAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjEpO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbn1cXG4uZWwtY2Fyb3VzZWxfX2l0ZW0gaDNbZGF0YS12LTdiOTdjOWFhXSB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgY29sb3I6ICM0NzU2Njk7XFxuICBvcGFjaXR5OiAwLjc1O1xcbiAgbGluZS1oZWlnaHQ6IDMwMHB4O1xcbiAgbWFyZ2luOiAwO1xcbn1cXG4uZWwtY2Fyb3VzZWxfX2l0ZW1bZGF0YS12LTdiOTdjOWFhXTpudGgtY2hpbGQoMm4pIHtcXG4gIGJhY2tncm91bmQtY29sb3I6ICM5OWE5YmY7XFxufVxcbi5lbC1jYXJvdXNlbF9faXRlbVtkYXRhLXYtN2I5N2M5YWFdOm50aC1jaGlsZCgybiArIDEpIHtcXG4gIGJhY2tncm91bmQtY29sb3I6ICNkM2RjZTY7XFxufVxcbltkYXRhLXYtN2I5N2M5YWFdIC5lbC1jYXJvdXNlbF9fY29udGFpbmVyIHtcXG4gIGhlaWdodDogNDgwcHg7XFxufVxcbltkYXRhLXYtN2I5N2M5YWFdIC5lbC1jYXJvdXNlbF9fY29udGFpbmVyIHtcXG4gIGhlaWdodDogNDQwcHggIWltcG9ydGFudDtcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vc3JjL3BhZ2VzL2Jyb2NodXJlL2luZGV4LnZ1ZVwiLFwid2VicGFjazovLy4vaW5kZXgudnVlXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUNBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0FDQUY7QURGQTtFQUlJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtBQ0NKO0FEWEE7RUFZTSxhQUFBO0VBQ0EsYUFBQTtBQ0VOO0FEZkE7RUFpQk0sYUFBQTtBQ0NOO0FEbEJBO0VBbUJRLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7QUNFUjtBRDFCQTtFQThCSSxpRUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUNESjtBRHBDQTtFQXVDTSxZQUFBO0FDQU47QUR2Q0E7RUEwQ1EsWUFBQTtBQ0FSO0FEMUNBO0VBa0RNLFdBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7QUNMTjtBRC9DQTtFQXVEUSxlQUFBO0VBQ0EsWUFBQTtBQ0xSO0FEbkRBO0VBMkRRLGFBQUE7RUFFQSxhQUFBO0VBQ0EsdUJBQUE7QUNOUjtBRHhEQTtFQXdFUSxhQUFBO0VBRUEsYUFBQTtFQUNBLHVCQUFBO0FDZFI7QUQ3REE7RUF5RkksZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQ0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQ3pCSjtBRHpFQTtFQXNHTSx5QkFBQTtBQzFCTjtBRDhCQTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFFQSxvQ0FBQTtFQUVBLGVBQUE7QUM5QkY7QURvQ0E7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUNsQ0Y7QURxQ0E7RUFDRSx5QkFBQTtBQ25DRjtBRHNDQTtFQUNFLHlCQUFBO0FDcENGO0FEc0NBO0VBQ0UsYUFBQTtBQ3BDRjtBRHNDQTtFQUNFLHdCQUFBO0FDcENGXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIlxcbi5ib3gge1xcbiAgaGVpZ2h0OiAxNDAwcHg7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICAuYnJvY2h1cmVIZWFkZXIge1xcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICBwb3NpdGlvbjogZml4ZWQ7XFxuICAgIHotaW5kZXg6IDEwO1xcbiAgICBoZWlnaHQ6IDEwMHB4O1xcbiAgICB3aWR0aDogMTAwJTtcXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAganVzdGlmeS1jb250ZW50OmZsZXgtc3RhcnQgLmxvZ28ge1xcbiAgICAgIGhlaWdodDogMTAwcHg7XFxuICAgICAgcGFkZGluZzogMTBweDtcXG4gICAgICAvLyBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgICB9XFxuICAgIC5oZWFkZXJUaXRsZSB7XFxuICAgICAgZGlzcGxheTogZmxleDtcXG4gICAgICBsaSB7XFxuICAgICAgICBmb250LXNpemU6IDI0cHg7XFxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XFxuICAgICAgICBtYXJnaW4tbGVmdDogMzBweDtcXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMDBweDtcXG4gICAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMik7XFxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XFxuICAgICAgfVxcbiAgICB9XFxuICB9XFxuICAuY29udGVudCB7XFxuICAgIC8vIG1hcmdpbi10b3A6IDEwMHB4O1xcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodmFyKC0tYmFja2dyb3VuZC1jb2xvcjIpLCAjZmZmKTtcXG4gICAgd2lkdGg6IDEwMCU7XFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgdG9wOiAxMDBweDtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAgZmxleC13cmFwOiB3cmFwO1xcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG4gICAgcGFkZGluZy10b3A6IDIwcHg7XFxuICAgIC5pbWdTd2lwZXIge1xcbiAgICAgIHdpZHRoOiA4MDBweDtcXG4gICAgICAvLyBwYWRkaW5nOiAxMHB4IDEwdncgNTBweDtcXG4gICAgICBpbWcge1xcbiAgICAgICAgd2lkdGg6IDgwMHB4O1xcbiAgICAgICAgLy8gd2lkdGg6IDgwdnc7XFxuICAgICAgICAvLyBoZWlnaHQ6IDcwdmg7XFxuICAgICAgfVxcbiAgICB9XFxuICAgIC5pbnRyb2R1Y2Uge1xcbiAgICAgIC8vIGRpc3BsYXk6IGZsZXg7XFxuICAgICAgLy8gYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjEpO1xcbiAgICAgIHdpZHRoOiAxMDAlO1xcbiAgICAgIGhlaWdodDogMTMwMHB4O1xcbiAgICAgIHBhZGRpbmc6IDUwcHggMTAwcHggNTBweDtcXG4gICAgICAvLyBkaXNwbGF5OiBmbGV4O1xcbiAgICAgIC50ZXh0IHtcXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcXG4gICAgICAgIG1hcmdpbjogMTBweDtcXG4gICAgICB9XFxuICAgICAgLmNvbnRlbnRNb3VkbGUge1xcbiAgICAgICAgZGlzcGxheTogZmxleDtcXG4gICAgICAgIC8vIHdpZHRoOiA4MDBweDtcXG4gICAgICAgIGhlaWdodDogNTAwcHg7XFxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG4gICAgICAgIC8vIC5jb250ZW50TGVmdCB7XFxuICAgICAgICAvLyAgIGZsb2F0OiBsZWZ0O1xcbiAgICAgICAgLy8gfVxcbiAgICAgICAgLy8gLmNvbnRlbnRSaWdodCB7XFxuICAgICAgICAvLyAgIGZsb2F0OiBsZWZ0O1xcbiAgICAgICAgLy8gICBtYXJnaW4tdG9wOiAxMHB4O1xcbiAgICAgICAgLy8gfVxcbiAgICAgIH1cXG4gICAgICAuYWN0aXZlTW91ZGxlIHtcXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgICAgICAvLyB3aWR0aDogODAwcHg7XFxuICAgICAgICBoZWlnaHQ6IDUwMHB4O1xcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XFxuICAgICAgICAvLyAuYWN0aXZlSW1nIHtcXG4gICAgICAgIC8vICAgZmxvYXQ6IGxlZnQ7XFxuICAgICAgICAvLyAgIG1hcmdpbi10b3A6IDEwMHB4O1xcbiAgICAgICAgLy8gfVxcbiAgICAgICAgLy8gLmFjdGl2ZVJpZ2h0IHtcXG4gICAgICAgIC8vICAgZmxvYXQ6IGxlZnQ7XFxuICAgICAgICAvLyAgIG1hcmdpbi10b3A6IDEwMHB4O1xcbiAgICAgICAgLy8gICBtYXJnaW4tbGVmdDogMjBweDtcXG4gICAgICAgIC8vIH1cXG4gICAgICB9XFxuICAgIH1cXG4gIH1cXG4gIC5mb290ZXIge1xcbiAgICBwb3NpdGlvbjogZml4ZWQ7XFxuICAgIGJvdHRvbTogMHB4O1xcbiAgICBsZWZ0OiAwcHg7XFxuICAgIHdpZHRoOiAxMDAlO1xcbiAgICBoZWlnaHQ6IDEwMHB4O1xcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrcm91bmQtY29sb3I0KTtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xcbiAgICBwYWRkaW5nOiAwIDMwcHg7XFxuICAgIGxpIHtcXG4gICAgICAvLyBmbG9hdDogbGVmdDtcXG4gICAgICAvLyBtYXJnaW46IDQwcHggNTBweCAxMHB4O1xcbiAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMSk7XFxuICAgIH1cXG4gIH1cXG59XFxuLmp1bXBMb2dpbiB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogMHB4O1xcbiAgdG9wOiAwcHg7XFxuICBmb250LXNpemU6IDI0cHg7XFxuICBtYXJnaW4tbGVmdDogMTAwcHg7XFxuICBwYWRkaW5nOiAwIDUwcHggMDtcXG4gIGxpbmUtaGVpZ2h0OiAxMDBweDtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMSk7XFxuICAvLyBib3JkZXItcmFkaXVzOiA1MCU7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yMSk7XFxuICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yMCk7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi8vIC5qdW1wTG9naW46aG92ZXIge1xcbi8vICAgYmFja2dyb3VuZDogdmFyKC0tYmFja2dyb3VuZC1jb2xvcjEpO1xcbi8vICAgY29sb3I6ICNmZmY7XFxuLy8gfVxcbi5lbC1jYXJvdXNlbF9faXRlbSBoMyB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgY29sb3I6ICM0NzU2Njk7XFxuICBvcGFjaXR5OiAwLjc1O1xcbiAgbGluZS1oZWlnaHQ6IDMwMHB4O1xcbiAgbWFyZ2luOiAwO1xcbn1cXG5cXG4uZWwtY2Fyb3VzZWxfX2l0ZW06bnRoLWNoaWxkKDJuKSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTlhOWJmO1xcbn1cXG5cXG4uZWwtY2Fyb3VzZWxfX2l0ZW06bnRoLWNoaWxkKDJuICsgMSkge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2QzZGNlNjtcXG59XFxuOjp2LWRlZXAoLmVsLWNhcm91c2VsX19jb250YWluZXIpIHtcXG4gIGhlaWdodDogNDgwcHg7XFxufVxcbjo6di1kZWVwKC5lbC1jYXJvdXNlbF9fY29udGFpbmVyKSB7XFxuICBoZWlnaHQ6IDQ0MHB4ICFpbXBvcnRhbnQ7XFxufVxcblwiLFwiLmJveCB7XFxuICBoZWlnaHQ6IDE0MDBweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXIge1xcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIHBvc2l0aW9uOiBmaXhlZDtcXG4gIHotaW5kZXg6IDEwO1xcbiAgaGVpZ2h0OiAxMDBweDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5ib3ggLmJyb2NodXJlSGVhZGVyIGp1c3RpZnktY29udGVudDpmbGV4LXN0YXJ0IC5sb2dvIHtcXG4gIGhlaWdodDogMTAwcHg7XFxuICBwYWRkaW5nOiAxMHB4O1xcbn1cXG4uYm94IC5icm9jaHVyZUhlYWRlciAuaGVhZGVyVGl0bGUge1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmJveCAuYnJvY2h1cmVIZWFkZXIgLmhlYWRlclRpdGxlIGxpIHtcXG4gIGZvbnQtc2l6ZTogMjRweDtcXG4gIG1hcmdpbi1yaWdodDogMzBweDtcXG4gIG1hcmdpbi1sZWZ0OiAzMHB4O1xcbiAgbGluZS1oZWlnaHQ6IDEwMHB4O1xcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IyKTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmJveCAuY29udGVudCB7XFxuICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodmFyKC0tYmFja2dyb3VuZC1jb2xvcjIpLCAjZmZmKTtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgdG9wOiAxMDBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LXdyYXA6IHdyYXA7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG4gIHBhZGRpbmctdG9wOiAyMHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5pbWdTd2lwZXIge1xcbiAgd2lkdGg6IDgwMHB4O1xcbn1cXG4uYm94IC5jb250ZW50IC5pbWdTd2lwZXIgaW1nIHtcXG4gIHdpZHRoOiA4MDBweDtcXG59XFxuLmJveCAuY29udGVudCAuaW50cm9kdWNlIHtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgaGVpZ2h0OiAxMzAwcHg7XFxuICBwYWRkaW5nOiA1MHB4IDEwMHB4IDUwcHg7XFxufVxcbi5ib3ggLmNvbnRlbnQgLmludHJvZHVjZSAudGV4dCB7XFxuICBmb250LXNpemU6IDIwcHg7XFxuICBtYXJnaW46IDEwcHg7XFxufVxcbi5ib3ggLmNvbnRlbnQgLmludHJvZHVjZSAuY29udGVudE1vdWRsZSB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgaGVpZ2h0OiA1MDBweDtcXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xcbn1cXG4uYm94IC5jb250ZW50IC5pbnRyb2R1Y2UgLmFjdGl2ZU1vdWRsZSB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgaGVpZ2h0OiA1MDBweDtcXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xcbn1cXG4uYm94IC5mb290ZXIge1xcbiAgcG9zaXRpb246IGZpeGVkO1xcbiAgYm90dG9tOiAwcHg7XFxuICBsZWZ0OiAwcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwcHg7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrcm91bmQtY29sb3I0KTtcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XFxuICBhbGlnbi1pdGVtczogY2VudGVyO1xcbiAgcGFkZGluZzogMCAzMHB4O1xcbn1cXG4uYm94IC5mb290ZXIgbGkge1xcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IxKTtcXG59XFxuLmp1bXBMb2dpbiB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogMHB4O1xcbiAgdG9wOiAwcHg7XFxuICBmb250LXNpemU6IDI0cHg7XFxuICBtYXJnaW4tbGVmdDogMTAwcHg7XFxuICBwYWRkaW5nOiAwIDUwcHggMDtcXG4gIGxpbmUtaGVpZ2h0OiAxMDBweDtcXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMSk7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yMSk7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5lbC1jYXJvdXNlbF9faXRlbSBoMyB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgY29sb3I6ICM0NzU2Njk7XFxuICBvcGFjaXR5OiAwLjc1O1xcbiAgbGluZS1oZWlnaHQ6IDMwMHB4O1xcbiAgbWFyZ2luOiAwO1xcbn1cXG4uZWwtY2Fyb3VzZWxfX2l0ZW06bnRoLWNoaWxkKDJuKSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTlhOWJmO1xcbn1cXG4uZWwtY2Fyb3VzZWxfX2l0ZW06bnRoLWNoaWxkKDJuICsgMSkge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2QzZGNlNjtcXG59XFxuOjp2LWRlZXAoLmVsLWNhcm91c2VsX19jb250YWluZXIpIHtcXG4gIGhlaWdodDogNDgwcHg7XFxufVxcbjo6di1kZWVwKC5lbC1jYXJvdXNlbF9fY29udGFpbmVyKSB7XFxuICBoZWlnaHQ6IDQ0MHB4ICFpbXBvcnRhbnQ7XFxufVxcblwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCI8dGVtcGxhdGU+XHJcbiAgPGRpdiBjbGFzcz1cImJveFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJyb2NodXJlSGVhZGVyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJsb2dvXCI+XHJcbiAgICAgICAgPGltZyBzcmM9XCJAL2Fzc2V0cy9Mb2dvLnBuZ1wiIGFsdD1cIlwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8dWwgY2xhc3M9XCJoZWFkZXJUaXRsZVwiPlxyXG4gICAgICAgIDxsaT7kuJrliqHpoobln588L2xpPlxyXG4gICAgICAgIDxsaT7ku7flgLzmtYE8L2xpPlxyXG4gICAgICAgIDxsaT7ku7vliqHnrqHnkIY8L2xpPlxyXG4gICAgICAgIDxsaT7lrp7kvZPpoobln588L2xpPlxyXG4gICAgICAgIDxsaT7po47pmanotYTkuqc8L2xpPlxyXG4gICAgICA8L3VsPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwianVtcExvZ2luXCIgQGNsaWNrPVwianVtcExvZ2luXCI+5byA5aeL5L2T6aqMPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpbWdTd2lwZXJcIj5cclxuICAgICAgICA8ZWwtY2Fyb3VzZWwgaW5kaWNhdG9yLXBvc2l0aW9uPVwib3V0c2lkZVwiPlxyXG4gICAgICAgICAgPGVsLWNhcm91c2VsLWl0ZW0+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiLi4vLi4vYXNzZXRzL3N3aXBlcjEucG5nXCIgYWx0PVwiXCIgLz5cclxuICAgICAgICAgIDwvZWwtY2Fyb3VzZWwtaXRlbT5cclxuICAgICAgICAgIDxlbC1jYXJvdXNlbC1pdGVtPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz1cIi4uLy4uL2Fzc2V0cy9zd2lwZXIyLnBuZ1wiIGFsdD1cIlwiIC8+XHJcbiAgICAgICAgICA8L2VsLWNhcm91c2VsLWl0ZW0+XHJcbiAgICAgICAgICA8ZWwtY2Fyb3VzZWwtaXRlbT5cclxuICAgICAgICAgICAgPGltZyBzcmM9XCIuLi8uLi9hc3NldHMvc3dpcGVyMy5wbmdcIiBhbHQ9XCJcIiAvPlxyXG4gICAgICAgICAgPC9lbC1jYXJvdXNlbC1pdGVtPlxyXG4gICAgICAgICAgPGVsLWNhcm91c2VsLWl0ZW0+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiLi4vLi4vYXNzZXRzL3N3aXBlcjQucG5nXCIgYWx0PVwiXCIgLz5cclxuICAgICAgICAgIDwvZWwtY2Fyb3VzZWwtaXRlbT5cclxuICAgICAgICAgIDxlbC1jYXJvdXNlbC1pdGVtPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz1cIi4uLy4uL2Fzc2V0cy9zd2lwZXI1LnBuZ1wiIGFsdD1cIlwiIC8+XHJcbiAgICAgICAgICA8L2VsLWNhcm91c2VsLWl0ZW0+XHJcbiAgICAgICAgPC9lbC1jYXJvdXNlbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpbnRyb2R1Y2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudE1vdWRsZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRlbnRMZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMiBzdHlsZT1cImZvbnQtc2l6ZTogNTBweDsgZm9udC13ZWlnaHQ6IDcwMFwiPlxyXG4gICAgICAgICAgICAgIElBTeaetuaehOi1hOS6p+euoeeQhuezu+e7n1xyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHRcIj7luK7liqnkvIHkuJrlr7nlhbZJVOaetuaehOi1hOS6p+i/m+ihjOWFqOmdoueuoeeQhuWSjOaOp+WItuOAgjwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+XHJcbiAgICAgICAgICAgICAg6YCa6L+H5a+56LWE5Lqn55qE5YWo6Z2i5LqG6Kej77yM5Y+v5Lul5pu05aW95Zyw6K+E5LywSVTotYTmnKzku7flgLzlkozmiJDmnKzmlYjnm4rvvIxcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHRcIj7lubbnoa7kv53lhbZJVOeOr+Wig+espuWQiOazleinhOWSjOihjOS4muagh+WHhuOAgjwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+6ZmN5L2O6L+Q6JCl5oiQ5pysLOS5n+WPr+aPkOmrmOWuieWFqOaAp+WSjOWPr+mdoOaApzwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+5biu5Yqp5LyB5Lia5Yi25a6a5ZKM5a6e5pa95YWz6ZSu5Yaz562WLOabtOWlveWcsOeuoeeQhuWFtklU6LWE5LqnLDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+5Li65LyB5Lia55qE5oyB57ut5Y+R5bGV5o+Q5L6b5Z2a5a6e55qE5Z+656GA44CCPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudFJpZ2h0XCI+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiQC9hc3NldHMvaW1nMi5wbmdcIiBhbHQ9XCJcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImFjdGl2ZU1vdWRsZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImFjdGl2ZUltZ1wiPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz1cIkAvYXNzZXRzL2ltZy5naWZcIiBhbHQ9XCJcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWN0aXZlUmlnaHRcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+5ZGY5bel6Ieq5Li75p+l55yL5LiO566h55CG6LWE5Lqn54q25oCBPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHRcIj7lr7nmiYDotJ/otKPotYTkuqfov5vooYznm7TmjqXnrqHnkIY8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dFwiPuWQhOWxgue6p+WRmOW3peaLpeacieS4jeWQjOeahOadg+mZkDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0XCI+5a+56LWE5Lqn55qE5Yib5bu6LOWuoeaJuSzor4TkvLDnmoTkuIDkvZPljJbnrqHnkIY8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dFwiPuWFt+aciea1geeoi+i/vei4quWSjOeUs+WKnuiusOW9leeahOiDveWKmzwvcD5cclxuICAgICAgICAgICAgPGltZyBzcmM9XCJAL2Fzc2V0cy9pbWcucG5nXCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxMHB4XCIgYWx0PVwiXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPHVsIGNsYXNzPVwiZm9vdGVyXCI+XHJcbiAgICAgIDxsaT7kuobop6PmiJHku6w8L2xpPlxyXG4gICAgICA8bGk+5oub5ZWG55S16K+dPC9saT5cclxuICAgICAgPGxpPuW5v+WRiui/nuaOpTwvbGk+XHJcbiAgICAgIDxsaT7llK7lkI7mnI3liqE8L2xpPlxyXG4gICAgICA8bGk+6L+c56iL5pyN5YqhPC9saT5cclxuICAgICAgPGxpPuWcqOe6v+WSqOivojwvbGk+XHJcbiAgICAgIDxsaT7mvI/mtJ7kuIrmiqU8L2xpPlxyXG4gICAgICA8bGk+5YWz5LqO5YW25LuWPC9saT5cclxuICAgIDwvdWw+XHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgbmFtZTogXCJicm9jaHVyZVwiLFxyXG4gIG1ldGhvZHM6IHtcclxuICAgIGp1bXBMb2dpbigpIHtcclxuICAgICAgbGV0IHRva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ0b2tlblwiKTtcclxuICAgICAgaWYgKHRva2VuKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2codG9rZW4sIFwidG9rZW7lgLw/Pz9cIik7XHJcbiAgICAgICAgdGhpcy4kcm91dGVyLnB1c2goeyBwYXRoOiBcIi9kYXNoYm9hcmRcIiB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLiRyb3V0ZXIucHVzaCh7IHBhdGg6IFwiL2xvZ2luXCIgfSk7XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgfSxcclxufTtcclxuPC9zY3JpcHQ+XHJcblxyXG48c3R5bGUgbGFuZz1cImxlc3NcIiBzY29wZWQ+XHJcbi5ib3gge1xyXG4gIGhlaWdodDogMTQwMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAuYnJvY2h1cmVIZWFkZXIge1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHotaW5kZXg6IDEwO1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6ZmxleC1zdGFydCAubG9nbyB7XHJcbiAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgIC8vIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICB9XHJcbiAgICAuaGVhZGVyVGl0bGUge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBsaSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMzBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMzBweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLXRleHQtY29sb3IyKTtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgLmNvbnRlbnQge1xyXG4gICAgLy8gbWFyZ2luLXRvcDogMTAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodmFyKC0tYmFja2dyb3VuZC1jb2xvcjIpLCAjZmZmKTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xyXG4gICAgLmltZ1N3aXBlciB7XHJcbiAgICAgIHdpZHRoOiA4MDBweDtcclxuICAgICAgLy8gcGFkZGluZzogMTBweCAxMHZ3IDUwcHg7XHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgd2lkdGg6IDgwMHB4O1xyXG4gICAgICAgIC8vIHdpZHRoOiA4MHZ3O1xyXG4gICAgICAgIC8vIGhlaWdodDogNzB2aDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmludHJvZHVjZSB7XHJcbiAgICAgIC8vIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIC8vIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGhlaWdodDogMTMwMHB4O1xyXG4gICAgICBwYWRkaW5nOiA1MHB4IDEwMHB4IDUwcHg7XHJcbiAgICAgIC8vIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIC50ZXh0IHtcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5jb250ZW50TW91ZGxlIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIC8vIHdpZHRoOiA4MDBweDtcclxuICAgICAgICBoZWlnaHQ6IDUwMHB4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIC8vIC5jb250ZW50TGVmdCB7XHJcbiAgICAgICAgLy8gICBmbG9hdDogbGVmdDtcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgLy8gLmNvbnRlbnRSaWdodCB7XHJcbiAgICAgICAgLy8gICBmbG9hdDogbGVmdDtcclxuICAgICAgICAvLyAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICB9XHJcbiAgICAgIC5hY3RpdmVNb3VkbGUge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgLy8gd2lkdGg6IDgwMHB4O1xyXG4gICAgICAgIGhlaWdodDogNTAwcHg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgLy8gLmFjdGl2ZUltZyB7XHJcbiAgICAgICAgLy8gICBmbG9hdDogbGVmdDtcclxuICAgICAgICAvLyAgIG1hcmdpbi10b3A6IDEwMHB4O1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyAuYWN0aXZlUmlnaHQge1xyXG4gICAgICAgIC8vICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgLy8gICBtYXJnaW4tdG9wOiAxMDBweDtcclxuICAgICAgICAvLyAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAuZm9vdGVyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0tYmFja3JvdW5kLWNvbG9yNCk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDAgMzBweDtcclxuICAgIGxpIHtcclxuICAgICAgLy8gZmxvYXQ6IGxlZnQ7XHJcbiAgICAgIC8vIG1hcmdpbjogNDBweCA1MHB4IDEwcHg7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMSk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5qdW1wTG9naW4ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMHB4O1xyXG4gIHRvcDogMHB4O1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxuICBtYXJnaW4tbGVmdDogMTAwcHg7XHJcbiAgcGFkZGluZzogMCA1MHB4IDA7XHJcbiAgbGluZS1oZWlnaHQ6IDEwMHB4O1xyXG4gIGNvbG9yOiB2YXIoLS10ZXh0LWNvbG9yMSk7XHJcbiAgLy8gYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcclxuICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1iYWNrZ3JvdW5kLWNvbG9yMCk7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi8vIC5qdW1wTG9naW46aG92ZXIge1xyXG4vLyAgIGJhY2tncm91bmQ6IHZhcigtLWJhY2tncm91bmQtY29sb3IxKTtcclxuLy8gICBjb2xvcjogI2ZmZjtcclxuLy8gfVxyXG4uZWwtY2Fyb3VzZWxfX2l0ZW0gaDMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgY29sb3I6ICM0NzU2Njk7XHJcbiAgb3BhY2l0eTogMC43NTtcclxuICBsaW5lLWhlaWdodDogMzAwcHg7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4uZWwtY2Fyb3VzZWxfX2l0ZW06bnRoLWNoaWxkKDJuKSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzk5YTliZjtcclxufVxyXG5cclxuLmVsLWNhcm91c2VsX19pdGVtOm50aC1jaGlsZCgybiArIDEpIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZDNkY2U2O1xyXG59XHJcbjo6di1kZWVwKC5lbC1jYXJvdXNlbF9fY29udGFpbmVyKSB7XHJcbiAgaGVpZ2h0OiA0ODBweDtcclxufVxyXG46OnYtZGVlcCguZWwtY2Fyb3VzZWxfX2NvbnRhaW5lcikge1xyXG4gIGhlaWdodDogNDQwcHggIWltcG9ydGFudDtcclxufVxyXG48L3N0eWxlPlxyXG4iLCJcbiAgICAgIGltcG9ydCBBUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5zZXJ0QnlTZWxlY3Rvci5qc1wiO1xuICAgICAgaW1wb3J0IHNldEF0dHJpYnV0ZXMgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc3R5bGVUYWdUcmFuc2Zvcm0uanNcIjtcbiAgICAgIGltcG9ydCBjb250ZW50LCAqIGFzIG5hbWVkRXhwb3J0IGZyb20gXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD03Yjk3YzlhYSZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgIFxuICAgICAgXG5cbnZhciBvcHRpb25zID0ge307XG5cbm9wdGlvbnMuc3R5bGVUYWdUcmFuc2Zvcm0gPSBzdHlsZVRhZ1RyYW5zZm9ybUZuO1xub3B0aW9ucy5zZXRBdHRyaWJ1dGVzID0gc2V0QXR0cmlidXRlcztcblxuICAgICAgb3B0aW9ucy5pbnNlcnQgPSBpbnNlcnRGbi5iaW5kKG51bGwsIFwiaGVhZFwiKTtcbiAgICBcbm9wdGlvbnMuZG9tQVBJID0gZG9tQVBJO1xub3B0aW9ucy5pbnNlcnRTdHlsZUVsZW1lbnQgPSBpbnNlcnRTdHlsZUVsZW1lbnQ7XG5cbnZhciB1cGRhdGUgPSBBUEkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5leHBvcnQgKiBmcm9tIFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3N0eWxlUG9zdExvYWRlci5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbGVzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9N2I5N2M5YWEmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTdiOTdjOWFhJnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9N2I5N2M5YWEmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtN2I5N2M5YWFcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL2Jyb2NodXJlL2luZGV4LnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCI3Yjk3YzlhYVwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzdiOTdjOWFhJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnN2I5N2M5YWEnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2luZGV4LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD03Yjk3YzlhYSZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCc3Yjk3YzlhYScsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1s0XSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vaW5kZXgudnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTdiOTdjOWFhJnNjb3BlZD10cnVlXCIiLCJleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9pbmRleC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD03Yjk3YzlhYSZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIiJdLCJuYW1lcyI6WyJuYW1lIiwibWV0aG9kcyIsImp1bXBMb2dpbiIsInRva2VuIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImNvbnNvbGUiLCJsb2ciLCIkcm91dGVyIiwicHVzaCIsInBhdGgiLCJfaW1wb3J0c18wIiwiX2ltcG9ydHNfMSIsIl9pbXBvcnRzXzIiLCJfaW1wb3J0c18zIiwiX2ltcG9ydHNfNCIsIl9pbXBvcnRzXzUiLCJfaW1wb3J0c182IiwiX2ltcG9ydHNfNyIsIl9pbXBvcnRzXzgiLCJfY3JlYXRlRWxlbWVudFZOb2RlIiwic3JjIiwiYWx0IiwiX2NyZWF0ZUVsZW1lbnRCbG9jayIsIl9ob2lzdGVkXzEiLCJfaG9pc3RlZF8yIiwiX2hvaXN0ZWRfMyIsIl9ob2lzdGVkXzQiLCJvbkNsaWNrIiwiX2NhY2hlIiwiJG9wdGlvbnMiLCJhcHBseSIsImFyZ3VtZW50cyIsIl9ob2lzdGVkXzUiLCJfaG9pc3RlZF82IiwiX2NyZWF0ZVZOb2RlIiwiX2NvbXBvbmVudF9lbF9jYXJvdXNlbCIsIl9jb21wb25lbnRfZWxfY2Fyb3VzZWxfaXRlbSIsIl9ob2lzdGVkXzciLCJfaG9pc3RlZF84IiwiX2hvaXN0ZWRfOSIsIl9ob2lzdGVkXzEwIiwiX2hvaXN0ZWRfMTEiLCJfaG9pc3RlZF8xMiIsIl9ob2lzdGVkXzEzIl0sInNvdXJjZVJvb3QiOiIifQ==