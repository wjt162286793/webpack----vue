"use strict";
(self["webpackChunkwebpack_vue"] = self["webpackChunkwebpack_vue"] || []).push([["src_pages_risk_components_riskList_vue"],{

/***/ 86477:
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/risk/components/riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 51864);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ 60352);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".modeBox[data-v-48210dac] {\n  padding: 12px;\n  height: 100%;\n  overflow: auto;\n  display: flex;\n  flex-direction: column;\n}\n.modeBox .searchBox[data-v-48210dac] {\n  margin-bottom: 10px;\n  display: flex;\n}\n.modeBox .searchBox .searchItem[data-v-48210dac] {\n  margin-right: 16px;\n}\n.modeBox .searchBox .searchItem .serachFormItem[data-v-48210dac] {\n  margin-left: 10px;\n  width: 200px;\n}\n.modeBox .tableBox[data-v-48210dac] {\n  border-top: 1px solid #eee;\n  margin: 20px 0;\n}\n.modeBox .paginationBox[data-v-48210dac] {\n  display: flex;\n  justify-content: flex-end;\n}\nh4[data-v-48210dac] {\n  font-size: 18px;\n  font-weight: 600;\n  margin-bottom: 20px;\n}\n.rowBox .el-col[data-v-48210dac] {\n  margin-bottom: 30px;\n}\n.rowBox .el-col h5[data-v-48210dac] {\n  font-size: 16px;\n  font-weight: 400;\n}\n", "",{"version":3,"sources":["webpack://./src/pages/risk/components/riskList.vue","webpack://./riskList.vue"],"names":[],"mappings":"AACA;EACE,aAAA;EACA,YAAA;EACA,cAAA;EACA,aAAA;EACA,sBAAA;ACAF;ADLA;EASI,mBAAA;EACA,aAAA;ACDJ;ADTA;EAaM,kBAAA;ACDN;ADZA;EAgBQ,iBAAA;EACA,YAAA;ACDR;ADhBA;EAuBI,0BAAA;EACA,cAAA;ACJJ;ADpBA;EA4BI,aAAA;EACA,yBAAA;ACLJ;ADSA;EACE,eAAA;EACA,gBAAA;EACA,mBAAA;ACPF;ADUA;EAEI,mBAAA;ACTJ;ADOA;EAKM,eAAA;EACA,gBAAA;ACTN","sourcesContent":["\n.modeBox {\n  padding: 12px;\n  height: 100%;\n  overflow: auto;\n  display: flex;\n  flex-direction: column;\n\n  .searchBox {\n    // background: red;\n    margin-bottom: 10px;\n    display: flex;\n\n    .searchItem {\n      margin-right: 16px;\n\n      .serachFormItem {\n        margin-left: 10px;\n        width: 200px;\n      }\n    }\n  }\n\n  .tableBox {\n    border-top: 1px solid #eee;\n    margin: 20px 0;\n  }\n\n  .paginationBox {\n    display: flex;\n    justify-content: flex-end;\n  }\n}\n\nh4 {\n  font-size: 18px;\n  font-weight: 600;\n  margin-bottom: 20px;\n}\n\n.rowBox {\n  .el-col {\n    margin-bottom: 30px;\n\n    h5 {\n      font-size: 16px;\n      font-weight: 400;\n    }\n  }\n}\n",".modeBox {\n  padding: 12px;\n  height: 100%;\n  overflow: auto;\n  display: flex;\n  flex-direction: column;\n}\n.modeBox .searchBox {\n  margin-bottom: 10px;\n  display: flex;\n}\n.modeBox .searchBox .searchItem {\n  margin-right: 16px;\n}\n.modeBox .searchBox .searchItem .serachFormItem {\n  margin-left: 10px;\n  width: 200px;\n}\n.modeBox .tableBox {\n  border-top: 1px solid #eee;\n  margin: 20px 0;\n}\n.modeBox .paginationBox {\n  display: flex;\n  justify-content: flex-end;\n}\nh4 {\n  font-size: 18px;\n  font-weight: 600;\n  margin-bottom: 20px;\n}\n.rowBox .el-col {\n  margin-bottom: 30px;\n}\n.rowBox .el-col h5 {\n  font-size: 16px;\n  font-weight: 400;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 86100:
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/risk/components/riskList.vue?vue&type=script&setup=true&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _javascript_envname__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/javascript/envname */ 78353);
/* harmony import */ var _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @element-plus/icons-vue */ 70649);
/* harmony import */ var _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils/requestUtils */ 62860);
/* harmony import */ var _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/dictionaries/wordList.json */ 59950);
/* harmony import */ var _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/dictionaries/risk.json */ 39753);
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-router */ 22201);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ 62494);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'riskList',
  setup: function setup(__props, _ref) {
    var expose = _ref.expose;
    expose();
    var router = (0,vue_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    var route = (0,vue_router__WEBPACK_IMPORTED_MODULE_5__.useRoute)();
    var query = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({
      name: "",
      uuid: "",
      riskLevel: ""
    });
    var pageSize = 10;
    var currentPage = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(1);
    var total = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(0);
    var multipleTableRef = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(null);
    var drawer = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(false);
    var direction = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)("rtl");
    var multipleSelection = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)([]);
    var selectionData = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)([]);
    var activeRecord = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)({});
    var selectionDoneFlag = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)(false);
    var toggleSelection = function toggleSelection(rows) {
      if (rows) {
        rows.forEach(function (row) {
          // TODO: improvement typing when refactor table
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-expect-error
          multipleTableRef.value.toggleRowSelection(row, undefined);
        });
      } else {
        multipleTableRef.value.clearSelection();
      }
    };
    var handleSelectionChange = function handleSelectionChange(val) {
      multipleSelection.value = val;
    };
    var tableData = (0,vue__WEBPACK_IMPORTED_MODULE_4__.ref)([]);
    var getType = function getType(value) {
      return _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_2__.typeList[value];
    };
    var getRiskType = function getRiskType(value) {
      return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__.status[value];
    };
    var reqList = function reqList() {
      var postData = {
        queryData: query.value,
        pageSize: pageSize,
        currentPage: currentPage.value
      };
      _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"].post("".concat(_javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname.apiUrl, "/app/risk/list"), postData).then(function (res) {
        if (res.code === 200) {
          tableData.value = res.data.list;
          total.value = res.data.total;
        }
      });
    };
    var openRiskInfo = function openRiskInfo(row) {
      activeRecord.value = row;
      drawer.value = true;
    };
    var selectionHandler = function selectionHandler(selection, row) {
      selectionData.value = selection;
      if (selectionData.value.length < 1) {
        selectionDoneFlag.value = false;
      } else {
        selectionDoneFlag.value = true;
      }
    };
    var downLoad = function downLoad() {
      console.log(selectionData.value, "选中的数据");
      var content = JSON.stringify(selectionData.value);
      var blob_file = new Blob([content], {
        type: "application/json;charset=utf-8"
      });
      var downLoadElement = document.createElement("a");
      var href = URL.createObjectURL(blob_file);
      downLoadElement.href = href;
      downLoadElement.download = "风险资产.json";
      document.body.appendChild(downLoadElement);
      downLoadElement.click();
      document.body.removeChild(downLoadElement);
      window.URL.revokeObjectURL(href);
    };
    var closeDrawer = function closeDrawer() {
      drawer.value = false;
    };
    var getriskPostion = function getriskPostion(info) {
      return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__.riskPositionList.find(function (item) {
        return item.value === info;
      }).label;
    };
    var getInfoType = function getInfoType(info) {
      return _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_2__.typeList[info];
    };
    var getLevel = function getLevel(info) {
      return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__.riskLevelOptions.find(function (item) {
        return item.value === info;
      }).label;
    };
    var getInfoStatus = function getInfoStatus(info) {
      return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__.status[info];
    };
    var getSize = function getSize(info) {
      return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__.controlSizeList.find(function (item) {
        return item.value === info;
      }).label;
    };
    var openFlow = function openFlow(info) {
      router.push({
        path: "/dashboard/risk/riskModel",
        query: {
          id: info.uuid
        }
      });
    };
    (0,vue__WEBPACK_IMPORTED_MODULE_4__.onMounted)(function () {
      reqList();
    });
    var __returned__ = {
      router: router,
      route: route,
      query: query,
      get pageSize() {
        return pageSize;
      },
      set pageSize(v) {
        pageSize = v;
      },
      get currentPage() {
        return currentPage;
      },
      set currentPage(v) {
        currentPage = v;
      },
      get total() {
        return total;
      },
      set total(v) {
        total = v;
      },
      multipleTableRef: multipleTableRef,
      drawer: drawer,
      direction: direction,
      multipleSelection: multipleSelection,
      selectionData: selectionData,
      activeRecord: activeRecord,
      get selectionDoneFlag() {
        return selectionDoneFlag;
      },
      set selectionDoneFlag(v) {
        selectionDoneFlag = v;
      },
      toggleSelection: toggleSelection,
      handleSelectionChange: handleSelectionChange,
      tableData: tableData,
      getType: getType,
      getRiskType: getRiskType,
      reqList: reqList,
      openRiskInfo: openRiskInfo,
      selectionHandler: selectionHandler,
      downLoad: downLoad,
      closeDrawer: closeDrawer,
      getriskPostion: getriskPostion,
      getInfoType: getInfoType,
      getLevel: getLevel,
      getInfoStatus: getInfoStatus,
      getSize: getSize,
      openFlow: openFlow,
      get envname() {
        return _javascript_envname__WEBPACK_IMPORTED_MODULE_0__.envname;
      },
      get View() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__.View;
      },
      get SetUp() {
        return _element_plus_icons_vue__WEBPACK_IMPORTED_MODULE_6__.SetUp;
      },
      get request() {
        return _utils_requestUtils__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      get wordList() {
        return _dictionaries_wordList_json__WEBPACK_IMPORTED_MODULE_2__;
      },
      get riskWordlist() {
        return _dictionaries_risk_json__WEBPACK_IMPORTED_MODULE_3__;
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ }),

/***/ 64887:
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./node_modules/source-map-loader/dist/cjs.js!./src/pages/risk/components/riskList.vue?vue&type=template&id=48210dac&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 62494);

var _withScopeId = function _withScopeId(n) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.pushScopeId)("data-v-48210dac"), n = n(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.popScopeId)(), n;
};
var _hoisted_1 = {
  "class": "modeBox"
};
var _hoisted_2 = {
  "class": "searchBox"
};
var _hoisted_3 = {
  "class": "searchItem"
};
var _hoisted_4 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLabel"
  }, "资产名称", -1 /* HOISTED */);
});
var _hoisted_5 = {
  "class": "searchItem"
};
var _hoisted_6 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLabel"
  }, "资产编号", -1 /* HOISTED */);
});
var _hoisted_7 = {
  "class": "searchItem"
};
var _hoisted_8 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("span", {
    "class": "searchLabel"
  }, "风险等级", -1 /* HOISTED */);
});
var _hoisted_9 = {
  "class": "searchItem"
};
var _hoisted_10 = {
  "class": "tableBox"
};
var _hoisted_11 = {
  "class": "paginationBox"
};
var _hoisted_12 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h3", null, "风险资产详情", -1 /* HOISTED */);
});
var _hoisted_13 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "基础信息", -1 /* HOISTED */);
});
var _hoisted_14 = {
  "class": "rowBox"
};
var _hoisted_15 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "风险别名:", -1 /* HOISTED */);
});
var _hoisted_16 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "风险编号:", -1 /* HOISTED */);
});
var _hoisted_17 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "资产名称:", -1 /* HOISTED */);
});
var _hoisted_18 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "风险定位:", -1 /* HOISTED */);
});
var _hoisted_19 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "资产类型:", -1 /* HOISTED */);
});
var _hoisted_20 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "资产编号:", -1 /* HOISTED */);
});
var _hoisted_21 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "风险等级:", -1 /* HOISTED */);
});
var _hoisted_22 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "资产状态:", -1 /* HOISTED */);
});
var _hoisted_23 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "监控粒度:", -1 /* HOISTED */);
});
var _hoisted_24 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "监控时间:", -1 /* HOISTED */);
});
var _hoisted_25 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "审核人员:", -1 /* HOISTED */);
});
var _hoisted_26 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h5", null, "通知方式:", -1 /* HOISTED */);
});
var _hoisted_27 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "处理进程", -1 /* HOISTED */);
});
var _hoisted_28 = {
  "class": "rowBox"
};
var _hoisted_29 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h4", null, "操作记录", -1 /* HOISTED */);
});
var _hoisted_30 = {
  "class": "rowBox"
};
var _hoisted_31 = /*#__PURE__*/_withScopeId(function () {
  return /*#__PURE__*/(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", null, null, -1 /* HOISTED */);
});
var _hoisted_32 = {
  style: {
    "flex": "auto"
  }
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_el_input = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-input");
  var _component_el_option = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-option");
  var _component_el_select = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-select");
  var _component_el_button = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-button");
  var _component_el_table_column = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table-column");
  var _component_el_table = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-table");
  var _component_el_pagination = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-pagination");
  var _component_el_col = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-col");
  var _component_el_tag = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-tag");
  var _component_el_row = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-row");
  var _component_el_step = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-step");
  var _component_el_steps = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-steps");
  var _component_el_drawer = (0,vue__WEBPACK_IMPORTED_MODULE_0__.resolveComponent)("el-drawer");
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [_hoisted_4, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    onChange: $setup.reqList,
    clearable: "",
    "class": "serachFormItem",
    modelValue: $setup.query.name,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return $setup.query.name = $event;
    }),
    placeholder: "请输入资产名称"
  }, null, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [_hoisted_6, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_input, {
    onChange: $setup.reqList,
    clearable: "",
    "class": "serachFormItem",
    modelValue: $setup.query.uuid,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function ($event) {
      return $setup.query.uuid = $event;
    }),
    placeholder: "请输入资产编号"
  }, null, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_7, [_hoisted_8, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_select, {
    clearable: "",
    modelValue: $setup.query.riskLevel,
    "onUpdate:modelValue": _cache[2] || (_cache[2] = function ($event) {
      return $setup.query.riskLevel = $event;
    }),
    "class": "serachFormItem",
    onChange: $setup.reqList
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.riskWordlist.riskLevelOptions, function (item) {
        return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_option, {
          key: item.value,
          label: item.label,
          value: item.value
        }, null, 8 /* PROPS */, ["label", "value"]);
      }), 128 /* KEYED_FRAGMENT */))];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_9, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.reqList
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("查询")];
    }),
    _: 1 /* STABLE */
  }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
    type: "primary",
    onClick: $setup.downLoad
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("下载")];
    }),
    _: 1 /* STABLE */
  }, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vShow, $setup.selectionDoneFlag]])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_10, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table, {
    onSelect: $setup.selectionHandler,
    ref: "multipleTableRef",
    data: $setup.tableData,
    style: {
      "width": "100%"
    },
    "max-height": "600",
    "cell-style": {
      pading: '15px 0'
    },
    stripe: "",
    border: true,
    onSelectionChange: $setup.handleSelectionChange
  }, {
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        type: "selection",
        width: "55"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "别名",
        width: "240"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row.riskAlias), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "资产类别",
        width: "180"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getType(scope.row.mode)), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "当前状态",
        width: "180"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getRiskType(scope.row.status)), 1 /* TEXT */)];
        }),

        _: 1 /* STABLE */
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "propertyCnName",
        label: "所属资产名称",
        width: "240"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "uuid",
        label: "风险编码",
        width: "400"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        property: "time",
        label: "更改日期",
        width: "240"
      }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
        label: "操作",
        fixed: "right",
        width: "180"
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            link: "",
            onClick: function onClick($event) {
              return $setup.openRiskInfo(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("查看")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
            type: "primary",
            link: "",
            onClick: function onClick($event) {
              return $setup.openFlow(scope.row);
            }
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("流程模型")];
            }),
            _: 2 /* DYNAMIC */
          }, 1032 /* PROPS, DYNAMIC_SLOTS */, ["onClick"])];
        }),
        _: 1 /* STABLE */
      })];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["data"])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_11, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_pagination, {
    small: "",
    background: "",
    layout: "prev, pager, next, jumper, ->, total",
    total: $setup.total,
    "class": "mt-4",
    "page-size": $setup.pageSize,
    "onUpdate:pageSize": _cache[3] || (_cache[3] = function ($event) {
      return $setup.pageSize = $event;
    }),
    "current-page": $setup.currentPage,
    "onUpdate:currentPage": _cache[4] || (_cache[4] = function ($event) {
      return $setup.currentPage = $event;
    }),
    onSizeChange: $setup.reqList,
    onCurrentChange: $setup.reqList,
    onPrevClick: $setup.reqList,
    onNextClick: $setup.reqList
  }, null, 8 /* PROPS */, ["total", "page-size", "current-page"])])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_drawer, {
    modelValue: $setup.drawer,
    "onUpdate:modelValue": _cache[5] || (_cache[5] = function ($event) {
      return $setup.drawer = $event;
    }),
    direction: $setup.direction,
    size: "75%"
  }, {
    header: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [_hoisted_12];
    }),
    "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [_hoisted_13, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_14, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_row, null, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_15];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.riskAlias), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_16];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.uuid), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_17];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.propertyName), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_18];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tag, {
                type: "success",
                effect: "plain"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getriskPostion($setup.activeRecord.riskPosition)), 1 /* TEXT */)];
                }),

                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_19];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getInfoType($setup.activeRecord.mode)), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_20];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.propertyId), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_21];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tag, {
                effect: "plain"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getLevel($setup.activeRecord.riskLevel)), 1 /* TEXT */)];
                }),

                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_22];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tag, {
                type: "warning",
                effect: "plain"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getInfoStatus($setup.activeRecord.status)), 1 /* TEXT */)];
                }),

                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_23];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_tag, {
                effect: "plain"
              }, {
                "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                  return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.getSize($setup.activeRecord.controlSize)), 1 /* TEXT */)];
                }),

                _: 1 /* STABLE */
              })];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_24];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.times[0]) + "   至   " + (0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.times[1]), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_25];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)($setup.activeRecord.auditUser), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 2
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [_hoisted_26];
            }),
            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_col, {
            span: 10
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
              return [((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(true), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,vue__WEBPACK_IMPORTED_MODULE_0__.renderList)($setup.activeRecord.inform, function (m, n) {
                return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)(_component_el_tag, {
                  effect: "plain",
                  key: n,
                  style: {
                    "margin-right": "10px"
                  }
                }, {
                  "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
                    return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(m), 1 /* TEXT */)];
                  }),

                  _: 2 /* DYNAMIC */
                }, 1024 /* DYNAMIC_SLOTS */);
              }), 128 /* KEYED_FRAGMENT */))];
            }),

            _: 1 /* STABLE */
          })];
        }),

        _: 1 /* STABLE */
      })]), _hoisted_27, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_28, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_steps, {
        active: $setup.activeRecord.progress,
        "align-center": ""
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "风险提交"
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "审批通过"
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "缺陷改造"
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "检查核定"
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_step, {
            title: "注销提交"
          })];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["active"])]), _hoisted_29, (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_30, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table, {
        data: $setup.activeRecord.recordList,
        style: {
          "width": "100%"
        },
        border: true,
        stripe: true
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
            prop: "name",
            label: "操作名称",
            width: "280"
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
            label: "操作人员",
            width: "280"
          }, {
            "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function (scope) {
              return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)((0,vue__WEBPACK_IMPORTED_MODULE_0__.toDisplayString)(scope.row.user.userName), 1 /* TEXT */)];
            }),

            _: 1 /* STABLE */
          }), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_table_column, {
            prop: "time",
            label: "操作时间",
            width: "width"
          })];
        }),
        _: 1 /* STABLE */
      }, 8 /* PROPS */, ["data"])]), _hoisted_31];
    }),
    footer: (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
      return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_32, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createVNode)(_component_el_button, {
        onClick: $setup.closeDrawer
      }, {
        "default": (0,vue__WEBPACK_IMPORTED_MODULE_0__.withCtx)(function () {
          return [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)("返回")];
        }),
        _: 1 /* STABLE */
      })])];
    }),

    _: 1 /* STABLE */
  }, 8 /* PROPS */, ["modelValue", "direction"])], 64 /* STABLE_FRAGMENT */);
}

/***/ }),

/***/ 54572:
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/less-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./src/pages/risk/components/riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 75701);
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ 8236);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ 6080);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ 56850);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ 87182);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ 39213);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true */ 86477);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ 52291:
/*!************************************************!*\
  !*** ./src/pages/risk/components/riskList.vue ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _riskList_vue_vue_type_template_id_48210dac_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./riskList.vue?vue&type=template&id=48210dac&scoped=true */ 50902);
/* harmony import */ var _riskList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./riskList.vue?vue&type=script&setup=true&lang=js */ 2812);
/* harmony import */ var _riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true */ 19131);
/* harmony import */ var D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/vue-loader/dist/exportHelper.js */ 51419);




;


const __exports__ = /*#__PURE__*/(0,D_webpack_vue_webpack_vue_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_riskList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_riskList_vue_vue_type_template_id_48210dac_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-48210dac"],['__file',"src/pages/risk/components/riskList.vue"]])
/* hot reload */
if (false) {}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ }),

/***/ 2812:
/*!***********************************************************************************!*\
  !*** ./src/pages/risk/components/riskList.vue?vue&type=script&setup=true&lang=js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_riskList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_riskList_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./riskList.vue?vue&type=script&setup=true&lang=js */ 86100);
 

/***/ }),

/***/ 50902:
/*!******************************************************************************************!*\
  !*** ./src/pages/risk/components/riskList.vue?vue&type=template&id=48210dac&scoped=true ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_riskList_vue_vue_type_template_id_48210dac_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_babel_loader_lib_index_js_clonedRuleSet_10_use_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_4_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_node_modules_source_map_loader_dist_cjs_js_riskList_vue_vue_type_template_id_48210dac_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-10.use!../../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!../../../../node_modules/source-map-loader/dist/cjs.js!./riskList.vue?vue&type=template&id=48210dac&scoped=true */ 64887);


/***/ }),

/***/ 19131:
/*!*********************************************************************************************************!*\
  !*** ./src/pages/risk/components/riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_unpluginName_unplugin_auto_import_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_less_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_17_use_0_riskList_vue_vue_type_style_index_0_id_48210dac_lang_less_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=unplugin-auto-import!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../../node_modules/less-loader/dist/cjs.js!../../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[17].use[0]!./riskList.vue?vue&type=style&index=0&id=48210dac&lang=less&scoped=true */ 54572);


/***/ }),

/***/ 39753:
/*!************************************!*\
  !*** ./src/dictionaries/risk.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"riskPositionList":[{"value":"purchase","label":"购置"},{"value":"product","label":"生产"},{"value":"check","label":"检验"},{"value":"storage","label":"入库"},{"value":"scrap","label":"报废"}],"riskLevelOptions":[{"value":"normal","label":"正常"},{"value":"attention","label":"关注"},{"value":"secondary","label":"次级"},{"value":"suspicious","label":"可疑"},{"value":"loss","label":"损失"}],"controlSizeList":[{"value":"year","label":"年"},{"value":"quarter","label":"季度"},{"value":"month","label":"月"},{"value":"week","label":"周"},{"value":"day","label":"日"}],"status":{"unreviewed":"未审批","reviewed":"已审批","missed":"已过期"}}');

/***/ }),

/***/ 59950:
/*!****************************************!*\
  !*** ./src/dictionaries/wordList.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"entiryList":{"entiryType":{"kind":"实物资产","mechanical":"机械设备","individual":"个体资产","information":"IT资产"},"region":{"important":"重要资产","affiliate":"附属资产","noGlobal":"非公共资产","risk":"风险资产"}},"typeList":{"business":"业务领域","entiry":"实体","task":"任务","valueflow":"价值流"}}');

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3BhZ2VzX3Jpc2tfY29tcG9uZW50c19yaXNrTGlzdF92dWUuMDgzYTQ3ZWRlZTBkZGY5OWFiYTcuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNtSDtBQUNqQjtBQUNsRyw4QkFBOEIsbUZBQTJCLENBQUMsNEZBQXFDO0FBQy9GO0FBQ0EscUVBQXFFLGtCQUFrQixpQkFBaUIsbUJBQW1CLGtCQUFrQiwyQkFBMkIsR0FBRyx3Q0FBd0Msd0JBQXdCLGtCQUFrQixHQUFHLG9EQUFvRCx1QkFBdUIsR0FBRyxvRUFBb0Usc0JBQXNCLGlCQUFpQixHQUFHLHVDQUF1QywrQkFBK0IsbUJBQW1CLEdBQUcsNENBQTRDLGtCQUFrQiw4QkFBOEIsR0FBRyx1QkFBdUIsb0JBQW9CLHFCQUFxQix3QkFBd0IsR0FBRyxvQ0FBb0Msd0JBQXdCLEdBQUcsdUNBQXVDLG9CQUFvQixxQkFBcUIsR0FBRyxTQUFTLG9JQUFvSSxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsS0FBSyxLQUFLLFdBQVcsVUFBVSxLQUFLLEtBQUssV0FBVyxLQUFLLEtBQUssWUFBWSxVQUFVLEtBQUssTUFBTSxZQUFZLFVBQVUsS0FBSyxNQUFNLFdBQVcsV0FBVyxLQUFLLEtBQUssVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFVBQVUsV0FBVyxxQ0FBcUMsa0JBQWtCLGlCQUFpQixtQkFBbUIsa0JBQWtCLDJCQUEyQixrQkFBa0IseUJBQXlCLDBCQUEwQixvQkFBb0IscUJBQXFCLDJCQUEyQiwyQkFBMkIsNEJBQTRCLHVCQUF1QixTQUFTLE9BQU8sS0FBSyxpQkFBaUIsaUNBQWlDLHFCQUFxQixLQUFLLHNCQUFzQixvQkFBb0IsZ0NBQWdDLEtBQUssR0FBRyxRQUFRLG9CQUFvQixxQkFBcUIsd0JBQXdCLEdBQUcsYUFBYSxhQUFhLDBCQUEwQixZQUFZLHdCQUF3Qix5QkFBeUIsT0FBTyxLQUFLLEdBQUcsZUFBZSxrQkFBa0IsaUJBQWlCLG1CQUFtQixrQkFBa0IsMkJBQTJCLEdBQUcsdUJBQXVCLHdCQUF3QixrQkFBa0IsR0FBRyxtQ0FBbUMsdUJBQXVCLEdBQUcsbURBQW1ELHNCQUFzQixpQkFBaUIsR0FBRyxzQkFBc0IsK0JBQStCLG1CQUFtQixHQUFHLDJCQUEyQixrQkFBa0IsOEJBQThCLEdBQUcsTUFBTSxvQkFBb0IscUJBQXFCLHdCQUF3QixHQUFHLG1CQUFtQix3QkFBd0IsR0FBRyxzQkFBc0Isb0JBQW9CLHFCQUFxQixHQUFHLHFCQUFxQjtBQUNqckY7QUFDQSxpRUFBZSx1QkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BRO0FBQ087QUFDWDtBQUNTO0FBQ0E7Ozs7QUFDcEQsaUVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixxREFBUztBQUMxQixnQkFBZ0Isb0RBQVE7QUFDeEIsZ0JBQWdCLHdDQUFHO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0Isd0NBQUc7QUFDekIsZ0JBQWdCLHdDQUFHO0FBQ25CLDJCQUEyQix3Q0FBRztBQUM5QixpQkFBaUIsd0NBQUc7QUFDcEIsb0JBQW9CLHdDQUFHO0FBQ3ZCLDRCQUE0Qix3Q0FBRztBQUMvQix3QkFBd0Isd0NBQUc7QUFDM0IsdUJBQXVCLHdDQUFHO0FBQzFCLDRCQUE0Qix3Q0FBRztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQUc7QUFDdkI7QUFDQSxhQUFhLGlFQUFpQjtBQUM5QjtBQUNBO0FBQ0EsYUFBYSwyREFBc0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLGdFQUFZLFdBQVcsK0RBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLDBFQUFrQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsaUVBQW9CO0FBQ2pDO0FBQ0E7QUFDQSxhQUFhLDBFQUFrQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsMkRBQW1CO0FBQ2hDO0FBQ0E7QUFDQSxhQUFhLHlFQUFpQztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4Q0FBUztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHdEQUFPO0FBQ3RCO0FBQ0E7QUFDQSxlQUFlLHlEQUFJO0FBQ25CO0FBQ0E7QUFDQSxlQUFlLDBEQUFLO0FBQ3BCO0FBQ0E7QUFDQSxlQUFlLDJEQUFPO0FBQ3RCO0FBQ0E7QUFDQSxlQUFlLHdEQUFRO0FBQ3ZCO0FBQ0E7QUFDQSxlQUFlLG9EQUFZO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQ3RNTSxTQUFNO0FBQVM7O0VBQ2IsU0FBTTtBQUFXOztFQUNmLFNBQU07QUFBWTs7c0JBQ3JCQSx1REFBQSxDQUNDO0lBREssU0FBTTtFQUFhLEdBQUMsTUFBSTtBQUFBOztFQVMzQixTQUFNO0FBQVk7O3NCQUNyQkEsdURBQUEsQ0FDQztJQURLLFNBQU07RUFBYSxHQUFDLE1BQUk7QUFBQTs7RUFTM0IsU0FBTTtBQUFZOztzQkFDckJBLHVEQUFBLENBQXFDO0lBQS9CLFNBQU07RUFBYSxHQUFDLE1BQUk7QUFBQTs7RUFlM0IsU0FBTTtBQUFZOztFQU9wQixTQUFNO0FBQVU7O0VBMkNoQixTQUFNO0FBQWU7O3NCQWtCeEJBLHVEQUFBLENBQWUsWUFBWCxRQUFNO0FBQUE7O3NCQUdWQSx1REFBQSxDQUFhLFlBQVQsTUFBSTtBQUFBOztFQUNILFNBQU07QUFBUTs7c0JBR2JBLHVEQUFBLENBQWMsWUFBVixPQUFLO0FBQUE7O3NCQUlUQSx1REFBQSxDQUFjLFlBQVYsT0FBSztBQUFBOztzQkFJVEEsdURBQUEsQ0FBYyxZQUFWLE9BQUs7QUFBQTs7c0JBSVRBLHVEQUFBLENBQWMsWUFBVixPQUFLO0FBQUE7O3NCQVFUQSx1REFBQSxDQUFjLFlBQVYsT0FBSztBQUFBOztzQkFJVEEsdURBQUEsQ0FBYyxZQUFWLE9BQUs7QUFBQTs7c0JBSVRBLHVEQUFBLENBQWMsWUFBVixPQUFLO0FBQUE7O3NCQVFUQSx1REFBQSxDQUFjLFlBQVYsT0FBSztBQUFBOztzQkFRVEEsdURBQUEsQ0FBYyxZQUFWLE9BQUs7QUFBQTs7c0JBUVRBLHVEQUFBLENBQWMsWUFBVixPQUFLO0FBQUE7O3NCQU9UQSx1REFBQSxDQUFjLFlBQVYsT0FBSztBQUFBOztzQkFNVEEsdURBQUEsQ0FBYyxZQUFWLE9BQUs7QUFBQTs7c0JBYWZBLHVEQUFBLENBQWEsWUFBVCxNQUFJO0FBQUE7O0VBQ0gsU0FBTTtBQUFROztzQkFTbkJBLHVEQUFBLENBQWEsWUFBVCxNQUFJO0FBQUE7O0VBQ0gsU0FBTTtBQUFROztzQkFnQm5CQSx1REFBQSxDQUFXO0FBQUE7O0VBR05DLEtBQWtCLEVBQWxCO0lBQUE7RUFBQTtBQUFrQjs7Ozs7Ozs7Ozs7Ozs7O3FLQTdOM0JELHVEQUFBLENBdUdNLE9BdkdORSxVQXVHTSxHQXRHSkYsdURBQUEsQ0EyQ00sT0EzQ05HLFVBMkNNLEdBMUNKSCx1REFBQSxDQVNNLE9BVE5JLFVBU00sR0FSSkMsVUFDQyxFQUFBQyxnREFBQSxDQU1DQyxtQkFBQTtJQUxDQyxRQUFNLEVBQUVDLE1BQUEsQ0FBQUMsT0FBTztJQUNoQkMsU0FBUyxFQUFULEVBQVM7SUFDVCxTQUFNLGdCQUFnQjtnQkFDYkYsTUFBQSxDQUFBRyxLQUFLLENBQUNDLElBQUk7O2FBQVZKLE1BQUEsQ0FBQUcsS0FBSyxDQUFDQyxJQUFJLEdBQUFDLE1BQUE7SUFBQTtJQUNuQkMsV0FBVyxFQUFDOzZDQUdoQmYsdURBQUEsQ0FTTSxPQVROZ0IsVUFTTSxHQVJKQyxVQUNDLEVBQUFYLGdEQUFBLENBTUNDLG1CQUFBO0lBTENDLFFBQU0sRUFBRUMsTUFBQSxDQUFBQyxPQUFPO0lBQ2hCQyxTQUFTLEVBQVQsRUFBUztJQUNULFNBQU0sZ0JBQWdCO2dCQUNiRixNQUFBLENBQUFHLEtBQUssQ0FBQ00sSUFBSTs7YUFBVlQsTUFBQSxDQUFBRyxLQUFLLENBQUNNLElBQUksR0FBQUosTUFBQTtJQUFBO0lBQ25CQyxXQUFXLEVBQUM7NkNBR2hCZix1REFBQSxDQWVNLE9BZk5tQixVQWVNLEdBZEpDLFVBQXFDLEVBQ3JDZCxnREFBQSxDQVlZZSxvQkFBQTtJQVhWVixTQUFTLEVBQVQsRUFBUztnQkFDQUYsTUFBQSxDQUFBRyxLQUFLLENBQUNVLFNBQVM7O2FBQWZiLE1BQUEsQ0FBQUcsS0FBSyxDQUFDVSxTQUFTLEdBQUFSLE1BQUE7SUFBQTtJQUN4QixTQUFNLGdCQUFnQjtJQUNyQk4sUUFBTSxFQUFFQyxNQUFBLENBQUFDOzs0REFHUDtNQUFBLE9BQTZDLHdEQUQvQ2EsdURBQUEsQ0FLRUMseUNBQUEsUUFBQUMsK0NBQUEsQ0FKZWhCLE1BQUEsQ0FBQWlCLFlBQVksQ0FBQ0MsZ0JBQWdCLFlBQXJDQyxJQUFJO2lFQURiQyxnREFBQSxDQUtFQyxvQkFBQTtVQUhDQyxHQUFHLEVBQUVILElBQUksQ0FBQ0ksS0FBSztVQUNmQyxLQUFLLEVBQUVMLElBQUksQ0FBQ0ssS0FBSztVQUNqQkQsS0FBSyxFQUFFSixJQUFJLENBQUNJOzs7Ozs7dUNBSW5CaEMsdURBQUEsQ0FLTSxPQUxOa0MsVUFLTSxHQUpKNUIsZ0RBQUEsQ0FBeUQ2QixvQkFBQTtJQUE5Q0MsSUFBSSxFQUFDLFNBQVM7SUFBRUMsT0FBSyxFQUFFNUIsTUFBQSxDQUFBQzs7NERBQVM7TUFBQSxPQUFFLHNEQUFGLElBQUU7OzswREFDN0NKLGdEQUFBLENBRUM2QixvQkFBQTtJQUZVQyxJQUFJLEVBQUMsU0FBUztJQUFFQyxPQUFLLEVBQUU1QixNQUFBLENBQUE2Qjs7NERBQy9CO01BQUEsT0FBRSxzREFBRixJQUFFOzs7c0VBRCtDN0IsTUFBQSxDQUFBOEIsaUJBQWlCLFNBS3pFdkMsdURBQUEsQ0EwQ00sT0ExQ053QyxXQTBDTSxHQXpDSmxDLGdEQUFBLENBd0NXbUMsbUJBQUE7SUF2Q1JDLFFBQU0sRUFBRWpDLE1BQUEsQ0FBQWtDLGdCQUFnQjtJQUN6QkMsR0FBRyxFQUFDLGtCQUFrQjtJQUNyQkMsSUFBSSxFQUFFcEMsTUFBQSxDQUFBcUMsU0FBUztJQUNoQjdDLEtBQW1CLEVBQW5CO01BQUE7SUFBQSxDQUFtQjtJQUNuQixZQUFVLEVBQUMsS0FBSztJQUNmLFlBQVUsRUFBRTtNQUFBOEMsTUFBQTtJQUFBLENBQW9CO0lBQ2pDQyxNQUFNLEVBQU4sRUFBTTtJQUNMQyxNQUFNLEVBQUUsSUFBSTtJQUNaQyxpQkFBZ0IsRUFBRXpDLE1BQUEsQ0FBQTBDOzs0REFFbkI7TUFBQSxPQUErQyxDQUEvQzdDLGdEQUFBLENBQStDOEMsMEJBQUE7UUFBOUJoQixJQUFJLEVBQUMsV0FBVztRQUFDaUIsS0FBSyxFQUFDO1VBQ3hDL0MsZ0RBQUEsQ0FFa0I4QywwQkFBQTtRQUZEbkIsS0FBSyxFQUFDLElBQUk7UUFBQ29CLEtBQUssRUFBQzs7UUFDckIsV0FBT0MsNENBQUEsQ0FBUyxVQUFQQyxLQUFLO1VBQUEsa0hBQUtBLEtBQUssQ0FBQ0MsR0FBRyxDQUFDQyxTQUFTOzs7O1VBRW5EbkQsZ0RBQUEsQ0FFa0I4QywwQkFBQTtRQUZEbkIsS0FBSyxFQUFDLE1BQU07UUFBQ29CLEtBQUssRUFBQzs7UUFDdkIsV0FBT0MsNENBQUEsQ0FBUyxVQUFQQyxLQUFLO1VBQUEsa0hBQUs5QyxNQUFBLENBQUFpRCxPQUFPLENBQUNILEtBQUssQ0FBQ0MsR0FBRyxDQUFDRyxJQUFJOzs7O1VBRXREckQsZ0RBQUEsQ0FJa0I4QywwQkFBQTtRQUpEbkIsS0FBSyxFQUFDLE1BQU07UUFBQ29CLEtBQUssRUFBQzs7UUFDdkIsV0FBT0MsNENBQUEsQ0FBUyxVQUFQQyxLQUFLO1VBQUEsa0hBQ3ZCOUMsTUFBQSxDQUFBbUQsV0FBVyxDQUFDTCxLQUFLLENBQUNDLEdBQUcsQ0FBQ0ssTUFBTTs7OztVQUdoQ3ZELGdEQUFBLENBSUU4QywwQkFBQTtRQUhBVSxRQUFRLEVBQUMsZ0JBQWdCO1FBQ3pCN0IsS0FBSyxFQUFDLFFBQVE7UUFDZG9CLEtBQUssRUFBQztVQUVSL0MsZ0RBQUEsQ0FBNEQ4QywwQkFBQTtRQUEzQ1UsUUFBUSxFQUFDLE1BQU07UUFBQzdCLEtBQUssRUFBQyxNQUFNO1FBQUNvQixLQUFLLEVBQUM7VUFDcEQvQyxnREFBQSxDQUE0RDhDLDBCQUFBO1FBQTNDVSxRQUFRLEVBQUMsTUFBTTtRQUFDN0IsS0FBSyxFQUFDLE1BQU07UUFBQ29CLEtBQUssRUFBQztVQUNwRC9DLGdEQUFBLENBU2tCOEMsMEJBQUE7UUFURG5CLEtBQUssRUFBQyxJQUFJO1FBQUM4QixLQUFLLEVBQUMsT0FBTztRQUFDVixLQUFLLEVBQUM7O1FBQ25DLFdBQU9DLDRDQUFBLENBQ2hCLFVBRGtCQyxLQUFLO1VBQUEsUUFDdkJqRCxnREFBQSxDQUVDNkIsb0JBQUE7WUFGVUMsSUFBSSxFQUFDLFNBQVM7WUFBQzRCLElBQUksRUFBSixFQUFJO1lBQUUzQixPQUFLLFdBQUFBLFFBQUF2QixNQUFBO2NBQUEsT0FBRUwsTUFBQSxDQUFBd0QsWUFBWSxDQUFDVixLQUFLLENBQUNDLEdBQUc7WUFBQTs7b0VBQzFEO2NBQUEsT0FBRSxzREFBRixJQUFFOzs7NERBRUxsRCxnREFBQSxDQUVDNkIsb0JBQUE7WUFGVUMsSUFBSSxFQUFDLFNBQVM7WUFBQzRCLElBQUksRUFBSixFQUFJO1lBQUUzQixPQUFLLFdBQUFBLFFBQUF2QixNQUFBO2NBQUEsT0FBRUwsTUFBQSxDQUFBeUQsUUFBUSxDQUFDWCxLQUFLLENBQUNDLEdBQUc7WUFBQTs7b0VBQ3REO2NBQUEsT0FBSSxzREFBSixNQUFJOzs7Ozs7Ozs7O2lDQU1meEQsdURBQUEsQ0FjTSxPQWRObUUsV0FjTSxHQWJKN0QsZ0RBQUEsQ0FZRThELHdCQUFBO0lBWEFDLEtBQUssRUFBTCxFQUFLO0lBQ0xDLFVBQVUsRUFBVixFQUFVO0lBQ1ZDLE1BQU0sRUFBQyxzQ0FBc0M7SUFDNUNDLEtBQUssRUFBRS9ELE1BQUEsQ0FBQStELEtBQUs7SUFDYixTQUFNLE1BQU07SUFDSixXQUFTLEVBQUUvRCxNQUFBLENBQUFnRSxRQUFROzthQUFSaEUsTUFBQSxDQUFBZ0UsUUFBUSxHQUFBM0QsTUFBQTtJQUFBO0lBQ25CLGNBQVksRUFBRUwsTUFBQSxDQUFBaUUsV0FBVzs7YUFBWGpFLE1BQUEsQ0FBQWlFLFdBQVcsR0FBQTVELE1BQUE7SUFBQTtJQUNoQzZELFlBQVcsRUFBRWxFLE1BQUEsQ0FBQUMsT0FBTztJQUNwQmtFLGVBQWMsRUFBRW5FLE1BQUEsQ0FBQUMsT0FBTztJQUN2Qm1FLFdBQVUsRUFBRXBFLE1BQUEsQ0FBQUMsT0FBTztJQUNuQm9FLFdBQVUsRUFBRXJFLE1BQUEsQ0FBQUM7dUVBSW5CSixnREFBQSxDQXlIWXlFLG9CQUFBO2dCQXpIUXRFLE1BQUEsQ0FBQXVFLE1BQU07O2FBQU52RSxNQUFBLENBQUF1RSxNQUFNLEdBQUFsRSxNQUFBO0lBQUE7SUFBR21FLFNBQVMsRUFBRXhFLE1BQUEsQ0FBQXdFLFNBQVM7SUFBRUMsSUFBSSxFQUFDOztJQUMzQ0MsTUFBTSxFQUFBN0IsNENBQUEsQ0FDZjtNQUFBLE9BQWUsQ0FBZjhCLFdBQWU7O0lBRU4sV0FBTzlCLDRDQUFBLENBQ2hCO01BQUEsT0FBYSxDQUFiK0IsV0FBYSxFQUNickYsdURBQUEsQ0FnRk0sT0FoRk5zRixXQWdGTSxHQS9FSmhGLGdEQUFBLENBOEVTaUYsaUJBQUE7Z0VBN0VQO1VBQUEsT0FFUyxDQUZUakYsZ0RBQUEsQ0FFU2tGLGlCQUFBO1lBRkFDLElBQUksRUFBRTtVQUFDO29FQUNkO2NBQUEsT0FBYyxDQUFkQyxXQUFjOzs7Y0FFaEJwRixnREFBQSxDQUF3RGtGLGlCQUFBO1lBQS9DQyxJQUFJLEVBQUU7VUFBRTtvRUFBRTtjQUFBLE9BQTRCLDJHQUF6QmhGLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ2xDLFNBQVM7Ozs7Y0FDNUNuRCxnREFBQSxDQUVTa0YsaUJBQUE7WUFGQUMsSUFBSSxFQUFFO1VBQUM7b0VBQ2Q7Y0FBQSxPQUFjLENBQWRHLFdBQWM7OztjQUVoQnRGLGdEQUFBLENBQW1Ea0YsaUJBQUE7WUFBMUNDLElBQUksRUFBRTtVQUFFO29FQUFFO2NBQUEsT0FBdUIsMkdBQXBCaEYsTUFBQSxDQUFBa0YsWUFBWSxDQUFDekUsSUFBSTs7OztjQUN2Q1osZ0RBQUEsQ0FFU2tGLGlCQUFBO1lBRkFDLElBQUksRUFBRTtVQUFDO29FQUNkO2NBQUEsT0FBYyxDQUFkSSxXQUFjOzs7Y0FFaEJ2RixnREFBQSxDQUEyRGtGLGlCQUFBO1lBQWxEQyxJQUFJLEVBQUU7VUFBRTtvRUFBRTtjQUFBLE9BQStCLDJHQUE1QmhGLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ0csWUFBWTs7OztjQUMvQ3hGLGdEQUFBLENBRVNrRixpQkFBQTtZQUZBQyxJQUFJLEVBQUU7VUFBQztvRUFDZDtjQUFBLE9BQWMsQ0FBZE0sV0FBYzs7O2NBRWhCekYsZ0RBQUEsQ0FJU2tGLGlCQUFBO1lBSkFDLElBQUksRUFBRTtVQUFFO29FQUNmO2NBQUEsT0FFVyxDQUZYbkYsZ0RBQUEsQ0FFVzBGLGlCQUFBO2dCQUZINUQsSUFBSSxFQUFDLFNBQVM7Z0JBQUM2RCxNQUFNLEVBQUM7O3dFQUFRO2tCQUFBLE9BRXBDLDJHQURBeEYsTUFBQSxDQUFBeUYsY0FBYyxDQUFDekYsTUFBQSxDQUFBa0YsWUFBWSxDQUFDUSxZQUFZOzs7Ozs7OztjQUc1QzdGLGdEQUFBLENBRVNrRixpQkFBQTtZQUZBQyxJQUFJLEVBQUU7VUFBQztvRUFDZDtjQUFBLE9BQWMsQ0FBZFcsV0FBYzs7O2NBRWhCOUYsZ0RBQUEsQ0FBZ0VrRixpQkFBQTtZQUF2REMsSUFBSSxFQUFFO1VBQUU7b0VBQUU7Y0FBQSxPQUFvQywyR0FBakNoRixNQUFBLENBQUE0RixXQUFXLENBQUM1RixNQUFBLENBQUFrRixZQUFZLENBQUNoQyxJQUFJOzs7O2NBQ25EckQsZ0RBQUEsQ0FFU2tGLGlCQUFBO1lBRkFDLElBQUksRUFBRTtVQUFDO29FQUNkO2NBQUEsT0FBYyxDQUFkYSxXQUFjOzs7Y0FFaEJoRyxnREFBQSxDQUF5RGtGLGlCQUFBO1lBQWhEQyxJQUFJLEVBQUU7VUFBRTtvRUFBRTtjQUFBLE9BQTZCLDJHQUExQmhGLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ1ksVUFBVTs7OztjQUM3Q2pHLGdEQUFBLENBRVNrRixpQkFBQTtZQUZBQyxJQUFJLEVBQUU7VUFBQztvRUFDZDtjQUFBLE9BQWMsQ0FBZGUsV0FBYzs7O2NBRWhCbEcsZ0RBQUEsQ0FJU2tGLGlCQUFBO1lBSkFDLElBQUksRUFBRTtVQUFFO29FQUNmO2NBQUEsT0FFVyxDQUZYbkYsZ0RBQUEsQ0FFVzBGLGlCQUFBO2dCQUZIQyxNQUFNLEVBQUM7Y0FBTzt3RUFBQztrQkFBQSxPQUVyQiwyR0FEQXhGLE1BQUEsQ0FBQWdHLFFBQVEsQ0FBQ2hHLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ3JFLFNBQVM7Ozs7Ozs7O2NBR25DaEIsZ0RBQUEsQ0FFU2tGLGlCQUFBO1lBRkFDLElBQUksRUFBRTtVQUFDO29FQUNkO2NBQUEsT0FBYyxDQUFkaUIsV0FBYzs7O2NBRWhCcEcsZ0RBQUEsQ0FJU2tGLGlCQUFBO1lBSkFDLElBQUksRUFBRTtVQUFFO29FQUNmO2NBQUEsT0FFVyxDQUZYbkYsZ0RBQUEsQ0FFVzBGLGlCQUFBO2dCQUZINUQsSUFBSSxFQUFDLFNBQVM7Z0JBQUM2RCxNQUFNLEVBQUM7O3dFQUFRO2tCQUFBLE9BRXBDLDJHQURBeEYsTUFBQSxDQUFBa0csYUFBYSxDQUFDbEcsTUFBQSxDQUFBa0YsWUFBWSxDQUFDOUIsTUFBTTs7Ozs7Ozs7Y0FHckN2RCxnREFBQSxDQUVTa0YsaUJBQUE7WUFGQUMsSUFBSSxFQUFFO1VBQUM7b0VBQ2Q7Y0FBQSxPQUFjLENBQWRtQixXQUFjOzs7Y0FFaEJ0RyxnREFBQSxDQUlTa0YsaUJBQUE7WUFKQUMsSUFBSSxFQUFFO1VBQUU7b0VBQ2Y7Y0FBQSxPQUVXLENBRlhuRixnREFBQSxDQUVXMEYsaUJBQUE7Z0JBRkhDLE1BQU0sRUFBQztjQUFPO3dFQUFDO2tCQUFBLE9BRXJCLDJHQURBeEYsTUFBQSxDQUFBb0csT0FBTyxDQUFDcEcsTUFBQSxDQUFBa0YsWUFBWSxDQUFDbUIsV0FBVzs7Ozs7Ozs7Y0FHcEN4RyxnREFBQSxDQUVTa0YsaUJBQUE7WUFGQUMsSUFBSSxFQUFFO1VBQUM7b0VBQ2Q7Y0FBQSxPQUFjLENBQWRzQixXQUFjOzs7Y0FFaEJ6RyxnREFBQSxDQUdDa0YsaUJBQUE7WUFIUUMsSUFBSSxFQUFFO1VBQUU7b0VBQ2Q7Y0FBQSxPQUEyQiwyR0FBeEJoRixNQUFBLENBQUFrRixZQUFZLENBQUNxQixLQUFLLE9BQU0sU0FDNUIsR0FBQUMsb0RBQUEsQ0FBR3hHLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ3FCLEtBQUs7Ozs7Y0FFdkIxRyxnREFBQSxDQUVTa0YsaUJBQUE7WUFGQUMsSUFBSSxFQUFFO1VBQUM7b0VBQ2Q7Y0FBQSxPQUFjLENBQWR5QixXQUFjOzs7Y0FFaEI1RyxnREFBQSxDQUVTa0YsaUJBQUE7WUFGQUMsSUFBSSxFQUFFO1VBQUU7b0VBQ2Y7Y0FBQSxPQUE0QiwyR0FBekJoRixNQUFBLENBQUFrRixZQUFZLENBQUN3QixTQUFTOzs7O2NBRTNCN0csZ0RBQUEsQ0FFU2tGLGlCQUFBO1lBRkFDLElBQUksRUFBRTtVQUFDO29FQUNkO2NBQUEsT0FBYyxDQUFkMkIsV0FBYzs7O2NBRWhCOUcsZ0RBQUEsQ0FRU2tGLGlCQUFBO1lBUkFDLElBQUksRUFBRTtVQUFFO29FQUdiO2NBQUEsT0FBcUMsd0RBRnZDbEUsdURBQUEsQ0FNQ0MseUNBQUEsUUFBQUMsK0NBQUEsQ0FKa0JoQixNQUFBLENBQUFrRixZQUFZLENBQUMwQixNQUFNLFlBQTVCQyxDQUFDLEVBQUVDLENBQUM7eUVBRmQxRixnREFBQSxDQU1DbUUsaUJBQUE7a0JBTENDLE1BQU0sRUFBQyxPQUFPO2tCQUVibEUsR0FBRyxFQUFFd0YsQ0FBQztrQkFDUHRILEtBQTBCLEVBQTFCO29CQUFBO2tCQUFBOzswRUFDQztvQkFBQSxPQUFPLDJHQUFKcUgsQ0FBQzs7Ozs7Ozs7Ozs7OztZQUtiRSxXQUFhLEVBQ2J4SCx1REFBQSxDQVFNLE9BUk55SCxXQVFNLEdBUEpuSCxnREFBQSxDQU1Xb0gsbUJBQUE7UUFOQUMsTUFBTSxFQUFFbEgsTUFBQSxDQUFBa0YsWUFBWSxDQUFDaUMsUUFBUTtRQUFFLGNBQVksRUFBWjs7Z0VBQ3hDO1VBQUEsT0FBd0IsQ0FBeEJ0SCxnREFBQSxDQUF3QnVILGtCQUFBO1lBQWZDLEtBQUssRUFBQztVQUFNLElBQ3JCeEgsZ0RBQUEsQ0FBd0J1SCxrQkFBQTtZQUFmQyxLQUFLLEVBQUM7VUFBTSxJQUNyQnhILGdEQUFBLENBQXdCdUgsa0JBQUE7WUFBZkMsS0FBSyxFQUFDO1VBQU0sSUFDckJ4SCxnREFBQSxDQUF3QnVILGtCQUFBO1lBQWZDLEtBQUssRUFBQztVQUFNLElBQ3JCeEgsZ0RBQUEsQ0FBd0J1SCxrQkFBQTtZQUFmQyxLQUFLLEVBQUM7VUFBTTs7O3VDQUd6QkMsV0FBYSxFQUNiL0gsdURBQUEsQ0FlTSxPQWZOZ0ksV0FlTSxHQWRKMUgsZ0RBQUEsQ0FhV21DLG1CQUFBO1FBWlJJLElBQUksRUFBRXBDLE1BQUEsQ0FBQWtGLFlBQVksQ0FBQ3NDLFVBQVU7UUFDOUJoSSxLQUFtQixFQUFuQjtVQUFBO1FBQUEsQ0FBbUI7UUFDbEJnRCxNQUFNLEVBQUUsSUFBSTtRQUNaRCxNQUFNLEVBQUU7O2dFQUVUO1VBQUEsT0FBd0QsQ0FBeEQxQyxnREFBQSxDQUF3RDhDLDBCQUFBO1lBQXZDOEUsSUFBSSxFQUFDLE1BQU07WUFBQ2pHLEtBQUssRUFBQyxNQUFNO1lBQUNvQixLQUFLLEVBQUM7Y0FDaEQvQyxnREFBQSxDQUlrQjhDLDBCQUFBO1lBSkRuQixLQUFLLEVBQUMsTUFBTTtZQUFDb0IsS0FBSyxFQUFDOztZQUN2QixXQUFPQyw0Q0FBQSxDQUNoQixVQURrQkMsS0FBSztjQUFBLGtIQUNwQkEsS0FBSyxDQUFDQyxHQUFHLENBQUMyRSxJQUFJLENBQUNDLFFBQVE7Ozs7Y0FHOUI5SCxnREFBQSxDQUEwRDhDLDBCQUFBO1lBQXpDOEUsSUFBSSxFQUFDLE1BQU07WUFBQ2pHLEtBQUssRUFBQyxNQUFNO1lBQUNvQixLQUFLLEVBQUM7Ozs7cUNBR3BEZ0YsV0FBVzs7SUFFRkMsTUFBTSxFQUFBaEYsNENBQUEsQ0FDZjtNQUFBLE9BRU0sQ0FGTnRELHVEQUFBLENBRU0sT0FGTnVJLFdBRU0sR0FESmpJLGdEQUFBLENBQThDNkIsb0JBQUE7UUFBbENFLE9BQUssRUFBRTVCLE1BQUEsQ0FBQStIO01BQVc7Z0VBQUU7VUFBQSxPQUFFLHNEQUFGLElBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlOMUMsTUFBd0c7QUFDeEcsTUFBOEY7QUFDOUYsTUFBcUc7QUFDckcsTUFBd0g7QUFDeEgsTUFBaUg7QUFDakgsTUFBaUg7QUFDakgsTUFBb1c7QUFDcFc7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIscUdBQW1CO0FBQy9DLHdCQUF3QixrSEFBYTs7QUFFckMsdUJBQXVCLHVHQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLCtGQUFNO0FBQ3ZCLDZCQUE2QixzR0FBa0I7O0FBRS9DLGFBQWEsMEdBQUcsQ0FBQyxzU0FBTzs7OztBQUk4UztBQUN0VSxPQUFPLGlFQUFlLHNTQUFPLElBQUksNlNBQWMsR0FBRyw2U0FBYyxZQUFZLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQkk7QUFDWDtBQUNMOztBQUVqRSxDQUFnRjs7QUFFa0M7QUFDbEgsaUNBQWlDLGtIQUFlLENBQUMsd0ZBQU0sYUFBYSwyRkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFLEVBWWY7OztBQUdELGlFQUFlOzs7Ozs7Ozs7Ozs7Ozs7QUN4Qm9YIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcmlzay9jb21wb25lbnRzL3Jpc2tMaXN0LnZ1ZT9kZjM4Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Jpc2svY29tcG9uZW50cy9yaXNrTGlzdC52dWU/ZWFhNSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9yaXNrL2NvbXBvbmVudHMvcmlza0xpc3QudnVlIiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Jpc2svY29tcG9uZW50cy9yaXNrTGlzdC52dWU/ZTkxOSIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9yaXNrL2NvbXBvbmVudHMvcmlza0xpc3QudnVlP2Y2ZTMiLCJ3ZWJwYWNrOi8vd2VicGFjay12dWUvLi9zcmMvcGFnZXMvcmlzay9jb21wb25lbnRzL3Jpc2tMaXN0LnZ1ZT9kNjY5Iiwid2VicGFjazovL3dlYnBhY2stdnVlLy4vc3JjL3BhZ2VzL3Jpc2svY29tcG9uZW50cy9yaXNrTGlzdC52dWU/NWU4MCIsIndlYnBhY2s6Ly93ZWJwYWNrLXZ1ZS8uL3NyYy9wYWdlcy9yaXNrL2NvbXBvbmVudHMvcmlza0xpc3QudnVlP2ZjYjciXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9zb3VyY2VNYXBzLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fIGZyb20gXCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9FWFBPUlRfX18gPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgXCIubW9kZUJveFtkYXRhLXYtNDgyMTBkYWNdIHtcXG4gIHBhZGRpbmc6IDEycHg7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBvdmVyZmxvdzogYXV0bztcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbn1cXG4ubW9kZUJveCAuc2VhcmNoQm94W2RhdGEtdi00ODIxMGRhY10ge1xcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcXG4gIGRpc3BsYXk6IGZsZXg7XFxufVxcbi5tb2RlQm94IC5zZWFyY2hCb3ggLnNlYXJjaEl0ZW1bZGF0YS12LTQ4MjEwZGFjXSB7XFxuICBtYXJnaW4tcmlnaHQ6IDE2cHg7XFxufVxcbi5tb2RlQm94IC5zZWFyY2hCb3ggLnNlYXJjaEl0ZW0gLnNlcmFjaEZvcm1JdGVtW2RhdGEtdi00ODIxMGRhY10ge1xcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XFxuICB3aWR0aDogMjAwcHg7XFxufVxcbi5tb2RlQm94IC50YWJsZUJveFtkYXRhLXYtNDgyMTBkYWNdIHtcXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZWVlO1xcbiAgbWFyZ2luOiAyMHB4IDA7XFxufVxcbi5tb2RlQm94IC5wYWdpbmF0aW9uQm94W2RhdGEtdi00ODIxMGRhY10ge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XFxufVxcbmg0W2RhdGEtdi00ODIxMGRhY10ge1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbiAgZm9udC13ZWlnaHQ6IDYwMDtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5yb3dCb3ggLmVsLWNvbFtkYXRhLXYtNDgyMTBkYWNdIHtcXG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XFxufVxcbi5yb3dCb3ggLmVsLWNvbCBoNVtkYXRhLXYtNDgyMTBkYWNdIHtcXG4gIGZvbnQtc2l6ZTogMTZweDtcXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL3NyYy9wYWdlcy9yaXNrL2NvbXBvbmVudHMvcmlza0xpc3QudnVlXCIsXCJ3ZWJwYWNrOi8vLi9yaXNrTGlzdC52dWVcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQ0E7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7QUNBRjtBRExBO0VBU0ksbUJBQUE7RUFDQSxhQUFBO0FDREo7QURUQTtFQWFNLGtCQUFBO0FDRE47QURaQTtFQWdCUSxpQkFBQTtFQUNBLFlBQUE7QUNEUjtBRGhCQTtFQXVCSSwwQkFBQTtFQUNBLGNBQUE7QUNKSjtBRHBCQTtFQTRCSSxhQUFBO0VBQ0EseUJBQUE7QUNMSjtBRFNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNQRjtBRFVBO0VBRUksbUJBQUE7QUNUSjtBRE9BO0VBS00sZUFBQTtFQUNBLGdCQUFBO0FDVE5cIixcInNvdXJjZXNDb250ZW50XCI6W1wiXFxuLm1vZGVCb3gge1xcbiAgcGFkZGluZzogMTJweDtcXG4gIGhlaWdodDogMTAwJTtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XFxuXFxuICAuc2VhcmNoQm94IHtcXG4gICAgLy8gYmFja2dyb3VuZDogcmVkO1xcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xcbiAgICBkaXNwbGF5OiBmbGV4O1xcblxcbiAgICAuc2VhcmNoSXRlbSB7XFxuICAgICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xcblxcbiAgICAgIC5zZXJhY2hGb3JtSXRlbSB7XFxuICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcXG4gICAgICAgIHdpZHRoOiAyMDBweDtcXG4gICAgICB9XFxuICAgIH1cXG4gIH1cXG5cXG4gIC50YWJsZUJveCB7XFxuICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZWVlO1xcbiAgICBtYXJnaW46IDIwcHggMDtcXG4gIH1cXG5cXG4gIC5wYWdpbmF0aW9uQm94IHtcXG4gICAgZGlzcGxheTogZmxleDtcXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcXG4gIH1cXG59XFxuXFxuaDQge1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbiAgZm9udC13ZWlnaHQ6IDYwMDtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcblxcbi5yb3dCb3gge1xcbiAgLmVsLWNvbCB7XFxuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XFxuXFxuICAgIGg1IHtcXG4gICAgICBmb250LXNpemU6IDE2cHg7XFxuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcXG4gICAgfVxcbiAgfVxcbn1cXG5cIixcIi5tb2RlQm94IHtcXG4gIHBhZGRpbmc6IDEycHg7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBvdmVyZmxvdzogYXV0bztcXG4gIGRpc3BsYXk6IGZsZXg7XFxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xcbn1cXG4ubW9kZUJveCAuc2VhcmNoQm94IHtcXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XFxuICBkaXNwbGF5OiBmbGV4O1xcbn1cXG4ubW9kZUJveCAuc2VhcmNoQm94IC5zZWFyY2hJdGVtIHtcXG4gIG1hcmdpbi1yaWdodDogMTZweDtcXG59XFxuLm1vZGVCb3ggLnNlYXJjaEJveCAuc2VhcmNoSXRlbSAuc2VyYWNoRm9ybUl0ZW0ge1xcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XFxuICB3aWR0aDogMjAwcHg7XFxufVxcbi5tb2RlQm94IC50YWJsZUJveCB7XFxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2VlZTtcXG4gIG1hcmdpbjogMjBweCAwO1xcbn1cXG4ubW9kZUJveCAucGFnaW5hdGlvbkJveCB7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcXG59XFxuaDQge1xcbiAgZm9udC1zaXplOiAxOHB4O1xcbiAgZm9udC13ZWlnaHQ6IDYwMDtcXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XFxufVxcbi5yb3dCb3ggLmVsLWNvbCB7XFxuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xcbn1cXG4ucm93Qm94IC5lbC1jb2wgaDUge1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbiAgZm9udC13ZWlnaHQ6IDQwMDtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsImltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcbmltcG9ydCB7IFZpZXcsIFNldFVwIH0gZnJvbSBcIkBlbGVtZW50LXBsdXMvaWNvbnMtdnVlXCI7XG5pbXBvcnQgcmVxdWVzdCBmcm9tIFwiQC91dGlscy9yZXF1ZXN0VXRpbHNcIjtcbmltcG9ydCB3b3JkTGlzdCBmcm9tIFwiQC9kaWN0aW9uYXJpZXMvd29yZExpc3QuanNvblwiO1xuaW1wb3J0IHJpc2tXb3JkbGlzdCBmcm9tIFwiQC9kaWN0aW9uYXJpZXMvcmlzay5qc29uXCI7XG5leHBvcnQgZGVmYXVsdCB7XG4gIF9fbmFtZTogJ3Jpc2tMaXN0JyxcbiAgc2V0dXA6IGZ1bmN0aW9uIHNldHVwKF9fcHJvcHMsIF9yZWYpIHtcbiAgICB2YXIgZXhwb3NlID0gX3JlZi5leHBvc2U7XG4gICAgZXhwb3NlKCk7XG4gICAgdmFyIHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICAgIHZhciByb3V0ZSA9IHVzZVJvdXRlKCk7XG4gICAgdmFyIHF1ZXJ5ID0gcmVmKHtcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICB1dWlkOiBcIlwiLFxuICAgICAgcmlza0xldmVsOiBcIlwiXG4gICAgfSk7XG4gICAgdmFyIHBhZ2VTaXplID0gMTA7XG4gICAgdmFyIGN1cnJlbnRQYWdlID0gcmVmKDEpO1xuICAgIHZhciB0b3RhbCA9IHJlZigwKTtcbiAgICB2YXIgbXVsdGlwbGVUYWJsZVJlZiA9IHJlZihudWxsKTtcbiAgICB2YXIgZHJhd2VyID0gcmVmKGZhbHNlKTtcbiAgICB2YXIgZGlyZWN0aW9uID0gcmVmKFwicnRsXCIpO1xuICAgIHZhciBtdWx0aXBsZVNlbGVjdGlvbiA9IHJlZihbXSk7XG4gICAgdmFyIHNlbGVjdGlvbkRhdGEgPSByZWYoW10pO1xuICAgIHZhciBhY3RpdmVSZWNvcmQgPSByZWYoe30pO1xuICAgIHZhciBzZWxlY3Rpb25Eb25lRmxhZyA9IHJlZihmYWxzZSk7XG4gICAgdmFyIHRvZ2dsZVNlbGVjdGlvbiA9IGZ1bmN0aW9uIHRvZ2dsZVNlbGVjdGlvbihyb3dzKSB7XG4gICAgICBpZiAocm93cykge1xuICAgICAgICByb3dzLmZvckVhY2goZnVuY3Rpb24gKHJvdykge1xuICAgICAgICAgIC8vIFRPRE86IGltcHJvdmVtZW50IHR5cGluZyB3aGVuIHJlZmFjdG9yIHRhYmxlXG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICBtdWx0aXBsZVRhYmxlUmVmLnZhbHVlLnRvZ2dsZVJvd1NlbGVjdGlvbihyb3csIHVuZGVmaW5lZCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbXVsdGlwbGVUYWJsZVJlZi52YWx1ZS5jbGVhclNlbGVjdGlvbigpO1xuICAgICAgfVxuICAgIH07XG4gICAgdmFyIGhhbmRsZVNlbGVjdGlvbkNoYW5nZSA9IGZ1bmN0aW9uIGhhbmRsZVNlbGVjdGlvbkNoYW5nZSh2YWwpIHtcbiAgICAgIG11bHRpcGxlU2VsZWN0aW9uLnZhbHVlID0gdmFsO1xuICAgIH07XG4gICAgdmFyIHRhYmxlRGF0YSA9IHJlZihbXSk7XG4gICAgdmFyIGdldFR5cGUgPSBmdW5jdGlvbiBnZXRUeXBlKHZhbHVlKSB7XG4gICAgICByZXR1cm4gd29yZExpc3QudHlwZUxpc3RbdmFsdWVdO1xuICAgIH07XG4gICAgdmFyIGdldFJpc2tUeXBlID0gZnVuY3Rpb24gZ2V0Umlza1R5cGUodmFsdWUpIHtcbiAgICAgIHJldHVybiByaXNrV29yZGxpc3RbXCJzdGF0dXNcIl1bdmFsdWVdO1xuICAgIH07XG4gICAgdmFyIHJlcUxpc3QgPSBmdW5jdGlvbiByZXFMaXN0KCkge1xuICAgICAgdmFyIHBvc3REYXRhID0ge1xuICAgICAgICBxdWVyeURhdGE6IHF1ZXJ5LnZhbHVlLFxuICAgICAgICBwYWdlU2l6ZTogcGFnZVNpemUsXG4gICAgICAgIGN1cnJlbnRQYWdlOiBjdXJyZW50UGFnZS52YWx1ZVxuICAgICAgfTtcbiAgICAgIHJlcXVlc3QucG9zdChcIlwiLmNvbmNhdChlbnZuYW1lLmFwaVVybCwgXCIvYXBwL3Jpc2svbGlzdFwiKSwgcG9zdERhdGEpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICBpZiAocmVzLmNvZGUgPT09IDIwMCkge1xuICAgICAgICAgIHRhYmxlRGF0YS52YWx1ZSA9IHJlcy5kYXRhLmxpc3Q7XG4gICAgICAgICAgdG90YWwudmFsdWUgPSByZXMuZGF0YS50b3RhbDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgICB2YXIgb3BlblJpc2tJbmZvID0gZnVuY3Rpb24gb3BlblJpc2tJbmZvKHJvdykge1xuICAgICAgYWN0aXZlUmVjb3JkLnZhbHVlID0gcm93O1xuICAgICAgZHJhd2VyLnZhbHVlID0gdHJ1ZTtcbiAgICB9O1xuICAgIHZhciBzZWxlY3Rpb25IYW5kbGVyID0gZnVuY3Rpb24gc2VsZWN0aW9uSGFuZGxlcihzZWxlY3Rpb24sIHJvdykge1xuICAgICAgc2VsZWN0aW9uRGF0YS52YWx1ZSA9IHNlbGVjdGlvbjtcbiAgICAgIGlmIChzZWxlY3Rpb25EYXRhLnZhbHVlLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgc2VsZWN0aW9uRG9uZUZsYWcudmFsdWUgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlbGVjdGlvbkRvbmVGbGFnLnZhbHVlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHZhciBkb3duTG9hZCA9IGZ1bmN0aW9uIGRvd25Mb2FkKCkge1xuICAgICAgY29uc29sZS5sb2coc2VsZWN0aW9uRGF0YS52YWx1ZSwgXCLpgInkuK3nmoTmlbDmja5cIik7XG4gICAgICB2YXIgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHNlbGVjdGlvbkRhdGEudmFsdWUpO1xuICAgICAgdmFyIGJsb2JfZmlsZSA9IG5ldyBCbG9iKFtjb250ZW50XSwge1xuICAgICAgICB0eXBlOiBcImFwcGxpY2F0aW9uL2pzb247Y2hhcnNldD11dGYtOFwiXG4gICAgICB9KTtcbiAgICAgIHZhciBkb3duTG9hZEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcbiAgICAgIHZhciBocmVmID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iX2ZpbGUpO1xuICAgICAgZG93bkxvYWRFbGVtZW50LmhyZWYgPSBocmVmO1xuICAgICAgZG93bkxvYWRFbGVtZW50LmRvd25sb2FkID0gXCLpo47pmanotYTkuqcuanNvblwiO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkb3duTG9hZEVsZW1lbnQpO1xuICAgICAgZG93bkxvYWRFbGVtZW50LmNsaWNrKCk7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGRvd25Mb2FkRWxlbWVudCk7XG4gICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTChocmVmKTtcbiAgICB9O1xuICAgIHZhciBjbG9zZURyYXdlciA9IGZ1bmN0aW9uIGNsb3NlRHJhd2VyKCkge1xuICAgICAgZHJhd2VyLnZhbHVlID0gZmFsc2U7XG4gICAgfTtcbiAgICB2YXIgZ2V0cmlza1Bvc3Rpb24gPSBmdW5jdGlvbiBnZXRyaXNrUG9zdGlvbihpbmZvKSB7XG4gICAgICByZXR1cm4gcmlza1dvcmRsaXN0LnJpc2tQb3NpdGlvbkxpc3QuZmluZChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICByZXR1cm4gaXRlbS52YWx1ZSA9PT0gaW5mbztcbiAgICAgIH0pLmxhYmVsO1xuICAgIH07XG4gICAgdmFyIGdldEluZm9UeXBlID0gZnVuY3Rpb24gZ2V0SW5mb1R5cGUoaW5mbykge1xuICAgICAgcmV0dXJuIHdvcmRMaXN0W1widHlwZUxpc3RcIl1baW5mb107XG4gICAgfTtcbiAgICB2YXIgZ2V0TGV2ZWwgPSBmdW5jdGlvbiBnZXRMZXZlbChpbmZvKSB7XG4gICAgICByZXR1cm4gcmlza1dvcmRsaXN0LnJpc2tMZXZlbE9wdGlvbnMuZmluZChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICByZXR1cm4gaXRlbS52YWx1ZSA9PT0gaW5mbztcbiAgICAgIH0pLmxhYmVsO1xuICAgIH07XG4gICAgdmFyIGdldEluZm9TdGF0dXMgPSBmdW5jdGlvbiBnZXRJbmZvU3RhdHVzKGluZm8pIHtcbiAgICAgIHJldHVybiByaXNrV29yZGxpc3Quc3RhdHVzW2luZm9dO1xuICAgIH07XG4gICAgdmFyIGdldFNpemUgPSBmdW5jdGlvbiBnZXRTaXplKGluZm8pIHtcbiAgICAgIHJldHVybiByaXNrV29yZGxpc3QuY29udHJvbFNpemVMaXN0LmZpbmQoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGl0ZW0udmFsdWUgPT09IGluZm87XG4gICAgICB9KS5sYWJlbDtcbiAgICB9O1xuICAgIHZhciBvcGVuRmxvdyA9IGZ1bmN0aW9uIG9wZW5GbG93KGluZm8pIHtcbiAgICAgIHJvdXRlci5wdXNoKHtcbiAgICAgICAgcGF0aDogXCIvZGFzaGJvYXJkL3Jpc2svcmlza01vZGVsXCIsXG4gICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgaWQ6IGluZm8udXVpZFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICAgIG9uTW91bnRlZChmdW5jdGlvbiAoKSB7XG4gICAgICByZXFMaXN0KCk7XG4gICAgfSk7XG4gICAgdmFyIF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIHJvdXRlcjogcm91dGVyLFxuICAgICAgcm91dGU6IHJvdXRlLFxuICAgICAgcXVlcnk6IHF1ZXJ5LFxuICAgICAgZ2V0IHBhZ2VTaXplKCkge1xuICAgICAgICByZXR1cm4gcGFnZVNpemU7XG4gICAgICB9LFxuICAgICAgc2V0IHBhZ2VTaXplKHYpIHtcbiAgICAgICAgcGFnZVNpemUgPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBjdXJyZW50UGFnZSgpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnRQYWdlO1xuICAgICAgfSxcbiAgICAgIHNldCBjdXJyZW50UGFnZSh2KSB7XG4gICAgICAgIGN1cnJlbnRQYWdlID0gdjtcbiAgICAgIH0sXG4gICAgICBnZXQgdG90YWwoKSB7XG4gICAgICAgIHJldHVybiB0b3RhbDtcbiAgICAgIH0sXG4gICAgICBzZXQgdG90YWwodikge1xuICAgICAgICB0b3RhbCA9IHY7XG4gICAgICB9LFxuICAgICAgbXVsdGlwbGVUYWJsZVJlZjogbXVsdGlwbGVUYWJsZVJlZixcbiAgICAgIGRyYXdlcjogZHJhd2VyLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24sXG4gICAgICBtdWx0aXBsZVNlbGVjdGlvbjogbXVsdGlwbGVTZWxlY3Rpb24sXG4gICAgICBzZWxlY3Rpb25EYXRhOiBzZWxlY3Rpb25EYXRhLFxuICAgICAgYWN0aXZlUmVjb3JkOiBhY3RpdmVSZWNvcmQsXG4gICAgICBnZXQgc2VsZWN0aW9uRG9uZUZsYWcoKSB7XG4gICAgICAgIHJldHVybiBzZWxlY3Rpb25Eb25lRmxhZztcbiAgICAgIH0sXG4gICAgICBzZXQgc2VsZWN0aW9uRG9uZUZsYWcodikge1xuICAgICAgICBzZWxlY3Rpb25Eb25lRmxhZyA9IHY7XG4gICAgICB9LFxuICAgICAgdG9nZ2xlU2VsZWN0aW9uOiB0b2dnbGVTZWxlY3Rpb24sXG4gICAgICBoYW5kbGVTZWxlY3Rpb25DaGFuZ2U6IGhhbmRsZVNlbGVjdGlvbkNoYW5nZSxcbiAgICAgIHRhYmxlRGF0YTogdGFibGVEYXRhLFxuICAgICAgZ2V0VHlwZTogZ2V0VHlwZSxcbiAgICAgIGdldFJpc2tUeXBlOiBnZXRSaXNrVHlwZSxcbiAgICAgIHJlcUxpc3Q6IHJlcUxpc3QsXG4gICAgICBvcGVuUmlza0luZm86IG9wZW5SaXNrSW5mbyxcbiAgICAgIHNlbGVjdGlvbkhhbmRsZXI6IHNlbGVjdGlvbkhhbmRsZXIsXG4gICAgICBkb3duTG9hZDogZG93bkxvYWQsXG4gICAgICBjbG9zZURyYXdlcjogY2xvc2VEcmF3ZXIsXG4gICAgICBnZXRyaXNrUG9zdGlvbjogZ2V0cmlza1Bvc3Rpb24sXG4gICAgICBnZXRJbmZvVHlwZTogZ2V0SW5mb1R5cGUsXG4gICAgICBnZXRMZXZlbDogZ2V0TGV2ZWwsXG4gICAgICBnZXRJbmZvU3RhdHVzOiBnZXRJbmZvU3RhdHVzLFxuICAgICAgZ2V0U2l6ZTogZ2V0U2l6ZSxcbiAgICAgIG9wZW5GbG93OiBvcGVuRmxvdyxcbiAgICAgIGdldCBlbnZuYW1lKCkge1xuICAgICAgICByZXR1cm4gZW52bmFtZTtcbiAgICAgIH0sXG4gICAgICBnZXQgVmlldygpIHtcbiAgICAgICAgcmV0dXJuIFZpZXc7XG4gICAgICB9LFxuICAgICAgZ2V0IFNldFVwKCkge1xuICAgICAgICByZXR1cm4gU2V0VXA7XG4gICAgICB9LFxuICAgICAgZ2V0IHJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0O1xuICAgICAgfSxcbiAgICAgIGdldCB3b3JkTGlzdCgpIHtcbiAgICAgICAgcmV0dXJuIHdvcmRMaXN0O1xuICAgICAgfSxcbiAgICAgIGdldCByaXNrV29yZGxpc3QoKSB7XG4gICAgICAgIHJldHVybiByaXNrV29yZGxpc3Q7XG4gICAgICB9XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoX19yZXR1cm5lZF9fLCAnX19pc1NjcmlwdFNldHVwJywge1xuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB2YWx1ZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBfX3JldHVybmVkX187XG4gIH1cbn07IiwiPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJtb2RlQm94XCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2VhcmNoQm94XCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJzZWFyY2hMYWJlbFwiPui1hOS6p+WQjeensDwvc3BhblxyXG4gICAgICAgID48ZWwtaW5wdXRcclxuICAgICAgICAgIEBjaGFuZ2U9XCJyZXFMaXN0XCJcclxuICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgY2xhc3M9XCJzZXJhY2hGb3JtSXRlbVwiXHJcbiAgICAgICAgICB2LW1vZGVsPVwicXVlcnkubmFtZVwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpei1hOS6p+WQjeensFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJzZWFyY2hMYWJlbFwiPui1hOS6p+e8luWPtzwvc3BhblxyXG4gICAgICAgID48ZWwtaW5wdXRcclxuICAgICAgICAgIEBjaGFuZ2U9XCJyZXFMaXN0XCJcclxuICAgICAgICAgIGNsZWFyYWJsZVxyXG4gICAgICAgICAgY2xhc3M9XCJzZXJhY2hGb3JtSXRlbVwiXHJcbiAgICAgICAgICB2LW1vZGVsPVwicXVlcnkudXVpZFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpei1hOS6p+e8luWPt1wiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2hJdGVtXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJzZWFyY2hMYWJlbFwiPumjjumZqeetiee6pzwvc3Bhbj5cclxuICAgICAgICA8ZWwtc2VsZWN0XHJcbiAgICAgICAgICBjbGVhcmFibGVcclxuICAgICAgICAgIHYtbW9kZWw9XCJxdWVyeS5yaXNrTGV2ZWxcIlxyXG4gICAgICAgICAgY2xhc3M9XCJzZXJhY2hGb3JtSXRlbVwiXHJcbiAgICAgICAgICBAY2hhbmdlPVwicmVxTGlzdFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGVsLW9wdGlvblxyXG4gICAgICAgICAgICB2LWZvcj1cIml0ZW0gaW4gcmlza1dvcmRsaXN0LnJpc2tMZXZlbE9wdGlvbnNcIlxyXG4gICAgICAgICAgICA6a2V5PVwiaXRlbS52YWx1ZVwiXHJcbiAgICAgICAgICAgIDpsYWJlbD1cIml0ZW0ubGFiZWxcIlxyXG4gICAgICAgICAgICA6dmFsdWU9XCJpdGVtLnZhbHVlXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9lbC1zZWxlY3Q+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoSXRlbVwiPlxyXG4gICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiBAY2xpY2s9XCJyZXFMaXN0XCI+5p+l6K+iPC9lbC1idXR0b24+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIEBjbGljaz1cImRvd25Mb2FkXCIgdi1zaG93PVwic2VsZWN0aW9uRG9uZUZsYWdcIlxyXG4gICAgICAgICAgPuS4i+i9vTwvZWwtYnV0dG9uXHJcbiAgICAgICAgPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cInRhYmxlQm94XCI+XHJcbiAgICAgIDxlbC10YWJsZVxyXG4gICAgICAgIEBzZWxlY3Q9XCJzZWxlY3Rpb25IYW5kbGVyXCJcclxuICAgICAgICByZWY9XCJtdWx0aXBsZVRhYmxlUmVmXCJcclxuICAgICAgICA6ZGF0YT1cInRhYmxlRGF0YVwiXHJcbiAgICAgICAgc3R5bGU9XCJ3aWR0aDogMTAwJVwiXHJcbiAgICAgICAgbWF4LWhlaWdodD1cIjYwMFwiXHJcbiAgICAgICAgOmNlbGwtc3R5bGU9XCJ7IHBhZGluZzogJzE1cHggMCcgfVwiXHJcbiAgICAgICAgc3RyaXBlXHJcbiAgICAgICAgOmJvcmRlcj1cInRydWVcIlxyXG4gICAgICAgIEBzZWxlY3Rpb24tY2hhbmdlPVwiaGFuZGxlU2VsZWN0aW9uQ2hhbmdlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gdHlwZT1cInNlbGVjdGlvblwiIHdpZHRoPVwiNTVcIiAvPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLliKvlkI1cIiB3aWR0aD1cIjI0MFwiPlxyXG4gICAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwic2NvcGVcIj57eyBzY29wZS5yb3cucmlza0FsaWFzIH19PC90ZW1wbGF0ZT5cclxuICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgICA8ZWwtdGFibGUtY29sdW1uIGxhYmVsPVwi6LWE5Lqn57G75YirXCIgd2lkdGg9XCIxODBcIj5cclxuICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+e3sgZ2V0VHlwZShzY29wZS5yb3cubW9kZSkgfX08L3RlbXBsYXRlPlxyXG4gICAgICAgIDwvZWwtdGFibGUtY29sdW1uPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLlvZPliY3nirbmgIFcIiB3aWR0aD1cIjE4MFwiPlxyXG4gICAgICAgICAgPHRlbXBsYXRlICNkZWZhdWx0PVwic2NvcGVcIj57e1xyXG4gICAgICAgICAgICBnZXRSaXNrVHlwZShzY29wZS5yb3cuc3RhdHVzKVxyXG4gICAgICAgICAgfX08L3RlbXBsYXRlPlxyXG4gICAgICAgIDwvZWwtdGFibGUtY29sdW1uPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW5cclxuICAgICAgICAgIHByb3BlcnR5PVwicHJvcGVydHlDbk5hbWVcIlxyXG4gICAgICAgICAgbGFiZWw9XCLmiYDlsZ7otYTkuqflkI3np7BcIlxyXG4gICAgICAgICAgd2lkdGg9XCIyNDBcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wZXJ0eT1cInV1aWRcIiBsYWJlbD1cIumjjumZqee8lueggVwiIHdpZHRoPVwiNDAwXCIgLz5cclxuICAgICAgICA8ZWwtdGFibGUtY29sdW1uIHByb3BlcnR5PVwidGltZVwiIGxhYmVsPVwi5pu05pS55pel5pyfXCIgd2lkdGg9XCIyNDBcIiAvPlxyXG4gICAgICAgIDxlbC10YWJsZS1jb2x1bW4gbGFiZWw9XCLmk43kvZxcIiBmaXhlZD1cInJpZ2h0XCIgd2lkdGg9XCIxODBcIj5cclxuICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiBsaW5rIEBjbGljaz1cIm9wZW5SaXNrSW5mbyhzY29wZS5yb3cpXCJcclxuICAgICAgICAgICAgICA+5p+l55yLPC9lbC1idXR0b25cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgbGluayBAY2xpY2s9XCJvcGVuRmxvdyhzY29wZS5yb3cpXCJcclxuICAgICAgICAgICAgICA+5rWB56iL5qih5Z6LPC9lbC1idXR0b25cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICA8L2VsLXRhYmxlLWNvbHVtbj5cclxuICAgICAgPC9lbC10YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdiBjbGFzcz1cInBhZ2luYXRpb25Cb3hcIj5cclxuICAgICAgPGVsLXBhZ2luYXRpb25cclxuICAgICAgICBzbWFsbFxyXG4gICAgICAgIGJhY2tncm91bmRcclxuICAgICAgICBsYXlvdXQ9XCJwcmV2LCBwYWdlciwgbmV4dCwganVtcGVyLCAtPiwgdG90YWxcIlxyXG4gICAgICAgIDp0b3RhbD1cInRvdGFsXCJcclxuICAgICAgICBjbGFzcz1cIm10LTRcIlxyXG4gICAgICAgIHYtbW9kZWw6cGFnZS1zaXplPVwicGFnZVNpemVcIlxyXG4gICAgICAgIHYtbW9kZWw6Y3VycmVudC1wYWdlPVwiY3VycmVudFBhZ2VcIlxyXG4gICAgICAgIEBzaXplLWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBjdXJyZW50LWNoYW5nZT1cInJlcUxpc3RcIlxyXG4gICAgICAgIEBwcmV2LWNsaWNrPVwicmVxTGlzdFwiXHJcbiAgICAgICAgQG5leHQtY2xpY2s9XCJyZXFMaXN0XCJcclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG4gIDxlbC1kcmF3ZXIgdi1tb2RlbD1cImRyYXdlclwiIDpkaXJlY3Rpb249XCJkaXJlY3Rpb25cIiBzaXplPVwiNzUlXCI+XHJcbiAgICA8dGVtcGxhdGUgI2hlYWRlcj5cclxuICAgICAgPGgzPumjjumZqei1hOS6p+ivpuaDhTwvaDM+XHJcbiAgICA8L3RlbXBsYXRlPlxyXG4gICAgPHRlbXBsYXRlICNkZWZhdWx0PlxyXG4gICAgICA8aDQ+5Z+656GA5L+h5oGvPC9oND5cclxuICAgICAgPGRpdiBjbGFzcz1cInJvd0JveFwiPlxyXG4gICAgICAgIDxlbC1yb3c+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMlwiPlxyXG4gICAgICAgICAgICA8aDU+6aOO6Zmp5Yir5ZCNOjwvaDU+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIxMFwiPnt7IGFjdGl2ZVJlY29yZC5yaXNrQWxpYXMgfX08L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIyXCI+XHJcbiAgICAgICAgICAgIDxoNT7po47pmannvJblj7c6PC9oNT5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEwXCI+e3sgYWN0aXZlUmVjb3JkLnV1aWQgfX08L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIyXCI+XHJcbiAgICAgICAgICAgIDxoNT7otYTkuqflkI3np7A6PC9oNT5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEwXCI+e3sgYWN0aXZlUmVjb3JkLnByb3BlcnR5TmFtZSB9fTwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjJcIj5cclxuICAgICAgICAgICAgPGg1PumjjumZqeWumuS9jTo8L2g1PlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTBcIj5cclxuICAgICAgICAgICAgPGVsLXRhZyB0eXBlPVwic3VjY2Vzc1wiIGVmZmVjdD1cInBsYWluXCI+e3tcclxuICAgICAgICAgICAgICBnZXRyaXNrUG9zdGlvbihhY3RpdmVSZWNvcmQucmlza1Bvc2l0aW9uKVxyXG4gICAgICAgICAgICB9fTwvZWwtdGFnPlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMlwiPlxyXG4gICAgICAgICAgICA8aDU+6LWE5Lqn57G75Z6LOjwvaDU+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIxMFwiPnt7IGdldEluZm9UeXBlKGFjdGl2ZVJlY29yZC5tb2RlKSB9fTwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjJcIj5cclxuICAgICAgICAgICAgPGg1Pui1hOS6p+e8luWPtzo8L2g1PlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTBcIj57eyBhY3RpdmVSZWNvcmQucHJvcGVydHlJZCB9fTwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjJcIj5cclxuICAgICAgICAgICAgPGg1PumjjumZqeetiee6pzo8L2g1PlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTBcIj5cclxuICAgICAgICAgICAgPGVsLXRhZyBlZmZlY3Q9XCJwbGFpblwiPnt7XHJcbiAgICAgICAgICAgICAgZ2V0TGV2ZWwoYWN0aXZlUmVjb3JkLnJpc2tMZXZlbClcclxuICAgICAgICAgICAgfX08L2VsLXRhZz5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjJcIj5cclxuICAgICAgICAgICAgPGg1Pui1hOS6p+eKtuaAgTo8L2g1PlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMTBcIj5cclxuICAgICAgICAgICAgPGVsLXRhZyB0eXBlPVwid2FybmluZ1wiIGVmZmVjdD1cInBsYWluXCI+e3tcclxuICAgICAgICAgICAgICBnZXRJbmZvU3RhdHVzKGFjdGl2ZVJlY29yZC5zdGF0dXMpXHJcbiAgICAgICAgICAgIH19PC9lbC10YWc+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIyXCI+XHJcbiAgICAgICAgICAgIDxoNT7nm5HmjqfnspLluqY6PC9oNT5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEwXCI+XHJcbiAgICAgICAgICAgIDxlbC10YWcgZWZmZWN0PVwicGxhaW5cIj57e1xyXG4gICAgICAgICAgICAgIGdldFNpemUoYWN0aXZlUmVjb3JkLmNvbnRyb2xTaXplKVxyXG4gICAgICAgICAgICB9fTwvZWwtdGFnPlxyXG4gICAgICAgICAgPC9lbC1jb2w+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMlwiPlxyXG4gICAgICAgICAgICA8aDU+55uR5o6n5pe26Ze0OjwvaDU+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIxMFwiXHJcbiAgICAgICAgICAgID57eyBhY3RpdmVSZWNvcmQudGltZXNbMF0gfX0gJm5ic3A7Jm5ic3A76IezJm5ic3A7Jm5ic3A7XHJcbiAgICAgICAgICAgIHt7IGFjdGl2ZVJlY29yZC50aW1lc1sxXSB9fTwvZWwtY29sXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICA8ZWwtY29sIDpzcGFuPVwiMlwiPlxyXG4gICAgICAgICAgICA8aDU+5a6h5qC45Lq65ZGYOjwvaDU+XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIxMFwiPlxyXG4gICAgICAgICAgICB7eyBhY3RpdmVSZWNvcmQuYXVkaXRVc2VyIH19XHJcbiAgICAgICAgICA8L2VsLWNvbD5cclxuICAgICAgICAgIDxlbC1jb2wgOnNwYW49XCIyXCI+XHJcbiAgICAgICAgICAgIDxoNT7pgJrnn6XmlrnlvI86PC9oNT5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgICAgPGVsLWNvbCA6c3Bhbj1cIjEwXCI+XHJcbiAgICAgICAgICAgIDxlbC10YWdcclxuICAgICAgICAgICAgICBlZmZlY3Q9XCJwbGFpblwiXHJcbiAgICAgICAgICAgICAgdi1mb3I9XCIobSwgbikgaW4gYWN0aXZlUmVjb3JkLmluZm9ybVwiXHJcbiAgICAgICAgICAgICAgOmtleT1cIm5cIlxyXG4gICAgICAgICAgICAgIHN0eWxlPVwibWFyZ2luLXJpZ2h0OiAxMHB4XCJcclxuICAgICAgICAgICAgICA+e3sgbSB9fTwvZWwtdGFnXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgIDwvZWwtY29sPlxyXG4gICAgICAgIDwvZWwtcm93PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGg0PuWkhOeQhui/m+eoizwvaDQ+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJyb3dCb3hcIj5cclxuICAgICAgICA8ZWwtc3RlcHMgOmFjdGl2ZT1cImFjdGl2ZVJlY29yZC5wcm9ncmVzc1wiIGFsaWduLWNlbnRlcj5cclxuICAgICAgICAgIDxlbC1zdGVwIHRpdGxlPVwi6aOO6Zmp5o+Q5LqkXCIgLz5cclxuICAgICAgICAgIDxlbC1zdGVwIHRpdGxlPVwi5a6h5om56YCa6L+HXCIgLz5cclxuICAgICAgICAgIDxlbC1zdGVwIHRpdGxlPVwi57y66Zm35pS56YCgXCIgLz5cclxuICAgICAgICAgIDxlbC1zdGVwIHRpdGxlPVwi5qOA5p+l5qC45a6aXCIgLz5cclxuICAgICAgICAgIDxlbC1zdGVwIHRpdGxlPVwi5rOo6ZSA5o+Q5LqkXCIgLz5cclxuICAgICAgICA8L2VsLXN0ZXBzPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGg0PuaTjeS9nOiusOW9lTwvaDQ+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJyb3dCb3hcIj5cclxuICAgICAgICA8ZWwtdGFibGVcclxuICAgICAgICAgIDpkYXRhPVwiYWN0aXZlUmVjb3JkLnJlY29yZExpc3RcIlxyXG4gICAgICAgICAgc3R5bGU9XCJ3aWR0aDogMTAwJVwiXHJcbiAgICAgICAgICA6Ym9yZGVyPVwidHJ1ZVwiXHJcbiAgICAgICAgICA6c3RyaXBlPVwidHJ1ZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wPVwibmFtZVwiIGxhYmVsPVwi5pON5L2c5ZCN56ewXCIgd2lkdGg9XCIyODBcIiAvPlxyXG4gICAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBsYWJlbD1cIuaTjeS9nOS6uuWRmFwiIHdpZHRoPVwiMjgwXCI+XHJcbiAgICAgICAgICAgIDx0ZW1wbGF0ZSAjZGVmYXVsdD1cInNjb3BlXCI+XHJcbiAgICAgICAgICAgICAge3sgc2NvcGUucm93LnVzZXIudXNlck5hbWUgfX1cclxuICAgICAgICAgICAgPC90ZW1wbGF0ZT5cclxuICAgICAgICAgIDwvZWwtdGFibGUtY29sdW1uPlxyXG4gICAgICAgICAgPGVsLXRhYmxlLWNvbHVtbiBwcm9wPVwidGltZVwiIGxhYmVsPVwi5pON5L2c5pe26Ze0XCIgd2lkdGg9XCJ3aWR0aFwiIC8+XHJcbiAgICAgICAgPC9lbC10YWJsZT5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXY+PC9kaXY+XHJcbiAgICA8L3RlbXBsYXRlPlxyXG4gICAgPHRlbXBsYXRlICNmb290ZXI+XHJcbiAgICAgIDxkaXYgc3R5bGU9XCJmbGV4OiBhdXRvXCI+XHJcbiAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJjbG9zZURyYXdlclwiPui/lOWbnjwvZWwtYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvdGVtcGxhdGU+XHJcbiAgPC9lbC1kcmF3ZXI+XHJcbjwvdGVtcGxhdGU+XHJcbiAgXHJcbjxzY3JpcHQgc2V0dXA+XHJcbmltcG9ydCB7IGVudm5hbWUgfSBmcm9tIFwiQC9qYXZhc2NyaXB0L2Vudm5hbWVcIjtcclxuaW1wb3J0IHsgVmlldywgU2V0VXAgfSBmcm9tIFwiQGVsZW1lbnQtcGx1cy9pY29ucy12dWVcIjtcclxuaW1wb3J0IHJlcXVlc3QgZnJvbSBcIkAvdXRpbHMvcmVxdWVzdFV0aWxzXCI7XHJcbmltcG9ydCB3b3JkTGlzdCBmcm9tIFwiQC9kaWN0aW9uYXJpZXMvd29yZExpc3QuanNvblwiO1xyXG5pbXBvcnQgcmlza1dvcmRsaXN0IGZyb20gXCJAL2RpY3Rpb25hcmllcy9yaXNrLmpzb25cIjtcclxuY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbmNvbnN0IHJvdXRlID0gdXNlUm91dGUoKTtcclxuY29uc3QgcXVlcnkgPSByZWYoe1xyXG4gIG5hbWU6IFwiXCIsXHJcbiAgdXVpZDogXCJcIixcclxuICByaXNrTGV2ZWw6IFwiXCIsXHJcbn0pO1xyXG5sZXQgcGFnZVNpemUgPSAxMDtcclxubGV0IGN1cnJlbnRQYWdlID0gcmVmKDEpO1xyXG5sZXQgdG90YWwgPSByZWYoMCk7XHJcbmNvbnN0IG11bHRpcGxlVGFibGVSZWYgPSByZWYobnVsbCk7XHJcbmNvbnN0IGRyYXdlciA9IHJlZihmYWxzZSk7XHJcbmNvbnN0IGRpcmVjdGlvbiA9IHJlZihcInJ0bFwiKTtcclxuY29uc3QgbXVsdGlwbGVTZWxlY3Rpb24gPSByZWYoW10pO1xyXG5jb25zdCBzZWxlY3Rpb25EYXRhID0gcmVmKFtdKTtcclxuY29uc3QgYWN0aXZlUmVjb3JkID0gcmVmKHt9KTtcclxubGV0IHNlbGVjdGlvbkRvbmVGbGFnID0gcmVmKGZhbHNlKTtcclxuY29uc3QgdG9nZ2xlU2VsZWN0aW9uID0gKHJvd3MpID0+IHtcclxuICBpZiAocm93cykge1xyXG4gICAgcm93cy5mb3JFYWNoKChyb3cpID0+IHtcclxuICAgICAgLy8gVE9ETzogaW1wcm92ZW1lbnQgdHlwaW5nIHdoZW4gcmVmYWN0b3IgdGFibGVcclxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxyXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXHJcbiAgICAgIG11bHRpcGxlVGFibGVSZWYudmFsdWUudG9nZ2xlUm93U2VsZWN0aW9uKHJvdywgdW5kZWZpbmVkKTtcclxuICAgIH0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBtdWx0aXBsZVRhYmxlUmVmLnZhbHVlLmNsZWFyU2VsZWN0aW9uKCk7XHJcbiAgfVxyXG59O1xyXG5jb25zdCBoYW5kbGVTZWxlY3Rpb25DaGFuZ2UgPSAodmFsKSA9PiB7XHJcbiAgbXVsdGlwbGVTZWxlY3Rpb24udmFsdWUgPSB2YWw7XHJcbn07XHJcblxyXG5jb25zdCB0YWJsZURhdGEgPSByZWYoW10pO1xyXG5jb25zdCBnZXRUeXBlID0gKHZhbHVlKSA9PiB7XHJcbiAgcmV0dXJuIHdvcmRMaXN0LnR5cGVMaXN0W3ZhbHVlXTtcclxufTtcclxuY29uc3QgZ2V0Umlza1R5cGUgPSAodmFsdWUpID0+IHtcclxuICByZXR1cm4gcmlza1dvcmRsaXN0W1wic3RhdHVzXCJdW3ZhbHVlXTtcclxufTtcclxuY29uc3QgcmVxTGlzdCA9ICgpID0+IHtcclxuICBsZXQgcG9zdERhdGEgPSB7XHJcbiAgICBxdWVyeURhdGE6IHF1ZXJ5LnZhbHVlLFxyXG4gICAgcGFnZVNpemU6IHBhZ2VTaXplLFxyXG4gICAgY3VycmVudFBhZ2U6IGN1cnJlbnRQYWdlLnZhbHVlLFxyXG4gIH07XHJcbiAgcmVxdWVzdC5wb3N0KGAke2Vudm5hbWUuYXBpVXJsfS9hcHAvcmlzay9saXN0YCwgcG9zdERhdGEpLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgaWYgKHJlcy5jb2RlID09PSAyMDApIHtcclxuICAgICAgdGFibGVEYXRhLnZhbHVlID0gcmVzLmRhdGEubGlzdDtcclxuICAgICAgdG90YWwudmFsdWUgPSByZXMuZGF0YS50b3RhbDtcclxuICAgIH1cclxuICB9KTtcclxufTtcclxuY29uc3Qgb3BlblJpc2tJbmZvID0gKHJvdykgPT4ge1xyXG4gIGFjdGl2ZVJlY29yZC52YWx1ZSA9IHJvdztcclxuICBkcmF3ZXIudmFsdWUgPSB0cnVlO1xyXG59O1xyXG5jb25zdCBzZWxlY3Rpb25IYW5kbGVyID0gKHNlbGVjdGlvbiwgcm93KSA9PiB7XHJcbiAgc2VsZWN0aW9uRGF0YS52YWx1ZSA9IHNlbGVjdGlvbjtcclxuICBpZiAoc2VsZWN0aW9uRGF0YS52YWx1ZS5sZW5ndGggPCAxKSB7XHJcbiAgICBzZWxlY3Rpb25Eb25lRmxhZy52YWx1ZSA9IGZhbHNlO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBzZWxlY3Rpb25Eb25lRmxhZy52YWx1ZSA9IHRydWU7XHJcbiAgfVxyXG59O1xyXG5jb25zdCBkb3duTG9hZCA9ICgpID0+IHtcclxuICBjb25zb2xlLmxvZyhzZWxlY3Rpb25EYXRhLnZhbHVlLCBcIumAieS4reeahOaVsOaNrlwiKTtcclxuICBsZXQgY29udGVudCA9IEpTT04uc3RyaW5naWZ5KHNlbGVjdGlvbkRhdGEudmFsdWUpO1xyXG4gIGxldCBibG9iX2ZpbGUgPSBuZXcgQmxvYihbY29udGVudF0sIHtcclxuICAgIHR5cGU6IFwiYXBwbGljYXRpb24vanNvbjtjaGFyc2V0PXV0Zi04XCIsXHJcbiAgfSk7XHJcbiAgbGV0IGRvd25Mb2FkRWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gIGxldCBocmVmID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iX2ZpbGUpO1xyXG4gIGRvd25Mb2FkRWxlbWVudC5ocmVmID0gaHJlZjtcclxuICBkb3duTG9hZEVsZW1lbnQuZG93bmxvYWQgPSBcIumjjumZqei1hOS6py5qc29uXCI7XHJcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkb3duTG9hZEVsZW1lbnQpO1xyXG4gIGRvd25Mb2FkRWxlbWVudC5jbGljaygpO1xyXG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZG93bkxvYWRFbGVtZW50KTtcclxuICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTChocmVmKTtcclxufTtcclxuY29uc3QgY2xvc2VEcmF3ZXIgPSAoKSA9PiB7XHJcbiAgZHJhd2VyLnZhbHVlID0gZmFsc2U7XHJcbn07XHJcbmNvbnN0IGdldHJpc2tQb3N0aW9uID0gKGluZm8pID0+IHtcclxuICByZXR1cm4gcmlza1dvcmRsaXN0LnJpc2tQb3NpdGlvbkxpc3QuZmluZCgoaXRlbSkgPT4gaXRlbS52YWx1ZSA9PT0gaW5mbylcclxuICAgIC5sYWJlbDtcclxufTtcclxuY29uc3QgZ2V0SW5mb1R5cGUgPSAoaW5mbykgPT4ge1xyXG4gIHJldHVybiB3b3JkTGlzdFtcInR5cGVMaXN0XCJdW2luZm9dO1xyXG59O1xyXG5jb25zdCBnZXRMZXZlbCA9IChpbmZvKSA9PiB7XHJcbiAgcmV0dXJuIHJpc2tXb3JkbGlzdC5yaXNrTGV2ZWxPcHRpb25zLmZpbmQoKGl0ZW0pID0+IGl0ZW0udmFsdWUgPT09IGluZm8pXHJcbiAgICAubGFiZWw7XHJcbn07XHJcbmNvbnN0IGdldEluZm9TdGF0dXMgPSAoaW5mbykgPT4ge1xyXG4gIHJldHVybiByaXNrV29yZGxpc3Quc3RhdHVzW2luZm9dO1xyXG59O1xyXG5jb25zdCBnZXRTaXplID0gKGluZm8pID0+IHtcclxuICByZXR1cm4gcmlza1dvcmRsaXN0LmNvbnRyb2xTaXplTGlzdC5maW5kKChpdGVtKSA9PiBpdGVtLnZhbHVlID09PSBpbmZvKS5sYWJlbDtcclxufTtcclxuY29uc3Qgb3BlbkZsb3cgPSAoaW5mbykgPT4ge1xyXG4gIHJvdXRlci5wdXNoKHsgcGF0aDogXCIvZGFzaGJvYXJkL3Jpc2svcmlza01vZGVsXCIsIHF1ZXJ5OiB7IGlkOiBpbmZvLnV1aWQgfSB9KTtcclxufTtcclxub25Nb3VudGVkKCgpID0+IHtcclxuICByZXFMaXN0KCk7XHJcbn0pO1xyXG48L3NjcmlwdD5cclxuPHN0eWxlIGxhbmc9XCJsZXNzXCIgc2NvcGVkPlxyXG4ubW9kZUJveCB7XHJcbiAgcGFkZGluZzogMTJweDtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuICAuc2VhcmNoQm94IHtcclxuICAgIC8vIGJhY2tncm91bmQ6IHJlZDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgIC5zZWFyY2hJdGVtIHtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xyXG5cclxuICAgICAgLnNlcmFjaEZvcm1JdGVtIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB3aWR0aDogMjAwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC50YWJsZUJveCB7XHJcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2VlZTtcclxuICAgIG1hcmdpbjogMjBweCAwO1xyXG4gIH1cclxuXHJcbiAgLnBhZ2luYXRpb25Cb3gge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgfVxyXG59XHJcblxyXG5oNCB7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuLnJvd0JveCB7XHJcbiAgLmVsLWNvbCB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG5cclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG48L3N0eWxlPlxyXG4gICIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiO1xuICAgICAgaW1wb3J0IGRvbUFQSSBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3NldEF0dHJpYnV0ZXNXaXRob3V0QXR0cmlidXRlcy5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydFN0eWxlRWxlbWVudCBmcm9tIFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL3Jpc2tMaXN0LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ4MjEwZGFjJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9sZXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD00ODIxMGRhYyZsYW5nPWxlc3Mmc2NvcGVkPXRydWVcIjtcbiAgICAgICBleHBvcnQgZGVmYXVsdCBjb250ZW50ICYmIGNvbnRlbnQubG9jYWxzID8gY29udGVudC5sb2NhbHMgOiB1bmRlZmluZWQ7XG4iLCJpbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDgyMTBkYWMmc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5leHBvcnQgKiBmcm9tIFwiLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vcmlza0xpc3QudnVlP3Z1ZSZ0eXBlPXN0eWxlJmluZGV4PTAmaWQ9NDgyMTBkYWMmbGFuZz1sZXNzJnNjb3BlZD10cnVlXCJcblxuaW1wb3J0IGV4cG9ydENvbXBvbmVudCBmcm9tIFwiRDpcXFxc6aG555uuXFxcXHdlYnBhY2stdnVlXFxcXHdlYnBhY2stLS0tdnVlXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtbG9hZGVyXFxcXGRpc3RcXFxcZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtNDgyMTBkYWNcIl0sWydfX2ZpbGUnLFwic3JjL3BhZ2VzL3Jpc2svY29tcG9uZW50cy9yaXNrTGlzdC52dWVcIl1dKVxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgX19leHBvcnRzX18uX19obXJJZCA9IFwiNDgyMTBkYWNcIlxuICBjb25zdCBhcGkgPSBfX1ZVRV9ITVJfUlVOVElNRV9fXG4gIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgaWYgKCFhcGkuY3JlYXRlUmVjb3JkKCc0ODIxMGRhYycsIF9fZXhwb3J0c19fKSkge1xuICAgIGFwaS5yZWxvYWQoJzQ4MjEwZGFjJywgX19leHBvcnRzX18pXG4gIH1cbiAgXG4gIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDgyMTBkYWMmc2NvcGVkPXRydWVcIiwgKCkgPT4ge1xuICAgIGFwaS5yZXJlbmRlcignNDgyMTBkYWMnLCByZW5kZXIpXG4gIH0pXG5cbn1cblxuXG5leHBvcnQgZGVmYXVsdCBfX2V4cG9ydHNfXyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tIFwiLSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzP3VucGx1Z2luTmFtZT11bnBsdWdpbi1hdXRvLWltcG9ydCEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xMC51c2UhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3Jpc2tMaXN0LnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vcmlza0xpc3QudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzPz9jbG9uZWRSdWxlU2V0LTEwLnVzZSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L3RlbXBsYXRlTG9hZGVyLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzRdIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1sb2FkZXIvZGlzdC9janMuanMhLi9yaXNrTGlzdC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9NDgyMTBkYWMmc2NvcGVkPXRydWVcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/dW5wbHVnaW5OYW1lPXVucGx1Z2luLWF1dG8taW1wb3J0IS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2xlc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuL3Jpc2tMaXN0LnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTQ4MjEwZGFjJmxhbmc9bGVzcyZzY29wZWQ9dHJ1ZVwiIl0sIm5hbWVzIjpbIl9jcmVhdGVFbGVtZW50Vk5vZGUiLCJzdHlsZSIsIl9ob2lzdGVkXzEiLCJfaG9pc3RlZF8yIiwiX2hvaXN0ZWRfMyIsIl9ob2lzdGVkXzQiLCJfY3JlYXRlVk5vZGUiLCJfY29tcG9uZW50X2VsX2lucHV0Iiwib25DaGFuZ2UiLCIkc2V0dXAiLCJyZXFMaXN0IiwiY2xlYXJhYmxlIiwicXVlcnkiLCJuYW1lIiwiJGV2ZW50IiwicGxhY2Vob2xkZXIiLCJfaG9pc3RlZF81IiwiX2hvaXN0ZWRfNiIsInV1aWQiLCJfaG9pc3RlZF83IiwiX2hvaXN0ZWRfOCIsIl9jb21wb25lbnRfZWxfc2VsZWN0Iiwicmlza0xldmVsIiwiX2NyZWF0ZUVsZW1lbnRCbG9jayIsIl9GcmFnbWVudCIsIl9yZW5kZXJMaXN0Iiwicmlza1dvcmRsaXN0Iiwicmlza0xldmVsT3B0aW9ucyIsIml0ZW0iLCJfY3JlYXRlQmxvY2siLCJfY29tcG9uZW50X2VsX29wdGlvbiIsImtleSIsInZhbHVlIiwibGFiZWwiLCJfaG9pc3RlZF85IiwiX2NvbXBvbmVudF9lbF9idXR0b24iLCJ0eXBlIiwib25DbGljayIsImRvd25Mb2FkIiwic2VsZWN0aW9uRG9uZUZsYWciLCJfaG9pc3RlZF8xMCIsIl9jb21wb25lbnRfZWxfdGFibGUiLCJvblNlbGVjdCIsInNlbGVjdGlvbkhhbmRsZXIiLCJyZWYiLCJkYXRhIiwidGFibGVEYXRhIiwicGFkaW5nIiwic3RyaXBlIiwiYm9yZGVyIiwib25TZWxlY3Rpb25DaGFuZ2UiLCJoYW5kbGVTZWxlY3Rpb25DaGFuZ2UiLCJfY29tcG9uZW50X2VsX3RhYmxlX2NvbHVtbiIsIndpZHRoIiwiX3dpdGhDdHgiLCJzY29wZSIsInJvdyIsInJpc2tBbGlhcyIsImdldFR5cGUiLCJtb2RlIiwiZ2V0Umlza1R5cGUiLCJzdGF0dXMiLCJwcm9wZXJ0eSIsImZpeGVkIiwibGluayIsIm9wZW5SaXNrSW5mbyIsIm9wZW5GbG93IiwiX2hvaXN0ZWRfMTEiLCJfY29tcG9uZW50X2VsX3BhZ2luYXRpb24iLCJzbWFsbCIsImJhY2tncm91bmQiLCJsYXlvdXQiLCJ0b3RhbCIsInBhZ2VTaXplIiwiY3VycmVudFBhZ2UiLCJvblNpemVDaGFuZ2UiLCJvbkN1cnJlbnRDaGFuZ2UiLCJvblByZXZDbGljayIsIm9uTmV4dENsaWNrIiwiX2NvbXBvbmVudF9lbF9kcmF3ZXIiLCJkcmF3ZXIiLCJkaXJlY3Rpb24iLCJzaXplIiwiaGVhZGVyIiwiX2hvaXN0ZWRfMTIiLCJfaG9pc3RlZF8xMyIsIl9ob2lzdGVkXzE0IiwiX2NvbXBvbmVudF9lbF9yb3ciLCJfY29tcG9uZW50X2VsX2NvbCIsInNwYW4iLCJfaG9pc3RlZF8xNSIsImFjdGl2ZVJlY29yZCIsIl9ob2lzdGVkXzE2IiwiX2hvaXN0ZWRfMTciLCJwcm9wZXJ0eU5hbWUiLCJfaG9pc3RlZF8xOCIsIl9jb21wb25lbnRfZWxfdGFnIiwiZWZmZWN0IiwiZ2V0cmlza1Bvc3Rpb24iLCJyaXNrUG9zaXRpb24iLCJfaG9pc3RlZF8xOSIsImdldEluZm9UeXBlIiwiX2hvaXN0ZWRfMjAiLCJwcm9wZXJ0eUlkIiwiX2hvaXN0ZWRfMjEiLCJnZXRMZXZlbCIsIl9ob2lzdGVkXzIyIiwiZ2V0SW5mb1N0YXR1cyIsIl9ob2lzdGVkXzIzIiwiZ2V0U2l6ZSIsImNvbnRyb2xTaXplIiwiX2hvaXN0ZWRfMjQiLCJ0aW1lcyIsIl90b0Rpc3BsYXlTdHJpbmciLCJfaG9pc3RlZF8yNSIsImF1ZGl0VXNlciIsIl9ob2lzdGVkXzI2IiwiaW5mb3JtIiwibSIsIm4iLCJfaG9pc3RlZF8yNyIsIl9ob2lzdGVkXzI4IiwiX2NvbXBvbmVudF9lbF9zdGVwcyIsImFjdGl2ZSIsInByb2dyZXNzIiwiX2NvbXBvbmVudF9lbF9zdGVwIiwidGl0bGUiLCJfaG9pc3RlZF8yOSIsIl9ob2lzdGVkXzMwIiwicmVjb3JkTGlzdCIsInByb3AiLCJ1c2VyIiwidXNlck5hbWUiLCJfaG9pc3RlZF8zMSIsImZvb3RlciIsIl9ob2lzdGVkXzMyIiwiY2xvc2VEcmF3ZXIiXSwic291cmNlUm9vdCI6IiJ9